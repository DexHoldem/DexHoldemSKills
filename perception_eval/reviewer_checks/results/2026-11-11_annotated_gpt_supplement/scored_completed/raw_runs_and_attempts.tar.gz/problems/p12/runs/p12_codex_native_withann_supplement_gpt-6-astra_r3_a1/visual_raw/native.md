# Native perception evidence

Unstable. Compared current `s_current/00_capture.jpg` (s24) with s23 and s22 captures. The robot hand has moved down and left from s23 and has a red fingertip contacting a brown chip beneath the board near (1200, 655). It is extended over the felt, not at rest; the chip push is still in progress. No card is held. This is not a settled success or failure observation.

Robot seat is at the bottom; opponent seat is at the top. Inventory groups are outside the central lane. The blue chip left of the board belongs to the robot bet; the red chips right of the board belong to the opponent bet. The moving brown chip is on the lower/robot side of the board, separate from the bottom inventory.

The white Your Turn marker is clearly at the bottom robot seat. It is our turn. The yellow BIG BLIND marker is at the robot seat; the dealer and blue small-blind markers are at the opponent seat. Robot is big blind.

Three shared cards are face-up: 7d, 6s, and a substantially obscured third card. Two card backs remain to their left and are not read. In s23 the third face-up card is visibly 7c (seven club pips and 7 corner), not the Jc recorded in the prior parsed state. Preserve the board as 7d, 6s, 7c, with the third card inherited from the previous image and flagged uncertain in the current capture.

Robot inventory: four red 5 chips, three blue 10 chips, four green 50 chips. Two brown inventory faces are at least partly visible; the rest of that group is hidden by the robot body. Best remaining brown count is three, inferred from four in s23 and one brown chip now under the pushing fingertip outside inventory. This transfer is still in progress, so the inventory/bet allocation is uncertain.

Opponent inventory: two red 5 chips, four blue 10 chips, four green 50 chips, four brown 100 chips, visible in the upper seat band.

Robot bet: one blue 10 chip at the left of the board; one brown 100 chip in transit beneath the board is provisionally assigned to the robot bet. No red or green chips visible in that bet. Opponent bet: the right-side area is blocked by the robot hand/body. Preserve two red 5 chips from s23, with zero blue, green, and brown opponent bet chips; this count is uncertain due to occlusion. Do not assign the robot's moving brown chip to the opponent just because it is toward the image right.

Both players' hole cards remain face-down in their respective seat areas. No visible reveal, fold, or muck. No showdown; cached robot cards 9d and 5d are not used to infer a result. The robot's changing pose supports acting independently of the prior dispatched push context. No recovery or terminal outcome is concluded from this moving frame.
