# Perception report

The s24 capture shows the dispatched 100-chip push in progress: the robot hand is extended over the betting lane and contacts a brown chip. Relative to s23, the hand has not returned to rest, so the scene is unstable and `loop_stage` is `acting`. The white turn button remains at the robot seat. There is no visible showdown.

The board's third card and the opponent bet are partly occluded, so their s23 reads were retained. The robot's brown inventory and new brown bet are best estimates while the chip is under the gripper. The blind comes from the recognized cache. These inherited or occluded fields are listed in `uncertain_fields`.
