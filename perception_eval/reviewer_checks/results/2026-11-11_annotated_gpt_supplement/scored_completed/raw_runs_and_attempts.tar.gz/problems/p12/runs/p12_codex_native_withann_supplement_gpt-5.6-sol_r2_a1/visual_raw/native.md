# Raw Visual Perception

## Current capture

- Source: `s_current/00_capture.jpg`.
- Orientation: robot/player seat is at the bottom; opponent seat is at the top; the shared board runs across the center.
- The dexterous hand is extended from the right over the central/right betting lane. Its fingers are down against a brown 100 chip. The hand is not near its idle pose and is not holding a card.
- Compared with `s23/00_capture.jpg`, the hand has moved materially leftward and the brown 100 chip has left the lower-right robot inventory group and is now under the fingers in the robot betting lane. The dispatched chip push is therefore still in progress. The scene is unstable; there is no visible dropped card, scattered chip group, or moved non-target object.
- Three face-up community cards are present. The first two are directly readable as `7d` and `6s`. The third card is occluded in the current capture by the dexterous hand, but its fixed board position and the immediately preceding stable parse identify it as `Jc`.
- The white `Your Turn` button is clearly at the lower-left robot seat, so it is the robot's turn.
- Robot/player inventory directly visible at lower left/center: four red 5 chips and three blue 10 chips. The lower-right inventory is substantially occluded by the robot. Merging the preceding inventory with the visibly transferred brown chip gives four green 50 chips and three brown 100 chips remaining.
- Robot/player bet lane: one blue 10 chip remains at the left of the board. One brown 100 chip is in the betting lane under the pushing fingers; its placement is transitional because the push has not settled. No red 5 or green 50 bet chips are visible.
- Opponent inventory at the top: two red 5 chips, four blue 10 chips, four green 50 chips, and four brown 100 chips.
- Opponent bet lane: the area is occluded by the extended robot hand. The preceding stable state showed two red 5 chips and no blue, green, or brown chips; no contrary visual change is visible.
- Both opponent hole cards remain face-down in the normal top-seat area. Both robot hole cards remain face-down in the normal bottom-seat area. There is no fold/muck signature and no showdown.
- Blind assignment is durable context from the recognized cache: robot is big blind.

## Uncertainty

- `community_cards` is partially inherited because the third board card is occluded in this frame.
- `my_chips.50` and `my_chips.100` are partly inferred through robot occlusion; the 100 count incorporates the visible chip transfer.
- `my_current_bet.100` is low-confidence/transitional because the chip is still under the moving hand.
- `opponent_bet` is inherited from the preceding stable state because its lane is occluded.

