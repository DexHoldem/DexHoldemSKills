# Raw visual perception

- Compared `s24/00_capture.jpg` with `s23/00_capture.jpg`.
- Scene: unstable. The robot dexterous hand is still extended over the board/betting area after the dispatched 100-chip push; it has not returned to an idle pose. The latest frame is therefore still acting/in-progress.
- Turn: the white `Your Turn` button is visible near the bottom/robot seat, so it is the robot's turn.
- Blinds: the cached session assignment is dealer/small blind at the opponent seat and big blind at the robot seat.
- Community cards: three cards are present, left-to-right `7d`, `6s`, `Jc`; the third card is partly occluded by the robot hardware in the current frame, but is clear in the immediately previous frame.
- Showdown: opponent hole cards remain face-down in the top/opponent area; no fold or showdown is visible. Cached robot hole cards are `9d` and `5d`, but no comparison is needed.
- Inventory chips: best current estimate is robot/bottom inventory 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, 3 brown 100-chips; opponent/top inventory 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips. The robot brown count is affected by the in-progress 100-chip movement.
- Betting areas: robot/lower current bet is estimated as 1 blue 10-chip and 1 brown 100-chip; opponent/upper current bet is 2 red 5-chips. The robot 100-chip placement is not yet settled and is partly obscured by the hand.
