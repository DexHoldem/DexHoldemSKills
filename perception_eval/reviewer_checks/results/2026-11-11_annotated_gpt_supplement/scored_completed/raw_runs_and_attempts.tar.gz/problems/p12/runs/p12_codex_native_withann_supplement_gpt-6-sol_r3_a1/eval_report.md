# Perception report

The current image shows the robot hand still over a brown 100-chip in the robot betting lane. Its position has changed from `s23/00_capture.jpg`, and it has not returned to rest, so the merged state is `acting` with `scene_stable: false`. The white turn button and yellow big-blind button remain at the robot seat. Three board cards remain; there is no showdown.

Visible chip groups determine the counts where clear. The third board card (`Jc`) uses the previous clear image because the hand partly covers it now. The robot's remaining brown inventory is estimated as three after the visible chip movement, with part of the group hidden by the robot housing. The opponent's two red bet chips are inherited from the previous clear image because the arm occludes their area. These fields are recorded in `uncertain_fields`; the prior workflow state was context for the moving hand, not treated as proof that the action completed.
