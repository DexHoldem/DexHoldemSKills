# Perception and merging

Current capture resolves to s24; s23 supplies the previous parsed state and visual comparison, with s22 as additional earlier context. All field-specific guidelines were read. Direct image inspection supports acting, scene_stable=false, robot big blind, robot turn, and not_showdown.

Visual evidence overrides the prior parsed board: the third card is 7c, clearly readable in s23, rather than Jc. Current occlusion makes its retained identity uncertain. Visible inventories were recounted. Opponent bets retain s23's two red chips because the current hand obscures that area.

One brown chip has left the robot inventory and is under the moving fingertip. Robot brown inventory is estimated at three; its partly hidden remainder is uncertain. The chip has not visibly reached the left-side robot bet area, so the provisional robot bet remains one blue chip. The in-transit brown chip is described in raw evidence rather than forced into a settled bet count; the schema has no in-transit field. Both affected chip fields are flagged.

The dispatched action supplies context only: visible hand displacement and contact with the chip establish ongoing execution. No completed push, failure, recovery, showdown, or poker action is inferred from the dispatch. No robot commands or helper scripts were run, and no poker action was chosen.
