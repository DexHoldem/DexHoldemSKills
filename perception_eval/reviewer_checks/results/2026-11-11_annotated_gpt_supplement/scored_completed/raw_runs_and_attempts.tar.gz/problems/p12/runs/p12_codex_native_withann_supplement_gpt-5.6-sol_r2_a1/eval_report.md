# Perception Evaluation

The current image visually overrides the prior workflow state where possible. The robot hand has moved left from `s23/00_capture.jpg` and is actively pushing a brown 100 chip, so the scene is unstable and `loop_stage` remains `acting`. The white turn button is visibly at the robot seat. There is no showdown evidence.

Durable context was merged only for occluded fields: the cached blind assignment supplies `big_blind`; the preceding stable board supplies the hand-hidden third card `Jc`; and the prior stable chip layout supplies the hidden opponent bet and lower-right inventory counts. The visible transfer of one brown chip was applied to the robot inventory and bet estimates. All inherited, inferred, or transitional values are listed in `uncertain_fields`.

