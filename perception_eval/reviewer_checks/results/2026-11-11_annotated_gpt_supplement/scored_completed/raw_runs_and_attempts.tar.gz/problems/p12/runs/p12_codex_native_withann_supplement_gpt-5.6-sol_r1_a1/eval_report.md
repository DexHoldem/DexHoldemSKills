# Perception Evaluation

The current frame is an `acting` state: the robot gripper is still contacting a brown 100 chip in the robot-side betting lane, so the scene is not stable and the dispatched push is not yet visually complete. The white turn marker remains at the robot seat.

Current visual evidence supplies the three-card board, visible inventory groups, the robot's visible 10 bet, and the in-progress 100 transfer. Durable context supplies the robot big-blind assignment. Occluded chip fields were merged conservatively: robot brown inventory is estimated as three after displacement of one 100 chip, and the opponent bet is inherited as two red 5 chips because the current robot pose blocks that area.

The previous parsed board value `Jc` was not inherited because it conflicts with the card image. The third shared card is best read as `7c`; it remains marked uncertain because it is substantially occluded in the current capture. No showdown or fold evidence is present.
