# Perception Evaluation

The current capture is an unstable `acting` frame: the robot hand is extended over the betting lane and visibly contacting the brown 100 chip from the dispatched push. The current image directly supports the first two board cards (`7d`, `6s`), robot turn button, robot big-blind marker, most inventory counts, and the in-progress 100-chip transfer.

Durable blind assignment agrees with the cached recognition. The occluded third board card was merged from the immediately previous clear image as `7c`, overriding the previous parsed text's conflicting `Jc` because visual evidence is authoritative. The opponent bet was likewise inherited as two red 5-chips because the current robot pose blocks that zone. Those merged values, the remaining robot 100-chip count, and the unsettled 100-chip bet placement are explicitly listed in `uncertain_fields`.

No opponent cards are face-up or displaced toward the board, so this is not a fold or showdown and the outcome remains `not_showdown`. No poker action or robot action was selected or executed.
