# Raw visual perception

Input mapping: no literal `s_current/` directory is present. The latest capture, `s24/00_capture.jpg`, was used as the current image and `s23/00_capture.jpg` as the previous image.

- Scene/stability: Unstable. Compared s23 and s24. The dexterous hand/robot arm is extended over the table near the central/right card and chip area, rather than near its settled rest pose. This matches the dispatched `push_chip_100_1` step; the 100-chip push is not visibly settled yet.
- Robot behavior: The hand is in an active push/placement posture and substantially occludes the lower-right table area. No dropped card or scattered chip layout is visibly established in this frame; the action appears still in progress.
- Turn/blinds: The yellow BIG BLIND marker is at the robot/bottom seat. The robot is the big blind. The visible turn marker is at the robot side, and the current workflow context is the robot's turn.
- Community cards: Three face-up board cards are visible from left to right: `7d`, `6s`, `Jc`. No additional community card is visible.
- Showdown: No showdown or win/loss indicator is visible. Face-down hole-card backs remain in the hole-card areas; cached robot hole cards are context only and are not reread from this frame.
- Robot inventory (bottom/robot seat): approximately 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips. The brown group is partly occluded by the robot apparatus/hand, and the 100 count reflects the dispatched chip push.
- Opponent inventory (top/opponent seat): approximately 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Betting areas: The robot-side bet area retains one blue 10-chip and has the dispatched brown 100-chip being pushed/placed; estimate 0 red, 1 blue, 0 green, 1 brown. The opponent-side bet area has 2 red 5-chips and no visible blue, green, or brown chips. Counts involving the moving/occluded robot-side 100-chip are uncertain until a settled capture.

