# Perception and merging

Inspected s24 through the s_current link, all field guidelines, prior s23 parsed state, action-sequence context, and hole-card cache. Compared s23 and s22 images for physical movement and occluded details.

Current visual evidence supports acting and scene_stable=false: the hand has moved and is contacting a brown chip in transit beneath the board. Turn and big-blind markers are directly visible at the robot seat. Hole cards remain face-down with no fold or showdown evidence, giving not_showdown.

Corrected the prior board's Jc to 7c using the clearly exposed s23 image. The current third card is obscured, so community_cards is flagged. Other visible inventory counts are read directly. Robot brown inventory is estimated at three after the visible transfer of one brown chip, provisionally counted in my_current_bet. Both fields are flagged because the transfer is unfinished and the remaining inventory is partly hidden. Opponent bet is inherited as two red chips from s23 and flagged because the current hand occludes it. No action completion is assumed from the dispatched workflow state.

All schema fields have concrete estimates. No robot commands, helper scripts, or poker action selection were performed.
