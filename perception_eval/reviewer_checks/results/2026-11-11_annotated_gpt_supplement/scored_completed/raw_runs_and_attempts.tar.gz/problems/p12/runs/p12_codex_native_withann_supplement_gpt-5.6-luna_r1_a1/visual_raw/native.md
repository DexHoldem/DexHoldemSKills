# Raw visual perception

- Current frame: `s_current/00_capture.jpg`.
- The robot dexterous hand/arm is extended over the right side of the table and is contacting/occluding the betting area after the dispatched `push_chip_100_1` step. The hand is not in a settled idle pose; the scene is therefore treated as unstable and the workflow remains acting.
- The white `Your Turn` button is visible near the bottom/robot seat, indicating that it is the robot's turn.
- Three face-up community-card positions are visible in the central row. Left-to-right, the first is readable as `7d`, the second as `6s`, and the third is partly occluded by the robot hand and is unreadable.
- Opponent and robot hole-card backs remain face-down in their normal areas. No showdown or fold outcome is visible. Cached robot hole cards are `9d` and `5d`, used only as context.
- Robot/player inventory estimate: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 2 brown 100-chips; the 100-chip count is affected by the dispatched push and partly occluded.
- Opponent inventory estimate: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current bet estimate: one brown 100-chip in/at the lower robot-side betting area; its placement is partly occluded by the hand.
- Opponent current bet: no clearly visible bet chips.
- Blind context comes from the cached preflight assignment: robot is the big blind.
