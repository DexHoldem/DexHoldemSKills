# Raw Visual Perception

## Current capture

- Source: `s_current/00_capture.jpg`.
- The robot/player seat is at the bottom and the opponent seat is at the top.
- The dexterous hand is extended from the right over the central betting lane. A red fingertip is contacting a brown 100 chip near the robot-side betting area. The hand is not in an idle/rest pose and the dispatched chip-push atom appears to still be in progress.
- The current frame is therefore unstable. No scattered chips, displaced cards, pinned object, or other clear physical failure is visible.

## Cards and outcome

- Three community-card positions are present. The first two are clearly readable as `7d` and `6s`.
- The third board position is occluded by the robot hand in the current capture. In the immediately previous clear visual frame (`s23/00_capture.jpg`) it is readable as `7c`, so `7c` is retained with uncertainty.
- Both opponent hole cards remain face-down in their normal top-seat area. Both robot hole cards remain face-down in their normal bottom-seat area.
- There is no visual fold/muck signature and no showdown. Outcome: `not_showdown`.

## Buttons

- The white “Your Turn” button is visible at the bottom-left robot seat, so `is_my_turn` is true.
- The yellow “BIG BLIND” button is at the bottom/robot seat. The dealer and small-blind markers are at the opponent seat, so the robot blind is `big_blind`.

## Chip inventories

- Robot/player inventory: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and an estimated 3 brown 100-chips remaining. The brown count reflects the clearly displaced/contacted 100 chip, while the rightmost inventory region is partly occluded by the robot body.
- Opponent inventory: 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.

## Betting areas

- Robot current bet: 0 red 5-chips, 1 blue 10-chip, 0 green 50-chips, and 1 brown 100-chip. The brown chip is under the fingertip in the robot betting lane, so its final settled placement is uncertain while the push is still in progress.
- Opponent bet: estimated 2 red 5-chips and no blue, green, or brown chips. This area is occluded in the current capture; the count is inherited from the immediately previous clear frame.
- Inventory chips and bet chips were kept separate; no generic pot was counted.

## Held-card / robot behavior

- The dexterous hand is not holding a card and no readable held card is visible.
- The hand appears to be pushing the intended 100 chip. The action looks still in progress rather than settled, failed, or ready for recovery classification.
