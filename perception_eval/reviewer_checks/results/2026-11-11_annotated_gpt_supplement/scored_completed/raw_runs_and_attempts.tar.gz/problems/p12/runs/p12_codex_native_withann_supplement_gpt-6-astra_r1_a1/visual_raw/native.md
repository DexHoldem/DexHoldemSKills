# Native visual evidence

Current image: `s_current/00_capture.jpg`, resolving to `s24/00_capture.jpg`. Compared directly with `s23/00_capture.jpg` and `s22/00_capture.jpg`. The literal `sN-1` directory is absent; `s23/01_parsed_state.md` is the previous parsed state.

Unstable. Between s23 and s24 the robot hand advances leftward and down onto a brown chip near (1200, 655). Its fingertip remains in contact with that chip in the central lane below the board. This is an ongoing chip push, not a settled completion. The dispatched push context agrees with the visible motion but does not establish success. No failure or recovery judgment is warranted during this movement. No readable held card is visible.

The white Your Turn button is clearly at the bottom robot seat. It is our turn. The yellow BIG BLIND button is at the robot seat; DEALER and SMALL BLIND are at the opponent seat. Robot is big blind.

Three face-up community cards occupy the right three board slots. Left to right they are 7d, 6s, and 7c. The first two are readable now; the third is substantially occluded by the hand. Its identity is retained from direct inspection of s23, where the corner reads 7 and clubs are visible. The prior parsed Jc is incorrect. Two board-slot card backs to the left are excluded, as are both players' hole cards.

Robot inventory: four red 5 chips, three blue 10 chips, four green 50 chips. Brown 100 inventory is partly hidden by the robot body: two faces are at least partly visible, and three remaining is the best estimate from four in s23 with one now visibly displaced under the fingertip. This is an inferred count, not three fully observed faces.

Opponent inventory: two red 5 chips, four blue 10 chips, four green 50 chips, four brown 100 chips. These are individual flat faces in the upper inventory band.

Robot current bet: one blue 10 chip clearly left of the board; no red or green chips. One brown 100 chip is visible under the fingertip in the lower central lane, outside its previous inventory position. Provisionally assign it to the robot bet using lower-side geometry and comparison with s23. The assignment is uncertain because transfer is unfinished and it has not reached the existing blue-chip location.

Opponent bet: right-side betting region is hidden by the hand/body. Two red 5 chips were visible in s23; retain two red chips, zero blue, green, and brown, with uncertainty. Do not misclassify the moving robot brown chip as an opponent bet merely because it is near the right side of the board.

Both players' hole cards remain face-down in their normal seat areas. No fold/muck or showdown is visible. Cached robot cards 9d and 5d are context only; no showdown comparison is applicable.
