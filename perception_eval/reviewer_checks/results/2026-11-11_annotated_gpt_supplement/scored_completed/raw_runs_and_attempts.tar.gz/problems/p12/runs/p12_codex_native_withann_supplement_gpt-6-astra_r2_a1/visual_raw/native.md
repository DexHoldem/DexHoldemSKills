# Native visual evidence

Inspected s_current/00_capture.jpg (symlink target s24), s23/00_capture.jpg, and s22/00_capture.jpg directly. Read all visual_guidelines files, action_sequence.json, hole_card_cache.json, and s23/01_parsed_state.md. The literal sN-1 directory does not exist; s23 is the preceding capture.

Unstable. Compared s24 with s23 and s22. The dexterous hand has moved substantially inward and downward from s23 and has a red fingertip on a brown chip near (1200, 655), below the right portion of the board. It is still executing the chip push and has not returned to rest. No readable held card is visible. The dispatched push_chip_100_1 is still in progress; completion, failure, and recovery are not established. The human's hands are off the playing surface in the current capture.

The white Your Turn marker is clearly at the bottom robot seat: it is our turn. The yellow BIG BLIND marker is at the robot seat; the white DEALER and blue SMALL BLIND markers are at the opponent seat. Robot is big blind.

Three face-up board cards are present, left to right: 7d, 6s, 7c. Two card backs to their left are excluded. The current hand partly covers the second and especially third face-up cards; s23 clearly shows 7d, 6s, 7c in the same positions. In particular, the third card is a seven of clubs, not the Jc recorded in the prior parsed state. The current third-card identity uses visual continuity with s23 and is flagged as uncertain due to occlusion.

Robot inventory: four red 5 chips, three blue 10 chips, four green 50 chips. Brown inventory is partly hidden by the robot body: two faces are visible, with an estimated three remaining based on the prior image's four and the single brown chip now under the fingertip outside the inventory. This is a provisional in-transit estimate, not proof of a completed bet.

Opponent inventory: two red 5 chips, four blue 10 chips, four green 50 chips, four brown 100 chips, all in the upper inventory band.

Robot current bet area to the left of the board: one blue 10 chip, no red, green, or brown chip visible there. Opponent bet area to the right of the board is hidden by the robot hand/body; estimate two red 5 chips from s23, with zero other denominations. This count is inherited and uncertain. The brown chip under the fingertip is in transit below the right portion of the board, not demonstrably delivered to the robot's left-side betting area. Do not count it as an opponent bet or a completed robot bet. Robot bet allocation is flagged uncertain while the transfer remains underway.

Both players' hole cards remain face-down in their normal seat areas. No fold, muck, or showdown is apparent. Cached robot cards are 9d and 5d, but no hand comparison is called for: not_showdown.
