# Perception and merge report

Read all field guidelines and inspected current s24 plus s23 and s22 images. Used s23 as the previous state because s_current resolves to s24 and no literal sN-1 directory exists.

Current visual motion supports acting and scene_stable=false: the robot is contacting and moving a brown chip and has not returned to rest. Turn and big-blind assignment are directly visible. No showdown or fold is evident.

Corrected the prior parsed third board card from Jc to 7c based on the clear s23 image; current occlusion makes community_cards uncertain. Directly counted visible inventories. Estimated robot brown inventory as three after one chip visibly leaves the previous four-chip group; provisionally counted the moving brown chip in the lower robot betting lane. Both fields are uncertain because the push is unfinished and inventory is occluded. Retained the opponent's two red bet chips from s23 because their current region is hidden, marking opponent_bet uncertain. Other chip counts are supported by current visible faces.

The action sequence was used only to contextualize visible chip movement. No dispatched action was assumed complete. No robot commands, helper scripts, or poker decisions were executed; no source state or cache was modified.
