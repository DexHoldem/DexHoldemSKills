# Raw visual perception

Unstable. Compared `s23/00_capture.jpg` with `s_current/00_capture.jpg`. The robot hand has moved from the right-side chip inventory to the central betting lane and is touching/pushing a brown 100 chip. It is extended over the table, not at rest. The dispatched chip-push atom appears still in progress. No dropped card, scattered chip group, or moved non-target object is evident. The hand blocks part of the robot's brown inventory and the right-side betting lane.

The white `Your Turn` button is at the lower-left robot seat. The yellow `BIG BLIND` button is at the robot seat; the white dealer button is at the opponent seat. Three face-up community cards are visible, left to right: 7d, 6s, Jc. The two additional central card backs are not community cards. Opponent and robot hole cards remain face-down in their usual seat areas, with no fold or showdown visible. No card is held by the robot hand.

Robot inventory at the bottom: four red 5 chips, three blue 10 chips, four green 50 chips, and an estimated three brown 100 chips. The brown group is partly hidden by the robot. Opponent inventory at the top: two red 5 chips, four blue 10 chips, four green 50 chips, and four brown 100 chips.

Robot current bet in the central lane: one blue 10 chip at the lower-left of the board and one brown 100 chip under the robot fingertips at the lower-right of the board. The brown chip is mid-transfer, so its final zone is uncertain. Opponent current bet at the upper-right of the board: estimated two red 5 chips, inherited from the last clear frame because the hand obscures this area in the current image; no other bet chips are apparent.
