# Raw Visual Perception

Current capture: `s_current/00_capture.jpg`.

- Scene/robot: Unstable. Compared with `s23/00_capture.jpg`, the dexterous gripper has moved from a near-idle position to the central robot-side betting lane and is still contacting/pushing a brown 100 chip. The dispatched chip-push atom therefore appears still in progress rather than settled. The robot body and hand occlude much of the right side of the board, the opponent bet area, and part of the robot inventory.
- Turn marker: The white `Your Turn` button is clearly visible at the bottom-left robot seat, so it is the robot's turn.
- Blind marker: The yellow `BIG BLIND` button is at the bottom/robot seat. This agrees with the durable recognized blind assignment: robot is big blind.
- Community cards: Three face-up shared cards are present. From left to right they read `7d`, `6s`, and best estimate `7c`. The third card is substantially occluded in the current capture; its pip-card appearance and the adjacent settled frame support `7c`, contradicting the prior parsed value `Jc`.
- Robot/player inventory: 4 red 5 chips, 3 blue 10 chips, 4 green 50 chips, and best estimate 3 brown 100 chips. The brown count is inferred from the prior four-chip inventory plus the visibly displaced 100 chip and is partly occluded.
- Opponent inventory: 2 red 5 chips, 4 blue 10 chips, 4 green 50 chips, and 4 brown 100 chips. These groups are visible along the top/opponent seat.
- Robot current bet: 1 blue 10 chip remains visible in the robot betting lane. One brown 100 chip is visibly under the gripper in that lane, but placement is not settled because the gripper is still in contact with it. No red 5 or green 50 bet chips are visible.
- Opponent bet: The opponent-side bet area is blocked by the robot hand/body. The durable prior count of 2 red 5 chips is inherited as the concrete best estimate; no blue, green, or brown opponent bet chips are evidenced.
- Showdown: Both players' hole cards remain face-down and the hand is still on a three-card board. No fold/muck or face-up showdown is visible, so this is not showdown.
- Held card: No readable held card is visible.

