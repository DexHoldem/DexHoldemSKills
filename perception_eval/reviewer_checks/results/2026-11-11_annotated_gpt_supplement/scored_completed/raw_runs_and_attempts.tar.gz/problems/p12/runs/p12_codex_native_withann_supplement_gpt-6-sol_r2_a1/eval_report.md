# Perception merge

The current capture shows the robot hand extended over a brown 100 chip in the robot betting lane. Relative to `s23`, that chip has left the bottom inventory, but the hand has not returned to rest. The scene is unstable and the dispatched atom remains `acting`.

The board (7d, 6s, Jc), turn button, and blind buttons are readable in the current image. The robot's brown inventory and opponent's red bet are partly occluded; their counts use the visible transfer and prior clear frame, respectively, and are marked uncertain. The prior workflow state supplied intent only. No fold or showdown evidence is visible.
