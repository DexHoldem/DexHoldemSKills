# Raw visual perception — s24

- Compared `s24/00_capture.jpg` with `s23/00_capture.jpg`. The robot hand has moved from the right side into the central betting lane and is touching a brown 100 chip near the lower edge of the board. It is away from rest; the dispatched chip push appears still in progress. **Unstable.** No card is held. No clear damage or unrelated object movement is visible, but the gripper blocks part of the board, right betting lane, and lower-right inventory.
- The white **Your Turn** button remains at the lower-left robot seat. The robot is the big blind from the cached dealer/blind recognition; the button is not being used to infer the blind.
- Three community cards: `7d`, `6s`, `Jc` left to right. The third is partly covered now; `Jc` is supported by its clear appearance in s23.
- Robot inventory: 4 red 5, 3 blue 10, 4 green 50, approximately 3 brown 100 chips. The brown group is partly hidden by the robot body; the estimate reflects one brown chip being moved from the prior group of four.
- Opponent inventory: 2 red 5, 4 blue 10, 4 green 50, 4 brown 100 chips, visible near the upper seat.
- Robot current bet lane: one blue 10 chip remains left of the board; one brown 100 chip is under the gripper near the lower-right board edge. The brown chip's final placement is uncertain while the push continues.
- Opponent bet lane: two red 5 chips were visible to the right of the board in s23. That area is occluded by the extended robot arm in s24, so the current count is inherited and uncertain. No additional bet chips are evident.
- Opponent hole cards remain face-down at the upper seat. Robot hole cards remain face-down. No fold or showdown is visible.
