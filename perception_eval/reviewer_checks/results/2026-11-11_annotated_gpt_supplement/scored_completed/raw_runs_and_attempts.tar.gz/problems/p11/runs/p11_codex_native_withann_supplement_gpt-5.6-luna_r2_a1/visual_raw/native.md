# Raw visual perception

- Source: `s23/00_capture.jpg` (used as the current capture because no literal `s_current/` directory is present).
- Scene: stable/settled. The robot/camera assembly is at the right side and partially occludes the far-right opponent-side table region; no active card or chip manipulation is visible.
- Turn: the white `Your Turn` button is at the bottom/robot seat, so it is the robot's turn.
- Blind: the cached preflight assignment says the robot is the big blind; no current image evidence conflicts with it.
- Community cards: no face-up shared community cards are visible. The face-down cards in the table lanes are not counted as community cards.
- Robot inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Opponent inventory, top seat: 3 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips. The far-right portion is partly occluded by the robot/camera body; counts agree with the previous settled parse and are inherited with low confidence for that occluded side.
- Robot current-bet area, lower/robot side of the board: 1 blue 10-chip; no red, green, or brown bet chips visible.
- Opponent current-bet area, upper/opponent side of the board: 1 red 5-chip; no blue, green, or brown bet chips visible.
- Showdown: no face-up opponent cards, no face-up robot cards, and no fold/muck signature; this is not showdown.
- Cached hole cards remain `9d` (left) and `5d` (right), but they are not newly read from this image.
