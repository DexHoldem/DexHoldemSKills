# Perception merge

The current and previous captures are byte-identical, so the stable s22 chip and bet estimates carry forward. Visible evidence confirms the robot turn button, one blue robot bet chip, no face-up board cards, and no showdown. The robot arm partly blocks the opponent inventory and bet area and the robot's far-right brown inventory; those estimates are marked uncertain. The prior parsed state and blind cache agree that the robot is big blind. `action_sequence.json` reports idle and no dispatched step, consistent with the settled image.
