# Perception and merge report

Read all field guidelines and inspected the current s23 capture against s22 and s21. The latest two frames show a settled near-idle robot pose and unchanged visible layout, supporting `idle` and `scene_stable: true`. The physical turn marker establishes robot turn. Visible blind/dealer buttons establish robot big blind. There are no face-up community cards or visible showdown/fold evidence, so the board is empty and the outcome is `not_showdown`.

Visible chip faces establish robot inventories of four 5s, three 10s, and four 50s; opponent inventories of three 5s and four 10s; and a robot bet of one 10. The opponent bet shows one red 5 but is partly blocked. Brown inventories are partly hidden; four per player is inherited from s22 because the visible layout is unchanged. Opponent 50 count is estimated at four with fingertip occlusion. The three affected aggregate fields are listed in `uncertain_fields`; hidden chips are not claimed as directly observed.

The prior action sequence was used only as context. Its idle label agrees with the independent image comparison. Cached 9d/5d hole cards were not treated as visible cards and did not require a showdown comparison. No cache or workflow state was changed, no helper script was run, and no robot or poker action was chosen.
