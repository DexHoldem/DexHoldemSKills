# Perception evaluation

The current capture was visually parsed using the field-specific guidelines. The scene is stable and the robot turn marker is present at the bottom seat. No community cards or showdown evidence are visible. Inventory and betting-zone counts match the prior settled parsed state (`s22/01_parsed_state.md`), with the opponent's far-right brown-chip count retained as a best estimate because the robot apparatus partially occludes that region. Cached blind context confirms the robot is the big blind. No poker action was selected or dispatched.

