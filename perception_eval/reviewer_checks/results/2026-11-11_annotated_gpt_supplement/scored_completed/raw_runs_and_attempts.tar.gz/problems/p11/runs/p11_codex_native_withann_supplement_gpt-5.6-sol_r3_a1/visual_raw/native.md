# Raw Visual Perception

- Source: `s_current/00_capture.jpg` (current `s23` capture), compared with `s22/00_capture.jpg` for stability.
- Scene stability: Stable. The current and previous frames show the dexterous hand in the same settled near-idle pose. No card or chip movement, motion blur, or human interference with table objects is visible.
- Robot behavior: The dexterous hand is not holding a card or chip and does not appear stuck. Its near-idle pose and camera body occlude portions of the right-side chip zones.
- Turn marker: The white `Your Turn` button is clearly at the bottom-left robot seat, so it is the robot's turn.
- Blind markers: The yellow `BIG BLIND` button is at the bottom/robot seat. The white dealer button is at the top/opponent seat, consistent with the robot being big blind.
- Community cards: No face-up community cards are visible. The five patterned rectangles in the center are the table's printed board positions, not dealt cards.
- Robot hole cards: Two face-down cards remain in the normal bottom hole-card area. No readable held card is visible.
- Opponent hole cards: Face-down cards remain in the normal top hole-card area; they are not displaced toward the board and are not face-up. There is no fold/muck or showdown evidence.
- Robot inventory (bottom seat): 4 red 5-chips and 3 blue 10-chips are directly countable. Best estimate is 4 green 50-chips and 4 brown 100-chips; parts of these right-side groups are occluded, so those two denomination counts inherit the prior durable counts.
- Opponent inventory (top seat): 3 red 5-chips and 4 blue 10-chips are directly countable. Best estimate is 4 green 50-chips and 4 brown 100-chips; the dexterous hand partly occludes those right-side groups, so those two denomination counts inherit the prior durable counts.
- Robot current bet (robot/left side of the board lane): 1 blue 10-chip; no red 5-, green 50-, or brown 100-chips visible.
- Opponent current bet (opponent/right side of the board lane): best estimate 1 red 5-chip and no blue 10-, green 50-, or brown 100-chips. The right end of this lane is partly occluded, so the red count is retained from the prior state with visible support.
- Workflow interpretation: The image is settled, the action sequence has no active intent or dispatched step, and there is no showdown. This supports `loop_stage: idle` and `showdown_outcome: not_showdown`.

