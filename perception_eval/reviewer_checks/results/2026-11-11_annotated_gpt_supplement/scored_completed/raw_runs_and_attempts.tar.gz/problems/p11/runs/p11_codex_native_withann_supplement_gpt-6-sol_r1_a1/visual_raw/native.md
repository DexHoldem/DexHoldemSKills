# Raw visual perception — s23

- Current `s23/00_capture.jpg` and previous `s22/00_capture.jpg` are byte-identical. The robot arm/hand is settled in the same near-idle pose, extending from the right and obscuring part of the opponent-side felt. No card or chip motion is visible. Scene stable.
- The white “Your Turn” button is visible at the bottom-left robot seat. It is the robot's turn.
- The shared board row has no face-up community cards; the five positions show card backs/printed placeholders. The two robot hole cards and two opponent hole cards remain face-down in their normal areas. No card is held by the robot hand. No fold or showdown is visible.
- Robot inventory at the bottom seat: four red 5 chips, three blue 10 chips, four green 50 chips, and approximately four brown 100 chips. The rightmost brown group is partly obscured by the robot body.
- Opponent inventory at the top seat: three red 5 chips, four blue 10 chips, approximately four green 50 chips, and approximately four brown 100 chips. The green/brown groups are partly obscured by the arm.
- Robot bet area, left/lower side of the board: one blue 10 chip; no red, green, or brown chips visible.
- Opponent bet area, right/upper side of the board: approximately one red 5 chip near the right edge; no blue, green, or brown bet chips apparent. The arm/body obscures part of this area.
- The dealer/small blind button remains by the opponent seat; the big blind button is by the robot seat. The robot is big blind.
