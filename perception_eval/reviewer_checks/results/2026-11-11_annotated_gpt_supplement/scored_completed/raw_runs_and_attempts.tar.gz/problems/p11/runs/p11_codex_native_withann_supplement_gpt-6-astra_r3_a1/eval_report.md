# Perception and merging report

Read all field guidelines and inspected the current s23 capture, s22, and s21. The literal `sN-1` path is absent; because `s_current` resolves to s23, used `s22/01_parsed_state.md` as the previous parsed state.

Current visual evidence supports idle, stable, robot turn, robot big blind, no face-up community cards, and no showdown. The s22-to-s23 comparison shows no material hand or table movement; s21 provides the earlier chip-pushing pose. The prior idle workflow state was context only.

Clearly visible inventory and robot-bet counts were read directly. Retained s22 totals for obscured robot brown chips and opponent green/brown chips. Retained the opponent bet estimate of one red chip and zero other denominations, supported by its visible red chip but limited by occlusion. These inherited or low-confidence fields are explicitly listed in uncertain_fields. Visible blind buttons independently confirm the cached blind assignment.

The cache contains robot hole cards 9d and 5d, but neither is a current face-up visual read and no showdown comparison is warranted. No cache or workflow files were changed. No helper scripts, robot actions, or poker decisions were executed.
