# Perception and merge report

Read the field-specific visual guidelines and inspected the current s23 capture plus s22 and s21 for stability. The s22-to-s23 robot pose and visible table layout are unchanged, supporting scene_stable=true and loop_stage=idle. The physical turn marker supports is_my_turn=true. Visible blind/dealer buttons confirm big_blind. No face-up board, revealed hole cards, or fold evidence supports a showdown; community_cards=[] and showdown_outcome=not_showdown.

Used s22/01_parsed_state.md as the previous parsed state because s_current points to s23. Clear inventory and robot bet counts were read directly from the capture. Occluded brown inventory counts retain the prior estimate of four per side. The opponent green count is estimated at four using partial visual evidence and the prior state. The opponent bet retains one red chip and zero other denominations, with the complete field flagged because the robot blocks much of the zone. All inherited or low-confidence chip estimates are listed in uncertain_fields.

The prior action sequence is idle and contains no dispatched atom; it was not treated as proof of current stability. Cached 9d/5d hole cards were read as context only; no comparison was needed. No robot actions, helper scripts, or poker decisions were executed. Outputs contain concrete estimates without nulls or placeholders.
