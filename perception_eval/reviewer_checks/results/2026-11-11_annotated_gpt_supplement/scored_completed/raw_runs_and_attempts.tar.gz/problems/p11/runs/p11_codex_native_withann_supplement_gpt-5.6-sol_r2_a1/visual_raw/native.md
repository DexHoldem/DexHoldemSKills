# Raw Visual Perception

- Current capture inspected: `s_current/00_capture.jpg`.
- Stability/robot: Stable relative to `s22/00_capture.jpg`; the current capture shows the same settled extended/near-idle dexterous-hand pose. The hand is not visibly blurred, is not holding a card or chip, and no card or chip is visibly in transit. The arm/camera assembly occludes part of the right side of the table, especially portions of the green/brown inventory groups and opponent-side betting area.
- Turn marker: The white `Your Turn` button is visible at the bottom-left robot/player seat, so it is the robot/player's turn.
- Blind marker: The yellow `BIG BLIND` button is at the bottom/robot side. This agrees with the recognized durable blind assignment: robot big blind, opponent dealer/small blind.
- Community-card row: No face-up community cards are visible. Five face-down cards occupy the printed board positions; under the guideline, face-down cards are not read or included as community cards.
- Hole-card/showdown evidence: The opponent's two hole cards remain face-down in their normal top-seat position, and the robot's two hole cards remain face-down in their normal bottom-seat position. There is no fold/muck displacement and no face-up showdown hand. Outcome is therefore `not_showdown`.
- Robot/player inventory, bottom seat band (excluding bet lane): 4 red 5-chips and 3 blue 10-chips are directly countable. The right-side green 50-chip and brown 100-chip groups are partly obscured; the durable settled counts of 4 each from `s22/01_parsed_state.md` are inherited because no visual movement or intervening dispatched action indicates a change.
- Opponent inventory, top seat band (excluding bet lane): 3 red 5-chips and 4 blue 10-chips are visible/countable. The green 50-chip and brown 100-chip groups are partly blocked by the dexterous hand; the durable settled counts of 4 each from `s22/01_parsed_state.md` are inherited because the layout is unchanged and no action was dispatched.
- Robot/player current bet, left of the community-card row: one blue 10-chip; no red 5-, green 50-, or brown 100-chips.
- Opponent current bet, right of the community-card row: one red 5-chip; no blue 10-, green 50-, or brown 100-chips. The arm partly borders this zone, but the red chip and unchanged prior layout support the count.
- Workflow context: `action_sequence.json` records `idle` with no sequence/action/steps. This is consistent with the settled visual pose; it is context only, not the basis for table-object reads.

