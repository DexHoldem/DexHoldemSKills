# Raw visual perception

- The capture is a stable preflop table scene. No face-up community cards are visible; the five central card positions show card backs, so `community_cards` is `[]`.
- The bottom/robot side shows a visible `Your Turn` marker. The yellow `BIG BLIND` marker is also on the robot side, so the blind is `big_blind` and it is currently my turn.
- Inventory chips are flat and grouped by denomination. Best visible counts: robot side 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips; opponent side 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- No current-bet chips are visibly placed in either central betting area.
- The robot/camera assembly occludes part of the right side, including portions of the opponent-side and robot-side inventory regions. Counts above are best visual estimates; the right-side denomination groups are lower confidence.
- The scene is settled: no clear hand motion, card exposure, chip push, or disturbed layout is visible. The action-sequence context is idle, so the visual loop stage is `idle`.
- No showdown evidence or outcome is visible.
