# Native visual evidence

Capture: `s_current/00_capture.jpg` resolves to `s23/00_capture.jpg`. Compared directly with `s22/00_capture.jpg` and `s21/00_capture.jpg` using the field guidelines.

Stable. The current image and s22 show the same raised, right-side near-idle hand pose and unchanged visible cards, chips, and buttons. In s21 the hand was extended over the left betting lane; that movement has finished in the two latest frames. No object is visibly held, no readable held card is present, and no active table interference is visible. The hand body occludes the right betting lane and portions of the inventories. Current physical evidence supports idle, with no visible failure or recovery condition.

The bottom seat is the robot and the top seat is the opponent. Inventory groups are outside the central lane; bet chips are counted separately to the left and right of the board. Chips are flat individual faces, not stacks.

It is our turn: the white "Your Turn" marker is clearly visible at the bottom-left robot seat.

The yellow "BIG BLIND" button is beside the robot hole-card area. The white dealer button and blue small-blind button are at the opponent seat. Robot is big blind; there is no button conflict.

No face-up community cards are visible. Five patterned rectangular board positions show no readable ranks or suits and contribute no community cards. Both players' hole cards remain face-down in their normal seat areas, with no visible fold/muck displacement. No showdown or outcome comparison is supported. Cached robot cards 9d and 5d are context only, not fresh visual reads.

Robot inventory: four red 5 chips, three blue 10 chips, and four green 50 chips are visible. Three brown 100 faces are at least partly visible, while the rest of this group is obscured by the hand body; estimate four brown chips using s22's durable count and unchanged layout. Brown count is uncertain.

Opponent inventory: three red 5 chips and four blue 10 chips are visible. About four green 50 chips are discernible, including a partly obscured chip near the fingertip; estimate four with occlusion uncertainty. Three brown 100 faces are visible; the remaining group is partly occluded, so estimate four from the unchanged s22 inventory. Brown count is uncertain.

Robot current bet, left of board: one blue 10 chip, no red, green, or brown chips visible. Opponent bet, right of board: one partly visible red 5 chip; no other denomination is visible. The hand blocks the continuation of this area, so the estimate of one red and zero other chips is uncertain and supported by s22.

The prior action sequence says idle with no dispatched step. This agrees with, but does not establish, the current visual idle judgment. No robot action or poker decision is selected.
