# Perception Evaluation

The current image was treated as primary evidence and compared with the previous settled capture/state (`s22`). It shows a stable idle/near-idle robot pose, the white turn button at the robot seat, no face-up community cards, normal face-down hole-card positions, one robot blue 10-chip bet, and one opponent red 5-chip bet. There is no showdown or fold signature.

Directly visible red/blue inventory and bet counts were read from their table zones. The robot arm/camera partly occludes the right-side green/brown inventory groups, so those four denomination counts were inherited from the durable `s22` state and listed in `uncertain_fields`. The idle action-sequence context and unchanged visual layout support that merge. Blind assignment was inherited from the recognized cache and is also visibly supported by the robot-side `BIG BLIND` button.
