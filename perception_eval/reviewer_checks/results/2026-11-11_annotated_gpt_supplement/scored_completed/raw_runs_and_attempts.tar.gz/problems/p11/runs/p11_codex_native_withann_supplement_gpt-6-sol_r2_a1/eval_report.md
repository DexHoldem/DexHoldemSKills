# Perception evaluation

The current `s23` image matches `s22`: settled robot hand, unchanged chips/cards, and a white turn button at the robot seat. The yellow big-blind button remains at the robot seat. No face-up board or hole cards, fold, or showdown are visible, so the state is stable, idle, and preflop.

Visible red and blue inventory chips and the robot's blue 10 bet were counted directly. The right-side inventory groups and opponent's red 5 bet are partly occluded by the robot body. Their concrete estimates use the visible portions plus `s22/01_parsed_state.md`; those fields are marked uncertain. `action_sequence.json` records no active action, and `hole_card_cache.json` supplies context only. No poker action was selected or executed.
