# Perception evaluation

The latest available capture is `s23/00_capture.jpg`; `s_current/00_capture.jpg` is absent, so `s23` was used as the current frame. The frame is settled, the robot-side `Your Turn` button is visible, and no community cards or showdown state are present. The robot is therefore idle and it is the robot's turn.

Inventory and bet counts match the previous settled parse (`s22/01_parsed_state.md`) and the visible chip layout: robot inventory 4/3/4/4, opponent inventory 3/4/4/4, robot bet one blue 10-chip, opponent bet one red 5-chip, in denomination order 5/10/50/100. The far-right opponent-side inventory is partly occluded by the robot/camera body, so `opponent_chips` is marked uncertain while retaining the best concrete count.

The cached blind assignment identifies the robot as big blind. Cached hole cards were treated as context only and not reread from the face-down cards.
