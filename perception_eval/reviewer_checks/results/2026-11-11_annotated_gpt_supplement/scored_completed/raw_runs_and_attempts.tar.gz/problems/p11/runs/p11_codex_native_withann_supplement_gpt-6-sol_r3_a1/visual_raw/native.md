# Raw visual perception — s23

- Compared `s_current/00_capture.jpg` (s23) with `s22/00_capture.jpg`; the image files are identical. The dexterous hand is settled near the right edge of the table and is not visibly holding a card or chip. It partly blocks the right side of the table. Scene stable; no physical failure visible.
- The white “Your Turn” button is at the bottom/robot seat. It is the robot's turn.
- The yellow “BIG BLIND” button is at the bottom/robot seat. The white dealer button is at the top/opponent seat. Robot is big blind.
- No face-up community cards in the central board row. The patterned rectangles are table markings, not cards. The two opponent hole cards and two robot hole cards remain face-down; no fold or showdown is visible. No readable held card is visible.
- Bottom/robot inventory: four red 5-chips and three blue 10-chips are visible. Best estimates for the partly obscured right-side groups are four green 50-chips and four brown 100-chips, inherited from s22 because the capture is identical.
- Top/opponent inventory: three red 5-chips and four blue 10-chips are visible. Best estimates for the partly obscured green and brown groups are four 50-chips and four 100-chips, inherited from s22.
- Robot current bet, left of the board row: one blue 10-chip; no red, green, or brown bet chips visible. Opponent current bet, right of the board row: one red 5-chip; no blue, green, or brown bet chips visible. The robot body partly occludes the opponent betting side, so its count is uncertain.
- Inventory chips and current bet chips were counted as separate zones. Buttons were excluded from chip counts.
