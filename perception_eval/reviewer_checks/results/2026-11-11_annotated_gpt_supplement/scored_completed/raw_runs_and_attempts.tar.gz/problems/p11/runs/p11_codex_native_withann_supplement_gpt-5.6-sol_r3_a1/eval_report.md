# Perception Evaluation

The current capture was compared with `s22/00_capture.jpg`. The table and dexterous hand are unchanged and settled, so the scene is stable. Direct visual evidence establishes the robot-side `Your Turn` marker, robot-side `BIG BLIND` marker, an empty community board, normal face-down hole-card placement, and no showdown or fold signature.

The clearly visible chip counts agree with `s22/01_parsed_state.md`: robot inventory 4/3 red-blue, opponent inventory 3/4 red-blue, robot bet one blue 10-chip, and opponent bet one red 5-chip. Right-side green/brown inventory groups and the far-right opponent bet lane are partly occluded by the robot/camera assembly. Their concrete estimates were merged from the prior durable counts where the current image remains consistent, and those fields are listed in `uncertain_fields`.

`action_sequence.json` contains no active sequence or dispatched step, so the stable non-showdown scene is labeled `idle`. The recognized blind assignment from `hole_card_cache.json` agrees with the visible buttons. No robot action or poker action was selected or executed.
