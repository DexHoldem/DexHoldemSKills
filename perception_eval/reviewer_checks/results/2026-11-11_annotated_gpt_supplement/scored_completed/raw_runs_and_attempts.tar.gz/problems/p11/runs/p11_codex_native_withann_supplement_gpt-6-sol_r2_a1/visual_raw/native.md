# Raw visual perception — s23

- Compared `s23/00_capture.jpg` with `s22/00_capture.jpg`. The frames look unchanged: the dexterous hand is settled near idle at the upper-right, with no visible card or chip movement. Its body blocks part of the right-side chip layout. The scene appears stable; no physical failure is visible.
- The white `Your Turn` button is at the bottom/robot seat. It is the robot's turn.
- The yellow `BIG BLIND` button is at the bottom/robot seat. The dealer button is at the upper/opponent seat. Robot is big blind.
- The five central shared-card positions are face-down card backs. No face-up community card is visible. The two robot hole cards and two opponent hole cards are also face-down. No fold or showdown is visible. The hand holds no readable card or chip.
- Robot inventory, bottom seat: four red 5 chips and three blue 10 chips clearly visible. The right-side green 50 and brown 100 groups are partly hidden by the robot body; best estimate is four of each, consistent with the previous stable parsed state.
- Opponent inventory, top seat: three red 5 chips and four blue 10 chips visible. The green 50 and brown 100 groups lie near the robot hand and are partly obscured; best estimate is four of each, consistent with the previous stable parsed state.
- Robot current bet, left of the shared-card row: one blue 10 chip; no red, green, or brown bet chip visible.
- Opponent current bet, right of the shared-card row: one red 5 chip is partly visible near the right edge of the board; no blue, green, or brown bet chip is evident. This area is partly occluded by the robot body, so the count is uncertain.
