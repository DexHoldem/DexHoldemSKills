# Raw Visual Perception

- Stable. Compared `s22/00_capture.jpg` with `s_current/00_capture.jpg`; the robot hand, cards, chips, and markers have the same settled layout. The dexterous hand is in a near-idle pose over the upper-right area, is not holding a card or chip, and shows no motion blur. No human hand is moving or blocking table objects.
- The white `Your Turn` button is clearly at the bottom-left robot seat, so it is the robot's turn.
- The yellow `BIG BLIND` button is at the bottom/robot seat. The white dealer button is at the top/opponent seat, consistent with the robot being big blind.
- No face-up community cards are visible. The five cards in the central board row are face-down and are not read as community cards.
- The opponent's two hole cards remain face-down in their normal top-seat position. The robot's two hole cards remain face-down in their normal bottom-seat position. There is no fold/muck or showdown signature.
- Robot inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and an estimated 4 brown 100-chips. The brown group is partly hidden by the right-side camera/robot body; its total is inherited from the unchanged previous stable state.
- Opponent inventory, top seat: 3 red 5-chips, 4 blue 10-chips, an estimated 4 green 50-chips, and an estimated 4 brown 100-chips. The upper-right green/brown groups are partly occluded by the robot fingers/body; totals are inherited from the unchanged previous stable state.
- Robot current bet area, left of the board row: one blue 10-chip; no red, green, or brown bet chips.
- Opponent current bet area, right of the board row: one red 5-chip; no blue, green, or brown bet chips.
- No disturbed chip groups, dropped cards, held card, physical failure, or recovery condition is visible.

