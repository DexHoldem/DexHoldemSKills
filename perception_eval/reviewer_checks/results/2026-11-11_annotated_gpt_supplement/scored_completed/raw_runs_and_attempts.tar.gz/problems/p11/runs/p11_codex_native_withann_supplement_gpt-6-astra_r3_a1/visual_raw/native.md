# Raw perception evidence

Stable. Compared the current capture (`s_current/00_capture.jpg`, resolving to s23) with s22 and the earlier s21 capture. The hand has moved away from the central chip-pushing position seen in s21; its near-idle pose and the visible table objects are unchanged between s22 and s23. The hand is empty, with no readable held card. It blocks portions of the right-side betting and inventory regions. No ongoing transfer, disturbed layout, or physical failure is evident.

The white “Your Turn” button is at the bottom/robot seat: it is our turn. The yellow big-blind button is at the robot seat, while the white dealer and blue small-blind buttons are at the top/opponent seat. The robot is the big blind.

There are no face-up community cards. Five patterned backs occupy the central row; their hidden ranks and suits are not read. Two face-down hole cards remain in each player's usual area. No opponent reveal or displacement indicating a fold is visible. This is not showdown; cached robot cards are not current visual reads.

Inventory chips are counted separately from bets, using red=5, blue=10, green=50, brown=100. Counts below are in that order.

- Bottom/robot inventory: four red, three blue, four green faces visible. Three brown faces are at least partly visible, with further inventory obscured by the robot body. Best total estimate: 4, 3, 4, 4; brown total inherited from s22 and uncertain.
- Top/opponent inventory: three red and four blue faces visible. Three green faces are clear and another is partly obscured by the fingers. Three brown faces are visible, with part of the group hidden. Best total estimate: 3, 4, 4, 4; green and brown totals uncertain, supported by s22.
- Robot bet, left of the central row: one blue 10-chip, no red, green, or brown chips visible. Counts: 0, 1, 0, 0.
- Opponent bet, right of the central row: one red 5-chip is partly visible beside the robot body. The rest of the betting region is blocked. Best estimate: 1, 0, 0, 0, consistent with s22; all denominations remain uncertain because hidden additional chips cannot be excluded.

The stable near-idle pose supports loop_stage=idle. The prior workflow file also says idle, but the visual comparison is the basis for the current judgment. No action is selected or dispatched.
