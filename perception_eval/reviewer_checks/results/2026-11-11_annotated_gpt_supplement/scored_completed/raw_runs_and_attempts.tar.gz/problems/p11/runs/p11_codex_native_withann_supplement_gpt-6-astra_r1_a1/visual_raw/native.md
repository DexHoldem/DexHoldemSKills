# Native visual evidence

Stable. Compared s_current/00_capture.jpg (s23) with s22/00_capture.jpg and s21/00_capture.jpg. The robot hand/body has the same settled, raised right-side pose in s22 and s23. In s21 it was extended lower across the table near the blue bet chip. No continuing object movement is evident between s22 and s23. The human is not manipulating table objects.

The robot is near idle, with no visibly held card or chip. Its body blocks the right portion of the table, including part of the opponent betting area and brown inventory groups; fingers partially obscure the opponent green group. No visible displaced card, scattered chip layout, or physical failure supports recovery or down. Current loop stage: idle.

The white Your Turn button is clearly visible at the bottom/robot seat, near seat 6: it is our turn. The yellow BIG BLIND button is at the bottom/robot seat; the white DEALER and blue SMALL BLIND buttons are at the top/opponent seat. Robot is big blind, opponent is dealer/small blind.

No face-up community cards are visible. Five patterned card backs occupy the central row; none provides readable rank/suit evidence, so the community-card list is empty. Both robot hole cards and both opponent hole cards remain face-down in their respective seat areas. No readable held card is visible. No fold/muck or showdown is evident. Showdown outcome: not_showdown. Cached robot cards 9d and 5d are contextual only and are not current visual reads.

Inventory counts use flat individual chip faces, excluding the central betting lane and all buttons. Denomination order below is 5, 10, 50, 100.

- Bottom/robot inventory: four red, three blue, four green faces are visible. Brown chips are partly hidden by the robot body; three faces/partial faces can be distinguished, but the full group is not countable. Retain the prior estimate of four brown chips, uncertain.
- Top/opponent inventory: three red and four blue faces are visible. The green group has visible faces and a partly obscured chip behind the fingers, consistent with four; count four with uncertainty. Three brown faces are visible, with remaining coverage obscured; retain the prior estimate of four brown chips, uncertain.
- Robot current bet, left of the community row: one blue 10 chip; no red, green, or brown bet chips visible. Counts: 0, 1, 0, 0.
- Opponent bet, right of the community row: one red 5 chip is partly visible at the edge of the robot-body occlusion. The rest of this zone is blocked. Best estimate, consistent with s22: 1, 0, 0, 0; uncertain because additional chips cannot be visually excluded.

The supplied action_sequence.json describes an idle workflow with no dispatched step. This is context only; the stable s22-to-s23 comparison supports the current idle assessment independently. s_current resolves to s23, so the previous parsed state used for merging is s22/01_parsed_state.md (there is no literal sN-1 directory).
