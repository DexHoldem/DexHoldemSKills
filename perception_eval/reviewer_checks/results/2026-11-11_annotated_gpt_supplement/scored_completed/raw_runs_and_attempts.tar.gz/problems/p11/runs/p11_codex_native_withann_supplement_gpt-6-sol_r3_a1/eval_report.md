# Perception and merge report

The s23 capture is byte-for-byte identical to s22, and the visible table remains stable. The bottom-seat turn and big-blind buttons are visible. There are no face-up community cards or showdown cards. The robot bet is one blue 10-chip and the opponent bet is one red 5-chip.

Visible red and blue inventory counts were read from the capture. Green and brown inventories, and the partly occluded opponent bet area, use concrete estimates corroborated by the identical s22 capture and its parsed state; these fields are marked uncertain. `action_sequence.json` supplies prior workflow context only and did not override the visual idle state. The hole-card cache was considered for showdown, but no showdown is visible.
