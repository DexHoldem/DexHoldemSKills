# Perception Evaluation

The current capture is visually unchanged from `s22/00_capture.jpg`: the robot hand is settled in the same near-idle pose, the table objects are stationary, and the action-sequence context contains no active or dispatched atom. The merged loop stage is therefore `idle`, with `scene_stable: true`.

Direct visual evidence establishes the bottom-seat `Your Turn` marker, the bottom-seat big-blind marker, no face-up community cards, normal face-down hole-card positions, and separate blind bets of one blue 10-chip for the robot and one red 5-chip for the opponent. These observations imply `is_my_turn: true`, `blind: big_blind`, and `showdown_outcome: not_showdown`.

Clearly visible inventory denominations were counted directly. The robot's brown group and the opponent's upper-right green/brown groups are partly occluded by the robot/camera assembly, so their unchanged counts were inherited from the previous parsed stable state and named in `uncertain_fields`. No cached hole-card values were used because the image does not show a showdown.

