# Raw visual perception

- Source: `s_current/00_capture.jpg`.
- Scene: settled table; no visible card or chip transfer. The robot apparatus/hand is at the right side and partially occludes the far-right upper table region, but the actionable table layout remains readable.
- Turn: the white `Your Turn` button is visible at the bottom/robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is at the bottom/robot seat; robot is big blind. This agrees with the cached blind assignment.
- Community cards: no face-up community cards are visible; the center board positions are face-down/deck-backed or empty, so no board cards are read.
- Robot inventory (bottom/robot seat, excluding betting lane): 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Opponent inventory (top/opponent seat, excluding betting lane): 3 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips. The right side is partly occluded by the robot apparatus, so the far-right inventory count is lower confidence.
- Robot current-bet area (lower side of board): 0 red, 1 blue 10-chip, 0 green, 0 brown.
- Opponent current-bet area (upper side of board): 1 red 5-chip, 0 blue, 0 green, 0 brown. The upper-right area is partly occluded, but the visible bet chip is countable.
- Showdown: neither player's hole cards are face-up and no fold/muck outcome is visible; this is not showdown.

