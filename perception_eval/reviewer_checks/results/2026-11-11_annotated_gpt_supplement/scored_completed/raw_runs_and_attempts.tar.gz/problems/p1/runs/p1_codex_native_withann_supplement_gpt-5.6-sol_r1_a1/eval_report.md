# Perception evaluation

The current capture is a stable, idle preflop scene. Direct visual evidence determines all output fields: the bottom-seat `Your Turn` marker makes `is_my_turn` true, and the bottom-seat yellow `BIG BLIND` marker makes the robot the big blind. No face-up shared cards are visible, both players' hole cards remain face-down in their normal zones, and there is no fold or showdown signature.

Inventory chips were separated from the central bet lanes using the fixed table geometry. Each player has four visible chips of every denomination; both bet lanes are empty. The robot hand is sharp and settled-looking, holds nothing, and does not prevent the relevant counts.

`action_sequence.json` was used only as context and agrees with the visual idle state. `hole_card_cache.json` contains no known cards and therefore contributes nothing to the current read. No previous `01_parsed_state.md` was available to inherit from, and no field was inferred or inherited; `uncertain_fields` is empty.
