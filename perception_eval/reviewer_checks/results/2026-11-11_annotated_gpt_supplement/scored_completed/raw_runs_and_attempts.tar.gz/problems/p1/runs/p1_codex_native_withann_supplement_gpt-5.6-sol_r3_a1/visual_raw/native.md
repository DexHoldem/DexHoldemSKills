# Raw visual perception

- Source: `s_current/00_capture.jpg` (single current frame).
- Geometry: robot/player seat is at the bottom; opponent seat is at the top.
- Scene/robot: the image is sharp and table objects are settled. The dexterous hand is raised at the upper-right in a near-idle pose, is not holding a card or chip, and does not cover the central board or visible betting lanes. No dispatched action exists in `action_sequence.json`. Because no previous state image or `sN-1/01_parsed_state.md` is available, stability is inferred from this single frame.
- Turn: the white physical marker labeled `Your Turn` is at the bottom-left robot seat, so it is the robot/player's turn.
- Blinds: the yellow `BIG BLIND` marker is at the bottom robot seat. The white `DEALER` marker and blue small-blind marker are on the top opponent side. Therefore the robot/player is big blind.
- Community cards: no face-up cards are present in the central five-card row.
- Hole cards/showdown: two face-down robot hole cards remain in the bottom hole-card area and two face-down opponent hole cards remain in the normal top hole-card area. No card is held or readable. There is no fold/muck or showdown evidence.
- Robot/player inventory (bottom seat), counted as individual flat chip faces: red/5 = 4, blue/10 = 4, green/50 = 4, brown/100 = 4.
- Opponent inventory (top seat), counted as individual flat chip faces: red/5 = 4, blue/10 = 4, green/50 = 4, brown/100 = 4.
- Robot/player current bet: no chips visible in the robot-side betting lane; 5 = 0, 10 = 0, 50 = 0, 100 = 0.
- Opponent current bet: no chips visible in the opponent-side betting lane; 5 = 0, 10 = 0, 50 = 0, 100 = 0.
- Uncertainty: `scene_stable` is inferred from a single sharp, settled-looking capture rather than confirmed by comparison with a previous frame. Chip, card, turn, blind, and bet reads are visually clear.
