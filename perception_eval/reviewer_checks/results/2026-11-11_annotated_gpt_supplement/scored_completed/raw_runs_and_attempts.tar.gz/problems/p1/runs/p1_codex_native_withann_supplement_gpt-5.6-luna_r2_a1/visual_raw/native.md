# Raw visual perception

- Capture used: `s0/00_capture.jpg` (the requested `s_current/00_capture.jpg` is absent).
- Scene: Texas Hold'em table; the robot assembly occupies the right side and partially occludes the far-right table area. The dexterous hand/assembly appears settled rather than mid-motion. No prior frame was available for a true frame-to-frame stability comparison.
- Turn: the white `Your Turn` button is visible at the bottom/robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is at the bottom/robot seat; robot is the big blind.
- Community cards: five face-down cards are visible in the shared board row; no face-up community card is present, so no card values are readable.
- Hole cards/showdown: robot and opponent hole-card areas show face-down cards; no showdown or visible outcome.
- Robot inventory (bottom/robot side): 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Opponent inventory (top/opponent side): 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips. The right-side hardware occludes part of the table, but the visible inventory groups are countable.
- Betting areas: no unfolded bet chips are visible in either the robot-side or opponent-side central betting area. Buttons are excluded.
