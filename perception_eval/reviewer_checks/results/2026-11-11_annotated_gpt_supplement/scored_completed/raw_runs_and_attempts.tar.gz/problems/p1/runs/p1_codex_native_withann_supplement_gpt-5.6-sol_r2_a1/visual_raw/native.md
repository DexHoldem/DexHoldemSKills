# Raw visual perception

- Capture inspected: `s_current/00_capture.jpg`.
- Scene/robot: The dexterous hand is in a settled near-idle pose at the upper-right. There is no visible motion blur, held card, held chip, collision, or displaced table object. The hand/camera assembly occludes part of the far upper-right background but does not prevent reading the relevant table zones. With the workflow context idle and the visible pose settled, the current scene is stable.
- Turn: The white physical button labeled `Your Turn` is at the bottom-left robot/player seat. It is the robot's turn.
- Blind: The yellow `BIG BLIND` button is at the bottom/robot seat. A blue `SMALL BLIND` button and the white dealer button are at the top/opponent seat. The robot is big blind.
- Community cards: No face-up community cards are visible. Five card backs occupy the central board positions; per the guideline, face-down cards are not read or included as community cards.
- Hole cards/showdown: Two face-down cards are in the normal bottom robot hole-card area and two face-down cards are in the normal top opponent hole-card area. Neither pair is exposed or displaced toward the board. There is no fold/muck or showdown evidence, and the empty hole-card cache provides no card values.
- Robot/player inventory (bottom seat), counting unfolded chip faces by color: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Opponent inventory (top seat), counting unfolded chip faces by color: 5 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot current-bet area: no red, blue, green, or brown bet chips visible.
- Opponent current-bet area: no red, blue, green, or brown bet chips visible. The green chip nearest the center-right belongs to the contiguous top-seat green inventory group, not the betting lane.
- Uncertainty: none material in the requested fields. Scene stability is judged from this single clear capture plus the idle workflow context because no previous parsed-state/image was supplied.
