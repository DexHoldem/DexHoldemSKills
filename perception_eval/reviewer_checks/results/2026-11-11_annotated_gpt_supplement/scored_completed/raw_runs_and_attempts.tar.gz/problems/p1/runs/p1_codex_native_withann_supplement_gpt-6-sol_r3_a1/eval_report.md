# Perception evaluation

The current capture supports `idle`, robot big blind, robot turn, no community cards, no visible bets, and no showdown. Both seats have four visible chips of each denomination in their inventory groups. The robot hand appears settled and is not holding an object.

`action_sequence.json` reports prior workflow stage `idle` and no dispatched steps; it was used only as context. `hole_card_cache.json` contains no known cards or blinds. The requested prior parsed state and comparison image were not supplied. Therefore `scene_stable` is the best estimate from a single clear frame and is listed in `uncertain_fields`. All other output fields come from current visual evidence.
