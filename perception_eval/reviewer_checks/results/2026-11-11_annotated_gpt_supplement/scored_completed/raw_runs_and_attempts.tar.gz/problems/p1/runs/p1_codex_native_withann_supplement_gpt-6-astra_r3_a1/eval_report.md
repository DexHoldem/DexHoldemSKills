# Perception and merging

Read all field guidelines and directly inspected the current capture (`s0`). Current visual evidence supplies blind assignment, turn ownership, inventory counts, empty visible betting zones, and absence of face-up community/showdown cards. Each inventory has four visible chips of each denomination. Central card backs are excluded from recognized community cards under the face-up-only rule.

The prior action sequence is idle with no dispatched steps; the hole-card and blind caches are unknown. No previous parsed-state file is present, so no durable values were inherited. The current idle/stable estimates follow the apparently resting empty hand and undisturbed table, with uncertainty recorded because no temporal comparison is available. The zero opponent bet estimate is also flagged because the robot/camera obscures the far-right portion of the table.

All requested schema fields have concrete values. No robot actions, helper scripts, or poker decisions were executed or selected.
