# Raw visual perception

- Source frame: `s0/00_capture.jpg` (used as the current capture because `s_current/00_capture.jpg` and a prior `sN-1` frame were not present).
- The table is visually settled: the robot arm/hand is at the right side and is not visibly moving or manipulating cards/chips.
- The white `Your Turn` button is at the bottom/robot seat, so it is the robot's turn.
- The yellow `BIG BLIND` button is at the bottom/robot seat. The blue dealer/small-blind marker is on the opponent/top side; therefore the robot is the big blind.
- No face-up community cards are visible. The five central board positions are face-down/unused for the current hand.
- Robot inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Opponent inventory, top seat: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- No chips are visible in the robot or opponent central betting areas; both current bets are zero.
- The two hole-card positions remain face-down. No showdown or outcome is visible; the hole-card cache contains no readable cached cards.
- No visual evidence supports `acting`, recovery, win, loss, or showdown; the supplied action state is idle.
