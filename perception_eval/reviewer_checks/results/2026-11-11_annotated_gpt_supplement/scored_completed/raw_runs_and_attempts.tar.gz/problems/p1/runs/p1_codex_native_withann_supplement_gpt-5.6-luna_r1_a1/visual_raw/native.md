# Raw visual perception

- Source image: `s0/00_capture.jpg` (the workspace has no literal `s_current/00_capture.jpg`).
- Scene: two-player Texas Hold'em table, visually settled; robot arm is present at the right but no active card/chip manipulation is visible.
- Turn: white `Your Turn` button is at the bottom/robot seat, so it is the robot's turn.
- Blind: yellow `BIG BLIND` button is at the bottom/robot seat; robot is big blind.
- Community cards: five central card backs are visible; no community card faces are readable, so community cards are empty.
- Robot inventory, bottom/robot side: approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Opponent inventory, top/opponent side: approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Current bets: no chips are visibly placed in either central betting area; both bet vectors are zero.
- Showdown: not present; both hole-card areas are face-down and the board is unrevealed.
- Cached hole cards: unavailable/unknown; no showdown comparison is needed for this frame.
