# Raw visual perception

Viewed `s_current/00_capture.jpg` and compared with `s0/00_capture.jpg`; the visible table layout and robot pose match.

- The robot/player seat is at the bottom. The dexterous hand is raised at the upper right in a settled, near-rest pose. It is not visibly holding a card or chips, contacting table objects, or blocking the central betting areas. No physical failure is visible.
- The white `Your Turn` button is beside the bottom/robot seat. It is the robot's turn.
- The blue dealer button is beside the top/opponent seat; the yellow `BIG BLIND` button is beside the bottom/robot seat. Thus the robot is the big blind.
- There are no face-up community cards in the central row. The five gray rectangles are face-down/printed card positions, not readable community cards. Both players' hole cards are face-down. No fold or showdown is visible.
- Robot inventory, bottom seat, left to right: four red 5 chips, four blue 10 chips, four green 50 chips, four brown 100 chips.
- Opponent inventory, top seat, left to right: four red 5 chips, four blue 10 chips, four green 50 chips, four brown 100 chips.
- Robot current bet area, left/lower side of the community row: no chips visible. Opponent current bet area, right/upper side of the community row: no chips visible.
- The robot and table objects appear settled. No significant occlusion affects these field reads. Scene stability is supported by the matching `s0` frame; no intermediate previous parsed state was supplied.
