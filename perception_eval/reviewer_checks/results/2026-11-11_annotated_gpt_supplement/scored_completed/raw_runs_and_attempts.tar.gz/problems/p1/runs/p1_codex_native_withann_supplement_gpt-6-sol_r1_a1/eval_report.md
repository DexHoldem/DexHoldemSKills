# Perception summary

The current image shows a preflop idle table. The robot's white turn marker and yellow big-blind marker are at the bottom seat; the dealer/small-blind markers are at the opponent seat. No face-up board cards, bet chips, fold, or showdown are visible. Each player has four visible chips of each denomination in their inventory.

The prior action sequence says idle and no atom was dispatched. The hole-card cache is unknown. Neither context source overrides the visual state. Scene stability is marked uncertain because only one capture is available; the visible robot hand and table objects appear settled.
