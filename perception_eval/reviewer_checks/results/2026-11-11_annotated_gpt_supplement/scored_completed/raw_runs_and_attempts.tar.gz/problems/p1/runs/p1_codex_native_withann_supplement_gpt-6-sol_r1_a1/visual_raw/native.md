# Raw visual evidence

- Current image: `s_current/00_capture.jpg` (1920 × 1080). No previous capture or parsed state is available for frame comparison.
- The robot/player seat is at the bottom; the opponent seat is at the top. The dexterous hand is extended from the right over the upper-right table edge. It is not visibly holding a card or chip; the image shows no obvious motion blur or displaced objects. Stability is estimated from this single frame.
- The small white `Your Turn` marker is at the bottom-left robot seat. It is the robot's turn.
- The white `DEALER` button and blue `SMALL BLIND` button are at the top/opponent seat. The yellow `BIG BLIND` button is at the bottom/robot seat. The robot is big blind.
- Five card-back-shaped areas are visible across the central board lane, but no face-up community card is visible. The top two and bottom two cards/areas are face-down and are not read as community cards. No readable card is held by the robot.
- Robot inventory (bottom): red 5 × 4; blue 10 × 4; green 50 × 4; brown 100 × 4. These are separate flat chip faces, not stacks.
- Opponent inventory (top): red 5 × 4; blue 10 × 4; green 50 × 4; brown 100 × 4. The fourth green chip is left of the other three, near the dealer marker, but remains in the top inventory band.
- Robot current bet area, left/lower side of the community-card lane: no chips visible. Opponent current bet area, right/upper side of the lane: no chips visible.
- Opponent hole cards are not face-up or visibly mucked into the board lane; no showdown or fold evidence is visible.
- `action_sequence.json` reports idle with no dispatched step, consistent with the image. `hole_card_cache.json` has no known hole cards or blinds. Visual markers determine the current blind assignment.
