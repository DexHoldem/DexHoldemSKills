# Native perception evidence

Source: `s_current/00_capture.jpg`, resolving to `s0/00_capture.jpg`. Inspected directly; no previous capture or parsed state is available.

Stable, provisionally from this single image. The robot hand is suspended at the upper right in an apparently resting pose, with no visible card or chips held and no contact with table objects. The foreground hand is soft in focus; motion cannot be established from one frame. The opponent's arms are folded outside the playing area. Temporal stability and the inferred idle stage remain uncertain. No visible physical failure or disturbed layout supports a recovery/failure label.

It is our turn. The white `Your Turn` marker is clearly at the bottom-left robot seat.

Dealer/small blind is at the top/opponent seat: the white DEALER button and blue SMALL BLIND marker are beside the opponent's two card backs. The yellow BIG BLIND button is at the bottom/robot seat. There is no visible button conflict.

Robot inventory, counted as individual flat chip faces: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. Red and blue groups are at the lower left/center; green and brown groups are at the lower right.

Opponent inventory: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. These are the upper-seat groups outside the central lane. Buttons are excluded.

Robot current bet area: no red, blue, green, or brown chips visible. Opponent bet area: no chips of any denomination visible; the far-right extension is partly obscured by the robot/camera assembly, so zero is the best visible estimate with uncertainty. Inventory chips remain distinct from these betting zones.

No face-up community cards are visible. Five patterned card-back rectangles occupy the central row; no rank or suit is exposed, so none is included as a recognized community card. Two face-down hole cards are visible at each seat. No readable held card is visible; hidden ranks and suits are not inferred.

No opponent hole cards are face-up, no robot hole cards are face-up, and no clear fold/muck displacement or showdown is visible. Outcome: not_showdown. The cache contains no known robot hole cards, so no hand comparison is possible or applicable.

Prior workflow context has idle stage and no dispatched steps. This is consistent with the visible resting pose but is not evidence of current motion completion. No previous parsed state exists to supply durable fields.
