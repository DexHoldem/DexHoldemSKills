# Raw visual perception

Source: `s_current/00_capture.jpg` (`s_current` points to `s0`). This is the only capture supplied; `sN-1/01_parsed_state.md` and a prior comparison frame are absent.

- The robot/player seat is at the bottom and the opponent seat is at the top. The robot hand is raised at the upper right, appears near a resting pose, and is not visibly holding a card or chip. No disturbed objects or physical failure are apparent. Motion cannot be confirmed from one still frame.
- Five empty printed community-card positions are visible across the center. No face-up community cards are present. The two face-down cards near each seat are hole cards, not board cards; none can be read.
- The white `Your Turn` marker is at the lower-left robot seat, so it is the robot's turn.
- A yellow `BIG BLIND` marker is at the robot seat. The white `DEALER` marker and blue `SMALL BLIND` marker are at the opponent seat. The robot is the big blind.
- Robot inventory, in the bottom seat band: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. The blue and brown groups are partly angled, but four separate faces are visible in each.
- Opponent inventory, in the top seat band: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. All are separate from the central betting lane.
- No loose bet chips are visible in either the robot's or opponent's central betting area.
- The opponent's hole cards remain face-down in their normal top-seat area; the robot's are face-down at the bottom. No fold or showdown is visible.
- The scene looks settled in this frame, but stability is an estimate because no prior frame is available for motion comparison.
