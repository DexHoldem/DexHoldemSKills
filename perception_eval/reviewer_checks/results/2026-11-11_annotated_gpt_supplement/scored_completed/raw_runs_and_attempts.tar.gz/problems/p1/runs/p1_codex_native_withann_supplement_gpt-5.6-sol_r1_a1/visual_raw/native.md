# Raw visual perception

- Camera orientation: robot/player seat is at the bottom; opponent seat is at the top.
- Robot hand: extended from the right in a settled-looking pose, with no visible motion blur and no card or chip held. The visible table layout is orderly; no dropped card, scattered chips, or unsafe contact is apparent.
- Turn marker: the white `Your Turn` button is clearly at the bottom/robot seat, so it is the robot's turn.
- Blind markers: the yellow `BIG BLIND` button is at the bottom/robot seat. The dealer/small-blind markers are on the top/opponent side. The robot is the big blind.
- Community-card lane: no face-up community cards are visible. Five face-down card backs occupy the board positions and are not read or counted as community cards.
- Robot hole-card area: two face-down cards are present in the normal bottom-seat positions.
- Opponent hole-card area: two face-down cards are present in the normal top-seat positions. They have not been moved into the board lane, so there is no visual fold/muck signature.
- Showdown: neither player's hole cards are face-up, no board cards are face-up, and no fold/muck outcome is visible. This is not a showdown.
- Robot/player inventory (bottom seat), counted as individual flat chip faces: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Opponent inventory (top seat), counted as individual flat chip faces: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot current-bet area, on the lower/robot side of the board: no red, blue, green, or brown bet chips visible.
- Opponent current-bet area, on the upper/opponent side of the board: no red, blue, green, or brown bet chips visible.
- Scene judgment: the image is sharp, the robot hand appears settled, and game objects are undisturbed. The scene is visually stable and consistent with an idle preflop state.
- Uncertainty: none of the structured fields requires inheritance or a low-confidence estimate.
