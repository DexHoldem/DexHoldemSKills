# Perception evaluation

The current capture is a settled-looking preflop/idle scene. Visual evidence determines the state: the bottom-seat `Your Turn` marker makes `is_my_turn` true, and the bottom-seat yellow `BIG BLIND` marker makes the robot/player the big blind. No shared cards or bet chips are visible, and both players' hole cards remain face-down in their normal areas, so this is not showdown.

Each inventory was counted directly from the visible flat chip faces: both robot and opponent have 4 chips of each denomination (5, 10, 50, 100). Both current-bet objects are all zero.

Merging was minimal. `action_sequence.json` supplies compatible idle context but does not override the image. `hole_card_cache.json` has no known hole cards or blind assignment, and no previous `sN-1/01_parsed_state.md` was available to inherit durable fields. `scene_stable` is set true from the sharp, settled-looking current frame and idle context, but is listed in `uncertain_fields` because it could not be confirmed against a previous frame.
