# Perception and merge report

Direct visual inspection indicates robot turn, robot big blind, no face-up community cards, and no showdown. Both inventories contain four visible chips of each denomination. No bet chips are visible; opponent bet counts are uncertain because the robot assembly obscures the far-right betting region.

The current capture resolves to the initial `s0` frame. No previous parsed state or comparison image exists, so no durable values were inherited. The prior action sequence has no dispatched atom and reports idle; this was used only as context. The hole-card cache has no known card identities or blind assignments. Blind and turn values were read from the visible buttons. Face-down cards were excluded from the community-card list and no card values were invented.

The near-rest hand and orderly layout support an estimated `idle` stage and stable scene. Without a second frame, motion cessation remains unverified, so `loop_stage` and `scene_stable` are listed as uncertain alongside `opponent_bet`. All required fields have concrete estimates; chip objects use the required four integer-count keys.

No robot actions, helper scripts, cache modifications, or poker decisions were performed. Outputs are limited to the requested perception artifacts.
