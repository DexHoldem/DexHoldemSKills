# Perception evidence and merge

Read all field guidelines and directly inspected the current capture, which points to `s0/00_capture.jpg`. The visible turn marker establishes the robot's turn, and the dealer/small-blind and big-blind markers establish the robot as big blind. Each inventory contains four visible chips of each denomination. No bet chips are visible. Five central card backs contribute no face-up community cards. Hole cards remain face-down in normal seat positions, with no showdown or clear fold evidence.

Merged current visual observations into the requested schema. The prior workflow is idle with no dispatched atom, consistent with the image; it was used only as context. The cache supplies no known hole cards or blinds. There is no previous parsed state to inherit from or previous image to compare.

Concrete estimates are supplied for all fields. `loop_stage` and `scene_stable` are flagged because idle/stability is inferred from a single apparently settled view. `opponent_bet` is flagged because its right portion is occluded; zero is the best visible estimate for every denomination. Counts were obtained from individual chip faces rather than the illustrative schema values. No hidden card identities or hidden chips were invented.

No robot actions, helper scripts, or poker decisions were executed. Outputs consist solely of raw evidence, structured perception, and this merge report.
