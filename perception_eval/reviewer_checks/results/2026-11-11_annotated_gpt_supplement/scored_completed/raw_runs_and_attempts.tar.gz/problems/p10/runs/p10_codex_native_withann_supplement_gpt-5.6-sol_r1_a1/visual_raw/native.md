# Raw Visual Perception

## Current capture

- Orientation: robot/player seat is at the bottom; opponent seat is at the top. The central community-card row is empty.
- Scene stability: **Unstable.** In `s_current/00_capture.jpg`, the dexterous hand and forearm are extended across the lower-right table and are not near the initial/rest pose. The fingertips are at a blue 10-chip in the lower central betting lane. This is consistent with a chip-push atom still in progress, not a settled post-atom view. No unrelated object is visibly disturbed.
- Robot behavior: the hand appears to be contacting or transporting one blue 10-chip. The gripper and arm occlude much of the right half of the table, including some inventory denominations and betting-lane detail. There is no visible dropped card, scattered chip group, or other human-help condition.
- Turn marker: the white `Your Turn` button is clearly visible in the bottom-left robot seat area, so `is_my_turn` is true.
- Community cards: no face-up shared cards are visible in the central row.
- Showdown: neither seat has face-up hole cards and there is no fold/muck signature. This is not a showdown.
- Blind: the current capture does not provide a clearer complete button read because of occlusion. The durable cache identifies the opponent as dealer/small blind and the robot as big blind, so the robot blind is inherited as `big_blind`.

## Chips and bets

- Robot/player inventory, bottom seat: 4 red 5-chips are visible; 3 blue 10-chips remain visibly grouped in inventory. Green 50- and brown 100-chip groups are occluded by the arm, so their prior durable counts of 4 each are inherited.
- Opponent inventory, top seat: the visible/previously established groups support 3 red 5-chips and 4 blue 10-chips. Green 50- and brown 100-chip groups are substantially occluded, so their prior durable counts of 4 each are inherited.
- Robot current bet, lower betting lane: best current estimate is one blue 10-chip and no red, green, or brown chips. The blue chip is still under/at the gripper, so its zone assignment is uncertain while the atom is in progress.
- Opponent current bet, upper betting lane: one red 5-chip remains the best estimate; no blue, green, or brown bet chips are evident. The hand partly occludes this lane, so this is inherited from the immediately prior parsed state and marked uncertain.

## Context use

`action_sequence.json` says a 10-chip call step was dispatched and verification is pending. That context agrees with, but does not override, the visible extended hand and blue chip. The previous parsed state supplies only durable values hidden by the current occlusion. No poker action is selected here.
