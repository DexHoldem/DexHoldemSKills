# Raw visual perception

Capture: `s_current/00_capture.jpg` (`s22/00_capture.jpg`). Compared with `s21/00_capture.jpg` and `s20/00_capture.jpg`; all three image files are identical.

- **Scene/robot:** The dexterous hand is extended across the center-right table and its red fingertips touch or cover a blue chip in the lower/robot-side betting lane. It is not near its rest pose and is not holding a card. The chip-push atom recorded as dispatched has no visible change across these frames. Its completion or failure cannot be judged from this extended pose. The hand and arm hide much of the right table, including portions of both players' green/brown inventories and the opponent betting lane. No clearly displaced card or scattered chips are visible in the exposed area. Treat the current action as still in progress; scene is not sufficiently clear or settled for a completed-atom judgment.
- **Turn:** The white `Your Turn` button is clearly at the bottom-left robot seat. It is the robot's turn.
- **Blinds:** The big-blind assignment for the robot is inherited from the previously recognized dealer/blind position; the blind buttons are not all visible now.
- **Community cards:** No face-up community cards are visible in the central row. The exposed board area is empty; the right end is obscured by the robot.
- **Robot inventory:** Four red 5 chips and three blue 10 chips are visible at the bottom seat. The green 50 and brown 100 groups are hidden by the robot; best estimates are four each from the prior state.
- **Opponent inventory:** Three red 5 chips and four blue 10 chips are visible at the top seat. The green 50 and brown 100 groups are hidden by the robot; best estimates are four each from the prior state.
- **Robot current bet:** One blue 10 chip is visible under the fingertips in the lower/robot-side betting lane. No other bet chips are visible there. Its exact final placement remains uncertain while the hand contacts it.
- **Opponent bet:** The opponent betting lane is occluded. The prior count of one red 5 chip is the best estimate; the other denominations remain zero by prior state, with the whole bet count uncertain.
- **Showdown:** Opponent hole cards are not shown face-up; robot hole cards are not shown face-up. No fold/muck or showdown outcome is visible. Cached robot cards (`9d`, `5d`) are context only and are not needed for this frame.
