# Raw Visual Perception

Stable. Compared `s_current/00_capture.jpg` with `s21/00_capture.jpg`, and also checked `s20/00_capture.jpg` and the last clearer near-idle frame `s19/00_capture.jpg`. The current and two preceding frames show the dexterous hand in the same extended pose over the lower/robot chip and betting area. The hand is not visibly moving, and no cards or chips change position across those recent frames. The pose is not near idle and the dispatched blue-chip push has not visibly finished; this is a settled, retryable post-atom condition rather than an actively moving scene.

The white `Your Turn` button is clearly localized at the bottom-left robot seat, so it is the robot/player's turn.

No face-up shared cards are present in the central community-card row. The patterned card backs on the table are face-down cards and are not counted or assigned values. The opponent's hole cards remain face-down in their normal top/opponent area, with no fold/muck displacement. The robot's hole cards are also face-down, and the dexterous hand is not holding a readable card. There is no showdown evidence.

The blind assignment is not re-read from this occluded late-hand frame. The durable recognized assignment is inherited from the cache: dealer/small blind at the opponent seat and big blind at the robot seat.

Robot/player inventory at the bottom seat: best estimate 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips. The arm substantially occludes the green and brown groups and partly overlaps the blue group, so the green/brown counts and the fourth blue chip are inherited from the previous parsed state.

Opponent inventory at the top seat: 3 red 5-chips and 4 blue 10-chips are visible; best estimate 4 green 50-chips and 4 brown 100-chips. The arm/body occludes much of the opponent's right-side green/brown inventory, so those two counts are inherited from the previous parsed state.

Robot current-bet area: no settled bet chip is safely separable from the hand-overlapped robot inventory/push path; best estimate is zero chips of every denomination, consistent with the unchanged preceding frame. Opponent current-bet area: one red 5-chip and no blue 10-, green 50-, or brown 100-chips, consistent with the previous state. The central/right area is partly occluded by the robot, but no additional visible opponent bet chip is present.

The dexterous hand is extended over the lower-center table, touching/overlapping the robot chip path. It is not visibly holding a card or a lifted chip. Its repeated unchanged non-idle pose indicates the chip-push atom stalled or paused and is visually suitable for `to_recover`; no poker action is selected here.
