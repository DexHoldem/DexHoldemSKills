# Raw visual evidence

Unstable. Inspected s_current/00_capture.jpg and compared s22/00_capture.jpg, s21/00_capture.jpg, and the clearer pre-action s18/00_capture.jpg. The recent views look essentially unchanged, but the robot remains extended across the table with its fingertips touching a blue chip in the lower central betting lane. It has not returned to the pre-action pose. A completed push is not visually established; classify the dispatched push_chip_10_1 as still in progress, not a confirmed failure or recovery. Motion cannot be proven from these similar still frames.

The robot enters from the right and blocks the right board area, robot hole cards, green/brown inventories and opponent betting area. No readable held card is visible. No visible scattering or moved non-target object establishes damage.

The white Your Turn marker is clearly at the bottom-left robot seat: it is our turn.

Robot inventory: four red 5-chips and three blue 10-chips are visible below the betting boundary. Green 50 and brown 100 groups cannot be counted in the current capture; estimate four of each from the previous parsed state.

Opponent inventory: three red 5-chips and four blue 10-chips are visible at the top seat. Green and brown groups are obscured; estimate four of each from the previous state, consistent with the clearer s18 view.

Robot current bet: one blue 10-chip is visible beneath the fingertips above the lower inventory boundary. Estimate zero red, green, and brown chips. The blue chip is still in contact with the hand, so its final placement and the occluded portion of this area are uncertain.

Opponent bet: the right betting area is blocked by the robot. No current full count is possible. Retain one red 5-chip and zero blue, green, and brown chips from s21; this is inherited, not a fresh visible count.

No face-up community cards are visible. The visible central patterned rectangle matches the face-down board layout in s18; do not assign any rank or suit. Retain an empty community-card list, with uncertainty because most of the board is occluded.

The blue small-blind marker is visible at the opponent seat, and the white dealer marker is partly visible there. The robot big-blind assignment is retained from the cache and previous state; s18 also shows the yellow big-blind marker at the robot seat.

No face-up opponent hole cards or clear fold/muck displacement is visible. Robot hole cards are occluded, and cached 9d/5d are context only. Estimate not_showdown; the occlusion prevents a complete current check. No hand comparison is warranted.
