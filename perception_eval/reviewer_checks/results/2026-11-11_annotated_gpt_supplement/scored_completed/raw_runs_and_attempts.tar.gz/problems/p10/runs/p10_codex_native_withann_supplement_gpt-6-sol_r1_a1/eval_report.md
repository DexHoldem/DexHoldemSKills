# Perception report

The current capture shows the dexterous hand over a blue chip in the betting lane, substantially displaced from its prior pose. With `push_chip_10_1` dispatched, this supports `acting` and `scene_stable: false`; the chip's final position is not settled. The bottom-left white turn button supports `is_my_turn: true`. No face-up board or showdown cards are visible.

Visible red and blue inventory chips were counted directly. The arm hides both players' green/brown groups and the opponent bet area, so those concrete estimates come from `s9/01_parsed_state.md`; the robot's big blind comes from the recognized blind cache. The blue chip under the gripper is provisionally assigned to the robot bet area. All inherited or placement-sensitive fields are listed in `uncertain_fields`.
