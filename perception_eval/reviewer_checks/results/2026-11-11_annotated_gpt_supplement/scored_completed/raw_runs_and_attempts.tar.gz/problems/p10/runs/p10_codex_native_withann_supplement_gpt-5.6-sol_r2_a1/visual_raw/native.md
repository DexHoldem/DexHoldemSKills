# Raw Visual Perception

## Current-frame evidence

- The robot/player seat is at the bottom and the opponent seat is at the top.
- The dexterous arm is extended across the lower-right/central table. Its fingers are down over a blue 10-chip near the robot inventory-to-bet path. It is not in an idle/rest pose, and it occludes much of the central-right betting area, the opponent betting area, and parts of both chip inventories.
- No card or chip motion blur is visible in the still image. However, the extended contact pose is consistent with the dispatched blue-chip push remaining physically in progress or unresolved. No unrelated object is visibly disturbed.
- The white `Your Turn` button is clearly visible at the bottom-left robot seat: it is the robot's turn.
- No face-up community cards are visible. The visible cards in the player areas are face-down hole cards and are not read as board cards.
- No opponent hole cards are face-up and there is no fold/muck signature or other showdown evidence.
- Robot inventory: four red 5-chips are visible. Three blue 10-chips are clearly visible in the lower inventory column, with a fourth blue chip partly under/adjacent to the dexterous fingers; this fourth chip's zone is ambiguous while the push is unresolved. Green 50- and brown 100-chip groups are substantially occluded.
- Opponent inventory: the upper red and blue groups are partly visible; the green and brown groups are substantially occluded by the robot assembly.
- My betting area: no clearly settled bet chip is visible. The blue chip beneath the fingers is not counted as a completed bet because it remains at the inventory-to-bet path and the atom is unresolved.
- Opponent betting area: substantially occluded. No new bet movement is directly visible.

## Frame comparison and context

- Compared `s_current/00_capture.jpg` with `s21/00_capture.jpg` and `s20/00_capture.jpg`; the table and arm pose appear unchanged across all three frames.
- Despite the lack of inter-frame change, the robot is not near rest and is still in contact with the target-chip area. Under the robot-behavior and stability guidelines, the dispatched `push_chip_10_1` atom is therefore treated as `acting`, and `scene_stable` is false rather than declaring a completed or retryable atom.
- Blind is durably inherited from the recognized cache: robot is big blind.
- Occluded chip counts are inherited from `s21/01_parsed_state.md`: robot 4/4/4/4 and opponent 3/4/4/4 by denominations 5/10/50/100.
- The prior opponent bet of one red 5-chip is inherited because its betting area is occluded and no visible evidence shows a change. All other inherited bet denominations remain zero.

