# Native visual evidence

Unstable for completion verification. Compared the current capture (`s_current`, resolving to `s22`) with `s21/00_capture.jpg` and `s20/00_capture.jpg`. The hand and table appear essentially unchanged. Nevertheless, the robot remains extended over the lower central betting lane, with fingertips contacting or immediately above one blue chip. It has not visibly returned to rest, and the occlusion prevents confirming a completed atom. Motion cannot be established from these unchanged frames; `acting` is a conservative, uncertain estimate of ongoing execution, not proof of motion. No completed-action failure or recovery is established.

The white “Your Turn” marker is clearly visible in the bottom robot seat area. It is our turn.

Robot inventory, outside the betting lane: four red 5-chips and three blue 10-chips are visible. Green 50- and brown 100-chip groups are blocked by the robot; neither can be counted. Retain four of each from the previous parsed state as uncertain estimates.

Opponent inventory at the upper rail: three red 5-chips and four blue 10-chips are visible. The right-hand inventory groups are occluded; retain four green 50-chips and four brown 100-chips from the prior state, uncertain.

Robot current bet: one blue 10-chip is visible beneath the fingertips, above the inventory boundary in the lower central lane. Count it in the current bet as a provisional location-based estimate; the push may still be underway. No red, green, or brown bet chips are visible. The hand blocks part of this zone.

Opponent bet: the relevant upper/right central area is blocked by the robot. No reliable current count is possible; retain the prior one red 5-chip and zero chips of the other denominations, all uncertain as an occluded field.

No face-up community cards are visible. A patterned card back near the hand is not a readable community card. The central/right board region is occluded, so retain the previous empty board with uncertainty. The far-left card backs belong to the deck area.

The upper seat has a blue blind-style marker and a partly visible white marker. Their labels are not sufficiently readable to independently establish assignment. Retain robot big blind from the prior parsed state and cached opponent dealer/small blind assignment.

No readable held card, face-up opponent hole cards, or conclusive fold/showdown evidence is visible. Retain `not_showdown`; cached robot cards 9d and 5d are context only and are not newly observed. The occluded card areas limit certainty.

The prior dispatched `push_chip_10_1` explains the target but does not establish success. The previous `to_recover` label and simulated-pause note do not override the current physical view. No robot action or poker action was selected or executed.
