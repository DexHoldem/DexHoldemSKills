# Raw visual perception

- Capture: `s_current/00_capture.jpg` (`s22/00_capture.jpg`); compared with `s21/00_capture.jpg`.
- The scene is not settled: the robot arm/hand is extended over and occludes much of the lower robot-side chip and betting area. The frame is effectively unchanged from the prior frame, so the dispatched chip movement appears still in progress.
- The white `Your Turn` button is visible near the bottom robot seat, indicating it is the robot's turn.
- No face-up community cards are visible.
- Robot-side inventory estimate: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips; the lower/right groups are partly occluded by the robot hardware.
- Opponent-side inventory estimate: 3 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Robot current-bet area: no bet chip is safely visible while the hand is extended; estimate remains zero in every denomination.
- Opponent current-bet area: 1 red 5-chip, with no blue, green, or brown bet chips visible.
- No showdown or fold evidence is visible. Cached hole cards are not needed for this non-showdown frame.
