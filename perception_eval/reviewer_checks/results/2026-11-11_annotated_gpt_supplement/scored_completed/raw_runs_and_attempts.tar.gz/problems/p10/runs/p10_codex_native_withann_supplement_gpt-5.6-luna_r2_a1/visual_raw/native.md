# Raw visual perception

- Source frame: `s22/00_capture.jpg` (used as the current frame because no literal `s_current/` directory is present).
- Comparison frame: `s21/00_capture.jpg`.
- Scene: the dexterous hand and robot body are extended across the lower/robot-side betting area and visibly occlude part of the table. The hand is not in a settled near-idle pose; the dispatched chip-push action appears still in progress.
- Turn: the white `Your Turn` marker is visible at the bottom/robot side, so it is the robot's turn.
- Board: no face-up community cards are visible; the center board area is empty.
- Showdown: no exposed hole cards, fold outcome, or win/loss indication is visible.
- Blind: the robot is the big blind per the recognized blind assignment cache; no contrary current marker is visible.
- Robot inventory: visible lower groups are consistent with approximately 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips. The robot/body occludes part of this inventory, so the counts are low-confidence, especially blue/green/brown separation.
- Opponent inventory: approximately 3 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips are visible in the upper/opponent inventory area.
- Betting areas: one blue 10-chip is visible at/under the robot hand in the lower/robot-side bet lane, consistent with the dispatched call. The upper/opponent-side bet lane retains an estimated one red 5-chip from the visible layout, but the robot occlusion makes this low-confidence.
