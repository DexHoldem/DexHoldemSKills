# Evaluation report

The capture was compared with the previous frame. The robot hand remains extended over the lower table and obscures the robot-side chip/bet zones, while the table otherwise appears unchanged. The dispatched 10-chip call cannot yet be confirmed physically, so the state is `acting` and the scene is unstable. Counts in the occluded robot-side zones inherit the prior visible estimate; the opponent's single red bet chip and the robot-turn button remain visible. No community cards or showdown evidence are present.
