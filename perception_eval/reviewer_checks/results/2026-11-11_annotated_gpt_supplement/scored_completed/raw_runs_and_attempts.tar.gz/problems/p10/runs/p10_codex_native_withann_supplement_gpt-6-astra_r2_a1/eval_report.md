# Perception and merging

Read all field guidelines, the current capture (s22), prior workflow context, hole-card cache, and s21 parsed state; compared s20 and s21 captures for stability.

Current visible counts override prior counts: three robot inventory blue chips and one blue chip in the robot betting lane, beneath the hand. Four robot red chips, three opponent red chips, four opponent blue chips, and the robot-side turn marker are directly visible.

Inherited hidden green/brown inventory counts (four each per seat), the opponent bet (one red chip), and robot big blind. Retained an empty board and no-showdown estimate because no contrary visible evidence exists. Occluded or inferred fields are explicitly listed in `uncertain_fields`; raw evidence distinguishes visible components from inherited components.

Although the compared frames appear unchanged, the extended hand remains at the chip and hides the action result. Conservatively classified `acting` with `scene_stable: false`, both uncertain. Did not inherit the prior recovery label or treat the dispatched command as proof of success. A static capture sequence does not establish whether this is a pause or completed motion.

Only perception output files were written. No helper scripts, robot commands, or poker decisions were run.
