# Raw perception evidence

- Current capture: `s_current/00_capture.jpg`; compared with `s21/00_capture.jpg` and `s20/00_capture.jpg`. The visible table and extended robot hand look essentially unchanged across these frames. The dexterous hand is over a blue chip in the robot betting lane and has not returned to a clear rest pose. The dispatched chip push cannot be verified as complete from this view. The scene is treated as unstable and the atom as still acting; there is no visible basis to declare a settled retry or failure.
- The white `Your Turn` button is at the bottom robot seat. The opponent has the dealer/small-blind button according to the visible top-side marker and the cached preflight read; the robot is big blind.
- No face-up community cards are visible. Both players' hole cards remain face-down or obscured; no fold or showdown is visible. No held face-up card is readable.
- Robot inventory, bottom side: four red 5 chips and three blue 10 chips are visible. A fourth blue chip is in/under the hand in the betting lane. The green 50 and brown 100 inventory groups are hidden by the arm; carry forward four of each from `s21/01_parsed_state.md` with uncertainty.
- Opponent inventory, top side: three red 5 chips and approximately four blue 10 chips are visible. The green 50 and brown 100 groups are occluded; carry forward four of each with uncertainty.
- Robot current bet: one blue 10 chip is partly visible under the fingers in the lower betting lane. Its final placement remains uncertain while the hand is there. No other bet chips are visible on that side.
- Opponent bet: one red 5 chip is partly visible near the opponent betting lane, consistent with the prior parsed state. No blue, green, or brown opponent bet chips are visible; the arm blocks part of this lane.
- The prior action sequence says `push_chip_10_1` was dispatched for a call. That is context for the extended hand, not proof that the chip push finished.
