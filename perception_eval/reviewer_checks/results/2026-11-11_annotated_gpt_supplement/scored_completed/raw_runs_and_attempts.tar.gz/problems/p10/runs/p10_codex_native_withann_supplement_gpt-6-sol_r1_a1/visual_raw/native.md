# Raw visual perception

- Compared `s_current/00_capture.jpg` with `s9/00_capture.jpg`. The robot arm and hand have moved from the right side into the central betting lane. The gripper is low over a blue 10 chip near the robot side of the lane, consistent with the dispatched push still being in progress. The hand has not returned to an idle pose. Scene is unstable.
- The white `Your Turn` button is visible at the bottom-left robot seat. It indicates the robot's turn.
- No face-up community cards are visible. The five central card positions remain face-down/empty-looking board slots; the opponent's hole-card backs remain near the top seat. No showdown or fold is visible.
- Robot inventory, bottom seat: four red 5 chips and three blue 10 chips are visible. The fourth blue chip from the preceding inventory appears under the gripper in the betting lane, so the blue count/placement is provisional while the push is underway. The green 50 and brown 100 inventory groups are hidden by the arm; best estimates are four each from the previous state.
- Opponent inventory, top seat: three red 5 chips and four blue 10 chips are visible. Green 50 and brown 100 groups are hidden by the robot arm; best estimates are four each from the previous state.
- Robot bet area: one blue 10 chip appears under the gripper in the robot-side betting lane; no other bet chips are visible. Its final placement is uncertain while the arm is over it.
- Opponent bet area: occluded by the arm. Best estimate is one red 5 chip from the preceding parsed state; denomination and count cannot be confirmed in the current capture.
- Blind assignment is inherited from the recognized dealer/blind cache: opponent is dealer/small blind, robot is big blind. No blind change is visible in this capture.
