# Perception and merging

Read all field guidelines and inspected s22 via s_current, plus s21 and s20 for stability. Since s_current resolves to s22 and no literal sN-1 directory exists, s21/01_parsed_state.md supplies prior state.

Current visible evidence sets turn=true, robot inventory red=4/blue=3, opponent inventory red=3/blue=4, and a provisional robot bet of one blue chip. This overrides the previous robot blue inventory=4 and blue bet=0. No face-up board or showdown is visible.

Occluded green/brown inventories retain four each from s21. Opponent bet retains one red chip; blind assignment retains big_blind, corroborated by the cache. The partially hidden empty board also uses prior context. Inherited and provisional fields are explicitly listed in uncertain_fields; a field-level chip flag covers its hidden denominations.

Although adjacent frames appear essentially unchanged, the hand remains over the target chip away from rest. Completion is unverified, so acting and scene_stable=false are conservative estimates, both flagged. The prior simulation-driven to_recover label is not inherited. No failure, recovery, or showdown outcome is asserted.

No helper scripts, robot actions, or poker decisions were executed. Outputs contain concrete estimates with no null values.
