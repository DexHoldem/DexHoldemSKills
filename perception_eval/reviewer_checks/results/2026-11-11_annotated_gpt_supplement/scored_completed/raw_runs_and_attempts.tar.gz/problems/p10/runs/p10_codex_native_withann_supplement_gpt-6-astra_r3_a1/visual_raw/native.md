# Native perception evidence

Unstable for completion assessment. Compared s_current/00_capture.jpg (s22) with s21/00_capture.jpg and s20/00_capture.jpg. The three views look essentially unchanged, but the dexterous hand remains extended low over the robot betting lane, with fingertips over a blue chip. It is not visibly returned to rest, and completion/release cannot be established. Still in progress is the best estimate; actual motion cannot be proven from these nearly identical frames. No readable held card is visible.

The bottom seat is the robot; the top seat is the opponent. Inventory chips are outside the central betting lane. Individual flat chip faces, rather than stack heights, were counted.

- Turn: the white “Your Turn” marker is clearly at the bottom robot seat. It is our turn.
- Board: no face-up community cards are visible. Card backs are visible near the center-left and top hole-card area; they are not readable community cards. Much of the center-right is occluded, so the empty board is also supported by the previous state.
- Robot inventory: four red 5-chips and three blue 10-chips are visible at the bottom. Green 50 and brown 100 groups are blocked by the robot body and cannot be counted; estimate four of each from s21.
- Opponent inventory: three red 5-chips and four blue 10-chips are visible at the top. Green and brown groups are occluded; estimate four of each from s21.
- Robot current bet: one blue 10-chip is visible beneath the fingertips, inside the lower betting lane and beyond the inventory boundary. Estimate zero red, green, and brown bet chips. Chip placement is provisional because it remains under the hand and the lane is partly blocked.
- Opponent bet: the upper/right betting region is blocked by the hand/body. Its chips cannot be reliably counted. Inherit one red 5-chip and zero other denominations from s21; these are not current visual confirmations.
- Blinds: a blue button and partial white marker are at the opponent seat, but their lettering is not safely readable. Inherit robot big blind from s21 and the cache, which records opponent dealer/small blind.
- Showdown: no face-up opponent hole cards, readable revealed hands, or clear displaced opponent-card fold signature are visible. Estimate not_showdown. Cached robot cards 9d and 5d are context only, not current face reads, and do not establish an outcome.

The action context records a dispatched push_chip_10_1. The visible blue chip supports a push in progress, not a verified completed sequence. The prior to_recover label and simulation note do not override the current physical pose. There is insufficient settled post-action evidence to label failure or recovery.
