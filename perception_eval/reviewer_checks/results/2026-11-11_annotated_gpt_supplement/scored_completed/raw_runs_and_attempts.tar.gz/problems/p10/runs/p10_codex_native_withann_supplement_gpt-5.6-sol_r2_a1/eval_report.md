# Perception Evaluation

The white turn button is visibly at the robot seat, no community cards are face-up, and no showdown or fold evidence is present. The robot arm is extended over and in contact with the blue-chip path rather than at rest. The current frame matches s21 and s20, but the dispatched chip-push atom remains physically unresolved, so the merged state is `acting` with `scene_stable: false`.

Directly visible counts were used where possible. Values hidden by the robot assembly were inherited from the prior parsed state: robot chips 4/4/4/4, opponent chips 3/4/4/4, and the opponent's prior single red 5-chip bet. The blue chip under the fingers is retained in robot inventory and not counted as a completed current bet; both that zone assignment and all occlusion-based inherited values are listed in `uncertain_fields`. Blind is inherited from the recognized cache as `big_blind`.
