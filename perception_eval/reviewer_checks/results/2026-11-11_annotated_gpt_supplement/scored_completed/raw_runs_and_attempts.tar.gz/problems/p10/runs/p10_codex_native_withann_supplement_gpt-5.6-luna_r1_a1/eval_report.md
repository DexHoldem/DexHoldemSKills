# Evaluation report

The latest available capture was used because `s_current/00_capture.jpg` is missing; it is `s22/00_capture.jpg`. The robot hand is extended over the chip/betting region while the dispatched `push_chip_10_1` step is underway, so the scene is marked unstable and the loop stage is `acting`. The `Your Turn` button establishes robot turn, and the cached blind assignment establishes big blind. No community cards or showdown evidence are visible. Inventory and bet counts are concrete estimates inherited from the previous stable parsed state because the current hand/camera occlusion prevents a reliable fresh count.

