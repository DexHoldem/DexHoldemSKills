# Perception Evaluation Report

The current capture is an unstable `acting` frame. The robot arm is extended over the lower betting lane, and the gripper is contacting or transporting a blue 10-chip. The visible `Your Turn` button remains at the robot seat, the community-card row is empty, and no showdown evidence is present.

The best visual estimate moves one blue 10-chip from robot inventory to the robot betting lane: robot blue inventory is 3 and robot blue bet is 1. Both values are marked uncertain because the chip is still under the gripper during an unfinished atom. The opponent's red 5-chip bet and all chip denominations hidden by the arm were merged from the immediately prior durable state; those inherited/occluded values are listed in `uncertain_fields`. The cached blind assignment supplies `big_blind` for the robot and is also marked uncertain because it is not freshly readable in this capture.

No robot command or poker decision was executed.
