# Perception and merging

Read all visual_guidelines files, the capture, action_sequence.json, hole_card_cache.json, and the latest available parsed state, s21/01_parsed_state.md. There is no literal sN-1 directory; s22 contains only a capture. Compared s21 and s22 captures and the clearer s18 pre-action capture.

Current visual evidence overrides the previous synthetic recovery note: the hand remains extended in contact with the pushed blue chip, so the conservative current estimate is acting with scene_stable false. Similar recent frames do not prove completion or a harmless failed push; this temporal ambiguity is flagged.

Visible robot blue inventory changes from four to three, and the blue chip now in the betting lane is counted as one current bet, provisionally while still under the hand. Visible robot red and opponent red/blue counts are freshly counted. Hidden green/brown inventories and the opponent bet are inherited from s21. Blind assignment is retained from cache with earlier visual corroboration. Empty board and not_showdown are concrete estimates with current occlusion flagged. The white bottom-left turn button directly establishes is_my_turn true.

All inherited, inferred, partially occluded, or low-confidence fields are listed in uncertain_fields. No robot commands, helper scripts, poker action selection, or cache modifications were performed.
