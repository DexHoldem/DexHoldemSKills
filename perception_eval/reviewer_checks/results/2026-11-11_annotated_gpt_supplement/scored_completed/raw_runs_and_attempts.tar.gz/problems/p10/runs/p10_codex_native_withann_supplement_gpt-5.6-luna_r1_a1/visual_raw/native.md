# Raw visual perception

## Source and context

- Requested source `s_current/00_capture.jpg` is absent.
- Used the latest available capture, `s22/00_capture.jpg`, and compared it with `s21/00_capture.jpg` and the prior parsed state.
- `action_sequence.json` says a `call` sequence is dispatched with `push_chip_10_1`; this is context only.

## Scene and robot behavior

- The dexterous robot hand/arm is visibly extended over the lower/central chip area and blocks a substantial portion of the table.
- The hand is not in a settled near-idle pose; the dispatched chip-push action appears still in progress.
- Therefore the scene is unstable/acting, not ready for a post-action recovery judgment.

## Turn and blind

- The white `Your Turn` button is visible at the bottom/robot seat, so it is the robot's turn.
- Cached blind assignment says the robot is the big blind; no current visual conflict is visible.

## Cards and outcome

- No face-up community cards are visible; the board is empty for this parse.
- No showdown or folded-card signature is visible. Cached robot hole cards are `9d` and `5d`, but they are not face-up in this frame.

## Chips and bets

- Inventory groups are partially visible but the robot hand/camera occludes the lower robot-side groups and central betting lane. Counts are inherited from the previous stable parsed state: robot inventory 4/4/4/4 and opponent inventory 3/4/4/4 in denomination order 5, 10, 50, 100.
- The previous stable state showed one red 5-chip in the opponent betting area and no robot bet chips. The current frame does not safely expose the full betting areas, so those estimates are retained with uncertainty.

