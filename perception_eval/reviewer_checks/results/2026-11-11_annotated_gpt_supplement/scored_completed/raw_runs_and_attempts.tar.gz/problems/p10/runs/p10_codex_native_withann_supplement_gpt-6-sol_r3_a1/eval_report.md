# Perception report

`s_current` resolves to `s22`. Its capture is byte-identical to `s20` and `s21`. The white `Your Turn` button, exposed red/blue inventories, and one blue chip in contact with the robot fingertips support the current visual counts. No face-up board or showdown cards appear.

The prior parsed state and blind cache provide the blind, hidden green/brown inventories, and occluded opponent bet estimate. The current image takes precedence for the visible blue chip: robot inventory is estimated at three blue chips with one in the betting lane. The hand remains extended over that chip, so the dispatched push is treated as acting and the scene as unstable; no completed-atom success or failure is asserted. Uncertain fields in the JSON identify occluded, inherited, or still-moving observations.
