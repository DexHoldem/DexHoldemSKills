# Raw visual perception

Unstable. Compared `s30/00_capture.jpg` (`s_current`), `s29/00_capture.jpg`, and the clearer `s28/00_capture.jpg`. The dexterous hand has moved from the right side of the board to the left betting area and is in contact with a brown chip. The dispatched chip push is still in progress; the arm is extended across and occludes much of the board and the right betting area. No settled post-action state or clear physical failure is visible. The hand is not holding a card.

- The white **Your Turn** button is visible near the bottom-left robot seat: it is the robot's turn by the button cue.
- The yellow **Big Blind** button is near the bottom robot seat. The prior recognized dealer assignment also places the robot as big blind.
- Four face-up community cards are on the board. The first is visibly **8h** and the second **7d**. The arm hides the remaining two in this frame; the clearer `s28` image shows **6s, Jc**. The prior parsed state said `Qh` for the first card, but the card face in `s28` and the current image reads `8h`.
- No face-up opponent hole cards or displaced face-down cards indicating a fold are visible. The robot's hole cards remain face-down. No showdown result is evident.
- Robot inventory at the bottom: four red 5 chips and three blue 10 chips are clear; three green 50 chips and about two remaining brown 100 chips are estimated from the prior arrangement because the arm covers the right side. The brown inventory count may still be changing during the push.
- Opponent inventory at the top: two red 5 chips, four blue 10 chips, three green 50 chips, and three brown 100 chips, using the latest clear view where the arm does not block the top-right groups. The current arm obscures much of that inventory.
- Robot bet on the left side of the community row: one blue 10, one green 50, and approximately two brown 100 chips. The hand is touching the brown-chip area, so its final count is uncertain. No red 5 chip is identifiable there.
- Opponent bet on the right side of the community row: inferred from the immediately preceding parsed/visible layout as two red 5 chips, one green 50 chip, and one brown 100 chip; no blue 10 chip. The arm blocks this zone in the current frame, so all opponent-bet counts are uncertain.
