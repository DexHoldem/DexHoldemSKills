# Perception and merge summary

The current image shows the robot hand extended to a brown 100 chip in the robot betting lane. The hand has not settled, so the scene is unstable and the loop remains **acting**, regardless of the dispatched step recorded in `action_sequence.json`. The white turn button is at the robot seat; no face-up community cards or showdown evidence is visible.

Robot red chips and the turn/button positions come from the current image. The robot's blue and green inventory counts, opponent inventory, and opponent red bet are retained from `s14/01_parsed_state.md` because the arm blocks those zones. One brown chip is estimated to be moving from robot inventory into its bet area, so both counts are provisional. The cached blind assignment in `hole_card_cache.json` supports the robot's big-blind field. All estimates affected by occlusion or the unfinished movement are listed in `uncertain_fields`.
