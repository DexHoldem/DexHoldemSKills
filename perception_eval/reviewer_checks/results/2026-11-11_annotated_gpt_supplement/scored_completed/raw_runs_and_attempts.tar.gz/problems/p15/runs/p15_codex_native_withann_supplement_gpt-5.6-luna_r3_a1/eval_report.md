# Perception evaluation

The latest capture was parsed as an in-progress robot action: the hand is extended and substantially occludes the table, so `loop_stage` is `acting` and `scene_stable` is `false`. The bottom-side `Your Turn` marker supports `is_my_turn: true`; the visible yellow button and cache support `blind: big_blind`. No showdown or outcome evidence is present.

The four-card board, inventories, and bet counts are carried forward from the prior parsed state because the current frame does not safely expose those regions. They are explicitly listed in `uncertain_fields`. The dispatched 100-chip push was not treated as complete, so no speculative bet/inventory mutation was applied.
