# Perception summary

The capture shows the dispatched 100-chip push still underway: the robot hand is extended across the board and touching the left betting area. The scene is unstable, so the visual stage remains `acting`. The white turn button is at the robot seat; the robot is big blind. There is no visible showdown or fold.

The current image shows the first two board cards; the clearer `s28` image supplies the two cards hidden by the arm. The first card reads **8h** in the images, correcting the prior parsed state's `Qh`. Chip counts use visible groups where possible and prior layout for occluded zones. The pushed brown chip, the remaining brown inventory, and the opponent bet are provisional until the arm settles and they can be seen clearly.
