# Raw visual perception evidence

- Input mapping: no literal `s_current/` exists; used newest capture `s30/00_capture.jpg`. Prior context used: `s29/01_parsed_state.md`.
- Scene: unstable. The robot arm/hand is extended over the table and appears to be actively pushing or transferring a chip, consistent with the dispatched `push_chip_100_1` step. It has not settled into an idle pose.
- Turn: the white `Your Turn` button is visible at the bottom/robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is visible near the robot-side lower table; robot is big blind.
- Community cards: the central board is substantially occluded by the robot body/arm in the current frame. The prior settled read is `Qh 7d 6s Jc`; no evidence indicates a board change.
- Robot inventory: bottom-side chip groups are partly visible; the right-side/brown-chip area is occluded during the action. Inherited concrete count: red 5 x4, blue 10 x3, green 50 x3, brown 100 x3.
- Opponent inventory: top-side groups are visible only in part and the current camera/robot occlusion makes a fresh complete count unsafe. Inherited concrete count: red 5 x2, blue 10 x4, green 50 x3, brown 100 x3.
- Betting areas: the right-side betting lane is occluded by the robot body/arm while the 100-chip push is in progress. Inherited concrete counts are robot bet red 5 x0, blue 10 x1, green 50 x1, brown 100 x1; opponent bet red 5 x2, blue 10 x0, green 50 x1, brown 100 x1.
- Showdown: no face-up showdown state or fold/muck signature is visible; outcome is not_showdown.

