# Raw visual perception

- Capture inspected: `s30/00_capture.jpg`; compared with `s29/00_capture.jpg`.
- Table geometry: robot/player seat is at the bottom; opponent seat is at the top. The robot arm enters from the right.
- Scene/robot: the dexterous hand and arm are extended across the table and are not in a settled idle pose. The arm blocks much of the center/right board, betting lane, and opponent-side inventory. This is consistent with the dispatched `push_chip_100_1` step still being in progress. No clear physical failure or displaced card is visible.
- Turn: the white `Your Turn` button is visible at the bottom robot-side seat area, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is visible on the robot/bottom side; the cached session assignment also identifies the robot as big blind.
- Community cards: the current arm occludes the board row. The durable prior read is four face-up board cards, `Qh`, `7d`, `6s`, `Jc`; no visual evidence of a new community card is available in this unstable frame. These are inherited and marked uncertain in the structured output.
- Hole cards/showdown: no showdown is visible. The cached robot hole cards are `9d` and `5d`; opponent cards are not face-up/readable and no fold/muck is evident.
- Robot inventory: visible bottom-side chip groups remain consistent with 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips, but the active hand partly occludes the area. Counts are inherited where blocked.
- Opponent inventory: the top-side groups are partly blocked by the robot arm. Best estimate is 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips, inherited from the prior stable parse.
- Current bets: the central betting lanes are not safely countable while the hand is moving. Best available estimate is robot/bottom-side bet: 0 red, 1 blue, 1 green, 1 brown; opponent/top-side bet: 2 red, 0 blue, 1 green, 1 brown, inherited from the prior parse. The dispatched 100-chip push may change the robot bet after completion, but completion is not visually established.
- Overall confidence: low for occluded board/inventory/bet fields; high for acting/unstable state and visible robot turn button.
