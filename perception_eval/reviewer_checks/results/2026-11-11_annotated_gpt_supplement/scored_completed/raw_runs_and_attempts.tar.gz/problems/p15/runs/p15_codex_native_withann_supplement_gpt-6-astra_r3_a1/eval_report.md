# Perception and merging

Read the field guidelines and inspected s30 (the s_current target), s29, and s28 directly. The literal sN-1 path does not exist; s29 is the actual predecessor and supplied the previous parsed state.

Current hand displacement and fingertip contact support acting and an unstable scene independently of the prior dispatched status. The turn marker and big-blind marker are directly visible at the robot seat. No robot action or poker decision was executed or selected.

Updated the robot's brown inventory estimate from three to two and its brown bet count from one to two based on the chip visibly transported into the left betting area. This is a provisional spatial count, not certification that the push completed. Other occluded chip counts were retained from prior evidence and marked uncertain.

Corrected prior board labels Qh/Jc to 8h/7c using the clear s28 image; the current exposed left card is consistent with 8h. Retained 7d and 6s and the four-card board under present occlusion. No hidden or face-down card identity was newly guessed. No showdown is evidenced; opponent-card occlusion is recorded as uncertainty.

All required schema fields have concrete estimates. Uncertainty lists inherited, inferred, and occluded values. Source workflow/cache files were not modified.
