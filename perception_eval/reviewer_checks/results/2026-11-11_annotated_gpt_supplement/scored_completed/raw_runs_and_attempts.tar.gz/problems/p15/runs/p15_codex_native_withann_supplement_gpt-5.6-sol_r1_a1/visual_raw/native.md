# Raw Visual Perception

Current image inspected: `s_current/00_capture.jpg`.
Comparison images: `s29/00_capture.jpg` and settled pre-action frame `s28/00_capture.jpg`.

- Stability and robot: Unstable. The dexterous arm has moved substantially leftward from its s29 position and is extended across the table. Its fingertips are down in contact with the left-side betting cluster, consistent with the dispatched 100-chip push still being in progress. The hand is not near idle, and the arm heavily occludes the board, both betting areas, and the lower-right inventory. No physical failure or disturbed non-target object is evident in this unsettled frame.
- Turn: The white `Your Turn` button is clearly visible at the bottom-left robot seat, so it is the robot's turn.
- Blind: The yellow `BIG BLIND` button is visible at the bottom/robot side. This agrees with the recognized durable blind assignment: robot is big blind.
- Community cards: The board is heavily occluded in the current frame. Portions of the existing face-up board remain visible, but the full ranks and suits cannot be safely reread. The previous stable board, carried forward as an uncertain durable value, is `Qh 7d 6s Jc` from left to right. There is no visual evidence of a newly dealt fifth card.
- Robot inventory: Four red 5-chips and three blue 10-chips remain clearly visible at the bottom. The green and brown groups are occluded. Carry forward three green 50-chips. Estimate two brown 100-chips remain because one brown chip is being transferred by the active push.
- Opponent inventory: Mostly occluded/angled in the current frame; carry forward the prior durable counts: two red 5-chips, four blue 10-chips, three green 50-chips, and three brown 100-chips.
- Robot current bet: The left-side betting cluster is under the fingertips. Carry forward zero red 5-chips, one blue 10-chip, and one green 50-chip; estimate two brown 100-chips after including the brown chip visibly being pushed into this cluster. The whole bet count is uncertain while the push is in progress.
- Opponent bet: The right-side betting area is substantially blocked by the arm. Carry forward two red 5-chips, zero blue 10-chips, one green 50-chip, and one brown 100-chip; all are uncertain in this frame.
- Held card: No card is held by the dexterous hand.
- Showdown: Opponent hole cards are not face-up, robot hole cards remain face-down, and only four community cards are present. No fold/muck signature or showdown is visible; outcome is `not_showdown`.

