# Perception Evaluation

The current scene is visually unstable and remains in `acting`: relative to `s29`, the robot hand has advanced across the table and is now at the robot bet cluster, consistent with the dispatched 100-chip raise step. The white turn button directly establishes `is_my_turn: true`. No showdown, exposed opponent cards, or fold/muck signature is visible.

Directly visible values were used where possible. The four-card board, opponent inventory, opponent bet, and occluded chip denominations were merged from the durable `s29` parse. The robot's brown inventory and brown current-bet counts were advanced by one chip because the current image shows the push reaching the robot bet cluster; those counts remain explicitly uncertain while the hand occludes the destination. The cached blind assignment supplies `big_blind` for the robot.

