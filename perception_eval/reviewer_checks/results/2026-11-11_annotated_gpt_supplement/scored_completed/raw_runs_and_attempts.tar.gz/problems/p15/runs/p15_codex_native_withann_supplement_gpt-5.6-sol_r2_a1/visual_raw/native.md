# Raw Visual Perception

Current image inspected: `s_current/00_capture.jpg`.
Comparison/context: `s29/00_capture.jpg`, `s28/00_capture.jpg`, `s29/01_parsed_state.md`, `action_sequence.json`, and `hole_card_cache.json`.

## Scene and robot

Unstable. Compared the current frame with `s29/00_capture.jpg` and the settled pre-action view `s28/00_capture.jpg`. The robot arm has moved substantially across the table, and the dexterous hand is extended over and touching the lower-left/robot bet cluster. It is not near its idle pose. This is consistent with the dispatched 100-chip push still being executed. The hand is not visibly holding a card. The large arm/camera body occludes much of the board, the right-side betting region, and parts of both chip inventories. No dropped card, scattered chip group, pinned object, or other settled failure is visibly established; the action is still in progress, so no recovery judgment is made.

## Turn and blinds

The white `Your Turn` button is clearly visible at the bottom-left robot seat, so it is the robot's turn. The dealer/blind assignment is not newly readable through the occlusion; the durable recognized assignment is inherited from the cache: dealer/small blind at the opponent seat and big blind at the robot seat.

## Community and hole cards

The arm occludes most of the central card row. The previously established four-card board is retained as `Qh, 7d, 6s, Jc`; this full read is uncertain in the current frame because not all four cards can be re-read. The two robot hole cards remain face-down in their normal lower seat area. No opponent hole cards are face-up, and no fold/muck displacement is visible. There is no showdown evidence; the cached robot cards `9d, 5d` are not needed for an outcome comparison.

## Chips and bets

Denominations use red=5, blue=10, green=50, brown=100.

- Robot inventory: 4 red 5-chips and 3 blue 10-chips are visible. The green and brown groups are partly hidden by the robot assembly. Best estimate: 3 green 50-chips and 2 brown 100-chips. The brown estimate accounts for the dispatched brown chip having visibly traveled from the inventory side toward the robot bet cluster.
- Opponent inventory: largely obscured/angled in the current frame. Best inherited estimate: 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current bet: the hand is at the robot bet cluster after carrying/pushing the brown chip across the table. Best estimate: 0 red, 1 blue, 1 green, and 2 brown chips. The denomination counts are partially occluded and the added brown chip is inferred from the visible motion/progress.
- Opponent bet: the relevant region is obscured by the robot body. Best inherited estimate: 2 red, 0 blue, 1 green, and 1 brown chip.

