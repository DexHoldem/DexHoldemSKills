# Evaluation report

The capture was parsed using the field-specific visual guidelines. The robot hand is visibly extended and the current action sequence says `push_chip_100_1` is dispatched, so the scene is classified as `acting` and not stable. The bottom-left `Your Turn` button supports `is_my_turn: true`; the visible `BIG BLIND` marker and cached blind context support `blind: big_blind`.

The robot body occludes much of the central/right table. Inventory values are concrete visual estimates, while community-card and bet-area values are conservative zero estimates because no settled, safely countable cards or bet chips are visible. These fields are explicitly listed as uncertain. No showdown evidence is present.
