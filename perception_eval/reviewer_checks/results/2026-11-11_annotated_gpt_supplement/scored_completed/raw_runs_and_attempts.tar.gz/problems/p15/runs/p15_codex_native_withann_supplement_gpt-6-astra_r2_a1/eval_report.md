# Perception and merge report

Read all field guidelines and inspected s30 (current), s29 (previous), and s28 (clearer pre-action view). The literal sN-1 directory does not exist; s29/01_parsed_state.md is the previous state for s_current -> s30.

Current physical evidence supports acting and scene_stable=false: the hand moved substantially and is still contacting the brown chip in the robot betting lane. The dispatched push in action_sequence.json provides context, not proof of completion. The visible turn and big-blind markers establish is_my_turn=true and blind=big_blind.

Corrected the prior board from Qh, 7d, 6s, Jc to visually read 8h, 7d, 6s, 7c using s28; the current first card is consistent with 8h. Retained the obscured board positions and opponent counts from earlier visual evidence. Updated robot brown inventory from three to two and brown bet count from one to two because the transferred chip is visibly in the betting lane, still under the fingertip. These counts remain provisional during movement. Other robot denominations agree with the visible layout and previous state.

No visible showdown or fold is established; not_showdown is the concrete estimate, flagged because the opponent card area is obscured. All inherited, inferred, or partly occluded field groups are listed in uncertain_fields. No robot actions, helper scripts, or poker decisions were executed.
