# Raw Visual Perception

Current frame inspected: `s_current/00_capture.jpg`.

Comparison frames: `s29/00_capture.jpg` (immediately previous) and `s28/00_capture.jpg` (last clearly settled layout).

- Scene/robot: Unstable. The robot arm has moved substantially between `s29` and the current frame and now spans the center of the table. The dexterous hand is extended over and contacting the left-side betting group rather than resting. The dispatched 100-chip push therefore appears still in progress. No card is held. No definite dropped object or scattered chip group is visible, but the arm and camera body heavily occlude the board, both betting lanes, the opponent inventory, and the lower-right robot inventory.
- Turn: The white `Your Turn` button is clearly visible at the bottom-left robot seat, so it is the robot's turn.
- Blind: The yellow `BIG BLIND` button is visible at the bottom/robot seat. This agrees with the durable blind assignment that the robot is big blind.
- Community cards: Four board positions are established by the last settled view. In the current frame, `Qh` and `7d` remain at least partly visible; the arm/body hides `6s` and `Jc`. Best current board estimate, left to right, is `Qh 7d 6s Jc`, with the board field uncertain because two cards are inherited through occlusion.
- Robot inventory: Four red 5-chips and three blue 10-chips are visible at the bottom seat. The green and brown groups are partly hidden by the robot body; best estimate remains three green 50-chips and three brown 100-chips. The brown count is additionally ambiguous because the dispatched action targets a 100-chip and is not settled.
- Opponent inventory: Most of the top-seat inventory is occluded. Best estimate from the last settled layout is two red 5-chips, four blue 10-chips, three green 50-chips, and three brown 100-chips; all opponent inventory denominations are inherited/uncertain in this frame.
- Robot current bet: The hand blocks the left-side bet group and may be transporting or pushing the targeted brown chip. Best estimate remains no red chips, one blue 10-chip, one green 50-chip, and one brown 100-chip. The entire field, especially denomination 100, is uncertain until the push settles.
- Opponent bet: The right-side betting area is largely hidden by the arm/body. Best estimate remains two red 5-chips, no blue chips, one green 50-chip, and one brown 100-chip; this field is inherited/uncertain.
- Showdown: No opponent hole cards are visibly face-up, no fold/muck displacement is established, and only four community cards are present. This is not a showdown and there is no visible outcome.

