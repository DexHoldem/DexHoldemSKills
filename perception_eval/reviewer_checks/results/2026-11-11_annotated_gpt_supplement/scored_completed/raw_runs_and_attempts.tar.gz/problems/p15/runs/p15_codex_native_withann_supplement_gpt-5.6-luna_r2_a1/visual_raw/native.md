# Raw visual perception

- Capture: `s_current/00_capture.jpg`.
- Table orientation: robot/player is at the bottom; opponent is at the top. The robot body and arm occupy much of the right/center of the image.
- Scene: the dexterous hand is extended over the robot-side chip area and appears to be executing the dispatched 100-chip push. It is not in a settled idle pose, so the scene is unstable/acting.
- Turn: the white `Your Turn` button is visible near the bottom-left robot seat; this indicates it is the robot's turn.
- Blinds: the visible yellow `BIG BLIND` button is on the robot side, consistent with the cached assignment that the robot is big blind.
- Community cards: no face-up shared community-card row is safely readable in the capture; the central/right table is heavily occluded. Estimate zero readable community cards.
- Robot inventory: visible bottom-side groups are estimated at 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory: visible top-side groups are estimated at 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips; the robot body partly occludes the area.
- Betting areas: no opponent bet chips are safely visible. The robot-side betting area is partly occluded by the moving hand; estimate no settled chips currently countable there. The in-progress 100-chip push makes the robot bet count low-confidence.
- Showdown: no face-up opponent cards or showdown comparison are visible; this is not a showdown.
