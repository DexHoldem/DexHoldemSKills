# Native visual evidence

Unstable. Compared current `s_current/00_capture.jpg` (symlink to s30) with s29 and s28. The robot hand moved from the right side to the left betting area; a red fingertip is contacting a brown chip at approximately (490, 686). It is extended over the felt, not at rest. The dispatched chip-push atom is still in progress; completion is not established. No readable held card is visible. No failure or recovery judgment is warranted from this moving state.

The white Your Turn button is clearly at the bottom robot seat: it is our turn. The yellow BIG BLIND button is also at the robot seat. Earlier comparison views show the dealer and small-blind buttons at the opponent seat, consistent with the cached assignment.

Current board: the leftmost exposed face-up card reads 8h. The hand hides the remaining board positions. In the clearer s28 image, the four face-up board cards read 8h, 7d, 6s, 7c from left to right. The prior parsed Qh and Jc labels conflict with those visible numeric ranks and pip layouts. Carry forward the visually corrected board, with hidden positions flagged as inherited. The face-down rectangle left of the board is not a face-up community card.

Robot inventory: four red 5 chips and three blue 10 chips are clear. Three green 50 chips are visible, the upper one partly blocked. Two brown 100 chips remain visible at bottom right, one partly covered by the arm. The former upper brown inventory chip is now under the fingertip in the left bet area; estimated inventory is 4, 3, 3, 2 in denomination order 5, 10, 50, 100. The brown count is uncertain because of occlusion and ongoing transfer.

Robot current bet, left of board: one blue 10, one green 50, the existing brown 100 behind the finger, and a second brown 100 under the fingertip. No red 5 chip is visible. Estimate 0, 1, 1, 2; the second brown chip is in transit/contact and the count is provisional.

Opponent inventory: almost completely blocked in the current frame. The preceding clear views show two red 5, four blue 10, three green 50 and three brown 100 chips. Retain these counts as inherited estimates, not fresh observations.

Opponent bet, right of board: blocked by the robot body. In s28 the area contains two red 5 chips, no blue 10 chips, one green 50 and one brown 100. Retain 2, 0, 1, 1 as an occluded inherited estimate.

The robot hole cards remain face-down at the bottom. Opponent hole cards were face-down in their normal top-seat positions in s28/s29 and are now obscured. No visible showdown or new fold evidence. Cached robot cards are 9d and 5d; they are not current visual reads and no showdown comparison is justified. Estimate not_showdown, with current opponent-card visibility limited.
