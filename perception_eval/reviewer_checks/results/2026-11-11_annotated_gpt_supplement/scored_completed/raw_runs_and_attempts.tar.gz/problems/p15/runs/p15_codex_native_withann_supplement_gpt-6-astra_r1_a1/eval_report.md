# Perception and merge report

Read all field guidelines and inspected s30 (current), s29 (previous), and s28 for comparison. The literal sN-1 directory is absent; s_current resolves to s30, so s29/01_parsed_state.md supplies previous state. Action-sequence and hole-card cache files were read only as context.

Current visual motion supports acting and scene_stable=false independently of the prior dispatched status. The turn and big-blind markers are directly visible at the robot seat. The moving brown chip is now in the left betting area, giving provisional robot inventory 100-count 2 and bet 100-count 2; this does not certify successful atom completion.

Corrected prior board labels Qh and Jc to 8h and 7c using the clear s28 visual evidence. Current first card remains readable as 8h; the other board positions are carried forward under occlusion. Opponent inventory and bet counts are inherited from s29 and corroborated by s28. Uncertainty flags identify obscured, inherited, and provisional fields. not_showdown is the best continuity estimate, with opponent cards currently hidden.

No robot actions, helper scripts, or poker decisions were executed. Output JSON uses concrete estimates throughout and keeps inventory and the two bet areas separate.
