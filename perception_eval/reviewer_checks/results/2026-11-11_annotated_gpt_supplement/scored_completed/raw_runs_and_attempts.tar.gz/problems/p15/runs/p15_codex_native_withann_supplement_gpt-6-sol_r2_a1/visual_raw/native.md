# Raw visual perception

Current image: `s_current/00_capture.jpg`. Compared with `s14/00_capture.jpg`, the previous settled view. The robot arm and dexterous hand have moved from the lower right to a far extended pose over the upper-left table. The gripper is down among chips and appears to be manipulating a chip; the arm is far from idle and its body hides much of the opponent-side inventory and betting lane. This is an in-progress chip movement, with no settled post-action evidence of success or failure. The scene is unstable.

The white **Your Turn** button is plainly at the lower-left robot seat. The yellow **BIG BLIND** button is near the lower robot seat; the prior dealer/blind record also assigns the robot the big blind. No face-up community cards are visible. The central patterned cards are face-down. There is no visible showdown, exposed opponent hand, or clear fold. Neither robot hole card is readable in this frame.

Robot inventory, lower seat: four red 5 chips are visible. Three blue 10 chips are clearly visible; the arm may hide another. The green 50 and brown 100 groups at the lower right are partly obscured; estimate three of each from visible faces and the dispatched brown-chip movement. These counts exclude the gripper and betting lane.

Opponent inventory, upper seat: substantially hidden by the robot arm and changed viewing angle. Carry forward the last settled estimate of three red 5, four blue 10, four green 50, and four brown 100 chips. These are low-confidence current counts.

Robot current bet, lower/left betting lane: no separate flat chip is clearly visible; estimate zero of each denomination. A possible brown 100 chip at the gripper is still being manipulated and is not counted as a placed bet. Opponent bet, upper/right betting lane: obscured by the arm; carry forward the previous one red 5 chip, with zero of the other denominations. Both bet-zone estimates are uncertain because of occlusion.
