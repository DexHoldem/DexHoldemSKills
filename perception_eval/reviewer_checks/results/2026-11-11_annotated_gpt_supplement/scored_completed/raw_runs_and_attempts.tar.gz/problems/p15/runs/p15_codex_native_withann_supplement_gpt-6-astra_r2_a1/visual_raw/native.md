# Native perception evidence

Unstable. Compared the current capture (s_current resolves to s30) with s29 and the clearer pre-action s28 image. The hand has travelled from the lower-right chip area to the left betting area; a red fingertip remains on a brown chip. The arm is extended across the board, not at rest. The dispatched chip push is still in progress; physical completion is not established. No failure or recovery conclusion is warranted from this moving pose.

The white “Your Turn” marker is clearly at the bottom/robot seat. It is our turn. The yellow “BIG BLIND” marker is also at the robot seat. The earlier image shows the dealer and small-blind markers at the opponent seat, consistent with the cache.

Community cards: the current image exposes the leftmost face-up card as 8h; the rest of the board is hidden by the arm. The clear s28 image shows four face-up board cards, left to right: 8h, 7d, 6s, 7c. The prior parsed Qh and Jc disagree with the visible ranks in that image. Carry forward the visually established four-card board, with current-frame occlusion flagged. The face-down card to its left is not a face-up community card and is excluded.

Robot inventory: four red 5-chips and three blue 10-chips are clearly visible at the bottom. Three green 50-chips are consistent with visible faces/edges and the earlier layout, though one is partly blocked. Two remaining brown 100-chip faces are visible toward the bottom right, with the upper group partly occluded. Estimate 4, 3, 3, 2 by denomination. The third former inventory brown chip is now under the fingertip in the left betting lane.

Robot current bet, left of the board: one partly hidden blue 10-chip, one green 50-chip, one original brown 100-chip behind the fingers, and another brown 100-chip beneath the red fingertip. No red chips visible. Estimate 0, 1, 1, 2; the new brown chip is still being pushed, so its placement is provisional.

Opponent inventory: mostly hidden by the robot. The prior clear s28/s29 views show two red, four blue, three green, and three brown chips. Retain 2, 4, 3, 3 as an uncertain estimate, not a fresh count.

Opponent bet, right of the board: blocked by the arm. The clear s28 image shows two red, zero blue, one green, and one brown chip. Retain 2, 0, 1, 1 with occlusion uncertainty.

Robot hole cards remain face-down in the bottom area. No readable held card is visible. Opponent cards were face-down in their normal top-seat slots in s29 and are now obscured. There is no new visible reveal or fold signature. Estimate not_showdown; current opponent-card visibility is limited. Cached robot cards 9d and 5d are context only and are not used to invent a showdown comparison.
