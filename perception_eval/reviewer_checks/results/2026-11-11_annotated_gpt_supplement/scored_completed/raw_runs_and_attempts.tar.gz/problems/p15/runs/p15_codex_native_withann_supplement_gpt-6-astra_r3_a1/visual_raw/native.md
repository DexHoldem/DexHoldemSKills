# Native perception evidence

Unstable. Compared current `s_current/00_capture.jpg` (symlink to s30), s29, and the clearer pre-action s28 capture. The robot hand moves from the right side in s29 to the left betting area in s30. A red fingertip contacts a brown chip near (490, 687). The hand is extended across the board, not at rest. The dispatched chip push still appears in progress; completion, failure, and recovery cannot be established from this frame. No readable held card is visible.

The white Your Turn marker is clearly at the bottom robot seat. It is our turn. The yellow BIG BLIND marker is also at the robot seat. The opponent dealer/small-blind assignment is supported by cache and the earlier clear captures; those markers are obscured now.

Robot inventory: four red 5 chips and three blue 10 chips are directly countable. Two green 50 faces and part of the upper green chip are visible around the arm; estimate three green chips. Two brown 100 chips remain visible on the lower right. The third brown chip visible in s28 has been transported toward the left bet area, consistent with the intermediate s29 view. Estimate inventory 4, 3, 3, 2; green and brown counts are uncertain because of occlusion and ongoing transfer.

Opponent inventory: almost entirely hidden by the robot body. Inherit two red 5, four blue 10, three green 50, and three brown 100 chips from s29, also supported by s28. These are not fresh counts.

Robot bet area, left of board: one blue 10, one green 50, and two brown 100 chips are visible or partly visible, including the brown chip beneath the fingertip. No red 5 chips are visible. Estimate 0, 1, 1, 2. The second brown chip is physically at the bet area but remains in contact with the hand; placement is provisional.

Opponent bet area, right of board: blocked by the robot arm/body. Inherit two red 5, zero blue 10, one green 50, and one brown 100 from s29 and the clear s28 capture. Do not interpret occlusion as an empty bet area.

Board: the leftmost face-up card is 8h, partly exposed beside the robot body. The rest of the board is obscured. The clear s28 image shows four face-up board cards in left-to-right order: 8h, 7d, 6s, 7c. Its first rank has two loops and eight heart pips, and its last card has rank 7 and seven club pips. The prior parsed Qh and Jc labels conflict with that visual evidence. Preserve the four-card board using these corrected reads, marking current board values uncertain because three positions cannot be read in s30. The separate face-down card left of the board is not counted as a community card.

Robot hole cards remain face-down in the lower seat area. Opponent hole cards are hidden in the current image and were face-down in their normal top-seat slots in s28/s29. There is no visible reveal or fold evidence. Estimate not_showdown, with current opponent-card visibility uncertain. Cached robot 9d and 5d are context only; no showdown comparison is warranted.
