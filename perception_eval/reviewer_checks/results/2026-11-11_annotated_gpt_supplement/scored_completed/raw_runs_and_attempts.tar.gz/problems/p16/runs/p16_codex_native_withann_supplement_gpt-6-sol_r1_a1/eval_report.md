# Perception summary

The dispatched `push_chip_100_1` is still visually in progress: the robot hand has moved well away from its s29 pose and occludes the board and betting areas. The current frame therefore supports `acting` and `scene_stable: false`, not a settled recovery judgment. The robot's white turn button and yellow big-blind button remain visible.

Exposed chip counts were read directly. Occluded inventory, opponent bet, and later board positions use s29/s28 evidence and are listed in `uncertain_fields`. The first board card was corrected to `8h` from the visible card face; s29's `Qh` text conflicts with both visible images. No showdown is visible.
