# Raw visual perception

Unstable. Compared `s_current/00_capture.jpg` with `s29/00_capture.jpg` and `s28/00_capture.jpg`. The robot arm has moved far across the table; its fingers are down near a chip left of the board. The hand is away from its rest pose and the pushed chip's final position is not visible. The dispatched chip-push atom appears still in progress. No card is visibly held. The arm blocks much of the board, opponent betting area, and right-side chip inventory; no settled success or failure can be judged from this frame.

The white **Your Turn** button is visible at the lower-left robot seat. The yellow **BIG BLIND** button is at the robot side. The dealer/small-blind assignment is also recorded in the prior cache.

Two board cards are directly visible in the current capture: `8h`, `7d`, left to right. The remaining board positions are hidden by the robot arm; `s28/00_capture.jpg` shows `6s`, `Jc` in those positions. The first card looks like `8h` in both the current and prior images, although the prior parsed state calls it `Qh`.

Robot inventory: four red 5-chips and three blue 10-chips are visible along the lower edge. The three green 50-chips and three brown 100-chips are obscured and retained as prior estimates. Opponent inventory: two red 5-chips and four blue 10-chips are suggested by the earlier clear frame; the current frame is partly blocked. Three green 50-chips and three brown 100-chips are likewise prior estimates.

Robot bet area, left of the board: earlier frames show one blue 10-chip, one green 50-chip, and one brown 100-chip. The hand now covers part of that area, so the current count is uncertain. Opponent bet area, right of the board: earlier frames show two red 5-chips, one green 50-chip, and one brown 100-chip. The robot arm blocks this area in the current frame; its count is uncertain.

Opponent hole cards are not visibly face-up, and there is no visible fold or showdown. The robot hole cards remain face-down. Cached `9d` and `5d` are context only and are not needed for an outcome comparison here.
