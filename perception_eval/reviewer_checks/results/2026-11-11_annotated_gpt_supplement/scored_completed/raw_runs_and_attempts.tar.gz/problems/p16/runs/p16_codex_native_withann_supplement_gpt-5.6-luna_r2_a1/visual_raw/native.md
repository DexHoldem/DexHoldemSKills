# Raw visual perception

- Requested source `s_current/00_capture.jpg` is absent. The latest available capture is `s30/00_capture.jpg`; the immediately preceding parsed state is `s29/01_parsed_state.md`.
- The robot dexterous hand/arm is extended over the table and the latest frame is not a settled idle pose. The dispatched chip-push action therefore appears still acting/in progress; no physical failure is declared from this frame alone.
- The white `Your Turn` button is visible near the bottom/robot seat, so it is the robot's turn.
- The yellow `BIG BLIND` button is visible on the robot/bottom side. Blind assignment is big blind.
- Four community cards are consistent with the prior stable read, left-to-right: `Qh`, `7d`, `6s`, `Jc`; the current frame is substantially occluded by the robot body/arm, so this board read is inherited and marked uncertain.
- Opponent hole cards are face-down and no showdown/fold outcome is visible. Cached robot hole cards are `9d` and `5d`, but no showdown comparison is applicable.
- Inventory and betting zones are partly occluded by the robot body/hand. Concrete counts are inherited from the latest settled parse: robot inventory `4 red/5`, `3 blue/10`, `3 green/50`, `3 brown/100`; opponent inventory `2 red/5`, `4 blue/10`, `3 green/50`, `3 brown/100`; robot bet `0 red/5`, `1 blue/10`, `1 green/50`, `1 brown/100`; opponent bet `2 red/5`, `0 blue/10`, `1 green/50`, `1 brown/100`.
