# Perception merge

The current image shows the robot hand extended over the betting area after a dispatched 100-chip push. Relative to s29, the robot has moved substantially and has not reached a settled pose, so the scene is unstable and the workflow remains `acting`. The robot-side “Your Turn” and “BIG BLIND” buttons are visible. No showdown or fold is established.

The visible first board card reads 8h, correcting the Qh recorded in s29; 7d is partly visible. The obscured 6s and Jc positions, right-side inventory, and opponent bet are carried from s29/s28 as concrete estimates and marked uncertain. The current push has not been counted as an additional 100-chip bet because the hand still covers the interaction. No robot or poker action was executed or selected.
