# Raw visual perception

- Source: `s_current/00_capture.jpg`; compared with `s29/00_capture.jpg` and the prior parsed state.
- Scene: the robot arm and dexterous hand are extended over the table and appear to be actively reaching/handling a chip near the central-left betting lane. The hand is not near an idle/rest pose. This is an in-progress action, so the scene is unstable.
- Turn: the white `Your Turn` button is clearly visible at the bottom/robot seat. It is the robot's turn.
- Blind: the yellow `BIG BLIND` button is visible at the robot/bottom seat. The robot is the big blind.
- Board: the current frame is heavily occluded by the robot body/arm. The previously stable board read is four face-up community cards, left-to-right `Qh`, `7d`, `6s`, `Jc`; only the left portion of the board is currently visible enough to confirm, so this board read is inherited and uncertain in the current frame.
- Hole cards/showdown: no reliable face-up showdown cards or fold/muck displacement is visible. The cached robot cards are `9d` and `5d`, but no showdown comparison is warranted.
- Inventory estimate, using visible layout plus the previous stable parsed state: robot/bottom inventory `4 red(5), 3 blue(10), 3 green(50), 3 brown(100)`; opponent/top inventory `2 red(5), 4 blue(10), 3 green(50), 3 brown(100)`. The robot body/hand occludes portions of both zones, especially the opponent/right side.
- Betting estimate: the current frame does not safely expose the full two betting areas while the hand is moving. Best inherited estimate is robot bet `0 red, 1 blue, 1 green, 1 brown`; opponent bet `2 red, 0 blue, 1 green, 1 brown`. These counts are uncertain until a settled capture is available.
- No action is selected or dispatched by this perception step.
