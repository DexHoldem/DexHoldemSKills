# Raw visual perception

Unstable. Compared current s_current/00_capture.jpg (s30) with s29/00_capture.jpg and the clearer pre-action s28/00_capture.jpg. The robot hand has traversed from the right toward the left betting area, with fingertips down near the felt. It is not in its resting pose. The brown chip formerly near the fingertip on the right in s29 is now near the lower middle of the betting lane. The dispatched chip-push atom is still in progress; completion cannot be established. No card is visibly held. Do not infer recovery or failure from this moving, occluded frame.

The white Your Turn button is plainly visible at the bottom robot seat: it is our turn. The yellow BIG BLIND button is at the robot seat. The dealer and small-blind assignment to the opponent is supported by the cache and s28.

The current board is heavily blocked by the hand. The exposed first face-up card reads 8h, not the Qh recorded in the previous parsed state. In the clearer s28 image, the four face-up cards read 8h, 7d, 6s, 7c from left to right. The last card has seven club pips, not a jack illustration. Carry forward this visually corrected four-card board with uncertainty for current occlusion. The face-down card to its left is not included. Two robot hole-card backs remain in the lower seat area. No readable held card is visible.

Robot inventory: four red 5 chips and three blue 10 chips are clear. Three green 50 chips are visible or partially visible at the lower right. Two brown 100 chips are visible at the lower right; the third previously inventoried brown chip is now in the betting lane, so the best current inventory estimate is two brown chips. Green and brown totals are uncertain under the arm.

Opponent inventory: mostly occluded by the hand/body. Use the prior counts, also visible in s28: two red 5, four blue 10, three green 50, three brown 100. These are inherited estimates, not current full visual counts.

Robot betting area to the left of the board: one green 50 face at roughly (355,642), one partially visible blue 10 at (449,621), one partially visible brown 100 near (529,638), and a separate brown 100 near (747,693). Best estimate: zero red, one blue, one green, two brown. The additional brown chip is still in transit within the central betting lane; its assignment is provisional. The green chip has shifted left relative to s29. These changes reinforce that the scene is still moving.

Opponent betting area to the right of the board: blocked by the robot. No reliable current count is available. Retain two red 5, zero blue 10, one green 50, one brown 100 from the previous parsed state and clearer s28 view.

No current positive evidence of showdown or a new fold. The s28/s29 views show opponent hole cards face-down at the top seat; their current area is occluded. Robot cards remain face-down. Cache values 9d and 5d are contextual only and do not establish a showdown. Best estimate: not_showdown, with uncertainty due to the hidden opponent cards.
