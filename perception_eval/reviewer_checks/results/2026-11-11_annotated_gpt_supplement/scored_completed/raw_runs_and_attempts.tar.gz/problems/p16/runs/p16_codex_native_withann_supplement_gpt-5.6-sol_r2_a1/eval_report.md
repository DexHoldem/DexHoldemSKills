# Perception Evaluation Report

The current capture was compared with `s29/00_capture.jpg` and the earlier settled `s28/00_capture.jpg`. The arm is extended across the table and the dexterous hand is at the betting lane, so the dispatched 100-chip push remains visually in progress. The current state is therefore merged as `loop_stage: acting` with `scene_stable: false`; the prior `to_recover` label is not carried forward because recovery requires a settled post-atom frame.

Direct current evidence establishes the bottom-left `Your Turn` button, the robot-side `BIG BLIND` button, four red and three blue robot inventory chips, and no visible showdown. The arm/camera body obscures much of the board, both bet zones, the opponent inventory, and the robot green/brown inventory. Those fields receive concrete estimates inherited from the previous stable parsed state, with uncertainty recorded. For the active 100-chip transfer, the pre-transfer inventory and bet counts are retained until movement is visibly complete; both affected 100-chip counts are uncertain.

No poker action was selected and no robot action was executed.
