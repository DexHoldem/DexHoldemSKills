# Raw visual perception

## Current-frame evidence

- The camera is oriented with the robot/player seat at the bottom and the opponent seat at the top.
- The robot arm is extended far across the center of the table. The dexterous fingers are down against the felt/chip area, the hand is not near its idle pose, and the arm/camera body heavily occludes the board and the right-side chip zones. No card is visibly held. A chip is not cleanly separable from the fingertip/contact point.
- Compared with the settled `s29/00_capture.jpg` frame, the arm and hand have moved substantially. With the dispatched `push_chip_100_1` context, the chip-push atom appears still in progress. The current image is not a settled post-atom view, so it does not support declaring success or retryable failure.
- The white `Your Turn` button is clearly visible at the bottom-left robot seat: it is the robot/player's turn.
- Four community-card positions belong to the current board. In this frame the arm/camera body obscures much of that row; the durable last-settled read is `Qh 7d 6s Jc`. Those card identities are inherited and uncertain in this frame.
- The opponent's two hole cards remain face-down in their normal top-seat area. The robot's two hole cards remain face-down in the bottom-seat area. There is no visible showdown or fold/muck signature.
- Robot inventory: four red 5-chips and three blue 10-chips are visible at the bottom. The green 50-chip and brown 100-chip groups are occluded; the last-settled counts of three each are inherited. Because a 100-chip push is in progress, the current split of brown chips between inventory and bet is especially uncertain.
- Opponent inventory is partly visible at the top but partly obscured by the arm/camera body. The last-settled counts are inherited: two red 5-chips, four blue 10-chips, three green 50-chips, and three brown 100-chips.
- Both central betting areas are substantially occluded. The last-settled counts are inherited: robot bet = one blue 10-chip, one green 50-chip, and one brown 100-chip; opponent bet = two red 5-chips, one green 50-chip, and one brown 100-chip. The in-progress 100-chip transfer could change the robot inventory/bet split, so the robot brown counts are not resolved by this frame.
- The blind assignment is not re-readable from the occluded current frame. The durable recognized assignment is inherited: robot is big blind.

## Perception judgment

Unstable. Compared `s29/00_capture.jpg` with `s_current/00_capture.jpg`. The robot hand has moved far from its prior settled pose and is extended over the chip/bet area during the dispatched push atom. The scene is therefore `acting`, not a settled recovery or idle state.

