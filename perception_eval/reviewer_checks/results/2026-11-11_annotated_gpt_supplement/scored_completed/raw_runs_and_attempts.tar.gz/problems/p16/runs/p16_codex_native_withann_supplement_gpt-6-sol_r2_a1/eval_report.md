# Perception summary

The current frame shows the robot hand extended into the chip area, with the dispatched push unresolved. The scene is unstable and the loop stage is `acting`. The white turn button remains at the robot seat. The robot is the big blind. No showdown is visible.

The board's visible first card reads `8h`, which conflicts with the previous parsed state's `Qh`; the current image and the clearer `s28` image support `8h`. Board positions three and four and several chip zones are hidden by the arm, so their concrete estimates inherit the prior clear images and parsed counts. Those fields are listed under `uncertain_fields`.
