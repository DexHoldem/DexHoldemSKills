# Raw Visual Perception

## Scene stability and robot behavior

Unstable. Compared `s_current/00_capture.jpg` with `s29/00_capture.jpg` and the earlier settled view `s28/00_capture.jpg`. In the current frame the robot arm is extended far across the table, the dexterous hand is down at the central-left betting lane, and a red fingertip is in contact with or immediately beside a chip. The arm and hand are in a substantially different pose from the prior settled frame and have not returned to idle. The large camera/arm body occludes much of the board and the right/central betting and inventory regions. Given the dispatched `push_chip_100_1` context, the physical atom appears still in progress; the frame does not establish whether the 100 chip completed its transfer. No card, button, or unrelated object is visibly displaced, and no unsafe scatter is visible, but completion or failure cannot be judged from this active pose.

## Table evidence

- Turn: the white `Your Turn` button is clearly visible in the bottom-left robot seat area, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is visible on the bottom/robot side. This agrees with the durable recognized blind assignment: robot is big blind.
- Community cards: the current arm/body occludes most of the shared board. The visible board portion is consistent with the prior four-card board `Qh, 7d, 6s, Jc`; only the left part is directly inspectable now, so the full four-card read is inherited and uncertain in this frame. The separate face-down card left of the board is not counted as a community card.
- Showdown: no opponent hole cards are visibly face-up, no fold/muck displacement is established, and the robot hole cards remain face-down. There is no visual showdown or outcome evidence.

## Chips and bets

Denominations are red=5, blue=10, green=50, brown=100. Chips are counted as unfolded faces.

- Robot inventory, bottom seat: four red 5 chips and three blue 10 chips are visibly countable. The green and brown inventory regions are occluded by the arm/camera body, so the best estimates remain three green 50 chips and three brown 100 chips from the previous stable state. The brown count is especially uncertain because the active atom is intended to move one 100 chip.
- Opponent inventory, top seat: substantially occluded in the current frame. Best concrete estimate inherited from the prior stable state is two red 5 chips, four blue 10 chips, three green 50 chips, and three brown 100 chips.
- Robot current bet, lower/robot side of the board: the active hand and arm obscure the area. Until a completed transfer is visually verified, the best estimate is the prior bet of zero red 5 chips, one blue 10 chip, one green 50 chip, and one brown 100 chip. The brown bet count is particularly uncertain during the active 100-chip transfer.
- Opponent bet, upper/opponent side of the board: occluded by the arm/camera body. Best estimate inherited from the prior stable state is two red 5 chips, zero blue 10 chips, one green 50 chip, and one brown 100 chip.

## Perception conclusion

The current loop stage is `acting`, not a settled recovery state. `scene_stable` is false. All concrete estimates affected by central/right-side occlusion or the active 100-chip transfer are explicitly listed as uncertain in the structured output.
