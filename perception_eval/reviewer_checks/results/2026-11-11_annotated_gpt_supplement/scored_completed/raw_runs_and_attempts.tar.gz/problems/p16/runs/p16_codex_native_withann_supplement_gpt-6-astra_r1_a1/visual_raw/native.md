# Native visual evidence

Inspected `s_current/00_capture.jpg`, with `s29/00_capture.jpg` as the latest numbered predecessor and `s28/00_capture.jpg` as the clearer pre-push comparison. Read all field guidelines, the action sequence, hole-card cache, and s29/s28 parsed states. No helper scripts or robot actions were executed.

Unstable. The hand has moved from the right-side chip region in s29 to the left betting lane in the current image. Its fingertips remain low over the felt, and the wrist/arm cover much of the board and opponent side. It is not in a settled rest pose. The dispatched brown-chip push appears still in progress; completion, failure, and recovery cannot be established from this frame. No readable held card is visible. The human's raised arm is away from the playing objects and is not the reason for instability.

The white Your Turn marker is clearly at the lower-left robot seat: it is our turn. The yellow BIG BLIND marker is visible at the robot seat. The previous clear image and cache place dealer/small blind at the opponent seat.

The current image exposes the first community card as 8h and hides most of the remainder behind the robot. The clear s28 image shows four face-up board cards, left to right: 8h, 7d, 6s, 7c. These override the saved Qh and Jc readings. Retain the four-card board under current occlusion and mark it uncertain. The face-down card left of the board is excluded; it was already present in the comparison frames. Both opponent hole cards remained in the upper seat in those frames, so this is not evidence of a new fold. Robot hole cards remain face-down at the bottom. No showdown or clear fold is visible; use not_showdown. Cached 9d and 5d are context only, not current visual reads.

Inventory counts use flat chip faces, not stack heights. Robot: four red 5-chips and three blue 10-chips are clear. Three green 50-chips are visible, with the upper one partly blocked. Two brown 100-chips are visible toward the lower-right; the upper part of this group is occluded. Estimate robot inventory as 4, 3, 3, 2 in denomination order 5, 10, 50, 100. The brown count is inferred from the previous three-chip group and an additional brown chip now in the central lane; it is not a fully unobstructed recount.

Opponent inventory is mostly hidden by the hand. Inherit 2 red, 4 blue, 3 green, 3 brown from s29, also supported by the clear s28 image; mark uncertain.

Robot bet area left of the board: one green 50-chip and one blue 10-chip are visible, plus a partly obscured brown 100-chip near the fingertips and a separate brown 100-chip farther right along the lower central lane. No red bet chips are visible. Estimate 0, 1, 1, 2; the second brown chip is displaced from its former position near the right-side fingertips in s29, consistent with the ongoing push. Ownership/placement remains provisional during motion.

Opponent bet area right of the board is blocked by the arm. Inherit 2 red, 0 blue, 1 green, 1 brown from the preceding state and clear s28 view; this is uncertain, not a current visible count. Do not merge the two bet areas.
