# Perception and merge report

Current visual evidence supports `acting`, an unstable scene, robot turn, and robot big blind. Compared the current capture with s29 and the clearer pre-push s28 image. The hand is still extended and its position has changed substantially; the prior `to_recover` label is not carried forward. Dispatched action metadata supplies context only and does not establish completion.

Corrected the saved board from Qh/7d/6s/Jc to visually supported 8h/7d/6s/7c. Most board positions are currently occluded, so the corrected prior-image readings remain flagged. Estimated the robot brown-chip transfer as inventory 3 to 2 and current bet 1 to 2 because two separate brown faces are now in the central robot betting lane; these counts remain provisional during movement and occlusion. Inherited opponent inventory and bet counts because the arm blocks those zones. All inherited or uncertain field groups are listed in `uncertain_fields`.

No visible showdown or new fold supports an outcome comparison. `not_showdown` is the concrete estimate, flagged because the opponent card area is currently occluded. Hole-card cache was not modified. No poker action was selected and no robot command or helper script was run.
