# Perception Evaluation Report

The current capture is an unstable `acting` frame. Compared with s29 and the settled s28 frame, the robot arm has advanced across the table and a fingertip is contacting/transporting a brown 100 chip in the robot-side betting lane. The dispatched chip-push atom therefore appears ongoing, not settled; no recovery, poker action, or robot action was selected.

Direct evidence establishes that the white `Your Turn` marker is at the robot seat, the robot remains big blind, no showdown is present, and the visible robot inventory includes four red 5 chips and three blue 10 chips. The moving/occluding arm prevents a complete fresh read of the board, opponent inventory, opponent bet, and some robot chip groups.

For occluded durable fields, the s29 settled parse was merged with current evidence. The board remains estimated as `Qh 7d 6s Jc`; opponent chips and opponent bet retain their prior counts. Current motion supports estimating one brown 100 chip transferred from robot inventory to the robot bet, yielding two robot inventory 100s and two robot-bet 100s, but both values are flagged uncertain until a settled capture confirms placement. All inherited, occluded, or motion-dependent estimates are listed in `uncertain_fields`.

