# Raw visual perception

- Current capture: `s_current/00_capture.jpg`. Compared with `s29/00_capture.jpg` and `s28/00_capture.jpg` for the dispatched chip push and obscured table regions.
- The dexterous arm is extended far across the table. Its fingertips are down around the left betting chips; the arm/camera blocks much of the board, the opponent betting area, and the robot's right inventory. Relative to s29, the hand has clearly changed position and is away from a settled pose. The chip-push atom appears still in progress. The image does not establish whether the target 100-chip was successfully pushed. No scattered chips or displaced cards are visible in the exposed regions.
- The white `Your Turn` button is visible at the bottom/robot seat. The yellow `BIG BLIND` button is also at the robot seat. The opponent dealer/small-blind assignment is consistent with the cache.
- Board: the first two exposed faces appear to be `8h` and `7d`; the second is partly covered. The later board positions are hidden by the arm. In s28, the four board cards read left to right as `8h`, `7d`, `6s`, `Jc`. The earlier parsed first card says `Qh`, but the visible card face in the images reads `8h`; the image read takes priority. No fifth board card can be established from the current capture.
- Robot inventory at the bottom: four red 5-chips and three blue 10-chips are exposed. The green 50 and brown 100 groups on the right are occluded; prior counts are three of each.
- Opponent inventory at the top is obscured by the arm/camera. The s29 count was two red 5-chips, four blue 10-chips, three green 50-chips, and three brown 100-chips.
- Robot bet area left of the board: one blue 10-chip, one green 50-chip, and one brown 100-chip are visible or partly under the hand; no red chip is evident. The brown chip's exact position/status after the push is uncertain.
- Opponent bet area right of the board is hidden. Prior count was two red 5-chips, zero blue 10-chips, one green 50-chip, and one brown 100-chip.
- Opponent hole cards are not visibly exposed or clearly mucked; the board is not at an established showdown. No hand outcome can be read.
