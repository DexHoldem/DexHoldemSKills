# Raw perception evidence

- Current capture used: `s30/00_capture.jpg` (the requested `s_current/00_capture.jpg` is absent); compared with prior `s29/00_capture.jpg`.
- Scene: the robot arm and dexterous hand extend across the table and are contacting/positioning a chip. The hand is not in a settled idle pose; the current frame is therefore unstable and the dispatched chip-push action appears still in progress.
- Turn: the white `Your Turn` button is visible in the lower robot-side area, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is visible on the robot/bottom side, consistent with robot = big blind.
- Community cards: four face-up cards are present in the shared board row. The visible/previously readable board is `Qh`, `7d`, `6s`, `Jc`; the robot arm occludes part of the row in the current frame, so the inherited reads are retained.
- Robot inventory: best estimate is 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The arm/hand partly occludes the lower/right inventory and the 100-chip count is not fully verifiable.
- Opponent inventory: best estimate is 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The upper/right inventory is substantially occluded by the robot body/arm.
- Robot current bet area: best estimate is no red 5-chips, 1 blue 10-chip, 1 green 50-chip, and 1 brown 100-chip visible before completion of the currently dispatched 100-chip push; the brown count is uncertain because the hand is contacting/occluding this area.
- Opponent current bet area: best estimate is 2 red 5-chips, no blue 10-chips, 1 green 50-chip, and 1 brown 100-chip. The right side is partly blocked by the robot arm, so these counts are uncertain.
- Showdown: no face-up showdown layout or outcome is visible; this is not a showdown.

