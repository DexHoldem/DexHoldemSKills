# Raw Visual Perception — s30

## Scene and robot

- Current capture inspected: `s_current/00_capture.jpg` (`s30`).
- Stability comparison: `s30/00_capture.jpg` versus `s29/00_capture.jpg` and the last clearly settled pre-action frame `s28/00_capture.jpg`.
- **Unstable.** The dexterous arm has moved substantially from the prior frames and is extended across the table. A red fingertip is in contact with a brown 100 chip in the lower/robot-side betting lane. The hand is not near its idle/rest pose and is not visibly holding a card. This is consistent with the dispatched 100-chip push still being in progress; the frame is not a settled post-atom success or recovery view.
- No scattered chip groups, displaced cards, or clearly moved non-target object are visible. The arm/camera body heavily occludes the center and right-side table regions.

## Turn and blind evidence

- The white `Your Turn` button is clearly visible at the lower-left robot/player seat: it is the robot's turn.
- The yellow `BIG BLIND` button is visible on the lower/robot side. This agrees with the durable recognized blind assignment: robot is big blind, opponent is dealer/small blind.

## Community cards

- Four face-up community-card positions remain on the board. The visible and prior-frame evidence supports, left to right: `Qh`, `7d`, `6s`, `Jc`.
- Much of the board is blocked by the extended arm in the current frame, so the four-card read is inherited from the immediately preceding settled visual state and is uncertain in this capture.
- No fifth community card is visible.

## Inventory chips

Denominations are red=5, blue=10, green=50, brown=100.

- Robot/player inventory at the bottom seat: 4 red 5 chips and 3 blue 10 chips are visible. The green and brown groups are partly or wholly occluded. Best merged estimate: `{5: 4, 10: 3, 50: 3, 100: 2}`. The brown count reflects the visually transported 100 chip leaving inventory, but remains uncertain until the hand settles.
- Opponent inventory at the top seat is substantially occluded by the arm/camera. Best durable estimate from the prior settled frame: `{5: 2, 10: 4, 50: 3, 100: 3}`; treat the full opponent inventory count as inherited/uncertain.

## Betting areas

- Robot current bet, lower/robot side of the board: the existing blue 10, green 50, and brown 100 remain, and the fingertip is transporting/contacting an additional brown 100 in this lane. Best current estimate: `{5: 0, 10: 1, 50: 1, 100: 2}`. The brown count is low-confidence because the chip is still under the moving hand.
- Opponent bet, upper/opponent side of the board: heavily blocked in the current image. Best durable estimate from the prior settled frame: `{5: 2, 10: 0, 50: 1, 100: 1}`; mark the opponent bet as inherited/uncertain.
- Inventory chips and the two betting zones were kept separate; no generic pot was formed.

## Showdown

- The opponent's two hole cards remain face-down in their normal top-seat area; they are not face-up and do not show the fold/muck displacement signature.
- The robot's hole cards are face-down at the lower seat. Cached values exist, but there is no showdown evidence in this frame.
- Outcome: `not_showdown`.

