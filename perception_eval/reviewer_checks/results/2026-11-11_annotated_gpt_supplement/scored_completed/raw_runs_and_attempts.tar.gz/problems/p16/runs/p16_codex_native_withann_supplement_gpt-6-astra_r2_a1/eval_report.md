# Perception and merging

Read all field guidelines and inspected s30 (the s_current target), s29, and s28 directly. The literal sN-1 path does not exist; s29 is the actual preceding state.

Current motion evidence overrides the previous parsed to_recover/stable labels: the hand has moved across the table, remains extended, and chips have shifted. Output acting with scene_stable=false. The prior dispatched status supplies context only; successful completion is not asserted.

The visible turn and big-blind buttons establish true and big_blind. Corrected the previous board transcription Qh/7d/6s/Jc to 8h/7d/6s/7c using current partial visibility and the clear s28 board. Hidden board positions are carried forward and flagged.

Retained opponent inventory and bet estimates because the current hand blocks those zones. Robot red/blue inventory is directly countable. Best current estimate transfers one brown 100 from robot inventory into the betting lane: inventory two, bet two. This is based on the visible chip locations across frames, not the requested raise amount; placement remains provisional during motion. Occluded or inferred fields are explicitly listed in uncertain_fields. No showdown comparison is warranted; not_showdown is an occlusion-limited estimate.

No robot actions, helper scripts, or poker decisions were executed. Only perception artifacts were written.
