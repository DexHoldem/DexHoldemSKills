# Evaluation report

Used the latest available capture, `s30/00_capture.jpg`, because the requested `s_current/00_capture.jpg` is absent. Compared it with the prior settled evidence in `s29/01_parsed_state.md` and applied the field-specific geometry, turn, chip, bet, stability, and showdown guidelines.

The current frame shows the robot hand extended over the table during the dispatched chip-push sequence, so the scene is classified as `acting` and unstable. The bottom `Your Turn` marker supports `is_my_turn: true`; the visible `BIG BLIND` marker supports `blind: big_blind`. Four board cards and chip counts are carried forward as concrete estimates because the current robot body/hand occludes those zones; all such inherited/occluded fields are listed in `uncertain_fields`. No showdown evidence is visible.

Verified that `visual_raw/native.md`, `visual_summary.json`, and `eval_report.md` exist in this run directory.
