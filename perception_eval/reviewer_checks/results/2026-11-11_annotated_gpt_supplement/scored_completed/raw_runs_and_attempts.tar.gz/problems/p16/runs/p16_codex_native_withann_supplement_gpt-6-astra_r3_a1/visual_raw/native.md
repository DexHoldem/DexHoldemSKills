# Native perception evidence

Inspected s_current/00_capture.jpg (s30), s29/00_capture.jpg, and the clearer pre-action s28/00_capture.jpg. Read all field guidelines, action_sequence.json, hole_card_cache.json, and s29/01_parsed_state.md. The literal sN-1 path does not exist; s29 is the preceding state.

Unstable. The hand has translated far left across the table between s29 and s30, with fingertips down near the left betting lane. It is not in its resting pose. The brown chip formerly beneath the fingertip near the middle-right lane is now near the lower edge of the board at approximately (747, 694). The left green betting chip also differs in position. The dispatched chip-push atom is still in progress; its final success cannot be established. No readable held card is visible. The hand and wrist obscure most of the board, the opponent betting lane, and much of the top inventory. Human posture changes do not determine this stability judgment.

The white Your Turn marker is clearly at the bottom robot seat: it is our turn. The yellow BIG BLIND marker is also at the robot seat. The cached opponent dealer/small-blind assignment is consistent with the earlier clear frame.

Community cards: the current exposed left board card reads 8h, not the prior parsed Qh. The remaining board is hidden by the wrist. The clearer s28 image shows the four-card row as 8h, 7d, 6s, 7c; the fourth is a pip seven of clubs, not the prior parsed Jc. Carry forward these visually corrected values for the hidden positions, with uncertainty. The face-down rectangle to the left of the row is not a face-up community card and is not assigned a value.

Robot inventory: four red 5 chips and three blue 10 chips are directly visible. Three green 50 chips are visible, including a partly obscured upper chip. Two brown 100 chip faces are visible at the lower right; the upper original inventory position is obscured. Best estimate is two remaining brown chips, since an additional brown chip is now in the central lane compared with s28. This inventory estimate is uncertain during the push.

Opponent inventory: largely occluded and not independently countable in s30. Carry forward two red 5, four blue 10, three green 50, and three brown 100 chips; these agree with the clearer s28 image.

Robot bet, left of the community row: no visible red chips, one blue 10, one green 50, and two brown 100 chips. One brown is partly behind the fingers near (530, 640); the other is separate near (747, 694). The latter is still in transit along the lower central lane, so treating it as a current bet rather than inventory is provisional. Do not infer that the requested push has finished.

Opponent bet, right of the row: hidden by the robot. Carry forward two red 5, zero blue 10, one green 50, and one brown 100 chip, supported by s28 and the prior state; all are uncertain in the current image.

Robot hole cards remain face-down in their bottom slots. No newly exposed opponent hand or new fold is established. Earlier frames retain two face-down opponent hole cards in their normal slots; the separate face-down central rectangle was already present. Use not_showdown as the best estimate, flagged for current occlusion. Cached 9d and 5d are context only; no showdown comparison is warranted.
