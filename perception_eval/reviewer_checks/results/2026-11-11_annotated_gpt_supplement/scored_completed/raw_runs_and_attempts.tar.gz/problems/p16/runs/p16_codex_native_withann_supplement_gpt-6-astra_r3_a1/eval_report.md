# Perception and merge report

Current capture resolves to s30. Used s29 as the prior state and inspected s28 as the clearer pre-action reference. All visual field guidelines were read. No robot commands, helper scripts, or poker decisions were executed.

Current hand displacement and chip displacement override the prior to_recover/stable labels: loop_stage is acting and scene_stable is false. The push is not visually complete. The visible white turn marker and yellow blind marker establish is_my_turn=true and big_blind.

Corrected the prior board transcription Qh/7d/6s/Jc to visually supported 8h/7d/6s/7c. Hidden current positions are carried from the reference image and marked uncertain. Opponent inventory and bets are inherited because the wrist blocks them. The extra brown chip in the central lane yields a provisional robot inventory of two 100 chips and bet of two 100 chips; this is an in-progress spatial estimate, not confirmation of action completion. All affected fields are listed in uncertain_fields.

No showdown is established. The cached robot cards were not used to invent an outcome. Output uses concrete estimates throughout, with no nulls or placeholder card values.
