# Perception and merge summary

Used the current s28 capture and all visual guidelines. There is no literal `sN-1` directory; resolved the previous state to s27 from the `s_current -> s28` link. Compared s26 and s27 images to assess the robot's movement.

Current evidence replaces the previous three-card board with `8h 7d 6s 7c`, including correcting the prior `Jc` read. Robot green inventory is three, and one green chip is visible in its bet; the previous parsed values were four and zero. Other inventory and bet counts are visually confirmed. Blind assignment agrees with the cache and is independently visible. The white turn marker supports `is_my_turn: true`. Face-down hole cards remain at both seats, so the outcome is `not_showdown`; cached 9d/5d require no comparison.

The robot has moved substantially from the preceding frames and appears to be finishing its withdrawal. Chose `acting` and `scene_stable: false` conservatively, flagging both because the raised current pose might already be settled. No failed action or recovery is inferred. The context's idle label is not treated as current visual evidence. No output value depends solely on inheritance.

Only perception artifacts were written. No helper scripts, robot actions, or poker decisions were executed.
