# Raw visual perception

- Capture: `s_current/00_capture.jpg` (symlink target `s28`).
- Scene: the table and robot hand appear settled; the hand is near the upper-right side and does not visibly move cards or chips.
- Turn: the white `Your Turn` button is visible at the bottom/robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is at the bottom/robot seat; the robot is the big blind.
- Community cards: three shared face-up cards are visible left-to-right: `7d`, `6s`, `Jc`.
- Robot hole-card area: one card is face-up in the robot hole-card area and appears consistent with the cached `5d`; the other card remains face-down. This is not counted as a community card.
- Opponent hole cards: remain face-down; no fold or showdown evidence is visible.
- Robot/player inventory, bottom side: approximately 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top side: approximately 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current-bet area: 1 blue 10-chip and 1 brown 100-chip; no red or green chips.
- Opponent current-bet area: 2 red 5-chips, 1 green 50-chip, and 1 brown 100-chip; no blue chips.
- No material visual ambiguity prevents the requested state estimate.
