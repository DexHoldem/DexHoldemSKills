# Raw Visual Perception

- Current capture: `s_current/00_capture.jpg`.
- Scene/robot: Stable. Compared with `s27/00_capture.jpg`, where the arm and camera occupied the table during the prior chip action. In the current capture the dexterous hand is settled in a near-idle pose at the upper right, is not holding a card or chip, and is not touching or pinning any table object. Cards and chip groups are clearly countable; no disturbed layout or active object motion is visible.
- Turn: It is our turn. The white `Your Turn` button is plainly visible in the bottom-left robot seat area.
- Blind: The yellow `BIG BLIND` button is at the bottom/robot seat, so the robot is the big blind. This also agrees with the cached blind assignment.
- Community cards: Four face-up shared cards are visible in the center row, left to right: `8h`, `7d`, `6s`, `7c`. No fifth board card is visible.
- Robot/player inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top seat: 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current bet, lower/robot side of the board: 0 red 5-chips, 1 blue 10-chip, 1 green 50-chip, and 1 brown 100-chip.
- Opponent current bet, upper/opponent side of the board: 2 red 5-chips, 0 blue 10-chips, 1 green 50-chip, and 1 brown 100-chip.
- Showdown: Not at showdown. Both opponent hole cards remain face-down in their normal top-seat slots, the robot hole cards remain face-down, and no fold/muck displacement is visible. The cached robot cards are therefore not needed for an outcome comparison.
- Workflow label: The prior chip action is visually complete and the hand is settled, so the current visual stage is `idle`, not `acting`, `atom_idle`, recovery, or a terminal outcome.
- Uncertainty: None of the required output fields needs an inherited or low-confidence estimate.
