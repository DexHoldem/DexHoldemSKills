# Perception Evaluation Report

The current image is visually stable: relative to `s27`, the robot has completed its chip-pushing motion and returned to a settled near-rest pose. The white turn marker remains at the robot seat, and the yellow big-blind marker visually confirms the cached robot blind assignment.

Current visual evidence supplies the four-card board (`8h 7d 6s 7c`), all inventory counts, and both separated betting-area counts. The prior state was used only to compare motion and reconcile the completed 50-chip call: the current image now shows that green 50-chip in the robot bet area and one fewer green 50-chip in robot inventory. No structured field was inherited solely from prior state, so `uncertain_fields` is empty.

There is no showdown or fold signature: both sets of hole cards remain face-down in their normal seat areas, and the hand has only four face-up community cards.
