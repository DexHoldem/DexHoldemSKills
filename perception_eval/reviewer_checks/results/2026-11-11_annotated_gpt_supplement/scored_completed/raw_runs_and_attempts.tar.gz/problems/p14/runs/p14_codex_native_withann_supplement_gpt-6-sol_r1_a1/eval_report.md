# Perception report

The capture shows a settled robot hand off the betting area, the robot-side `Your Turn` button, and four board cards: 8h, 7d, 6s, Jc. Inventory and bet chips were counted separately by their table zones. Both hole-card pairs are face-down in their normal positions, so there is no visible showdown or fold.

The prior parsed state supplied context for the robot's earlier movement and the previous three board cards. The hole-card cache corroborated the robot's big-blind assignment. Current visual evidence determined the fourth board card, chip counts, turn indicator, and settled state; the prior workflow label was not carried forward.
