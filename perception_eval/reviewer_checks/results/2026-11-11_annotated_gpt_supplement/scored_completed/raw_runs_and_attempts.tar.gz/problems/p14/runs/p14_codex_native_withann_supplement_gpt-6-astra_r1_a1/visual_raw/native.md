# Raw visual evidence

Inspected `s_current/00_capture.jpg` (symlink resolves to `s28/00_capture.jpg`), with `s27/00_capture.jpg` and `s26/00_capture.jpg` for motion comparison. Read all field guidelines. Bottom seat is robot; top seat is opponent. Chip counts below count flat individual faces, excluding buttons.

- Scene: Unstable, conservatively. In s26 the hand is near a green chip on the right, in s27 it is extended over the left betting area, and in s28 it is raised and withdrawn toward the upper-right. The current hand is empty and approaching a near-idle pose, but these frames show substantial movement rather than a confirmed stationary endpoint. Current board also exposes a previously face-down card. No human hand is interfering with the table. Stability and acting versus completed-idle are uncertain.
- Robot behavior: raised above the table at the right, without a held card or chips. No visible pinning, dropped hole card, scattered inventory, or other physical failure. The movement appears to be finishing; settling is not confirmed. No recovery/failure classification is supported.
- Turn: the white `Your Turn` marker is at the bottom-left robot seat. It is our turn.
- Blinds: yellow `BIG BLIND` at bottom robot seat; white `DEALER` and blue small-blind marker at top opponent seat. Robot is big blind.
- Board: four face-up cards, left-to-right `8h`, `7d`, `6s`, `7c`. The rightmost card has a 7 index and club pips, not a jack. A separate face-down card to the left of 8h is excluded; its identity is unknown.
- Robot inventory: four red 5-chips, three blue 10-chips, three green 50-chips, three brown 100-chips.
- Opponent inventory: two red 5-chips, four blue 10-chips, three green 50-chips, three brown 100-chips.
- Robot bet, left of the board: zero red, one blue, one green, one brown chip.
- Opponent bet, right of the board: two red, zero blue, one green, one brown chip. All four faces are visible to the left of the robot body; no countable group is hidden by it.
- Hole cards/showdown: both players retain two face-down cards in their respective seat areas. No face-up opponent hole cards or displaced/mucked pair. No readable held card. No showdown or visible hand winner. Cached robot cards 9d and 5d are context only and do not supply board values.

Current visual counts and card reads take precedence over previous parsed values. The prior action sequence has no active step; it does not prove current physical stability.
