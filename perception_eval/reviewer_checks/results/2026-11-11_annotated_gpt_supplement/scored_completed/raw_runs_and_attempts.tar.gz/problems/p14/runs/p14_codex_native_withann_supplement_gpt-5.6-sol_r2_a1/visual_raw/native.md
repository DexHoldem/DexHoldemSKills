# Raw Visual Perception

- Scene stability: Stable. Compared `s27/00_capture.jpg` with `s_current/00_capture.jpg`. The robot arm has withdrawn from its extended chip-pushing pose to the same near-rest pose seen in the initial stable view; it is not holding a card or chip, no motion blur is visible, and the table objects are settled.
- Robot behavior / loop stage: The dexterous hand is near its initial pose at the right edge. It is not contacting or pinning any game object. The current view is compatible with `idle`, and there is no visible recovery or failure condition.
- Turn: It is the robot's turn. The white `Your Turn` button is clearly visible in the bottom-left robot seat area.
- Blind: The yellow `BIG BLIND` button is at the bottom robot seat. This agrees with the durable cached blind assignment, so the robot is `big_blind`.
- Community cards: Four face-up shared cards are visible in the central row. Left-to-right they are `8h`, `7d`, `6s`, `7c`. One additional face-down board-position card is visible to their left and is not assigned a value or counted as a face-up community card.
- Robot/player inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top seat: 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current bet, left/lower side of the community row: 1 blue 10-chip, 1 green 50-chip, and 1 brown 100-chip; no red 5-chip.
- Opponent current bet, right/upper side of the community row: 2 red 5-chips, 1 green 50-chip, and 1 brown 100-chip; no blue 10-chip.
- Showdown: Not at showdown. Both players' two hole cards remain face-down in their normal seat areas; the opponent cards are not exposed or displaced as a fold/muck, and only four community cards are face-up.
- Uncertainty: No output field requires inheritance or a low-confidence estimate. The robot hardware occupies the far-right edge but does not prevent the relevant chip groups, turn marker, or face-up board cards from being counted.
