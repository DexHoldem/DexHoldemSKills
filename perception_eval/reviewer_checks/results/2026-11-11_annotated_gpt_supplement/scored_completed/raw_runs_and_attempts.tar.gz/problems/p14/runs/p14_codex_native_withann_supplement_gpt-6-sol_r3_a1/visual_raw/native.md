# Raw visual perception

Source: `s_current/00_capture.jpg`. Compared robot pose with `s27/00_capture.jpg` and the settled initial pose in `s0/00_capture.jpg`.

- **Scene and robot:** The dexterous hand is raised at the upper right, matching its initial/idle pose. It holds no card or chip and does not block the board or betting areas. No object movement or disturbed chip layout is visible. The prior frame had the arm extended over the central table; it has since returned to the raised pose. Current scene appears stable.
- **Turn and blind buttons:** The white `Your Turn` button is in the bottom/robot seat area. The yellow `BIG BLIND` button is also by the robot seat. The white dealer and blue small-blind buttons are by the top/opponent seat. Robot is the big blind and it is the robot's turn.
- **Community cards:** Four face-up cards in the central row, left to right: `8h`, `7d`, `6s`, `Jc`. The face-down card immediately left of the `8h` is not a community card. There is no fifth face-up board card.
- **Robot inventory, bottom seat:** Four red 5 chips, three blue 10 chips, three green 50 chips, and three brown 100 chips.
- **Opponent inventory, top seat:** Two red 5 chips, four blue 10 chips, three green 50 chips, and three brown 100 chips.
- **Robot current bet, left/lower side of the board:** One blue 10 chip, one green 50 chip, and one brown 100 chip; no red 5 chip.
- **Opponent bet, right/upper side of the board:** Two red 5 chips, one green 50 chip, and one brown 100 chip; no blue 10 chip.
- **Hole cards and outcome:** Opponent hole cards remain face-down in their normal top-seat position. Robot hole cards remain face-down near the bottom seat. No fold, revealed opponent hand, or showdown result is visible. No readable held card is visible.
