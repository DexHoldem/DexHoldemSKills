# Raw visual perception

- Input path requested: `s_current/00_capture.jpg` (not present).
- Current capture used: `s28/00_capture.jpg`; prior comparison frame: `s27/00_capture.jpg`.
- Table orientation: robot/player seat is at the bottom; opponent seat is at the top.
- Scene: the robot hand is visible at the upper-right and appears settled, but it occludes part of the opponent-side/right betting area.
- Turn marker: the white `Your Turn` button is at the bottom robot seat, so it is the robot's turn.
- Community cards: four face-up cards, left-to-right `8h`, `7d`, `6s`, `Jc`.
- Robot hole cards: face-down; no new readable held card is visible. Cached cards remain `9d` and `5d` for showdown context.
- Robot/player inventory: best visible count is 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips.
- Opponent inventory: best visible count is 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips; the right-side group is partly occluded by the robot hand.
- Robot current-bet area: 1 blue 10-chip and 1 brown 100-chip visible; no red or green bet chip visible.
- Opponent current-bet area: 2 red 5-chips, 1 green 50-chip, and 1 brown 100-chip visible; right-side visibility is partly occluded.
- Showdown: no opponent hole cards are face-up and no fold/muck signature is visible.
