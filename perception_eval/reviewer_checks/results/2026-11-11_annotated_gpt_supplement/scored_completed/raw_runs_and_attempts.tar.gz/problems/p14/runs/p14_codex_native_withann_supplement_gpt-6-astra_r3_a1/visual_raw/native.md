# Native visual evidence

Current capture: `s_current/00_capture.jpg` (resolves to s28). Compared with s27 and s26 captures. Read all field guidelines, the prior action sequence, hole-card cache, and s27 parsed state. Counts below follow denomination order 5, 10, 50, 100.

## Stability and robot behavior

Unstable. Across s26, s27, and s28 the robot moves from the lower-right chip area, across to the left betting area, then withdraws upward/right. In s28 its empty fingers are raised above the table, approaching a rest pose; it is no longer touching the bet chips. The substantial inter-frame movement does not establish that withdrawal has finished. Best estimate: still acting, with uncertainty about whether it has just settled. No held card, pinned object, scattered inventory, or visible physical failure. The robot body obscures the far-right edge, but the visible chip groups and board are countable. The opponent is not interfering with the table.

## Turn and blinds

The white Your Turn marker is clearly at the bottom-left robot seat: it is our turn. The yellow BIG BLIND button is at the robot seat. The white DEALER and blue SMALL BLIND buttons are at the opponent seat. Robot is big blind; this independently confirms the durable cached assignment.

## Community cards and hole cards

Four face-up community cards read left-to-right as 8h, 7d, 6s, 7c. One additional face-down card occupies the leftmost board-lane position; its identity is not readable and it is excluded from the face-up community-card list. The rightmost face-up card is a seven of clubs, with numeral and multiple club pips, rather than the prior parsed Jc.

Both opponent hole cards remain face-down in their normal upper-seat positions. Both robot hole cards remain face-down in the lower-seat positions. No readable held card is visible. Cached robot cards 9d and 5d are context only and are not current visual reads. No visible fold/muck or showdown: not_showdown. No hand comparison is warranted.

## Inventory

Robot inventory at the bottom: four red 5 chips, three blue 10 chips, three green 50 chips, three brown 100 chips. Individual faces are visible in separated denomination groups.

Opponent inventory at the top: two red 5 chips, four blue 10 chips, three green 50 chips, three brown 100 chips. Buttons are excluded.

## Bets

Robot bet to the left of the board: zero red, one blue, one green, one brown chip. These are distinct from the bottom inventory.

Opponent bet to the right of the board: two red, zero blue, one green, one brown chip. The two red faces overlap slightly but are separately visible. These are distinct from the top inventory.

## Uncertainty

loop_stage and scene_stable are temporal estimates: the latest pose is near rest, but the compared frames show substantial robot withdrawal and do not confirm a settled endpoint. All chip counts, turn ownership, blind assignment, and face-up board identities are based on the current image; no hidden card identity is inferred.
