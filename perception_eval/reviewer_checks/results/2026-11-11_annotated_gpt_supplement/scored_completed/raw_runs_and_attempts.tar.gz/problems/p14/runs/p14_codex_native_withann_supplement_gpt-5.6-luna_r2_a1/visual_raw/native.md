# Raw visual perception

Source image inspected: `s28/00_capture.jpg` (the workspace has no literal `s_current/` directory). The immediately preceding frame was `s27/00_capture.jpg`; the latter shows the robot apparatus mid-motion, while the current frame shows the apparatus/hand withdrawn from the playing surface and the table layout settled.

- Scene: stable; no card or chip is visibly being moved in the current frame.
- Turn: the white `Your Turn` button is on the bottom/robot side, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is at the robot/bottom seat; cached preflight assignment also identifies the robot as big blind.
- Community cards: four face-up cards in the central row, read left-to-right as `8h`, `7d`, `6s`, `Kc`.
- Robot inventory (bottom/robot-side groups): approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top/opponent-side groups): approximately 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current bet, left of the community-card row: 1 blue 10-chip, 1 green 50-chip, and 1 brown 100-chip; no red 5-chips.
- Opponent current bet, right of the community-card row: 2 red 5-chips, 1 green 50-chip, and 1 brown 100-chip; no blue 10-chips.
- Showdown: not present. The hole cards remain face-down; no opponent face-up reveal is visible.
- No readable held card is visible in the current frame.
