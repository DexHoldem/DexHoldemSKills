# Perception Evaluation

The current capture is a clear, stable post-action frame. Direct visual evidence supplies the four-card board (`8h 7d 6s 7c`), turn marker, inventory counts, and separate bet-zone counts. The robot's bet now includes one green 50-chip and its remaining green inventory is three, consistent with completion of the chip transfer that was occluded/in progress in the previous capture.

The previous parsed state was used only for continuity and comparison. Its three-card board read and unstable/acting label were not inherited because the current image clearly shows four community cards and a settled near-idle hand. The durable big-blind assignment was inherited only after confirming it against the visible yellow `BIG BLIND` button at the robot seat. The hole-card cache was checked but not used for hand comparison because neither player has exposed cards and the hand is not at showdown.

All required fields have concrete visual estimates. No field is marked uncertain.
