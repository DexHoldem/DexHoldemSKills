# Perception and merge summary

Current capture resolves to s28; previous-state context came from s27. All visual field guidelines were read. Images s26 and s27 were additionally inspected for robot movement and board changes.

Current visual evidence supersedes prior parsing: board is 8h, 7d, 6s, 7c, excluding the remaining face-down board-area card. Robot green inventory is three, and its green bet count is one. Other chip counts match the prior state and are independently visible. Blind assignment agrees with the cache and visible buttons; the bottom-side Your Turn button directly supports true.

The action-sequence file says idle but contains no dispatched step. It was used only as prior context. The raised hand has withdrawn substantially since s27; settling is not confirmed across frames. Acting and scene_stable=false are conservative estimates, explicitly flagged as uncertain. Opponent bet uses the four visible chip faces; far-right robot-body occlusion is also flagged. No failure or recovery is inferred.

Both pairs of hole cards remain face-down in their normal zones, so showdown_outcome is not_showdown. Cached 9d/5d were not treated as freshly observed cards. No unsupported durable value needed inheritance; current evidence confirms the blind assignment.

Only the requested perception artifacts were written. No robot actions, helper scripts, or poker-action selection were performed.
