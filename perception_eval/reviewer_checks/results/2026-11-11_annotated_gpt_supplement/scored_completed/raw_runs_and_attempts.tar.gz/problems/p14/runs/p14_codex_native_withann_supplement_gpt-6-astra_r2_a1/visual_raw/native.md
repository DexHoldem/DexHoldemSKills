# Native visual evidence

Inspected s_current/00_capture.jpg (s28), s27/00_capture.jpg, and s26/00_capture.jpg. Read all field guidelines, action_sequence.json, hole_card_cache.json, and s27/01_parsed_state.md.

Unstable, conservatively estimated. Compared s26, s27, and s28: the robot moves from the right-side chip region to the left bet region and then upward/right, away from the felt. The current empty hand is raised near a rest pose, with no visible card or chip held and no contact with the table. Its substantial displacement since s27 does not establish that return motion has finished. A central card previously face-down is now face-up. No human hand is manipulating the table. Settling is uncertain; current loop-stage estimate is acting, not a failure or recovery state.

Robot seat is at the bottom; opponent seat is at the top. Inventory chips are separated from the central betting lane. Chips are flat and counted by individual faces, not stack height.

Four face-up shared cards read left to right: 8h, 7d, 6s, 7c. One additional face-down card lies to their left and is excluded. The rightmost card has a visible 7 and club symbols; the prior Jc transcription is not retained. Both players retain two face-down cards in their normal hole-card areas. No readable held card is visible.

Robot inventory: four red 5-chips, three blue 10-chips, three green 50-chips, three brown 100-chips.

Opponent inventory: two red 5-chips, four blue 10-chips, three green 50-chips, three brown 100-chips.

Robot current bet, left of the board: no red 5-chips, one blue 10-chip, one green 50-chip, one brown 100-chip.

Opponent bet, right of the board: two red 5-chips, no blue 10-chips, one green 50-chip, one brown 100-chip. These four faces are visible; the robot body obscures the far-right continuation of the lane, so this is the best visible count with uncertainty about hidden chips.

It is our turn. The white Your Turn button is at the bottom-left robot seat.

The yellow BIG BLIND button is at the robot seat. The white DEALER and blue SMALL BLIND buttons are at the opponent seat. Robot is big blind, consistent with cached assignment.

Neither player's hole cards are face-up or visibly mucked. No showdown or terminal outcome is evident: not_showdown. Cached robot cards 9d and 5d remain context only; no opponent cards are readable and no hand comparison is warranted.
