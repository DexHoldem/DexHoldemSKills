# Perception evidence and merging

Inspected s28 directly and compared s27/s26 for robot movement. Applied all visual_guidelines. Current pixels override the prior workflow's idle label: the robot has withdrawn substantially from its previous chip-contact pose, with completion not yet confirmed. Estimated acting / scene_stable=false and flagged both temporal fields as uncertain. No failure or recovery is inferred.

Current visual reads replace the prior three-card board with four face-up cards, 8h 7d 6s 7c; correct the prior Jc read to 7c; set robot green inventory to three rather than four; and count one green chip in the robot bet rather than zero. The remaining counts are independently visible and agree with prior values. The extra face-down board-lane card is excluded without guessing its identity.

The robot's big blind assignment agrees with the cache and prior state and is freshly confirmed by visible buttons. Your Turn is visibly at the robot seat. Both players' hole cards remain face-down in their normal positions, so the outcome is not_showdown; cached 9d/5d are not used to invent an opponent hand or outcome.

All schema fields have concrete estimates. No robot actions, helper scripts, or poker decisions were performed.
