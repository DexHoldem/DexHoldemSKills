# Raw Visual Perception

- Current capture: `s_current/00_capture.jpg` (`s28`).
- Geometry: robot/player seat is at the bottom; opponent seat is at the top; the shared board is in the center. Inventory and betting zones were counted separately.
- Scene stability: stable. Compared with `s27/00_capture.jpg`, where the robot arm was extended over the table. In the current capture the dexterous hand is retracted into a settled near-idle pose, with no visible motion blur or moving table objects. The relevant cards and chip zones are readable.
- Turn marker: the white "Your Turn" button is at the bottom-left robot seat, so it is the robot/player's turn.
- Community cards: four face-up cards are visible in the shared board row, left to right: `8h`, `7d`, `6s`, `7c`.
- Robot/player inventory (bottom): 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top): 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot/player current bet, left of the board: no red 5-chips, 1 blue 10-chip, 1 green 50-chip, and 1 brown 100-chip.
- Opponent current bet, right of the board: 2 red 5-chips, no blue 10-chips, 1 green 50-chip, and 1 brown 100-chip.
- Blind markers: the yellow "BIG BLIND" marker is at the bottom robot seat; the dealer marker is at the opponent seat. The robot is the big blind.
- Showdown: no opponent hole cards are face-up, both robot hole cards remain face-down, and only four community cards are visible. There is no fold/muck signature and no showdown outcome.
- Robot behavior: the hand is not holding a card or chips and appears settled; no physical failure is visible.

