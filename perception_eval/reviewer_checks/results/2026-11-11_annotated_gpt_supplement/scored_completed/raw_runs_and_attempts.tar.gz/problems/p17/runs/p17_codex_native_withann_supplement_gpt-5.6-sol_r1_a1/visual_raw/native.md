# Raw Visual Perception

- Current frame inspected: `s_current/00_capture.jpg`; motion comparison used `s29/00_capture.jpg` and the last settled pre-action frame `s28/00_capture.jpg`.
- Scene stability: **Unstable**. The dexterous hand/arm has moved substantially from its low central position in `s29` to the upper-right table area in the current frame and remains far from its idle/rest pose. This is continued execution/return motion for the dispatched 100-chip push, so the state is still `acting`. No dropped card, scattered chip group, pinned object, or other clear human-help condition is visible.
- Robot behavior: the hand is not holding a card. The brown 100-chip contacted in `s29` is now visible left behind in the central betting lane near/below the board while the hand has moved away. Its exact final placement is uncertain because the atom has not visually settled.
- Turn marker: the white `Your Turn` button is clearly at the bottom-left robot seat, so it is the robot's turn.
- Community cards: four face-up shared cards are visible, left-to-right: `Qh`, `7d`, `6s`, `Jc`.
- Showdown: neither player's normal hole-card pair is face-up and there is no fold/muck signature. This is not a showdown.
- Blind: inherited from the recognized durable blind cache: robot is big blind (dealer/small blind is opponent). The current action frame is not suitable for re-reading the blind buttons.
- Robot inventory best estimate (5, 10, 50, 100): **4, 3, 3, 2**. Red, blue, and green groups remain consistent with the last settled frame. Only one brown chip is directly clear at the lower-right edge; a second remaining brown chip is inferred behind the robot occlusion after one of the prior three was pushed. Brown inventory is uncertain.
- Opponent inventory best estimate (5, 10, 50, 100): **2, 4, 3, 3**. The visible portions agree with the durable previous count, but the robot hand/body partially occludes the upper-right groups, so the count is inherited/uncertain.
- Robot current bet best estimate (5, 10, 50, 100): **0, 1, 1, 2**. The earlier blue, green, and brown bet chips remain, and the newly pushed brown chip is visible in the central betting lane. The second brown chip's final zoning is uncertain while the robot is still moving.
- Opponent bet best estimate (5, 10, 50, 100): **2, 0, 1, 1**. The right-side bet region is substantially occluded in the current frame, so the last durable visible count is inherited and marked uncertain.

