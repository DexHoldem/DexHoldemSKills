# Raw visual perception

- Source: `s_current/00_capture.jpg`; compared with `s29/00_capture.jpg` for motion and durable table layout.
- Scene/robot: the dexterous hand is visibly extended over the central-right betting lane and appears to be actively pushing or positioning a 100-value chip. The hand and camera hardware occlude part of the right side. This is still in-progress motion, so the scene is unstable and the dispatched `push_chip_100_1` step is not yet visibly complete.
- Turn: the white `Your Turn` button is visible at the bottom/robot side; it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is on the robot/bottom side; the robot is big blind.
- Community cards: four face-up board cards are visible left-to-right and read as `Qh`, `7d`, `6s`, `Jc`, consistent with the previous parsed state. The rightmost card is partly occluded by the robot hardware but remains identifiable.
- Robot inventory (bottom side): approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The right-side denominations are partly occluded by the robot hardware.
- Opponent inventory (top side): approximately 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The right-side group is partly occluded.
- Robot current-bet area, lower/robot side of the board: visible prior bet layout is 0 red, 1 blue, 1 green, and 1 brown chip; the active hand is currently handling an additional brown 100-chip, so completion of the push cannot yet be confirmed.
- Opponent current-bet area, upper/opponent side of the board: approximately 2 red, 0 blue, 1 green, and 1 brown chips; partly occluded by the robot hardware/hand.
- Showdown: no face-up showdown presentation or fold/muck signature is visible; this is not showdown.
