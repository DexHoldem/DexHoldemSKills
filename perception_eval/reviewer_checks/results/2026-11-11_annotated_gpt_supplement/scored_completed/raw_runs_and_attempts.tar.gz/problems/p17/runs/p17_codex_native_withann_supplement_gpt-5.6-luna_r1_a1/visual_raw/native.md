# Raw visual perception

- Capture: `s_current/00_capture.jpg`.
- Scene: Unstable. The dexterous robot hand is extended over the upper-right/central table area and the camera body occludes much of the right side; this is consistent with the dispatched 100-chip push still being in progress.
- Turn: The white `Your Turn` button is visible near the lower-left robot seat, so it is the robot's turn.
- Blind: The yellow `BIG BLIND` button is on the bottom/robot side; robot is big blind.
- Community cards: Four face-up cards are visible left-to-right: `8h`, `7d`, `6s`, and `4c` (the rightmost card is partly close to the camera/occlusion but its black club pips and rank are readable).
- Hole cards: The table hole-card backs are not used for card-value inference. Cached robot cards remain `9d` and `5d` for showdown context; this is not a showdown image.
- Inventory chips: Best visible estimate is robot/bottom inventory `4` red 5-chips, `3` blue 10-chips, `3` green 50-chips, `2` brown 100-chips; opponent/top inventory `2` red 5-chips, `4` blue 10-chips, `3` green 50-chips, `3` brown 100-chips. The robot brown group and the opponent right-side groups are partly occluded/angled.
- Betting areas: Robot/lower-side bet estimate is no red 5-chips, one blue 10-chip, one green 50-chip, and one brown 100-chip. Opponent/upper-side bet estimate is two red 5-chips, no blue 10-chips, one green 50-chip, and one brown 100-chip. Counts are provisional because the hand is mid-transfer and the upper-right bet/inventory boundary is occluded.
- Showdown: No face-up opponent hole cards or fold/muck signature is visible; outcome is not showdown.

