# Raw visual perception

- Requested `s_current/00_capture.jpg` is absent; used newest available `s30/00_capture.jpg` as current and `s29/00_capture.jpg` as the prior frame.
- Scene is **unstable/acting**: the dexterous hand remains extended over the lower/right betting lane and is still engaged with the dispatched 100-chip push. It has not returned to an idle pose.
- The white `Your Turn` button is visible at the bottom/robot seat, so it is the robot's turn.
- Four face-up community cards are visible left-to-right: `Qh`, `7d`, `6s`, `Jc`.
- The robot is the big blind per the cached blind assignment; the yellow `BIG BLIND` marker is visible at the robot-side lower area.
- Robot inventory estimate: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Opponent inventory estimate: 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips. The right/top zone is partly occluded by the robot apparatus.
- Current bet estimate from visible placed chips: robot side 0 red, 1 blue, 1 green, 1 brown; opponent side 2 red, 0 blue, 1 green, 1 brown. The opponent-side betting area is partly occluded, and the robot-side brown 100-chip push is still in progress.
- No showdown evidence is visible; hole cards remain face-down and the hand is not at showdown.
