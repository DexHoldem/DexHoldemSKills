# Evaluation report

Perception used `s30/00_capture.jpg` as the current frame and `s29/00_capture.jpg` as the prior frame because the requested `s_current/` and `sN-1/` paths are not present. The current frame still shows the robot hand in the dispatched 100-chip trajectory, so the scene is unstable and the loop remains `acting`. The board, turn marker, blind assignment, and non-showdown status are visually supported. Chip and bet counts inherit the prior stable parse where the robot apparatus occludes the opponent zone; those affected fields are listed in `uncertain_fields`.
