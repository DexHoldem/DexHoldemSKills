# Evaluation report

The current capture is an acting/mid-transfer frame: the robot hand and camera obscure the upper-right table, so `scene_stable` is false. The lower-left `Your Turn` marker establishes robot turn ownership, and the yellow `BIG BLIND` marker establishes the blind. Four shared cards are read as `8h 7d 6s 4c`; no showdown evidence is present. Chip inventories and betting-area counts are concrete best estimates, with the occluded or transfer-sensitive fields listed in `uncertain_fields`. No action was selected or dispatched.

