# Perception Evaluation

The current capture was merged with durable context only where current visual evidence was occluded. Comparison with `s29` and the last settled frame `s28` shows continued robot motion away from the central pushed chip, so `loop_stage` remains `acting` and `scene_stable` is false. The frame does not support declaring atom failure or recovery.

Direct current evidence establishes the four-card board (`Qh 7d 6s Jc`), the robot-side turn button, no showdown, and a newly displaced brown 100-chip in the central betting lane. The big-blind assignment comes from the recognized blind cache. Occluded inventory and opponent-bet counts were merged from the preceding durable state; the robot brown inventory was reduced from three to two to account for the visibly pushed chip. All inferred or zoning-sensitive values are listed in `uncertain_fields`.
