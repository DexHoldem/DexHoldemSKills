# Perception merge

Used s25/00_capture.jpg as the current visual source and s24/00_capture.jpg to judge robot motion and chip changes. The arm is raised away from the betting area, the white turn button remains at the robot seat, and three board cards remain visible. The brown 100 chip now appears in the robot betting area while three remain in robot inventory. The opponent inventory's far-right brown position is partly occluded, so its count uses the previous parsed state as a best estimate. The blind assignment also agrees with the cached preflight recognition. Current visual evidence shows no showdown or fold.

The opponent bet counts are estimates because the right-side chips are angled and close to the robot arm. These fields are flagged in `uncertain_fields`.
