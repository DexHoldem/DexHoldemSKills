# Raw visual perception

- Compared `s_current/00_capture.jpg` with the available prior capture `s25/00_capture.jpg`; the frames appear visually identical and settled.
- Scene is stable enough to parse. The robot hand is visible at the upper-right in a stationary near-idle pose and partially occludes the far upper-right table area, but does not cover the board cards or the turn marker.
- The white `Your Turn` button is at the bottom/robot seat, so it is the robot's turn.
- The yellow `BIG BLIND` button is at the robot seat; the robot is the big blind.
- Three face-up community cards are visible left-to-right: `7d`, `6s`, `Jc`.
- Robot/player inventory on the bottom side: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Opponent inventory on the top side: 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips. The upper-right portion is partly occluded by the robot hardware, but the visible groups match the inherited counts.
- Robot current-bet area: 1 blue 10-chip; no red, green, or brown bet chips visible.
- Opponent current-bet area: 2 red 5-chips; no blue, green, or brown bet chips visible.
- No face-up showdown cards or fold/muck movement is visible.
