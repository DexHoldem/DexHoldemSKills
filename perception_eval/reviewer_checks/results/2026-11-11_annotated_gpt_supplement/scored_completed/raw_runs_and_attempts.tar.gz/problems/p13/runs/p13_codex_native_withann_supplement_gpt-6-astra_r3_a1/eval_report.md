# Perception and merge report

Read the field-specific visual guidelines and inspected the current s25 capture, with s24 and s23 images for motion and layout comparison. Used s24 parsed state as the previous state because `s_current` resolves to s25; no literal `sN-1` directory exists.

Current visual evidence overrides previous counts and card text: the board is 7d, 6s, 7c, correcting the prior Jc. Robot inventory is 4/3/4/3 and opponent inventory is 2/4/3/3 in denomination order 5/10/50/100. Bets are separately recorded as robot 0/1/0/1 and opponent 2/0/1/1. Face-down cards are excluded from the community-card list.

The robot big-blind assignment agrees with prior state and cache and is independently confirmed by visible buttons. The lower-left turn marker directly supports `is_my_turn: true`. Normal face-down hole-card positions support `not_showdown`; cached 9d/5d are not needed for comparison.

The current hand is raised and empty after the earlier chip contact, supporting an apparently completed movement and an idle, stable estimate. Because no second capture of this final pose is available, `loop_stage` and `scene_stable` are marked uncertain. The action-sequence idle value was used only as context; it did not override the image. No active dispatched atom is present in that file.

No helper scripts, robot actions, or poker-action selection were used. Only the requested perception artifacts were written.
