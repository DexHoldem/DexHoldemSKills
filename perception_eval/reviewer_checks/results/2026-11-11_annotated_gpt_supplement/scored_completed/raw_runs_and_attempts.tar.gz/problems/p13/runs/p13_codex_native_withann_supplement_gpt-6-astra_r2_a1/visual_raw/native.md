# Native visual evidence

Source: `s_current/00_capture.jpg`, resolving to `s25/00_capture.jpg`. Compared directly with `s24/00_capture.jpg` and `s23/00_capture.jpg`. Read all field guidelines in `visual_guidelines/`.

## Scene and robot

Unstable, conservatively estimated from s23, s24, and s25. In s24 the robot finger contacts a brown chip near the lower central betting lane. In s25 the empty hand is raised above the right side of the table, and the brown chip is now in the robot bet area to the left of the board. The hand has substantially changed pose and may still be withdrawing toward rest. It is clear of the chips and cards in the current frame, but a settled pose is not confirmed by consecutive captures. Current loop-stage estimate: acting; scene_stable: false. These two estimates are uncertain because the raised pose could be a completed near-idle return. No card is held, no obvious object is pinned, and no scattered or damaged layout is visible. No failure or recovery conclusion is warranted.

## Turn and blinds

The white Your Turn button is clearly visible at the bottom robot seat: it is our turn. The yellow BIG BLIND button is at the robot seat. The white DEALER and blue SMALL BLIND buttons are at the top opponent seat. Robot is big blind; no button conflict.

## Cards and outcome

Three face-up community cards, left to right: 7d, 6s, 7c. The rightmost card has a seven index and club pips, not a jack illustration. Two additional central cards are face-down and are excluded. Both opponent hole cards remain face-down in their normal top-seat positions; both robot hole cards remain face-down in the bottom seat. No readable held card and no fold/muck or showdown evidence. Outcome: not_showdown. Cached robot cards 9d and 5d are context only and were not visually re-read or used to invent a showdown.

## Inventory chips

Counted individual flat chip faces, excluding buttons and betting-lane chips. Denomination order is 5, 10, 50, 100.

- Bottom robot inventory: four red, three blue, four green, three brown chips.
- Top opponent inventory: two red, four blue, three green, three brown chips.

The robot hardware occupies the far right foreground, but all listed inventory chip faces are visible and separable.

## Bets

- Robot bet area, left of the central cards: zero red, one blue, zero green, one brown chip.
- Opponent bet area, right of the central cards: two red, zero blue, one green, one brown chip. The brown chip sits between the upper red and green chips; the second red is below them.

The visible bet cluster is countable; no specific chip face is hidden by the hand. No generic pot or betting decision is derived.
