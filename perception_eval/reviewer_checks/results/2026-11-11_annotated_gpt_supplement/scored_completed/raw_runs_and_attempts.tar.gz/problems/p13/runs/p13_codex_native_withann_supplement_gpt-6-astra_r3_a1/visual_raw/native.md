# Native perception evidence

Capture: `s_current/00_capture.jpg`, resolving to `s25/00_capture.jpg`. Compared with `s24/00_capture.jpg` and `s23/00_capture.jpg`; prior durable-state context is `s24/01_parsed_state.md`.

Stable, best estimate. In s24 the robot fingertip contacts a brown chip in transit; in s25 the hand is raised at the upper right, empty and clear of the felt, in an apparently settled near-rest pose. The brown chip is now in the robot betting area. The opponent's added chips are also resting flat, with no human hand interfering. Movement occurred between captures, but no active transfer is visible in the current image. A single final frame cannot prove the hand has stopped; scene stability and the idle stage are inferred and marked uncertain. No visible dropped card, scattered inventory, pinned object, or physical failure.

It is our turn: the white “Your Turn” marker is at the lower-left robot seat. The yellow BIG BLIND marker is at the robot seat. The white DEALER and blue SMALL BLIND markers are at the opponent seat, agreeing with the cached blind assignment.

Three face-up community cards read left to right as 7d, 6s, 7c. The last card has a 7 index and club pips, not a jack illustration. Two additional card backs occupy the left part of the board lane; they are not face-up community cards and their identities are not inferred. They were already present in s23 and s24. Both opponent hole cards remain face-down in their normal top-seat positions, and both robot hole cards remain face-down at the bottom seat. No fold/muck or showdown is visible.

Inventory counts, counting individual flat faces in denomination order 5, 10, 50, 100:

- Robot, bottom seat: 4 red, 3 blue, 4 green, 3 brown.
- Opponent, top seat: 2 red, 4 blue, 3 green, 3 brown.

Bet counts, excluding seat inventories and labeled buttons:

- Robot bet, left of the board: 0 red, 1 blue, 0 green, 1 brown.
- Opponent bet, right of the board: 2 red, 0 blue, 1 green, 1 brown.

The right-side robot body obscures the far-right table edge, but the visible opponent betting group and all four inventory denomination groups can be counted. No extra hidden chips are assumed.

No readable held card is visible. Cached robot cards 9d and 5d are context only; no showdown comparison is applicable. The prior action-sequence file contains an idle state with no dispatched step, so it supplies no active atom to certify. Current visual evidence supports idle as the best estimate, rather than preserving the previous parsed acting label automatically.
