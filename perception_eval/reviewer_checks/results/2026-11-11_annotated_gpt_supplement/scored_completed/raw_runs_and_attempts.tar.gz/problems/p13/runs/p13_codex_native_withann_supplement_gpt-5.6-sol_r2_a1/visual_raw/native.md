# Raw Visual Perception

- Current image: `s_current/00_capture.jpg`.
- Stability comparison: compared with `s24/00_capture.jpg`. The dexterous hand has withdrawn from its prior extended chip-pushing pose and is now settled above the upper-right edge of the table. There is no visible motion blur, it is not holding a card or chip, and the card/chip layout is clear. The current scene is stable.
- Robot behavior: the hand is near its idle/rest area and no longer contacts the betting lane. No dropped card, scattered chips, moved non-target object, or human-help condition is visible.
- Turn marker: the white `Your Turn` button is at the bottom-left robot seat, so it is the robot's turn.
- Blind marker: the yellow `BIG BLIND` button is at the bottom/robot seat. The robot is the big blind, consistent with the cached dealer/small-blind assignment at the opponent seat.
- Community cards: three face-up cards are visible in the central row, left to right: `7d`, `6s`, `Jc`.
- Hole/showdown evidence: both opponent hole cards and both robot hole cards remain face-down in their normal seat areas. There is no fold/muck signature and no showdown; cached robot cards are not needed for an outcome comparison.
- Robot inventory (bottom seat, outside the betting lane): 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top seat, outside the betting lane): 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current bet (left of the community-card row): no red chips, 1 blue 10-chip, no green chips, and 1 brown 100-chip.
- Opponent current bet (right of the community-card row): 2 red 5-chips, no blue chips, 1 green 50-chip, and 1 brown 100-chip.
- The inventory reductions and visible bet chips balance by denomination: the robot's brown inventory decreased by one into its bet, and the opponent's green and brown inventories each decreased by one into the opponent bet. No fields require inheritance or a low-confidence estimate.
