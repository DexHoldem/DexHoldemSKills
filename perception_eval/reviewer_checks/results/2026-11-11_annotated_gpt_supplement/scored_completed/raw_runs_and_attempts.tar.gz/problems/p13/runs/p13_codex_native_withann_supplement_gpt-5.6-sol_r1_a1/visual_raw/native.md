# Raw Visual Perception

- Scene stability: Stable. Compared `s24/00_capture.jpg` with `s_current/00_capture.jpg`. In the prior frame the dexterous hand was down in the robot betting/inventory region; in the current frame it has withdrawn to a settled near-idle pose above the upper-right table. The chips and cards are sharp and no object is visibly in motion.
- Table geometry: robot/player seat is at the bottom; opponent seat is at the top; the shared board is across the center.
- Turn marker: the white `Your Turn` button is clearly at the bottom-left robot seat, so it is the robot/player's turn.
- Blind marker: the yellow `BIG BLIND` button is at the bottom robot seat. This agrees with the durable blind assignment.
- Community cards: three face-up shared cards are visible, left to right: `7d`, `6s`, `Jc`.
- Robot/player inventory: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips.
- Opponent inventory: 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot/player current bet, left of the community-card row: 1 blue 10-chip and 1 brown 100-chip; no red 5-chips or green 50-chips.
- Opponent current bet, right of the community-card row: 2 red 5-chips; no blue 10-chips, green 50-chips, or brown 100-chips.
- Robot behavior: no card or chip is being held. The hand appears settled after the chip movement and does not indicate a visible physical failure.
- Showdown: the opponent's two hole cards remain face-down in the normal opponent hole-card area, and the robot's two hole cards remain face-down in the normal robot area. There is no fold/muck signature and no showdown.

