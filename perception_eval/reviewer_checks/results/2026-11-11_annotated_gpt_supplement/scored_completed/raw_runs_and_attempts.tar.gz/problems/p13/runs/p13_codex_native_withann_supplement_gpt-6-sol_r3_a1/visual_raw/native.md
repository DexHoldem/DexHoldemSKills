# Raw perception — s25/00_capture.jpg

Stable. Compared s24/00_capture.jpg with s25/00_capture.jpg. The robot hand has lifted clear of the felt into an apparently settled raised pose. It holds no visible card or chip. Cards and chip groups are countable; the hand partly covers the far-right edge of the opponent inventory.

The white “Your Turn” button is at the bottom/robot seat. The yellow big-blind button is also at the robot seat; the white dealer button is at the top/opponent seat. The blue small-blind button is at the opponent seat.

Three face-up community cards are visible, left to right: 7d, 6s, Jc. The two face-down cards in the central lane are not board cards. The opponent's hole cards remain face-down at the top seat; the robot's hole cards remain face-down at the bottom seat. No fold, revealed hand, or showdown result is visible.

Robot inventory (bottom): four red 5 chips, three blue 10 chips, four green 50 chips, and three brown 100 chips. Opponent inventory (top): two red 5 chips, four blue 10 chips, three visible green 50 chips, and approximately four brown 100 chips; the rightmost brown chip position is partly covered by the raised hand.

Robot current bet (left of board): one blue 10 chip and one brown 100 chip. Opponent current bet (right of board): two red 5 chips, one green 50 chip, and one brown 100 chip. The right-side bet denominations are slightly less certain because of angle and proximity to the robot arm, but the chips are distinguishable from the top inventory.
