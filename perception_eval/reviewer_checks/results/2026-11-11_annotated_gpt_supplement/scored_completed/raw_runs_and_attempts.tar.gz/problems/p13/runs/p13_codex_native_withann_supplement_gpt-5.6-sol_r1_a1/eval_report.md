# Perception Evaluation Report

The current capture was compared with `s24/00_capture.jpg`. The prior frame showed the robot in the middle of a brown 100-chip movement; the current frame shows the hand withdrawn and settled, one fewer brown 100-chip in robot inventory, and one brown 100-chip in the robot betting area. This supports `scene_stable: true`, `loop_stage: idle`, robot inventory brown count 3, and robot brown bet count 1.

Direct current-frame evidence determines the three-card board (`7d 6s Jc`), the robot-side white turn marker, all visible chip counts, and the absence of showdown. The robot big-blind assignment is both directly supported by the yellow `BIG BLIND` marker at the bottom seat and consistent with `hole_card_cache.json`. The previous parsed state was used only to preserve and cross-check unchanged durable fields. No field required low-confidence inheritance, so `uncertain_fields` is empty.
