# Raw visual perception

## Capture used

- Requested `s_current/00_capture.jpg` is absent.
- Latest available frame used as current: `s25/00_capture.jpg`.
- Prior comparison frame: `s24/00_capture.jpg`.

## Scene and robot

- The table layout is clear and the robot hand/arm is visible at the upper-right edge.
- The hand is settled enough to read the table, but it partially occludes the right/top betting and inventory region.
- No cards or chips appear scattered; no showdown or fold signature is visible.

## Board and turn

- Three face-up community cards are visible, left to right: `7d`, `6s`, `Jc`.
- The white `Your Turn` button is at the bottom robot/player side, so it is the robot's turn.
- The yellow `BIG BLIND` button is at the bottom robot/player side; robot is big blind.

## Chips

- Robot/player inventory estimate: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Opponent inventory estimate: 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Robot current-bet area: 1 blue 10-chip visible; no red, green, or brown bet chips visible.
- Opponent current-bet area: 2 red 5-chips estimated; the right-side area is partly occluded by the robot hand, so this count is lower confidence.

## Showdown

- Neither player's hole cards are face-up in a showdown configuration.
- Showdown outcome: not_showdown.
