# Raw Visual Perception

- Current image: `s_current/00_capture.jpg`.
- Geometry: robot/player seat is at the bottom; opponent seat is at the top; the community-card row is central.
- Scene/robot: Stable. Compared with `s24/00_capture.jpg` (and the preceding `s23/00_capture.jpg`). The dexterous hand has withdrawn from the robot chip inventory to the familiar raised near-idle pose, is open, and is not holding a card or chip. The newly moved chip is lying flat in the robot bet area; no object appears mid-transfer, blurred, scattered, pinned, or disturbed. This is a settled post-atom view, so the visual loop stage is `atom_idle`.
- Turn: the white "Your Turn" button is visible at the bottom-left robot seat, so it is the robot's turn.
- Blind: the yellow "BIG BLIND" button is at the bottom robot seat. The robot is big blind; this agrees with the durable cached blind assignment.
- Community cards: three face-up cards are visible, left-to-right `7d`, `6s`, `Jc`.
- Robot inventory (bottom seat, excluding bet chips): 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top seat, excluding bet chips): 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot current bet (left/lower robot side of the board): 1 blue 10-chip and 1 brown 100-chip; no red 5-chip or green 50-chip.
- Opponent current bet (right/upper opponent side of the board): 2 red 5-chips; no blue 10-chip, green 50-chip, or brown 100-chip.
- Showdown: not at showdown. Both players' hole cards remain face-down, the opponent has not exposed or visibly mucked their cards, and only the three-card flop is present.
- Confidence/occlusion: the camera/robot body occludes part of the far right edge but not the counted chip faces. No output field requires inheritance at low confidence.
