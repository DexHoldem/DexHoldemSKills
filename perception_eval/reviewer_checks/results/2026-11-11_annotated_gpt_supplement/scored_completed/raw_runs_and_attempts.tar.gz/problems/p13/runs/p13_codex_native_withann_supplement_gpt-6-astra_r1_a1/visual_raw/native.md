# Native visual evidence

Source: `s_current/00_capture.jpg` resolves to `s25/00_capture.jpg`. Compared with `s24/00_capture.jpg` and `s23/00_capture.jpg`; the previous parsed state is `s24/01_parsed_state.md`.

Unstable (conservative estimate). Between s24 and s25 the robot hand moves from low over the betting lane to a raised pose at the upper right, and chips change position. The current hand is empty and clear of the felt, possibly returning to near idle, but a settled endpoint is not established by these frames. Use acting, with uncertainty in loop_stage and scene_stable. No visible dropped card, pinned object, scattered inventory, or basis for a failure/recovery label.

The bottom seat is the robot; the top seat is the opponent. Count flat individual chip faces, excluding labeled buttons. Inventory groups remain separate from the bets beside the board.

Robot inventory: four red 5 chips, three blue 10 chips, four green 50 chips, three brown 100 chips.

Opponent inventory: two red 5 chips, four blue 10 chips, three green 50 chips, three brown 100 chips.

Robot bet, left of the community cards: no red 5 chips, one blue 10 chip, no green 50 chips, one brown 100 chip.

Opponent bet, right of the community cards: two red 5 chips, no blue 10 chips, one green 50 chip, one brown 100 chip. The visible cluster is countable, but the robot assembly obscures the farther-right continuation of this area; counts are best visible estimates and opponent_bet is uncertain.

Three face-up community cards, left to right: 7d, 6s, 7c. The rightmost card shows a 7 and club pips, not Jc. Two additional card backs in the central row are excluded; their values cannot be read. Both opponent hole cards remain face-down in their normal top-seat positions, and both robot hole cards remain face-down at the bottom. No readable held card is visible.

It is our turn. The white Your Turn button is at the bottom-left robot seat.

The white dealer button and blue small-blind button are at the opponent seat. The yellow BIG BLIND button is at the robot seat. Robot blind assignment is big_blind, with no visible conflict.

There is no visible showdown or fold/muck. Opponent hole cards have not been displaced into the board lane. Outcome is not_showdown. Cached robot cards 9d and 5d are context only; no hand comparison is warranted.
