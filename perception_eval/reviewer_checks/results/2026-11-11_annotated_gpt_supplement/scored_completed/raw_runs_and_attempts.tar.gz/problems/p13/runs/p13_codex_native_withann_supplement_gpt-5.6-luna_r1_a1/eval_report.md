# Perception merge report

The current frame was compared with the prior parsed state and prior capture context. The prior frame showed the robot motion still in progress while pushing a 100-chip. The current frame shows the hand withdrawn and the table settled, so the state advances to `atom_idle` with `scene_stable: true`.

Durable fields were retained where the current image agrees: big blind, robot turn, and community cards `7d 6s Jc`. The visual chip evidence reflects one brown 100-chip newly in the robot current-bet area and one fewer brown 100-chip in robot inventory. Both hole-card positions are face down, so showdown outcome remains `not_showdown`. No uncertainty was necessary.
