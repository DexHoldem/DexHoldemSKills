# Raw visual perception

Capture: `s_current/00_capture.jpg` (1920 × 1080). Compared with `s24/00_capture.jpg` and the earlier settled `s23/00_capture.jpg` for robot motion.

- **Scene and robot:** Unstable. The dexterous hand has risen from the lower-right betting area in s24 to above the upper-right table edge in the current frame. It is away from the settled near-idle position seen in s23, so the chip-push sequence appears still in progress. The hand is not visibly holding a card or chips. The layout is countable; no stuck hand, displaced card, or scattered chip group is visible. The hand partly occludes the far upper-right edge, but the bet chips in view can be counted.
- **Turn and blind:** The white `Your Turn` button is at the bottom-left robot seat, so it is the robot's turn. The white dealer button remains at the opponent seat; robot is big blind (also recorded in the blind cache).
- **Board:** Three face-up community cards, left to right: `7d`, `6s`, `Jc`. The two card backs to their left are face-down board positions, not readable community cards.
- **Robot inventory, bottom seat:** Four red 5 chips, three blue 10 chips, four green 50 chips, three brown 100 chips. The brown count is one lower than s24 and the newly placed brown chip is visible in the central-right betting lane.
- **Opponent inventory, top seat:** Two red 5 chips, four blue 10 chips, three green 50 chips, three brown 100 chips. The blue `SMALL BLIND` marker is a button, not an inventory chip.
- **Robot betting area, left of community cards:** One blue 10 chip and one brown 100 chip; no red or green chips. The brown chip sits beside the blue chip and was absent there in s24.
- **Opponent betting area, right of community cards:** Two red 5 chips, one green 50 chip, and one brown 100 chip; no blue chips. The green and brown chips are now in this lane, separate from the opponent's top inventory.
- **Showdown:** Neither player's hole cards are face-up. The opponent cards remain in the normal upper seat area; no fold or muck is visible. The cached robot cards are `9d` and `5d`, but they are not needed for a showdown comparison here. Outcome is not showdown.

The latest hand pose may be a return motion rather than a fully settled pose; scene stability and loop stage reflect that uncertainty conservatively.
