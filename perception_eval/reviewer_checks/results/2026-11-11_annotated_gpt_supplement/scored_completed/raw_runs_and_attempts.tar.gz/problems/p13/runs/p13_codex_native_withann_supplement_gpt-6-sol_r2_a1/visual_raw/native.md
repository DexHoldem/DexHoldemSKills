# Raw visual perception

- Compared `s12/00_capture.jpg` with `s_current/00_capture.jpg`. The robot hand has moved from the lower-right hole-card area to an extended position above the upper-right table. It is not near its resting pose; the action appears in progress. No card or chip is clearly held, and no clear physical failure is visible. The hand partly occludes the far-right opponent inventory.
- The white "Your Turn" button is at the lower-left robot seat. The yellow big-blind button is at the robot seat. The dealer button is at the upper opponent seat, consistent with the cached blind assignment.
- Three face-up community cards are visible in the central row, left to right: `7d`, `6s`, `7c`. The two card backs to their left are not face-up community cards. Neither player's hole cards are face-up; no showdown or fold is apparent.
- Robot inventory in the lower seat: four red 5 chips, three blue 10 chips, four green 50 chips, three brown 100 chips. The robot betting area left of the board has one blue 10 chip and one brown 100 chip.
- Opponent inventory in the upper seat: approximately two red 5 chips, four blue 10 chips, three green 50 chips, and three brown 100 chips. The extended hand limits confidence in the far-right upper inventory. The opponent betting area right of the board has two red 5 chips and one blue 10 chip.
