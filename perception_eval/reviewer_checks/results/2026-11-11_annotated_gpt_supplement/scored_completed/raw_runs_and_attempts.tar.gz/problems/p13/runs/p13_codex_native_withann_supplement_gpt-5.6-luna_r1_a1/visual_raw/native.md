# Raw visual perception

- Capture inspected: `s25/00_capture.jpg` (the requested `s_current/00_capture.jpg` is represented by the current capture in this workspace).
- The table is visually settled: the dexterous hand/robot body is at the right side and is not contacting or moving cards or chips. No substantial human arm is interfering with the table.
- Robot/player is the bottom-side seat. The white `Your Turn` marker is visible near that seat, so it is the robot's turn.
- The yellow `BIG BLIND` button is at the robot seat. In the two-player layout this makes the robot the big blind.
- Three community cards are face up in the center: 7 of diamonds, 6 of spades, and jack of clubs (`7d`, `6s`, `Jc`). No additional community card is face up.
- Both hole-card positions remain face down; this is not a showdown. The cached robot hole cards are context only and are not re-read from this frame.
- Inventory chips: robot/bottom-side inventory is consistent with 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips. Opponent/top-side inventory is consistent with 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Betting areas are anchored to the community-card row. Robot current-bet area (left/lower-left of the board) shows one blue 10-chip and one brown 100-chip. Opponent current-bet area (right/upper-right of the board) shows two red 5-chips and no blue, green, or brown bet chips.
- Confidence is high for scene stability, turn, blind, community cards, and the visible chip groups; no fields require inheritance or low-confidence marking.
