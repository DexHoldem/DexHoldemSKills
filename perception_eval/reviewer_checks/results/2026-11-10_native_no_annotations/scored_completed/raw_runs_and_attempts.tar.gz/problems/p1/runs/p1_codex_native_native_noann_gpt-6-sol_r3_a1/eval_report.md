# Perception merge

The current image is the sole evidence source. Dealer, big blind, and turn markers visibly locate the opponent as dealer/small blind and the robot as big blind and current actor. Each seat has four visible chips of each denomination. No bet chips or face-up community cards are visible. The face-down cards in the central board positions were excluded from `community_cards`.

The robot hand appears settled and clear of table objects, supporting `idle` and `scene_stable: true`. Stability is listed as uncertain because no previous capture exists for motion comparison. The prior workflow state, hole-card cache, and previous parsed state files are absent, so no field was inherited from them. No showdown evidence is visible.
