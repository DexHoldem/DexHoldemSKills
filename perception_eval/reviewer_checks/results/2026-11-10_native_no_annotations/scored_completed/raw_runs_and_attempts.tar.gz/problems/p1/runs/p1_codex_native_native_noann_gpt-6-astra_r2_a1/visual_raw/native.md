# Native visual evidence

Source: `s_current/00_capture.jpg`, resolving to `s0/00_capture.jpg`. Inspected directly. Read all field guidelines in `visual_guidelines/`.

## Geometry and chip inventories

The robot seat is at the bottom; the opponent seat is at the top. Chips are flat individual faces, separate from labeled buttons and the central betting lane.

Robot inventory: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. The red and blue groups are at bottom-left/center; the green and brown groups are at bottom-right. Each group has four separately visible faces.

Opponent inventory: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. The red group includes the isolated leftmost red chip; the blue group includes the rightmost blue chip beside the left hole card. The green group includes the lower-left green chip near the dealer button; the brown group has four faces at upper-right.

## Bets

Robot current bet area, left/lower side of the community lane: no bet chips visible; zero of each denomination.

Opponent bet area, right/upper side of the community lane: no bet chips visible; best estimate zero of each denomination. The robot assembly obscures the far-right portion of the table and limits inspection of the right betting area, so this count is uncertain. Inventory chips remain separate from bets.

## Cards and outcome

No face-up community cards are visible. Five patterned card backs/card positions lie across the central lane; none provides a readable rank or suit, and none is included as a face-up community card. Two face-down cards are in each seat's hole-card area. The far-left deck is excluded. No readable held card is visible, and the robot hand appears empty.

Neither player's hole cards are face-up. No clear fold/muck displacement or showdown is visible. Outcome: `not_showdown`; no hand comparison is possible or needed.

## Turn and blinds

It is our turn. The white button reading “Your Turn” is at the bottom-left robot seat.

The white DEALER button and blue SMALL BLIND marker are at the top/opponent seat. The yellow BIG BLIND marker is at the bottom/robot seat. Dealer/small blind is the opponent; big blind is the robot. No button conflict is apparent.

## Robot and stability

Stable, as a single-frame estimate only. Only `s0/00_capture.jpg` is available; no previous image was available for comparison. The hand is elevated at the right in an apparently resting open pose, holding no visible card or chips and making no visible contact with game objects. Foreground softness does not establish motion. The opponent's arms are folded outside the playing area. Cards and chip groups are orderly. No dropped card, scattered layout, or stuck/pinning contact is evident.

The best loop-stage estimate is `idle`. Without action-sequence context or a comparison frame, settledness and exact workflow stage cannot be confirmed. There is no visible basis for a failure, recovery, win, lose, or show-hand label.

## Context and uncertainty

`action_sequence.json`, `hole_card_cache.json`, and a previous `01_parsed_state.md` are absent from the supplied workspace. No cached cards or durable fields were inherited. Flag `loop_stage`, `scene_stable`, and `opponent_bet` as inferred or uncertain. No robot action or poker action was selected or executed.
