# Native perception — s_current (-> s0/00_capture.jpg)

Context: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md`
are absent (first state, s0). No previous frame is available for comparison.

## Scene stability
Stable (single frame only; no previous image to compare). The dexterous hand is at the
upper right in a near-idle/rest pose above the opponent's top-right inventory area. It is
not blurred and not holding a card or chips. The opponent is seated with arms crossed and
not touching the table. Note: the fingertips hover just above the top-right
(brown 100) opponent inventory group but do not hide it.

## Turn detection
It is our turn. The white "Your Turn" button is at the bottom-left robot seat area
(~19-24% x, ~73-77% y).

## Blind buttons
The white DEALER button and the blue SMALL BLIND button are at the top/opponent seat,
between the opponent's two hole-card slots. The yellow BIG BLIND button is at the
bottom/robot side, just below the board row. Dealer/small blind = opponent; robot = big blind.
No conflict.

## Community cards
No face-up community cards visible. The five board slots show only card-back
patterned rectangles (printed placeholders / face-down), not readable cards. 0 cards -> preflop.

## Hole cards
Robot: two face-down card backs in the bottom hole-card slots. Opponent: two face-down
card backs in the top slots, in their normal position (no fold/muck signature).
No held card visible.

## Robot/player inventory (bottom seat)
- red 5: 4 (two left of the blue group in an upper row, then two below)
- blue 10: 4 (two upper, two lower in the column next to the robot hole cards)
- green 50: 4 (group to the lower-right of the board, right of the BIG BLIND button)
- brown 100: 4 (far right group near the robot hand/camera body)
Counts are reasonably clear. The brown/green groups at the right are a bit angled.

## Opponent inventory (top seat)
- red 5: 4 (three in a column, one to the left)
- blue 10: 4 (three in a column, one to the right)
- green 50: 4 (right of the opponent's right hole card)
- brown 100: 4 (top-right, partly under the robot fingertips)
Counts are approximate because the top seat is far from the camera and angled.

## Bets
My current bet area (lower/robot side of the board lane): no chips visible.
Opponent bet area (upper/opponent side of the board lane): no chips visible.

## Showdown
Not showdown. No cards are face-up and nobody has folded.
