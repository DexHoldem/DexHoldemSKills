# Native Visual Perception — s0/00_capture.jpg

This is the first captured state (`s0`). No `action_sequence.json`,
`hole_card_cache.json`, or previous parsed state exist yet, so everything
below is read directly from the image with no inherited context.

## Table Geometry / Orientation

Camera looks diagonally from the robot/player side toward the opponent. The
dexterous hand and camera housing enter from the right edge and occlude the
upper-right of the frame. Robot/player seat is the bottom of the image,
opponent seat is the top. A printed "TEXAS HOLD'EM" felt logo in the
community-card row reads upside-down, consistent with the opponent being on
the far side of the table.

## Turn Detection

A white button labeled "Your Turn" is clearly visible at the bottom-left of
the table, in the robot/player seat area. No turn button is visible at the
opponent seat. Conclusion: it is the robot/player's turn.

## Blind / Button Recognition

Two round buttons sit at the top/opponent side next to the opponent's
face-down hole cards: a blue button and a white button (consistent with
"DEALER" and a small-blind marker). A yellow button labeled "BIG BLIND" sits
on the bottom/robot side, near the robot's hole cards. Applying the
two-player rule (dealer = small blind), the opponent is dealer/small blind
and the robot is big blind.

## Community Cards

The central community-card row shows five gray face-down card-back
placeholders. No community cards are face-up or dealt. Zero community cards
visible → preflop stage.

## Held / Hole Cards

Both the robot's two hole cards (bottom, near "Your Turn" button) and the
opponent's two hole cards (top) are face-down placeholders. The dexterous
hand is not holding any card — no readable held card is visible. No hole
card values can be read or cached from this frame.

## Chip Recognition

Chips are flat/unfolded. Denominations: red=5, blue=10, green=50, brown=100.

Opponent (top) inventory, flanking the opponent's face-down hole cards:
- left-of-hole-cards cluster: ~3 red (5) chips, ~3 blue (10) chips
- right-of-hole-cards cluster: ~3 green (50) chips, ~3 brown (100) chips

So opponent inventory reads as about 3 red, 3 blue, 3 green, 3 brown. Counts
are fairly confident but the chips are small in frame and slightly fanned, so
treat as approximate.

Robot/player (bottom) inventory, flanking the robot's face-down hole cards
and the "Your Turn" button:
- left cluster (near "Your Turn"): about 2 red (5) chips, plus a small mixed
  cluster showing roughly 1 brown (100) chip and 2 blue (10) chips
- right cluster (near/above the robot hole cards, beside the "BIG BLIND"
  button): about 2 blue (10) chips, ~3 green (50) chips, and ~3 brown (100)
  chips

Summed, robot inventory reads as about 2 red, 4 blue, 3 green, 4 brown. The
blue/brown counts are less certain than the opponent's because two separate
clusters have to be summed and some chips are partially overlapping/angled
near the dexterous hand side of the table.

## Bet Recognition

The actual community-card lane (the five gray placeholders and the felt area
immediately around them) has no chips sitting in it at all — it is visually
empty. The blind buttons (dealer/small-blind at the opponent seat, big blind
at the robot seat) sit adjacent to each player's own hole cards/inventory,
not inside the shared board lane. Based on this, no chips are currently
placed in either betting area: no bet chips visible on the robot side, and no
bet chips visible on the opponent side. This reading is somewhat uncertain
because the chip clusters nearest each player's hole cards could alternatively
be interpreted as already-posted blind chips rather than pure inventory; the
guidelines' "it's between inventory and the board" bet-lane description is a
thin band that, in this frame, shows no chips at all.

## Scene Stability

No previous state image exists (this is `s0`), so a two-frame comparison is
not possible. Within this single frame: the dexterous hand/camera housing is
visible at the right edge but is not reaching over the felt, no card or chip
appears to be mid-transfer, and the human opponent is simply sitting with
arms crossed off the table. Nothing in the frame suggests ongoing motion.
Treat as stable by default, noting the lack of a prior frame for comparison.

## Robot Behavior

The dexterous hand/gripper is visible entering from the right edge of the
frame, largely off the table felt itself, not holding any card or chips, and
not extended over the betting/board area. It does not appear to be acting on
anything right now.

## Showdown / Outcome

No hole cards are face-up for either player, and no fold/muck signature
(displaced face-down cards in the board lane) is visible. This is a normal
preflop state, not a showdown.
