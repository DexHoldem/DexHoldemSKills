# Perception evaluation

The current frame is stable and visually matches `s0/00_capture.jpg`. The robot hand is settled and empty. The white turn marker and yellow big-blind marker are both at the bottom robot seat, yielding `is_my_turn: true`, `blind: big_blind`, and an idle loop stage.

No face-up community or showdown cards are visible, so the board is empty and the outcome is `not_showdown`. Both players' visible inventory groups were counted separately from the central betting lanes. No bet chips are visible on either side. The opponent bet estimate is marked uncertain because the robot hand partially occludes that lane.

The named action-sequence, hole-card-cache, and prior parsed-state context files were absent, so no fields were inherited or merged from them. All concrete output values come from the current image, with `s0` used only to confirm visual stability.
