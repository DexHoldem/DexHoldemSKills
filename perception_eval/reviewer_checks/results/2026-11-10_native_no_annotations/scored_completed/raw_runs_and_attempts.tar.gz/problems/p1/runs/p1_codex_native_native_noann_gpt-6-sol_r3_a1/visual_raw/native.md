# Raw visual perception

Source: `s_current/00_capture.jpg` (`s0/00_capture.jpg`). The requested prior `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` are absent from this workspace; no earlier frame is available.

- The robot/player seat is at the bottom and the opponent seat is at the top. The white **Your Turn** button lies at the bottom-left robot seat. The white **Dealer** button is in the opponent band, while the yellow **Big Blind** button is in the robot band. Thus the opponent is dealer/small blind and the robot is big blind.
- The dexterous hand is elevated at the upper right, away from the cards and chips. It does not visibly hold a card or chips. The table objects look settled in this single frame; motion cannot be confirmed without a prior frame. The robot body blocks part of the far-right view but the counted chip groups remain visible.
- Five card-back-shaped objects occupy the central board positions. None is face-up or readable, so there are **zero visible face-up community cards**. Two face-down hole cards are in each seat's normal area. No card is visibly held by the robot. There is no visible fold, revealed hand, or showdown.
- Robot inventory, bottom seat: red 5 chips **4**; blue 10 chips **4**; green 50 chips **4**; brown 100 chips **4**. These are flat individual faces, not stacks.
- Opponent inventory, top seat: red 5 chips **4**; blue 10 chips **4**; green 50 chips **4**; brown 100 chips **4**.
- Robot bet area on the lower side of the central lane: no visible bet chips of any denomination. Opponent bet area on the upper side of the central lane: no visible bet chips of any denomination. Buttons and inventory groups were excluded from the bet counts.
