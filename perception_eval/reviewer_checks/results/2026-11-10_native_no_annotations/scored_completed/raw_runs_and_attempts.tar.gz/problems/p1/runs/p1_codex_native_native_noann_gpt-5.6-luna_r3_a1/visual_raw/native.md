# Raw visual perception

Capture inspected: `s0/00_capture.jpg` (the requested `s_current/00_capture.jpg` is not present).

- Table orientation: robot/player seat is at the bottom; opponent seat is at the top.
- Scene: the robot apparatus is at the right edge and appears settled; no visible card or chip movement. The right side is partly occluded by the apparatus, but the relevant chip groups and markers remain readable.
- Community cards: no face-up community cards. Five central card slots are face-down, so the board is preflop.
- Turn marker: white `Your Turn` button is at the bottom/robot seat; it is the robot's turn.
- Blind marker: yellow `BIG BLIND` button is at the bottom/robot seat. With two players, robot is the big blind.
- Robot inventory (bottom seat), denomination order 5/10/50/100: approximately 4 red, 3 blue, 3 green, 3 brown chips.
- Opponent inventory (top seat), denomination order 5/10/50/100: approximately 4 red, 4 blue, 3 green, 3 brown chips.
- Robot current-bet area (lower side of the community-card row): no chips visible.
- Opponent current-bet area (upper side of the community-card row): no chips visible.
- Showdown: not indicated; hole cards remain face-down and there is no visible outcome.

Context note: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` were not present in the workspace, so no prior state was inherited.
