# Visual Raw Perception — s_current

## Scene Markers
- **"Your Turn" marker**: visible near robot side (bottom-left of robot area) → it is the robot's turn.
- **"BIG BLIND" marker (yellow)**: centered on robot side between hole cards → robot is big blind.
- **"SMALL BLIND" marker (blue)**: on opponent side → opponent is small blind.
- **"DEALER" marker (white)**: on opponent side → opponent is the dealer/button (heads-up: SB = dealer).
- Scene appears stable; no motion blur or chip animation; robot arm idle to the right.

## Community Cards
- 5 face-down card backs in the center row. No community cards revealed → pre-flop.

## Hole Cards
- Robot (bottom): 2 face-down card backs in front of robot.
- Opponent (top): 2 face-down card backs in front of opponent.

## Chips — Robot (my_chips) — stacks flanking robot's hole cards
- Left stack: red/white "5" chips, ~4 visible.
- Center-left: blue "10" chips arranged in betting zone (some may be current bet).
- Right stacks: green "50" chips (~3) and black/white "100" chips (~3).
- Rough breakdown: {"5": 4, "10": 3, "50": 3, "100": 3} (starting-stack approximation).

## Chips — Opponent — stacks flanking opponent hole cards
- Mirror layout: red "5" chips (~4), blue "10" chips (~3-4), green "50" (~3), black/white "100" (~3).
- Rough breakdown: {"5": 4, "10": 4, "50": 3, "100": 3}.

## Current Bets
- Robot side: a few blue "10" chips in betting zone forward of hole cards → likely the posted big blind (1×10 chip).
  - my_current_bet ≈ {"5": 0, "10": 1, "50": 0, "100": 0}.
- Opponent side: a single "5" red chip forward in betting zone → likely posted small blind.
  - opponent_bet ≈ {"5": 1, "10": 0, "50": 0, "100": 0}.

## Loop Stage
- "Your Turn" button present AND no community cards revealed AND blinds posted → `acting` (robot pre-flop action turn).

## Showdown
- No hole cards exposed on either side; not a showdown.

## Uncertainty Notes
- Chip counts are approximate; exact denomination stack heights hard to verify at this angle.
- my_current_bet / opponent_bet split between "stack" and "bet" chips is estimated based on BB=10 / SB=5 convention and proximity to hole cards.
