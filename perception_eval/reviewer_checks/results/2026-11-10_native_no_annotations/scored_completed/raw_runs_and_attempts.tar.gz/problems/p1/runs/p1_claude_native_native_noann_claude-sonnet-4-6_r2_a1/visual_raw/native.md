# Raw Perception Evidence

## Source Image
`s_current/00_capture.jpg`

## Turn Detection
White "Your Turn" button is CLEARLY visible at the bottom-left of the table, in the robot/player seat area. It is our turn.

## Blind Buttons
- Yellow "BIG BLIND" button is at the robot/bottom seat area.
- Blue "DEALER" button is at the opponent/top seat area.
- Conclusion: Robot is the big blind; opponent is the dealer/small blind.

## Community Cards
The center community card area shows face-down card backs (blue/gray pattern) in approximately 4 card-slot positions. No face-up cards are readable. This indicates preflop — 0 community cards visible.

## Chip Inventory — Robot/Player (bottom seat area)
Chips in the bottom seat inventory groups, excluding the bet area:
- Red (5): approximately 4 chips
- Blue (10): approximately 3 chips
- Green (50): approximately 3 chips
- Brown (100): approximately 3 chips
Note: counts are approximate due to chip overlap and viewing angle.

## Chip Inventory — Opponent (top seat area)
Chips in the top seat inventory groups:
- Red (5): approximately 4 chips
- Blue (10): approximately 4 chips
- Green (50): approximately 3 chips
- Brown (100): approximately 3 chips
Note: counts are approximate; top-seat chips are viewed at a steeper angle.

## Bet Areas
- My current bet (left of community card area): approximately 2 blue 10-chips visible. Counts uncertain.
- Opponent bet (right of community card area): approximately 1 blue 10-chip visible. Partially occluded by the robot arm at right side of image; count is uncertain.

## Scene Stability
The image is clear and stable. The robot arm is in a resting pose on the right. No motion blur or transition state visible. Scene is stable.

## Showdown
No showdown in progress. Cards are face-down. Not a showdown situation.

## Loop Stage Assessment
The "Your Turn" white button is at the robot seat, indicating it is our turn to act. Loop stage is `acting`.
