# Evaluation Report

## Evidence Summary
- **Scene Stability:** Stable (s0, no motion visible).
- **Turn:** Robot turn (`is_my_turn: true`). The "Your Turn" button is at the robot seat.
- **Blinds:** Robot is Big Blind. Opponent is Dealer/Small Blind.
- **Chips:**
    - Robot: 4x5, 3x10, 3x50, 3x100.
    - Opponent: 4x5, 4x10, 3x50, 3x100.
- **Bets:** No bets active.
- **Cards:** Preflop. No community cards visible. All hole cards are face-down.
- **Robot State:** Hand is near idle pose in the top-right.

## Merging and Confidence
All fields are derived directly from visual evidence in `s0/00_capture.jpg`. Confidence is high as all objects (buttons, chips, cards) are clearly visible and countable. No context files were available, so all state is based on current perception.
