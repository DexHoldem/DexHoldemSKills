# Evaluation report

The current capture was parsed directly using the field-specific visual guidelines. The `Your Turn` button identifies the robot turn, and the yellow `BIG BLIND` button identifies the robot as big blind. The board and both hole-card areas are face-down, so no readable community cards or showdown result were merged. Inventory chip counts were estimated from the unfolded color groups; both betting areas appear empty.

No `action_sequence.json`, `hole_card_cache.json`, or previous parsed-state file exists in this workspace, so there was no durable-field inheritance or action-context merge. `scene_stable` and `loop_stage` are single-frame estimates and are flagged as uncertain for that reason. No robot action was executed.
