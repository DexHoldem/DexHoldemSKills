# Raw visual perception

Source: `s_current/00_capture.jpg` (symlinked to `s0/00_capture.jpg`).

- Scene: The table and cards appear visually settled in the single available frame. The robot dexterous hardware is visible at the right and is not visibly holding a card or chip. No prior frame is available for motion comparison.
- Turn: The white `Your Turn` button is at the bottom-left robot/player seat, so it is the robot/player's turn.
- Blind: A yellow `BIG BLIND` button is at the bottom robot/player seat. The robot/player is the big blind.
- Community cards: Five face-down card backs are visible in the central community-card row. No face-up community-card values are readable.
- Hole cards/showdown: Both players' hole-card areas appear face-down. No opponent reveal, fold/muck displacement, or showdown outcome is visible.
- Robot/player inventory: approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory: approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The right-side hardware partially crowds the top-right view, but the groups remain countable.
- Current bets: No chips are visibly placed in either betting area adjacent to the community-card row; both bet vectors are estimated as zero.
- Missing context: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` are not present in the workspace, so no prior-state merge or cached-hole-card comparison was possible.

