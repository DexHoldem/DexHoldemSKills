# Eval Report

## Image Analyzed
`s_current/00_capture.jpg` — single frame, no prior parsed state available.

## Key Evidence

| Field | Evidence | Confidence |
|---|---|---|
| `is_my_turn` | White "Your Turn" button clearly at robot/bottom seat | High |
| `blind` | Yellow BIG BLIND button at robot seat; blue DEALER at opponent seat | High |
| `community_cards` | All 5 community card slots show face-down blue card backs — preflop | High |
| `scene_stable` | Robot arm in settled near-idle pose on right; no motion detected | High |
| `showdown_outcome` | No hole cards face-up; no showdown in progress | High |
| `loop_stage` | Robot's turn to act, preflop → "acting" | High |
| `my_chips` | ~4 red, ~3 blue visible; green/brown estimated from right portion of inventory | Medium (green/brown low) |
| `opponent_chips` | ~4 red, ~4 blue, ~3 green, ~3 brown in top-right area; all approximate | Low–Medium |
| `my_current_bet` | ~1 blue (10) chip near left of community cards, consistent with BB | Low |
| `opponent_bet` | ~1 red (5) chip near right of community cards, consistent with SB | Low |

## Merging Notes

- No `sN-1/01_parsed_state.md` available for inheritance — all fields estimated directly from image.
- No `action_sequence.json` or `hole_card_cache.json` available — no prior context to merge.
- Chip counts for green (50) and brown (100) denominations are estimated due to partial occlusion/angle; listed in `uncertain_fields`.
- Bet area chip counts are inherently small (just blinds posted) and difficult to count precisely; also listed as uncertain.
- All high-confidence fields (turn, blind, community cards, scene stability, showdown) are directly observable from clear visual cues.
