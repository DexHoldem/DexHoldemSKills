# Native visual evidence

Source: `s_current/00_capture.jpg`, resolving to `s0/00_capture.jpg`. Inspected the image directly and read all field guidelines in `visual_guidelines/`.

Stable, provisionally from this single image. No previous capture is available for comparison. The robot hand is raised at the upper-right in an apparently resting pose, with no visible card or chip held and no evident contact with the felt. The nearer robot hardware is out of focus; this alone does not establish movement. The opponent has folded arms outside the playing surface. No visible object is being rearranged. Stability and the idle loop-stage estimate are uncertain without temporal comparison or workflow context. No visible failure or recovery condition is established.

Orientation: robot inventory is in the bottom seat band; opponent inventory is in the top seat band. Central betting areas are distinct from these inventory groups. Robot hardware obscures the far-right table edge and part of the right/opponent betting region.

It is our turn. The white `Your Turn` marker is clearly at the bottom-left robot seat.

The white `DEALER` marker and blue small-blind marker are at the top/opponent seat. The yellow `BIG BLIND` marker is at the bottom/robot seat. Dealer and small blind belong to the opponent; big blind belongs to the robot. No button conflict is visible.

Robot inventory: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. Each denomination has four separately visible faces in the bottom inventory band.

Opponent inventory: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. The top groups are foreshortened but their four individual faces are distinguishable. Buttons are excluded from both counts.

Robot current bet area: no red, blue, green, or brown chips visible; estimate zero of each denomination.

Opponent bet area: no red, blue, green, or brown chips visible in the exposed central lane; estimate zero of each denomination. The far-right portion is obscured by robot hardware, so this count is uncertain.

No face-up community cards are visible. Five patterned card-shaped positions occupy the center lane; none provides a readable rank or suit and none is counted as a face-up community card. Two face-down card-shaped positions are visible at each player's normal hole-card area. No readable held card is visible. Hidden card values are not inferred.

No opponent or robot hole cards are visibly face-up, and no clear displaced/mucked cards or other hand-ending evidence is present. The image does not establish showdown, a fold, or a winner. Outcome: not_showdown.

The requested `action_sequence.json`, `hole_card_cache.json`, and previous `01_parsed_state.md` are absent from the available workspace. No durable field was inherited and no dispatched action or cached hole-card value was assumed.
