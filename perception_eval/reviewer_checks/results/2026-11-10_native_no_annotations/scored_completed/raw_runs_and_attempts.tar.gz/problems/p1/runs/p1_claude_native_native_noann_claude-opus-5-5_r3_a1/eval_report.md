# Eval report — perception step (s_current = s0)

## Evidence
- Source: `s0/00_capture.jpg` (through the `s_current` symlink). This is a single frame.
- Context files: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md`
  are all missing. This is the first state, so no fields were inherited and no
  frames were compared.

## Results
- Turn: the white "Your Turn" button is at the bottom-left robot seat, so `is_my_turn` is true.
- Blinds: DEALER and SMALL BLIND buttons are on the opponent side and BIG BLIND
  is on the robot side, so `blind` is `big_blind`.
- Board: no face-up community cards (the center slots are card-back placeholders), so this is preflop.
- Inventories: the robot has 4 of each denomination (5/10/50/100), and so does the opponent.
- Bets: both betting lanes are empty.
- Robot hand: near-idle at the upper right. It holds nothing and doesn't block either bet lane
  or the board.
- Showdown: none. The opponent's cards are face-down in their normal slot.

## Merging / uncertainty
- `scene_stable` is set to true from a single frame, because no previous frame exists to compare.
- `opponent_chips` is marked uncertain because the brown 100 group sits next to the robot
  hand and is angled. The best count is 4.
- `loop_stage` is set to `idle` because no workflow action is in flight and the hand is settled.
