# Visual Perception - Raw Evidence

## Image analyzed
- `s_current/00_capture.jpg` (first capture, s0)
- No prior state for comparison (first perception cycle)

## Table Geometry & Orientation

The camera angle is diagonal from the robot/player side (bottom of frame) toward the opponent (top of frame). The table is a reddish felt with white line markings for Texas Hold'em.

- Robot/player seat: bottom of image, where the person in white shirt is positioned
- Opponent seat: top/upper area of the table
- Central community-card row: middle band across the table, marked "TEXAS HOLDEM"
- Community cards visible: 5 face-up positions in the central row
- Dexterous hand: visible on the right edge of frame, near idle/resting pose

## Community Cards

Five community cards are visible in the central row, laid out left to right face-up:
1. Left-most card: appears to show card patterns but rank/suit not clearly legible from this angle
2. Second card: visible but pattern unclear
3. Middle card: visible but pattern unclear
4. Fourth card: visible but pattern unclear
5. Right-most card: visible but pattern unclear

The cards are positioned in the standard Texas Hold'em board area. All five appear to be face-up, suggesting river stage (postflop complete hand).

**Note**: Exact card values are uncertain due to image angle, lighting, and resolution. The card faces show patterns consistent with playing cards but specific ranks and suits are not definitively readable.

## Robot/Player Inventory Chips (Bottom Area)

Located in the lower-left seat band, near the robot's position and below the community cards.

Observed chip counts by denomination:
- Red (5-value): approximately 4 chips
- Blue (10-value): approximately 3 chips
- Green (50-value): approximately 3 chips
- Brown (100-value): approximately 3 chips

The chips are flat/unfolded on the felt and countable. The inventory appears largely intact and well-separated.

## Opponent Inventory Chips (Top Area)

Located in the upper/opponent seat band, near the opponent's hole-card position.

Observed chip counts by denomination:
- Red (5-value): approximately 4 chips
- Blue (10-value): approximately 4 chips
- Green (50-value): approximately 3 chips
- Brown (100-value): approximately 3 chips

The opponent's inventory appears similarly organized and countable.

## Current Betting Areas

- **Robot/Player bet (left of community cards)**: No chips visibly placed in the robot's betting area
- **Opponent bet (right of community cards)**: Several chips visible, including what appears to be a yellow "BIG BLIND" marker button and additional chips

The presence of the yellow big blind marker on the opponent's side suggests the opponent is currently the big blind.

## Turn Button & Blind Assignment

- **Turn indicator**: A white "YOUR TURN" marker is visible in the robot's seat area (bottom-left), indicating it is currently the robot's turn
- **Dealer/Small Blind Button**: Not clearly visible, but inference from big blind marker placement
- **Big Blind Button**: Yellow marker visible on the opponent's (right) side of the betting area

**Blind assignment**: Opponent has the big blind button, suggesting:
- Robot is small blind (dealer) 
- Opponent is big blind

## Hole Cards

- **Robot hole cards (bottom-right area)**: Two cards visible, appears face-down in the standard robot hole-card position
- **Opponent hole cards (top area)**: Two cards visible, appears face-down in the standard opponent hole-card position
- Neither player's hole cards are currently face-up

## Robot Hand & Arm Behavior

The dexterous hand is visible on the right side of the frame:
- Position: near idle/rest pose, not far from its initial position
- Activity: not actively holding, moving, or manipulating any object
- Occlusion: the hand does not appear to be blocking critical game zones (betting areas, community cards, or critical chip inventory areas)
- State: appears settled and stable

The hand appears to be in a near-idle configuration consistent with a completed action or ready-for-action state.

## Scene Stability

This is the first capture (s0) with no prior frame to compare. Visual assessment:
- The dexterous hand is in or near a settled pose
- Cards are not visibly moving
- Chips are flat and organized on the felt
- No human arm is substantially blocking or moving table objects
- The image is clear enough for visual parsing

**Assessment**: Scene appears stable for initial analysis. The hand has settled and all table elements are in clear, stationary positions.

## Uncertainties & Notes

1. **Community card ranks/suits**: Five cards are visible face-up, but exact values are not definitively readable from the image angle and resolution. This is noted as uncertain pending closer card reading or a clearer view.

2. **Chip counts**: Inventory and betting chip counts are approximate estimates based on visible chip faces. Some chips may be partially occluded by the viewing angle or other chips.

3. **Prior action context**: This is the first capture, so there is no prior action sequence or state to compare against. The scene represents the initial deal or table state.

4. **Hand-card relationship**: Robot hole cards are face-down and unread. Any cached values from prior viewing would need to be referenced to understand the current hand value.
