# Raw visual evidence — s0/00_capture.jpg

- The bottom seat is the robot/player; the top seat is the opponent. The five central community-card positions are face-down printed placeholders, with no face-up community cards.
- The white `Your Turn` button is at the bottom-left robot seat. The white `DEALER` button is by the top/opponent seat, so the opponent is dealer/small blind and the robot is big blind. The yellow `BIG BLIND` button is at the bottom robot seat.
- Robot inventory at the bottom: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips, all flat in their inventory groups.
- Opponent inventory at the top: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips, all flat in their inventory groups. The low green chip beside the dealer button remains within the top inventory band.
- No chip faces are visible in either central betting lane; both current bets are zero for each denomination.
- Two face-down robot hole cards and two face-down opponent hole cards remain in their usual seat areas. No cards are face-up for showdown, and no fold/muck is visible.
- The dexterous hand is suspended at the upper right, away from the chips and cards. It holds no visible object. No disturbance or motion blur is evident in this frame; the table appears settled. There is no earlier frame to compare for scene stability.

