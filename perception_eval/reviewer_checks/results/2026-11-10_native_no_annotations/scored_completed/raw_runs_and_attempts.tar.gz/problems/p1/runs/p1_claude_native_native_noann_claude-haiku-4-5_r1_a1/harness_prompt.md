# Native Perception Setup

Perform visual perception directly without delegating to subagents.

Read the capture image and extract all visual fields following the guidelines
in `visual_guidelines/`. Do not run helper scripts, call a reasoning agent,
or choose a poker action.

Write your raw perception evidence to `runs/<run_id>/visual_raw/native.md`.

Then write `runs/<run_id>/visual_summary.json` and
`runs/<run_id>/eval_report.md`. Do not execute robot actions.
