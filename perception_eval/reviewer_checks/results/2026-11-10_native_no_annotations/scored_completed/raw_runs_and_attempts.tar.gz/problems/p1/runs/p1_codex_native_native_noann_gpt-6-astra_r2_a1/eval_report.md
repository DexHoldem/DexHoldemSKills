# Perception evidence and merging

Directly inspected `s_current/00_capture.jpg` (`s0/00_capture.jpg`) using the field-specific visual guidelines. Both inventories contain four visible chip faces of each denomination. The bottom white turn button establishes robot turn; the bottom yellow big-blind marker agrees with the opponent's dealer/small-blind buttons. No face-up board cards, visible bets, exposed hole cards, or clear fold are present.

The structured result uses current visual evidence, not the sample schema counts. Central face-down card backs are excluded from community cards. Inventory chips and labeled buttons are excluded from bets.

No action-sequence file, hole-card cache, previous parsed state, or previous capture is supplied, so no prior values were merged or inherited. `idle` and stable are single-frame estimates from an apparently resting empty hand and orderly table; both fields are flagged. Opponent bets are estimated as zero and flagged because the right robot assembly partially obscures that area. No showdown comparison was performed.

Only perception output files were written. No helper script, robot action, or poker decision was executed.
