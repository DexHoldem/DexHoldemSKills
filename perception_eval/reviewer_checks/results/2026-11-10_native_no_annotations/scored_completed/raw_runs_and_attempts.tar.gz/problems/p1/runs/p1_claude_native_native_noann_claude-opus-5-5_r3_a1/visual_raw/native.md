# Native perception — s_current (-> s0/00_capture.jpg)

Context: no `action_sequence.json`, no `hole_card_cache.json`, and no prior
parsed state exist in the workspace. This is the first frame (s0), so there is no
previous image to compare against and nothing to inherit.

## Scene stability
Stable (single-frame judgment, because no sN-1 exists). The dexterous hand is at the upper right,
hovering above the opponent-side top-right chip area near the "1" marking. It is
not blurred, not holding a card or chips, and looks settled in a near-idle pose.
It does not cover either betting lane or the community-card row. It sits just
above the opponent's brown 100 chips without hiding them. The human opponent has
their arms crossed and is not touching the table.

## Turn detection
It is our turn. The white "Your Turn" button sits at the bottom-left robot seat
area (about x=410, y=800).

## Blind buttons
The white DEALER button and the blue SMALL BLIND button are both on the top/opponent
side, near the opponent hole cards. The yellow BIG BLIND button is on the
bottom/robot side, just above the robot hole cards. So the opponent is
dealer/small blind and the robot is the big blind. The buttons do not conflict.

## Community cards
No face-up community cards are visible. The five card-back images in the central
row are the mat's printed card slots or face-down placeholders, not dealt board
cards. Board stage: preflop (0 cards).

## Held card
No card is held by the dexterous hand. The robot hole cards (bottom, two card backs)
are face-down and were not read.

## Robot/player inventory (bottom seat band)
- Red 5: 4. Three sit in a column left of the "5" region, plus one at the far left.
- Blue 10: 4, in two pairs.
- Green 50: 4, in the lower-right group.
- Brown 100: 4, in the far lower-right group.

## Opponent inventory (top seat band)
- Red 5: 4. Three are stacked in a column, plus one at the left.
- Blue 10: 4. Three are in a column, plus one to the right.
- Green 50: 4, in the group right of the DEALER button.
- Brown 100: 4, in the top-right group near "1", partly under the robot hand but
  still countable. This count is slightly uncertain because the chips are angled
  and close to the hand.

## Bets
- My current bet area (robot side of the board lane): no bet chips are visible.
- Opponent bet area (opponent side of the board lane): no bet chips are visible.

## Showdown
Not a showdown. The opponent's hole cards are face-down in their normal slot, and
there is no fold or muck signature.
