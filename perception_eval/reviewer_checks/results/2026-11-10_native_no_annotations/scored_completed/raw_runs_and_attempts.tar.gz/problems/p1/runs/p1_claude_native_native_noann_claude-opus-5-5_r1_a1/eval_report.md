# Eval report — s_current (s0)

**Inputs:** `s_current/00_capture.jpg` (symlink to s0). `action_sequence.json`,
`hole_card_cache.json`, and the previous parsed state do not exist, so nothing was
inherited. Every value comes from this one image.

**Evidence summary**
- Turn: the white "Your Turn" button is at the bottom-left robot seat, so `is_my_turn = true`.
- Blinds: DEALER and SMALL BLIND are at the opponent seat and BIG BLIND is on the robot
  side, so `blind = big_blind`.
- Board: no face-up community cards, so preflop and `community_cards = []`.
- Bets: both betting lanes are empty, so both are all zeros.
- Inventories: robot has 4/4/4/4 (5/10/50/100) and opponent has 4/4/4/4.
- Robot hand: in a settled near-idle pose at the upper right, holding nothing. No layout damage.
- Showdown: none (`not_showdown`).

**Merging / stage:** There is no prior workflow state, the scene is settled and it is our turn,
so `loop_stage = idle`.

**Uncertain fields**
- `opponent_chips`: the top seat is far from the camera and angled, and the brown group is
  near the robot fingertips.
- `scene_stable`: judged from one frame because there is no previous capture to compare.

Note: I could not run the crop step for a closer look because permission was not granted.
Counts come from the full-resolution image.
