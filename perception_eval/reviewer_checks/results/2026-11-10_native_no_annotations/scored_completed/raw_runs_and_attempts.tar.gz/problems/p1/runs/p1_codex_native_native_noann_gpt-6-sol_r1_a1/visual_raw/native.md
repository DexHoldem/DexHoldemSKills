# Raw visual perception

Source: `s_current/00_capture.jpg` (`s0/00_capture.jpg`). No prior capture, `action_sequence.json`, `hole_card_cache.json`, or previous parsed state is present in this workspace.

- The bottom side is the robot seat; the top side is the opponent seat. The dexterous hand is at the upper right, away from the playing areas, with no card or chip visibly held. It appears settled in a near-rest pose. No disturbed cards or chips are visible. A single frame cannot establish whether the hand was moving between captures.
- The white `Your Turn` button is in the lower-left robot seat area: it is the robot's turn.
- The white dealer button and blue small blind button are by the opponent seat. The yellow `BIG BLIND` button is by the robot seat. The robot is the big blind.
- No face-up shared cards are visible in the central board row. Five face-down card-shaped backs/positions are visible there; none can be read as a community card. The two cards at each seat are also face-down. No visible fold or showdown result.
- Robot inventory, bottom seat: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips.
- Opponent inventory, top seat: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips.
- Robot current bet area, left/lower side of the board: no chips visible (zero of each denomination).
- Opponent bet area, right/upper side of the board: no chips visible (zero of each denomination). The hand is above this area but does not visibly cover the felt where bet chips would be.
- Stability estimate: stable from the clear single frame and settled-looking hand; uncertain because no earlier image exists for motion comparison.
