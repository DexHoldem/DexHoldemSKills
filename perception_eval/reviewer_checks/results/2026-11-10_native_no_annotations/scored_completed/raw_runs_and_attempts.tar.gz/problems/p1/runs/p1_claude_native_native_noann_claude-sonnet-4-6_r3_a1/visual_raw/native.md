# Visual Raw Perception — Native

**Source**: `s_current/00_capture.jpg`
**Previous state**: `s0/00_capture.jpg` (images are identical — first captured state)

---

## Turn Detection

The white circular button labeled "Your Turn" is clearly visible at the bottom-left of the table, within the robot/player seat area (approximately x=7–17%, y=73–86% per TABLE_GEOMETRY). This is the robot seat, so it is our turn.

**Result: It is our turn.**

---

## Blind Assignment

- Blue "DEALER" button: located in the center-upper table area, text facing away from camera (readable from opponent's side), placing it at the opponent/top seat.
- Yellow "BIG BLIND" button: located at the bottom-right of the table, within the robot/player seat band (near position "5" marker).
- Two-player rule: Dealer position = small blind. Dealer button is at opponent seat → opponent is small blind. Robot is big blind.

**Result: Robot = big blind. Opponent = small blind (dealer).**

---

## Community Cards

The central row of the table shows only face-down card-slot placeholders (gray mat rectangles). No face-up community cards are visible. This is a pre-flop state.

**Result: 0 community cards visible.**

---

## Scene Stability

Compared `s0/00_capture.jpg` and `s_current/00_capture.jpg` — images are identical. The robot arm is in a settled, near-idle pose at the right side of the frame. No active robot motion. No human arm is on the table blocking or moving objects. Cards and chips are not in motion.

**Result: Stable.**

---

## Showdown / Hand Outcome

Opponent hole cards are face-down in the normal top/opponent hole-card area. No face-up cards on the table indicating showdown. No win/lose screen or indicator visible.

**Result: Not showdown.**

---

## Chip Inventory — Robot (bottom seat band, outside betting lane)

Chips visible in the lower-center / left area of the table (robot inventory zone):
- Red (5): approximately 5 chips
- Blue (10): approximately 3 chips
- Green (50): approximately 2 chips
- Brown (100): approximately 2 chips

Counts are approximate; partial occlusion by chip grouping angle.

---

## Chip Inventory — Opponent (top seat band, outside betting lane)

Chips visible in the upper table area (opponent inventory zone):
- Red (5): approximately 4 chips
- Blue (10): approximately 4 chips
- Green (50): approximately 2 chips
- Brown (100): approximately 2 chips

Counts are approximate; angle and distance reduce precision.

---

## Bet Areas (central betting lane)

My current bet area (left of community cards / robot side of central lane):
- Approximately 1 blue (10) chip visible — consistent with big blind posted.
- No red, green, or brown chips clearly visible in this zone.

Opponent bet area (right of community cards / opponent side of central lane):
- Approximately 1 red (5) chip visible — consistent with small blind posted.
- No blue, green, or brown chips clearly visible in this zone.

Both bet counts uncertain due to small chip size and angle; best visible estimates given.
