# Perception evidence and merging

Direct inspection of `s_current/00_capture.jpg` shows the robot's white turn marker and yellow big-blind marker, with dealer/small-blind markers at the opponent seat. Both inventories contain four visible chips per denomination. No face-up board cards or visible bet chips were found. No showdown or fold is evident.

The requested `action_sequence.json`, `hole_card_cache.json`, and previous parsed state are absent; `s_current` resolves to `s0`. No prior state was merged or inherited. Counts come from the image rather than the example schema. Card-back/slot patterns are excluded from the face-up community-card list.

The empty, raised robot hand and orderly table support an idle/stable estimate, but no previous frame exists to verify motion or atom completion. Both fields are marked uncertain. Opponent bets are estimated as all zero from the exposed region and marked uncertain because the far-right area is occluded by the robot.

All schema fields have concrete values. No robot actions, helper scripts, or poker decisions were executed.
