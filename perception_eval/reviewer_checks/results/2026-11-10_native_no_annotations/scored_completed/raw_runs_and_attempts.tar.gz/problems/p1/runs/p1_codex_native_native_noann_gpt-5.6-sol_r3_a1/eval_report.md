# Perception evaluation

The current capture shows a stable, idle preflop table. The robot-side white turn marker is visible, the robot-side yellow big-blind marker is visible, all five community-card positions are empty, and neither central betting area contains chips. Both players' inventory groups visually contain four chips of each denomination. The opponent and robot hole cards remain face-down in their normal seat areas, so there is no showdown evidence.

For stability, the current frame was compared with the available `s0/00_capture.jpg` reference; the table and robot pose match with no visible object motion. No `action_sequence.json`, `hole_card_cache.json`, or prior `01_parsed_state.md` was present to merge. Consequently all structured values come directly from visual evidence, and no requested field is marked uncertain.
