# Eval Report — Perception Step

## Image: `s_current/00_capture.jpg`

## Key Evidence

**Turn**: White "Your Turn" button is unambiguously at the robot/bottom seat area → `is_my_turn = true`, `loop_stage = "acting"`.

**Blind**: Yellow "BIG BLIND" button at robot seat; blue "DEALER" button at opponent seat → robot is big blind → `blind = "big_blind"`.

**Community cards**: Center community card area shows face-down card backs in ~4 slots; no face-up cards are readable → preflop, `community_cards = []`.

**Showdown**: No showdown — all hole cards are face-down and no showdown result buttons visible → `showdown_outcome = "not_showdown"`.

**Scene stability**: Image is sharp and static; robot arm in resting pose → `scene_stable = true`.

## Chip Counts (Estimates)

| Field | 5 | 10 | 50 | 100 | Confidence |
|-------|---|----|----|-----|------------|
| my_chips | 4 | 3 | 3 | 3 | Medium — chip overlap at angle |
| opponent_chips | 4 | 4 | 3 | 3 | Medium — steeper viewing angle |
| my_current_bet | 0 | 2 | 0 | 0 | Low — bet area partially obscured |
| opponent_bet | 0 | 1 | 0 | 0 | Low — robot arm occludes right bet zone |

## Merging Notes
- No previous `s0/01_parsed_state.md` or context files found — no inherited fields.
- Bet chip counts reflect expected blind structure (BB=20, SB=10 in blue chips), but are marked uncertain due to occlusion.
- Chip inventory counts are field estimates; overlap and viewing angle reduce confidence.

## Uncertain Fields
`my_current_bet`, `opponent_bet`, `my_chips`, `opponent_chips`
