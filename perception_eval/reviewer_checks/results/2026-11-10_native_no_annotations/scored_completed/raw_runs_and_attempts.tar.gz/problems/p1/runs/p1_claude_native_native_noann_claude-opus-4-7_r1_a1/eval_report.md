# Perception Eval Report — p1

## Evidence Summary

- "Your Turn" marker visible on robot side → `is_my_turn = true`.
- "BIG BLIND" marker on robot side; "SMALL BLIND" + "DEALER" on opponent side → `blind = big_blind` (heads-up preflop; opponent is dealer+SB).
- Five community-card slots are empty (card-back pattern, no face-up ranks) → `community_cards = []` (preflop).
- No face-up showdown cards → `showdown_outcome = not_showdown`.
- Both players have two face-down hole cards.
- Chips in the two bet lanes are roughly symmetric (≈ 4 blue 10s and 3 red 5s on each side), consistent with a BB post and an SB call/limp. Inventory chips are green 50s and brown 100s on both seats.
- Scene shows no motion blur; robot hand is retracted → `scene_stable = true`.

## Loop Stage Reasoning

- Hole cards dealt, blinds posted, robot flagged to act preflop → `loop_stage = acting`.

## Context Merging

- No prior `action_sequence.json`, `hole_card_cache.json`, or `sN-1/01_parsed_state.md` present (fresh run at p1).
- No durable fields inherited; all values derived directly from the current image.

## Uncertainty Notes

- Chip inventory counts are approximate because the stacks are angled and partially occluded by the robot/camera body on the right side.
- Bet counts are a best-effort read of the bottom and upper betting lanes; marked uncertain.

## Outputs Written

- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
