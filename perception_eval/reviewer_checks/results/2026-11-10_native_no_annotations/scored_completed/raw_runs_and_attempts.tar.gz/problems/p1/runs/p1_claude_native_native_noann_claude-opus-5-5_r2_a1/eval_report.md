# Eval report — s0

- Source: s_current/00_capture.jpg (s0). There was no action_sequence, hole-card cache, or previous parsed state, so nothing was inherited. Every field comes from this image.
- loop_stage=idle: no workflow was dispatched, the hand is near idle, and it is not holding anything.
- blind=big_blind: the yellow BIG BLIND button is at the robot seat; the dealer and small blind buttons are at the opponent seat.
- is_my_turn=true: the "Your Turn" button is at the bottom-left robot seat.
- community_cards=[]: no face-up board cards (preflop).
- Chips: robot 4/4/4/4 and opponent 4/4/4/4 (5/10/50/100). Neither betting area has chips.
- Uncertain: scene_stable (judged from one frame, nothing to compare against) and opponent_chips (the upper-right green/brown group is small and angled next to the robot hand).
