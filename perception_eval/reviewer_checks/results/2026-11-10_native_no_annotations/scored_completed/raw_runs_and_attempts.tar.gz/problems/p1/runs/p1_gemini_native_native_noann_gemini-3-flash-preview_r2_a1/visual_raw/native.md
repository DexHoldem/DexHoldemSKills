# Raw Perception Evidence - s0/00_capture.jpg

## Table Orientation
- Robot seat is at the bottom of the image.
- Opponent seat is at the top of the image.
- Community cards are in the central row.

## Turn Detection
- The white "Your Turn" button is located at the bottom-left of the table, near the robot seat.
- Conclusion: It is our turn.

## Blind and Dealer Buttons
- The yellow "BIG BLIND" button is at the robot's side (bottom middle).
- The blue "SMALL BLIND" button and white "DEALER" button are at the opponent's side (top middle).
- Conclusion: Robot is the big blind; opponent is the dealer and small blind.

## Community Cards
- There are five community cards visible in the central row, but all are face-down.
- Conclusion: No face-up community cards; board stage is pre-flop.

## Robot Inventory (Bottom)
- Red (5): 4 chips
- Blue (10): 3 chips
- Green (50): 3 chips
- Brown (100): 3 chips
- All chips are unfolded and countable in the inventory area.

## Opponent Inventory (Top)
- Red (5): 4 chips
- Blue (10): 4 chips
- Green (50): 3 chips
- Brown (100): 3 chips
- All chips are unfolded and countable in the inventory area.

## Betting Areas
- Robot current bet area (bottom center): No chips visible.
- Opponent current bet area (top center): No chips visible.

## Robot Behavior
- The dexterous hand is on the right side of the image, in a near-idle/rest pose.
- The hand is not holding any cards or chips and does not appear to be moving.
- The scene is stable and the action appears safe to continue.

## Showdown Outcome
- The hand is still in progress (pre-flop). No cards have been turned over for a showdown.
- Conclusion: Not a showdown.
