# Perception evidence and merging

Directly inspected the current capture and applied the field-specific visual guidelines. The robot has the white turn marker and yellow big-blind marker; the opponent has the dealer/small-blind markers. Each inventory visibly contains four chips of each denomination. No face-up board cards or visible bets are present, and there is no showdown evidence.

The image supports an apparently idle, stable scene. These two estimates are flagged because only one capture is available and motion/completion cannot be confirmed across frames. Opponent bet counts are estimated as zero and flagged because robot hardware obscures the far-right portion of that region.

The current image resolves to the initial `s0` capture. The action sequence, hole-card cache, and previous parsed-state files are unavailable. Consequently no prior values were merged or inherited; all concrete values come from current visual evidence or the explicitly flagged estimates. Card backs/patterned positions were not assigned card identities, and inventory chips were kept separate from bets and buttons.

No robot actions, helper scripts, or poker decisions were executed. Output uses the requested schema with concrete values and no nulls.
