# Eval Report — s0 perception

## Context

This is the first captured state (`s0`). `action_sequence.json` and
`hole_card_cache.json` do not exist yet (preflight warnings confirm both are
"cache missing"), and there is no `sN-1/01_parsed_state.md` to inherit from.
All fields below are derived purely from `s0/00_capture.jpg` plus the
`visual_guidelines/` docs.

## Evidence → field mapping

- **is_my_turn / loop_stage**: White "Your Turn" button is at the
  bottom/robot seat (per `TURN_DETECTION.md`, only the physical turn button
  decides this). → `is_my_turn: true`. No action sequence has been dispatched
  and the robot hand is not mid-motion, so `loop_stage: "idle"`.
- **blind**: Dealer + a second (small-blind-style) button sit at the
  opponent/top seat; a yellow "BIG BLIND" button sits at the robot/bottom
  seat. Two-player rule (dealer = small blind) is consistent with this
  reading. → `blind: "big_blind"`.
- **community_cards**: Five gray face-down placeholders in the board row, no
  face-up cards. → `[]` (preflop).
- **showdown_outcome**: No face-up hole cards either side, no fold/muck
  displacement signature. → `"not_showdown"`.
- **chips**: Counted per `CHIP_RECOGNITION.md` zones (inventory flanking each
  player's own hole cards, outside the board lane). Opponent clusters read
  fairly cleanly as 3 red / 3 blue / 3 green / 3 brown. Robot clusters are
  split across two sub-groups (one beside "Your Turn", one beside "BIG
  BLIND") that had to be summed, and partially overlap/angle near the
  dexterous-hand side of the table, so the robot totals (2 red / 4 blue / 3
  green / 4 brown) are less certain — flagged in `uncertain_fields`.
- **bets**: Per `BET_RECOGNITION.md`/`TABLE_GEOMETRY.md`, the actual
  community-card lane and the thin strip between each player's inventory and
  the board are visually empty of chips in this frame, so both
  `my_current_bet` and `opponent_bet` are read as all-zero. This is a
  judgment call since the chip clusters sit close to the blind buttons; noted
  in the raw notes as a soft ambiguity, though the literal board-lane
  emptiness is clear enough that I did not add it to `uncertain_fields`.
- **scene_stable**: No previous-state image exists to diff against (this is
  `s0`), so stability is a single-frame default judgment rather than the
  normal two-frame comparison — flagged uncertain for that reason, even
  though nothing in the single frame suggests motion.

## Outputs written

- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md` (this file)

All three files verified present in
`runs/p1_claude_native_native_noann_claude-sonnet-5_r3_a1/`.
