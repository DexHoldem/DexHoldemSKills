# Raw visual perception

- Capture used: `s0/00_capture.jpg` (the requested `s_current/00_capture.jpg` is absent).
- Scene: Texas Hold'em table viewed from the robot/player side; the dexterous hand/camera assembly is at the right edge and is not visibly contacting or moving cards/chips.
- Scene stability: stable single frame; no visible motion blur or mid-transfer state. The right-side robot assembly partially occludes the far-right table area.
- Turn: the white `Your Turn` button is in the bottom/robot-side seat area, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is on the bottom/robot side, so the robot is big blind.
- Community cards: zero face-up community cards; all five central board slots are face-down card backs.
- Hole cards: both opponent/top-side and robot/bottom-side hole cards are face-down. No held card is readable.
- Showdown: no face-up hole cards, no muck/fold signature, and no outcome evidence; this is not showdown.
- Chips: inventory groups are unfolded and countable by denomination. Robot/player inventory estimate: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips. Opponent inventory estimate: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Betting areas: no distinct current-bet chips are visible in either central betting lane; all counted chips appear to be inventory groups. The far-right opponent-side region is partly occluded by the robot assembly, so the zero opponent-bet read is lower confidence.
- Context limitation: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` were not present, so no durable fields could be inherited from them.
