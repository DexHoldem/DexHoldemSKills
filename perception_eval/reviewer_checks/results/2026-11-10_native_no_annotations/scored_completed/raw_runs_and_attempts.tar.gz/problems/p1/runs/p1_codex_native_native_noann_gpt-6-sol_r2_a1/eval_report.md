# Perception evaluation

The s0 capture shows the robot's white turn button and yellow big-blind button, with the dealer button at the opponent seat. No community cards, bet chips, fold, or showdown are visible. Each seat has four chips of each denomination in its inventory groups. The robot hand appears settled and empty.

No `action_sequence.json`, `hole_card_cache.json`, or previous `01_parsed_state.md` is present in this workspace, so no durable fields were inherited. `scene_stable` is a best estimate from one frame and is marked uncertain because no earlier capture is available for comparison.
