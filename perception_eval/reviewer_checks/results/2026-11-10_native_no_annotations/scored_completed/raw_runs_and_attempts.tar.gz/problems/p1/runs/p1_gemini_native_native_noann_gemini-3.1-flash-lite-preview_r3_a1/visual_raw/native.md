# Native Perception Evidence

The scene is stable. It is the robot's turn to act, indicated by the "Your Turn" puck in front of the robot. The Big Blind button is in front of the robot. No community cards are face up.

## Robot (My) Chips
- White (5): 6
- Blue (10): 4
- Red (50): 0
- Black (100): 0

## Opponent Chips
- White (5): 4
- Blue (10): 4
- Red (50): 1
- Black (100): 0

## Bets
- My current bet: 0
- Opponent bet: 0
