# Visual Perception Raw Evidence — s0/00_capture.jpg

## Table Orientation & Geometry

Camera position: diagonal view from robot/player side toward opponent.
- Robot/player seat: bottom of image
- Opponent seat: top of image
- Community card row: center, horizontal layout
- Robot hand visible at right edge (slight occlusion of upper-right table area)

## Blind & Turn Button Recognition

**Turn Button (White):**
A white button labeled "Your Turn" is clearly visible at the bottom-left of the table, near the robot/player seat area. This indicates it is currently the robot's turn.

**Blind Assignment:**
A yellow button (big blind marker) is visible in the center-lower area of the community card row. Given the two-player rule, the player with the dealer button is the small blind, and the other is the big blind. The button positioning suggests the dealer/small blind is at the robot seat, making the robot the small blind and the opponent the big blind.

**Conclusion:** Robot is small blind; opponent is big blind.

## Community Cards

The community card row shows multiple face-down cards with diagonal striped backs. The cards are placed in the central row but their exact rank/suit values cannot be determined from this angle and image resolution. Based on visible card count, there appear to be community cards dealt, suggesting the hand is at least at the flop stage or beyond.

## Robot/Player Inventory Chips (Bottom Area)

Chips are unfolded flat on the felt at the bottom-left side near the robot seat:
- Red chips (5-value): approximately 4 visible
- Blue chips (10-value): approximately 3 visible
- Green chips (50-value): approximately 3 visible
- Brown chips (100-value): approximately 3 visible

Total estimated inventory value: (4×5) + (3×10) + (3×50) + (3×100) = 20 + 30 + 150 + 300 = 500

## Opponent Inventory Chips (Top Area)

Chips are unfolded flat on the felt at the top-right side near the opponent seat:
- Red chips (5-value): approximately 4 visible
- Blue chips (10-value): approximately 4 visible
- Green chips (50-value): approximately 3 visible
- Brown chips (100-value): approximately 3 visible

Total estimated inventory value: (4×5) + (4×10) + (3×50) + (3×100) = 20 + 40 + 150 + 300 = 510

## Current Bets (Betting Lanes)

Chips are visible in the central betting areas:
- Left side (robot bet area): Some chips visible in the betting lane, count is approximate due to angle
- Right side (opponent bet area): Some chips visible in the betting lane, count is approximate due to angle

Exact chip denominations in betting areas are difficult to determine with certainty from this angle.

## Hole Cards

- Robot hole cards: Two face-down cards visible at bottom of image in the lower hole-card area. Cards are in back-down position (only card backs visible).
- Opponent hole cards: Two face-down cards visible at top of image in the upper hole-card area. Cards are in back-down position.

No face-up cards visible; no immediate showdown indication.

## Scene Stability Assessment

**Stable.** The robot hand is not in active motion (visible at right edge in a stationary pose). Cards and chips are not visibly moving. The table layout is consistent and clear enough for parsing. No human arm is substantially blocking or reorganizing the board. The scene is ready for state extraction.

## Loop Stage Inference

- No fold signature visible (opponent cards remain in normal position, not displaced to community lane)
- No face-up cards (hole cards still face-down)
- No showdown comparison possible yet
- It is currently the robot's turn

**Likely loop stage:** `acting` (robot must decide a poker action for this hand)

## Notes & Uncertainties

- Exact community card values cannot be read; only face-down positions visible
- Exact current bet counts uncertain due to viewing angle and chip overlap
- Blind assignment inferred from yellow button position; no explicit dealer button visible in this frame
- Robot and opponent inventory counts are visual estimates; chips are roughly in focus but some depth/angle distortion present
