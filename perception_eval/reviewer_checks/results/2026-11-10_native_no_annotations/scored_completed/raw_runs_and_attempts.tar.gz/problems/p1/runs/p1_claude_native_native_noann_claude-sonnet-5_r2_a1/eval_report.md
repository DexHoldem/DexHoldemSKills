# Perception Eval Report — s_current (s0)

## Context

This is the first capture in the run (`s_current` is a symlink to `s0`).
There is no `action_sequence.json`, no `hole_card_cache.json`, and no prior
`sN-1/01_parsed_state.md` to inherit from, so every field below is derived
directly from `s_current/00_capture.jpg` with no cross-frame merge.

## Evidence Summary

- **Turn**: A white "Your Turn" button sits at the bottom-left, in the
  robot/player seat band -> `is_my_turn: true`.
- **Blind**: "DEALER" + "SMALL BLIND" buttons are together at the top
  (opponent) seat; a separate "BIG BLIND" button sits on the bottom (robot)
  side in the lane just above the robot's hole cards -> robot is
  `big_blind`.
- **Community cards**: all five board slots show only face-down card backs
  -> `community_cards: []` (preflop).
- **Hole cards**: both opponent's and robot's two hole cards are face-down
  in their normal seat positions; no fold/muck displacement toward the
  board is visible -> not a showdown state.
- **Scene stability**: no previous frame exists to diff against; the
  dexterous hand is at the right frame edge, raised and not touching the
  felt or any table object, with no blur/motion signature -> treated as
  stable baseline.
- **Chips**: two chip clusters per side (left/right of each seat's
  hole-card pair). Denominations by color (red=5, blue=10, green=50,
  brown=100) were counted per `CHIP_RECOGNITION.md`. The clusters nearest
  the community-card row overlap with the hole-card band rather than
  forming a visually distinct bet lane, so no chips were confidently
  assigned to `my_current_bet`/`opponent_bet`; both are reported as zero
  with low confidence rather than forced non-zero guesses.

## Merge Notes

No prior parsed state exists, so this is a fresh baseline rather than a
merge. `loop_stage` is set to `idle` because it is the robot's turn, no
action has been dispatched yet, and the scene reads as a settled pre-action
state.

## Uncertainty

- `my_chips` / `opponent_chips`: green(50)/brown(100) counts in the
  clusters nearest the robot's right-side occlusion zone (by the dexterous
  hand) and the opponent's right-side cluster are approximate; chip faces
  overlap and exact counts could be off by one in either denomination.
- `my_current_bet` / `opponent_bet`: no chip cluster was clearly separated
  into a distinct bet lane distinct from inventory in this frame, despite
  blind-role buttons being placed. Reported as all-zero but flagged
  uncertain since blind posting would typically show a bet-lane stack.

## Outputs Written

- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md` (this file)
