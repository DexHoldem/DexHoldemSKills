# Raw visual perception

- Frame comparison: `s_current/00_capture.jpg` matches the available reference frame `s0/00_capture.jpg`. The dexterous hand is settled at the right side, is not holding a card or chips, and no table object is visibly in motion. The scene is stable.
- Table orientation: robot/player seat is at the bottom; opponent seat is at the top.
- Turn marker: the white "Your Turn" button is clearly at the bottom-left robot seat, so it is the robot/player's turn.
- Blind markers: the yellow "BIG BLIND" button is at the bottom robot seat. The white dealer button and blue small-blind button are at the top opponent seat. The robot is the big blind.
- Community board: all five central community-card positions are empty; no face-up community cards are visible.
- Robot/player inventory (bottom seat), counted as unfolded chip faces: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Opponent inventory (top seat), counted as unfolded chip faces: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot current-bet area on the lower/robot side of the board: no bet chips visible (0 of every denomination).
- Opponent current-bet area on the upper/opponent side of the board: no bet chips visible (0 of every denomination).
- Hole cards: two face-down cards remain in each player's normal hole-card area. No hole cards are face-up or displaced into the board lane.
- Showdown/outcome: no showdown, fold/muck, win, loss, or tie is visually indicated.
- Robot behavior: settled near-rest pose, no object held, no disturbed layout, and no unsafe contact. This is an idle table state.
- Uncertainty: none material for the requested fields.

