# Raw visual perception

- Frame comparison: `s_current/00_capture.jpg` and `s0/00_capture.jpg` appear visually identical. The dexterous hand is settled at the upper-right, is not holding a card or chips, and no table objects appear to be moving. The scene is stable.
- Robot behavior: the hand is empty and in a settled near-idle pose. It partially occludes the upper-right/opponent-side betting lane, but does not appear stuck or in contact with a game object. No disturbed cards or chips are visible.
- Turn marker: the white `Your Turn` button is clearly visible at the bottom-left robot/player seat. It is the robot's turn.
- Blind markers: the yellow `BIG BLIND` button is at the bottom/robot seat. The white dealer button is at the top/opponent seat, consistent with the opponent being dealer/small blind and the robot being big blind.
- Community cards: no face-up community cards are visible. Five face-down cards occupy the central board slots and are not read or included as community cards.
- Hole/showdown cards: two robot hole cards and two opponent hole cards are face-down in their normal seat areas. No readable held card is visible, neither player has exposed showdown cards, and there is no fold/muck displacement.
- Robot/player inventory (bottom seat), visible flat chip faces: red 5 = 4, blue 10 = 4, green 50 = 4, brown 100 = 4.
- Opponent inventory (top seat), visible flat chip faces: red 5 = 4, blue 10 = 4, green 50 = 4, brown 100 = 4.
- Robot current-bet area: no chips visible; 5 = 0, 10 = 0, 50 = 0, 100 = 0.
- Opponent bet area: no bet chips are visible; 5 = 0, 10 = 0, 50 = 0, 100 = 0. This zone is partly occluded by the settled dexterous hand, so the zero estimate is lower confidence.
- Context availability: `action_sequence.json`, `hole_card_cache.json`, and a prior `01_parsed_state.md` are not present in this workspace. No durable values were inherited; current visual evidence supplies every output field.

