# Raw Perception Evidence

## Scene Stability
Stable. This is the first capture (s0). The robot hand is settled in the top-right area, and no objects are in motion.

## Turn Detection
It is our turn. The white "Your Turn" button is located at the robot seat in the bottom-left area of the table.

## Blind Button Recognition
Dealer/small blind is at the opponent seat. The robot is the big blind.
- The white "DEALER" button and blue "SMALL BLIND" button are at the top/opponent seat.
- The yellow "BIG BLIND" button is at the bottom/robot seat.

## Chip Recognition
Robot/player inventory: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
Opponent inventory: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.

## Bet Recognition
My current bet area, left of the community cards: no chips visible.
Opponent bet area, right of the community cards: no chips visible.

## Community Card Recognition
No community cards are visible. All five cards in the central row are face-down.

## Held Card Recognition
No readable held card is visible. The robot hand is not holding any cards.

## Robot Behavior
The dexterous hand is in the top-right area of the image, near its initial/rest pose. It is not holding any cards or chips. The scene appears safe to continue.

## Showdown and Outcome
Not a showdown. Opponent hole cards are face-down in the top hole-card area. Robot hole cards are face-down in the bottom hole-card area. No showdown comparison is needed.
