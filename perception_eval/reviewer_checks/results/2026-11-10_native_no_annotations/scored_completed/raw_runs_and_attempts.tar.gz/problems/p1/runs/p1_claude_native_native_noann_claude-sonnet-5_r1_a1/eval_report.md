# Perception Eval Report — s0

## Context

This is the first perception step of the session: `action_sequence.json`,
`hole_card_cache.json`, and `sN-1/01_parsed_state.md` do not yet exist in the
workspace, so there is no prior workflow state to inherit and no previous
frame to diff for stability. All fields below are derived purely from
`s_current/00_capture.jpg` (= `s0/00_capture.jpg`).

## Evidence Summary

- **Turn**: White "Your Turn" button is at the bottom/robot seat →
  `is_my_turn: true`.
- **Blind**: Dealer + blue (small-blind-styled) buttons sit together at the
  top/opponent seat; a yellow BIG BLIND button sits at the bottom/robot seat →
  opponent is dealer/small blind, robot is `big_blind`.
- **Community cards**: Five face-down placeholders in the central row, no
  ranks visible → preflop, `community_cards: []`.
- **Chips**: Flat unfolded chip clusters read by zone per
  `TABLE_GEOMETRY.md`/`CHIP_RECOGNITION.md`/`BET_RECOGNITION.md`. Central-lane
  blue clusters next to each hole-card pair are read as matched current bets
  (3x denomination-10 each side), consistent with the robot's turn already
  being active (opponent/SB has acted). Inventory counts for the far
  left/right clusters are approximate; the rightmost clusters on both sides
  are partially occluded by the robot arm/camera housing, so `my_chips` and
  `opponent_chips` are flagged uncertain.
- **Robot behavior / scene stability**: Dexterous hand is at the frame edge,
  not touching table objects, not blurred — consistent with an idle, settled
  scene. No second frame exists to confirm via diff, so `scene_stable` is
  flagged uncertain despite a `true` best estimate.
- **Showdown**: No face-up hole cards on either side, no fold/muck signature
  → `not_showdown`.

## Merging Notes

No durable fields to inherit (no previous parsed state). `loop_stage` is set
to `idle` because no action has been dispatched and the scene requires a
poker decision, not a robot-action judgment. All output fields were given
concrete best-estimate values; none left null/placeholder.

## Outputs Written

- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
