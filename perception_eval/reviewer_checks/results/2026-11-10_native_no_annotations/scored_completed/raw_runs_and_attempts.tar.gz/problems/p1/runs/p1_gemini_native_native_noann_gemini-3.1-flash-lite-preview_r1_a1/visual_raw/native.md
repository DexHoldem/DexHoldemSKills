# Native Perception Evidence

- **Loop Stage**: Idle. The "Your Turn" chip is visible, suggesting it's the robot's turn.
- **Blind**: Big Blind. "BIG BLIND" button is on the robot's side of the table.
- **Showdown**: Not showdown. No cards are revealed.
- **My Chips (Robot)**:
  - 5: 3 (stacks of 1, 2)
  - 10: 2
  - 50: 3
  - 100: 3
- **Opponent Chips**:
  - 5: 4 (stacks of 2, 2)
  - 10: 2
  - 50: 2
  - 100: 3
- **My Current Bet**: 0 (all chips are in stack areas).
- **Opponent Bet**: 0.
- **Community Cards**: None visible (all face down).
- **Turn Detection**: "Your Turn" chip is present.
