# Native Visual Perception — s0/00_capture.jpg

No `action_sequence.json`, `hole_card_cache.json`, or prior `sN-1/01_parsed_state.md`
exist in the workspace. This is the first capture of the session (s0), so there is
no prior workflow context and no previous frame to diff against for scene
stability. All judgments below are from the single current image only.

## Table Geometry / Orientation

Camera looks diagonally across the table. Human opponent is visible at the top
of the frame (arms crossed, not touching the table). The robot dexterous
hand/camera housing enters from the right edge, mostly in the upper-right
corner, not actively touching any cards or chips. Five face-down community-card
placeholders sit in the central row (preflop — 0 cards dealt). Two face-down
hole-card pairs flank the board: one pair upper-center (opponent hole cards,
near the dealer/small-blind buttons) and one pair lower-center (robot hole
cards, near the yellow BIG BLIND button).

## Turn Detection

A white button reading "Your Turn" is visible at the bottom-left of the table,
on the robot/player side near the seat-number marker. Per `TURN_DETECTION.md`,
this places the turn button at the robot seat. Judgment: **it is the robot's
turn.**

## Blind / Button Recognition

- A white `DEALER` button and a blue button (small-blind styling) sit together
  in the upper/opponent seat band, next to the opponent's hole cards.
- A yellow `BIG BLIND` button sits in the lower/robot seat band, next to the
  robot's hole cards.
- Per the two-player rule, the dealer-button seat is also small blind, so:
  **opponent = dealer/small blind, robot = big blind.**

## Community Cards

Five face-down gray card-backs are visible in the central board row, evenly
spaced. No pips/ranks are visible on any of them. Per `COMMUNITY_CARDS.md`,
face-down placeholders are not read as cards. **0 community cards visible —
preflop.**

## Chip Recognition (Inventory) and Bet Recognition

Chips are flat/unfolded. Reading by zone, anchored on the community-card row
and the robot/opponent hole-card pairs:

**Opponent (top) side:**
- Far upper-left, outside the central lane: a red-chip cluster (~5 chips,
  denomination 5) — opponent inventory.
- Just left of the dealer/small-blind buttons, inside the central betting
  lane (between opponent hole cards and the board): a blue-chip cluster
  (~3 chips, denomination 10) — read as the **opponent's current bet**
  (consistent with a small-blind call, since the turn has already passed to
  the robot/BB, implying the opponent already acted).
- Upper-right, outside the central lane, partially under the robot-arm/camera
  housing: a mixed cluster of green (50), blue (10), and brown (100) chips,
  roughly 4 chips total — opponent inventory. This group is **partially
  occluded by the robot arm/camera** and its exact count is uncertain.

**Robot (bottom) side:**
- Lower-left, outside the central lane, near the "Your Turn" button: a
  red-chip cluster (~5 chips, denomination 5) — robot inventory.
- Just left of the yellow BIG BLIND button, inside the central betting lane
  (between robot hole cards and the board): a blue-chip cluster (~3 chips,
  denomination 10) — read as the **robot's current bet** (the posted big
  blind / call amount).
- Lower-right, outside the central lane: a cluster with green (50) and blue
  (10) chips (~2 chips), and farther right a brown/green cluster (~2-3 chips)
  partially under the robot-arm/camera housing — robot inventory, also
  **partially occluded**.

Because the rightmost inventory clusters on both sides sit partly under the
robot arm/camera housing, exact per-denomination counts there are the least
certain part of this read; the red-chip and central-lane blue-chip counts are
the most confidently read.

## Robot Behavior / Scene Stability

The dexterous hand/camera housing is visible at the right edge of frame but is
not touching, reaching for, or holding any card or chip, and is not blurred.
No human arm is on the table. With no `sN-1` frame available for this first
capture, a strict two-frame stability comparison cannot be done, but the
single frame shows no mid-motion blur and no object in transit, consistent
with an idle/settled scene.

## Showdown Outcome

No hole cards (robot or opponent) are face-up. No fold/muck signature (no
hole-card pair displaced toward the board). **Not a showdown.**
