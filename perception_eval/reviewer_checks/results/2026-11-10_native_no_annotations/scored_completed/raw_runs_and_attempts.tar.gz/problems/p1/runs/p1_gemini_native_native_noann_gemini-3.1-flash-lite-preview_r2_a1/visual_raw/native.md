# Perception Analysis - s0

## Visual Evidence
- **Game State**: The scene is stable. "Your Turn" chip is present on the bottom left.
- **My Chips**:
  - 5: 3 (bottom left stack has 3 red chips visible)
  - 10: 2 (blue chips)
  - 50: 0
  - 100: 0
- **Opponent Chips**:
  - 5: 6 (top left cluster)
  - 10: 5 (top left cluster)
  - 50: 0
  - 100: 0
- **Bets**:
  - My current bet: 0
  - Opponent bet: 0
- **Community Cards**: 0 visible (deck is face down).
- **Turn**: "Your Turn" sign is active.

## Summary
The scene shows the robot's turn (active "Your Turn" marker). No community cards are out yet. Both players have chips in their stacks, no bets are currently on the table.
