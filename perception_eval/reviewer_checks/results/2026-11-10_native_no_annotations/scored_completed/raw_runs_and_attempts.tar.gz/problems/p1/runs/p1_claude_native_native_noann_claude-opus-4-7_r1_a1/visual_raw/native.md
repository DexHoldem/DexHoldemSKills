# Visual Raw Perception — s_current/00_capture.jpg

## Table Geometry / Orientation

- Robot/player seat at bottom; opponent seat at top.
- Robot hand/camera body enters from the right (occludes upper-right region).
- Community-card row visible as central lane with 5 slots.

## Buttons & Blinds

- "Your Turn" white button visible on the lower-left (robot side) → **is_my_turn = true**.
- "BIG BLIND" yellow button in the robot-side betting lane (bottom) → **blind = big_blind** for robot.
- "SMALL BLIND" blue button and "DEALER" white button both on opponent side (top).
- Heads-up preflop configuration: opponent is dealer + small blind; robot is big blind.

## Community Cards

- All 5 community-card slots show felt/card-back pattern with no face-up ranks.
- Treating as empty → **preflop** → `community_cards = []`.

## Hole Cards

- Robot has two face-down cards in the robot hole-card area (bottom-center-right).
- Opponent has two face-down cards in the opponent hole-card area (top).

## Chip Inventory

Robot/player inventory (bottom-right seat band, near seat "5"):
- No red 5-chips visible in inventory.
- No blue 10-chips visible in inventory.
- About 3 green 50-chips.
- About 3–4 brown 100-chips (partially angled; count uncertain).

Opponent inventory (top-right seat band, near seat "1"):
- No red 5-chips visible in inventory.
- No blue 10-chips visible in inventory.
- About 3 green 50-chips.
- About 3–4 brown 100-chips (angled; count uncertain).

## Bet Areas

Robot current bet (lower central betting lane, between robot hole cards and community row):
- About 3 red 5-chips.
- About 4 blue 10-chips.
- No green 50-chips.
- No brown 100-chips.
- Appears to be big-blind post (≈ 50–55).

Opponent current bet (upper central betting lane, between community row and opponent hole cards):
- About 3 red 5-chips.
- About 4 blue 10-chips.
- No green 50-chips.
- No brown 100-chips.
- Appears to be a matched call/SB-topped bet (symmetric to robot bet).

## Scene Stability

- No motion blur visible; robot hand not in the middle of a chip transfer.
- Clean "Your Turn" marker present → scene is stable and action is required.

## Showdown

- No cards face-up on either side; not a showdown state → `showdown_outcome = not_showdown`.

## Loop Stage

- "Your Turn" visible, hole cards dealt, preflop, no action dispatched yet → **loop_stage = acting**.
