# Visual Raw Perception — s0

## Turn
White "Your Turn" button is at bottom-left, near the robot seat → it is our turn.

## Blind / Button
- Yellow BIG BLIND button sits in front of the robot's hole cards (bottom) → robot is big blind.
- White DEALER button and blue SMALL BLIND button are at the top, by the opponent → opponent is dealer/small blind.

## Community Cards
All five community-card slots in the center strip are face-down (card-back pattern visible, no face cards). Pre-flop: `community_cards = []`.

## Hole Cards
- Robot: two face-down cards in front of robot (bottom-right area).
- Opponent: two face-down cards in front of opponent (top).

## Bets In Front Of Cards
- Robot bet area (bottom, left of hole cards): a short stack of blue "10" chips (≈4) with a couple of red "5" chips below. Best estimate: {10: 4, 5: 2} ≈ 50 (BB).
- Opponent bet area (top, right of their hole cards, below the DEALER button): a short stack of blue "10" chips (≈2) with red "5" chips (≈1). Best estimate: {10: 2, 5: 1} ≈ 25 (SB).

Both bet estimates are approximate due to oblique angle and partial occlusion.

## Chip Banks
- Robot bank (bottom-right of image): one visible row with ~3 blue "10" chips, ~3 white "100" chips and a couple of green "50" chips. Estimate {5:4, 10:3, 50:3, 100:3}.
- Opponent bank (top-right): similar row. Estimate {5:4, 10:4, 50:3, 100:3}.

Bank counts are uncertain — camera angle only shows one face of each stack.

## Scene Stability
No hands in motion over chip or card areas; no robot gripper over the table. Scene is stable.

## Loop Stage
It is our turn pre-flop with hole cards dealt and blinds posted → `acting`.

## Showdown
Not a showdown — community cards are undealt and hole cards are face-down.
