# Visual Raw Perception — native.md

## Source
Image: `s_current/00_capture.jpg`
Previous state: `s0/00_capture.jpg` (no parsed state available — first capture in session)

---

## Turn Detection

The white "Your Turn" button is clearly visible at the bottom-left of the table, in the robot/player seat area. **It is the robot's turn.**

---

## Blind Detection

- A yellow **BIG BLIND** button is visible near the bottom-center of the table, on the robot/player side.
- A blue **DEALER** button is visible in the upper-center area, toward the opponent/top side.
- In a two-player game the dealer holds the small blind; thus the opponent is dealer/small blind and the robot is the big blind.
- **Robot = big blind. Opponent = small blind / dealer.**

---

## Community Cards

The five community card slots in the center horizontal strip are all face-down (blue card backs). No face-up community cards are visible. **This is preflop; zero community cards dealt.**

---

## Scene Stability

Only one frame is available (no prior s_N-1 image). The robot arm is visible on the right side of the table in what appears to be a near-idle, settled position — no blurring or mid-motion pose detected. Cards and chips appear stationary. The human opponent is seated with arms crossed and no hand is on the table moving objects. **Scene appears stable.**

---

## Showdown / Outcome

No hole cards are face-up for either player. No showdown is in progress. **Not a showdown.**

---

## Chip Inventory — Robot/Player (bottom seat)

Looking at the bottom area of the table (robot seat side), chip groups are laid flat on the felt:

- **Red (5-value):** approximately 4 chips visible in the left and center-left groups
- **Blue (10-value):** approximately 3 chips visible in the center group
- **Green (50-value):** approximately 3 chips visible toward the right of the inventory area
- **Brown (100-value):** approximately 3 chips visible at the far right of the bottom inventory

Counts for green and brown denominations are partly occluded by distance/angle — marked uncertain.

---

## Chip Inventory — Opponent (top seat)

Looking at the top-right area of the table (opponent seat side), chip groups are visible:

- **Red (5-value):** approximately 4 chips
- **Blue (10-value):** approximately 4 chips
- **Green (50-value):** approximately 3 chips
- **Brown (100-value):** approximately 3 chips

Counts are approximate because the opponent's chip area is angled and partially occluded by distance.

---

## Bet Areas

**My current bet (left of community cards):**
Approximately 1 blue (10-value) chip visible — consistent with big blind posted (value ≈ 10). No red, green, or brown chips clearly visible in this zone. Count is uncertain (small chips, slight angle).

**Opponent bet (right of community cards):**
Approximately 1 red (5-value) chip visible — consistent with small blind posted (value ≈ 5). No blue, green, or brown chips clearly visible in this zone. Count is uncertain.

---

## Summary

- It is the robot's turn (Your Turn button at robot seat)
- Robot is big blind; opponent is small blind / dealer
- Preflop (zero community cards face-up)
- Scene is stable (robot arm idle, no motion)
- No showdown
- Robot inventory: ~4 red, ~3 blue, ~3 green, ~3 brown (green/brown uncertain)
- Opponent inventory: ~4 red, ~4 blue, ~3 green, ~3 brown (all approximate)
- Robot current bet: ~1 blue (10) — uncertain
- Opponent current bet: ~1 red (5) — uncertain
