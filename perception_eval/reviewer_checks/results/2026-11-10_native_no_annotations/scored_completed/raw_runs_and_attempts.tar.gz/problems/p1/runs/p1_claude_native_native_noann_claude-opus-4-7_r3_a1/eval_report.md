# Eval Report — s0

## Evidence
- "Your Turn" white button at robot seat → `is_my_turn = true`.
- Yellow BIG BLIND at robot seat → `blind = big_blind`; DEALER + SMALL BLIND at opponent.
- All 5 community slots face-down, both players' hole cards face-down → pre-flop.
- Bet stacks present for both players consistent with blinds posted (SB ~25, BB ~50).
- Scene is stable; no gripper motion over chips/cards.

## Merging
- No prior parsed state (`s-1`) and no `action_sequence.json` / `hole_card_cache.json` exist in the workspace, so nothing to inherit.
- Chip counts and bet counts come from a single oblique view; marked uncertain in `uncertain_fields`.

## Derived fields
- `loop_stage = acting` — our turn with hand in progress.
- `showdown_outcome = not_showdown`.
- `community_cards = []`.
