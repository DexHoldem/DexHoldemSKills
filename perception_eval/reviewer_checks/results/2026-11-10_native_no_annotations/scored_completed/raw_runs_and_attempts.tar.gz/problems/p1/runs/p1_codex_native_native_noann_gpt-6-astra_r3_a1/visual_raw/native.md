# Native visual evidence

Source: `s_current/00_capture.jpg`, resolving to `s0/00_capture.jpg`. Inspected the original capture directly and read all field guidelines. No previous capture or parsed state, action sequence, or hole-card cache is present in this workspace.

Stable, provisionally from this single image only. The robot hand is raised at the upper right in an apparently resting, empty pose. No card or chips are visibly held, and no contact with the felt or game objects is apparent. The foreground robot is soft in focus; this alone does not establish motion. The opponent's arms are folded away from the playing surface. The visible chip layout is orderly. Temporal stability and completion of any prior atom cannot be verified without another frame or sequence context. Best loop-stage estimate: idle. No visible evidence supports a failure, recovery, or terminal outcome.

It is our turn. The white button labeled Your Turn is at the bottom-left robot seat.

Dealer/small blind is at the top/opponent seat: a white DEALER button and blue SMALL BLIND button sit there. The yellow BIG BLIND button is at the bottom/robot seat. Robot blind assignment is big_blind; no button conflict is visible.

No face-up community cards are visible. Five patterned rectangular card-back/slot regions occupy the central board lane, but none provides a readable face-up board card. They are excluded from community_cards. The two lower hole-card regions and two upper hole-card regions likewise show no readable faces. No readable held card is visible; no hidden card values are inferred.

Robot inventory, bottom seat: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. Counted individual flat faces, including the offset chips in each group. The red and blue groups are toward the lower left; green and brown groups are toward the lower right.

Opponent inventory, top seat: four red 5-chips, four blue 10-chips, four green 50-chips, and four brown 100-chips. The red group has three chips in a short column and one offset left; blue has three near its column and one offset right; green has three along a diagonal and one offset lower left; brown has three along a diagonal and one offset right. These are inventory groups near the rail, not bets.

Robot current bet area, left/lower side of the board: no bet chips visible, giving zero of every denomination.

Opponent bet area, right/upper side of the board: no bet chips visible in the exposed area, giving a best estimate of zero of every denomination. The robot housing obscures the far-right continuation of this region, so this estimate is uncertain due to occlusion.

Neither player's hole cards are visibly revealed. There is no clear fold/muck displacement, showdown, or winner evidence. Showdown outcome: not_showdown. No hand comparison is possible or needed from this capture.

Uncertain fields: loop_stage and scene_stable are single-frame inferences; opponent_bet has partial right-side occlusion. No fields were inherited.
