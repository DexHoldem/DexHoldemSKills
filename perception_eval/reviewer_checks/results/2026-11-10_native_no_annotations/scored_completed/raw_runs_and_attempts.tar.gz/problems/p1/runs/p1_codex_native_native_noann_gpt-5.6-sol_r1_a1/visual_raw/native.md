# Raw visual perception

Source inspected: `s_current/00_capture.jpg` (the available initial capture, also represented by `s0/00_capture.jpg`).

- Scene/robot: The image is sharp, with no visible motion blur. The dexterous hand is suspended at the upper-right in a settled open pose and is not holding a card or chip. Cards and chips appear stationary. No human hand is on the felt or manipulating table objects. On this single available frame, the scene appears stable and safe to parse.
- Turn: It is our turn. The small white physical button labeled `Your Turn` is clearly located at the bottom-left robot/player seat.
- Blinds: The yellow `BIG BLIND` button is at the bottom robot/player seat. A white dealer button and blue small-blind button are at the top/opponent seat. Therefore the robot is the big blind and the opponent is dealer/small blind; there is no visible button conflict.
- Community-card row: Five card backs occupy the board positions, but no face-up shared card is visible. Per the community-card rule, the current community-card list is empty.
- Robot hole-card area: Two face-down cards are visible at the bottom/robot side. No robot hole-card value is visually readable.
- Opponent hole-card area: Two face-down cards are visible at the top/opponent side. They remain in their normal hole-card area and do not show a fold/muck signature.
- Showdown/outcome: Neither player's hole cards are face-up, there is no fold/muck displacement, and there are no face-up community cards. This is not a showdown and no win/lose/tie outcome is visible.
- Robot/player inventory, bottom seat band: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips. These are flat inventory chips outside the central betting lane.
- Opponent inventory, top seat band: 4 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips. These are flat inventory chips outside the central betting lane.
- Robot current-bet zone, lower/robot side of the board: no red, blue, green, or brown bet chips are visible.
- Opponent current-bet zone, upper/opponent side of the board: no red, blue, green, or brown bet chips are visible. The robot hand is above the upper-right area but does not hide the betting lane enough to prevent the zero-chip observation.
- Uncertainty: No state field requires inheritance or a low-confidence estimate. Scene stability is judged from the single available sharp frame because no prior capture was supplied.

The requested `action_sequence.json`, `hole_card_cache.json`, and prior `sN-1/01_parsed_state.md` were not present, so they contributed no merged values.
