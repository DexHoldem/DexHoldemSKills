# Perception summary

The current capture shows a settled-looking robot hand, the white turn button at the robot seat, and the big blind button at that seat. Both inventories have four chips of each denomination; neither betting area contains visible chips. No face-up community cards or showdown evidence is visible.

All output values come from the capture. No prior workflow, cache, or previous parsed state was available to merge. `scene_stable` is the only uncertain field because there is no earlier frame for the required motion comparison.
