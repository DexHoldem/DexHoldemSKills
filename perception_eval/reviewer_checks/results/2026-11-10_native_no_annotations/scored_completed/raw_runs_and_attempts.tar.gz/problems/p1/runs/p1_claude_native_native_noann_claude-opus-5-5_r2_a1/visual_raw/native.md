# Native perception — s_current (-> s0/00_capture.jpg)

No prior state: s0 is the first frame. There is no action_sequence.json, no hole_card_cache.json, and no sN-1 parsed state.

## Scene stability
Stable, but judged from one frame only because there is no previous frame to compare. The dexterous hand is at the upper right in a near-idle pose. It is not holding a card or chips and is not touching anything on the table. It hovers over the top-right opponent rail area but does not hide any chips, cards, or betting lanes. The human opponent has their arms crossed and is not touching the table.

## Turn
It is our turn. The white "Your Turn" button is at the bottom-left robot seat area.

## Blinds
The blue SMALL BLIND button and the white DEALER button are at the top/opponent seat. The yellow BIG BLIND button is at the bottom/robot seat. This matches the two-player rule: the opponent is dealer/small blind and the robot is big blind.

## Community cards
No face-up community cards. Five card-back shapes sit in the board row; they are face-down or undealt placeholders and are not counted. Stage is preflop.

## Hole cards
Robot: two face-down cards in the bottom hole-card area. Opponent: two face-down cards in the top hole-card area. The hand is not holding a card. No showdown and no fold signature.

## Robot inventory (bottom)
Left of the robot hole cards: 4 red 5-chips and 4 blue 10-chips. Right of the robot hole cards: 4 green 50-chips and 4 brown 100-chips. The right-side group is slightly angled near the robot body, but the counts are fairly clear.

## Opponent inventory (top)
Upper left: 4 red 5-chips and 4 blue 10-chips. Upper right: 4 green 50-chips and 4 brown 100-chips. The upper-right group is small, angled, and next to the robot hand, so it is less certain.

## Bets
My current bet area (robot side of the board): no chips visible.
Opponent bet area (opponent side of the board): no chips visible. The blinds have not been posted as chips yet.
