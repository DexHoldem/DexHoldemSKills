# Native Visual Perception — s_current (s0) `00_capture.jpg`

This is the first capture in this run (`s_current` -> `s0`). No prior
`action_sequence.json`, `hole_card_cache.json`, or previous parsed state
exist yet, so all fields are derived from this single image with no
cross-frame or cache context.

## Table Geometry / Orientation

Camera looks diagonally from the robot/player side toward the opponent.
Opponent (human, arms crossed, white t-shirt) sits at the top of the frame.
The dexterous hand/robot gripper enters from the right edge and occludes the
far right of the table. Robot/player seat is the bottom of the frame. This
matches `TABLE_GEOMETRY.md` orientation defaults.

## Turn Detection

A white physical button reading "Your Turn" is visible near the bottom-left
of the table, in the robot/player seat band (approx x 340-480, y 760-830 in
the 1920-wide frame). Per `TURN_DETECTION.md`, this is a clear positive case:
the white turn button is at the robot/player seat.

**It is our turn.** The white "Your Turn" button is near the robot seat at
the bottom-left of the table.

## Blind Button Recognition

Two buttons are visible together near the top/opponent seat, just left of
the opponent's two face-down hole cards: a white button labeled "DEALER" and
a blue round button labeled "SMALL BLIND" (approx x 790-900, y 440-510). A
separate yellow button labeled "BIG BLIND" is visible on the bottom/robot
side, in the lane between the robot's inventory chips and the robot's
face-down hole cards (approx x 1030-1130, y 697-750).

Dealer/small blind is at the opponent seat. The robot is the big blind. This
is internally consistent with the two-player rule (dealer seat == small
blind seat).

## Community Cards

Five face-down gray card-back placeholders are laid out in the central row
between the two "TEXAS HOLD'EM" text banners (one upside-down near the top
banner for the opponent's reading orientation, one right-side-up near the
bottom banner for the robot's). All five positions show only card backs; no
pips or face-up community cards are visible anywhere in that row.

No community cards are visible (0 of 5 revealed). This reads as the preflop
stage.

## Hole Cards (context only, not asked to read values)

- Opponent hole cards: two face-down gray card-back squares near the top
  seat, immediately right of the DEALER/SMALL BLIND buttons.
- Robot hole cards: two face-down gray card-back squares near the bottom
  seat, between the seat-number markers "5"/"6" labels on the mat.

Both pairs are face-down; no values are read here (not requested, and no
held card is being presented to the camera by the dexterous hand in this
frame).

## Chip Recognition (Inventories)

Chips are unfolded flat chip faces, consistent with `CHIP_RECOGNITION.md`.
Two separated chip clusters are visible on each side of the table.

**Opponent inventory** (top seat band, outside the hole-card area):
- Left cluster (left of the DEALER/SMALL BLIND buttons and opponent hole
  cards): about 3 red (5) chips and 4 blue (10) chips.
- Right cluster (right of the opponent hole cards, toward the seat-number
  "1" marker): about 3 green (50) chips and 3 brown (100) chips.
- Combined opponent inventory estimate: 3x red(5), 4x blue(10), 3x green(50),
  3x brown(100). The green/brown split in the right cluster is partly
  occluded by overlap between chip faces and is somewhat uncertain.

**Robot/player inventory** (bottom seat band, outside the hole-card area):
- Left cluster (right of the "Your Turn" button): about 5 red (5) chips.
- Lane between the inventory and the robot hole cards (near the BIG BLIND
  button): about 4 blue (10) chips.
- Right-of-hole-cards cluster (toward seat-number "5" marker, partly near
  the dexterous hand's occlusion zone): a mixed group that looks like about
  3 green (50) chips and 4 brown (100) chips, with some chip faces harder to
  separate due to the robot hand entering the frame from the right edge.
- Combined robot inventory estimate: 5x red(5), 4x blue(10), 3x green(50),
  4x brown(100). The green/brown counts on the robot's right-side cluster are
  uncertain due to partial occlusion/overlap and proximity to the dexterous
  hand.

## Bet Recognition

Per `BET_RECOGNITION.md`/`TABLE_GEOMETRY.md`, bet-lane chips should sit in
the central lane directly adjacent to the community-card row (opponent side
above it, robot side below it), distinct from the inventory clusters further
out near each seat's rail.

In this frame, no chip cluster is clearly separated from the inventory
groups and positioned strictly between a hole-card row and the community-card
row on either side — the clusters nearest the community row largely overlap
with the hole-card band itself. Given this is the first captured frame with
the DEALER/SMALL BLIND/BIG BLIND role buttons just placed (and no action
sequence yet dispatched), the most consistent reading is that blind
*assignments* are marked by the buttons but blind chips have not yet been
physically pushed into a separate current-bet lane.

My current bet area (robot, left/lower side of community cards): no chips
clearly separated from inventory; treated as no bet chips visible.

Opponent bet area (opponent, right/upper side of community cards): no chips
clearly separated from inventory; treated as no bet chips visible.

This reading carries meaningful uncertainty since blind posting usually
accompanies a visible bet-lane stack; it is flagged as uncertain rather than
forced.

## Scene Stability

No previous state image exists for this run (`s_current` is the first
capture, `s0`). There is nothing to compare against. The dexterous hand is
visible entering from the right edge of the frame in a raised/forward pose,
not overlapping the central table zones (hole cards, community cards, or
either bet lane). No cards or chips show any blur or mid-transfer signature.
No human arm is on the table; the opponent's arms are crossed off the felt.

Treated as stable (baseline first-capture state): no evidence of hand motion
or table disturbance is visible, and nothing contradicts a settled scene.

## Robot Behavior

The dexterous hand/gripper is at the right edge of frame, elevated and not
touching the felt. It is not holding a card or chips. It does not appear to
be pinned, stuck, or pressed into any object. No action-sequence context was
provided (none exists yet for this first capture), so this is read purely as
"hand present at frame edge, not engaged with the table," which is
consistent with an idle/pre-action state.

## Showdown / Outcome

Community cards: none visible (preflop). Opponent hole cards: face-down,
in their normal top-seat position (no fold/muck displacement toward the
board). Robot hole cards: face-down, in their normal bottom-seat position.
No hole-card cache exists yet. This is not a showdown state; the hand is at
or before the start of a betting round with no revealed cards.
