# Perception and merge report

Inspected s24 directly and compared s23 and s22 under the field-specific visual guidelines. Current hand displacement and chip contact support acting with scene_stable=false. The white bottom-side turn marker supports is_my_turn=true independently of robot motion. Visible blind markers establish big_blind. Hole cards remain face-down at both seats, with no showdown or fold evidence.

Current visual evidence determines readable cards, markers, and visible chip counts. The obscured 7c and two opponent red bet chips use s23 as supporting evidence. Robot brown inventory is estimated at three after apparent movement of one of the previous four brown chips; the moving brown chip is provisionally assigned to the right betting area. This assignment and the hidden counts are uncertain, explicitly flagged in the JSON and raw evidence. No face-down board values were guessed.

The named action-sequence file, hole-card cache, and previous parsed-state file were absent, so no durable values could be merged from them. No helper scripts, robot actions, or poker decisions were executed. Outputs contain concrete estimates with all required fields.
