# Native Visual Perception — s_current (s24)

## Table geometry
- Robot (me) seated at the BOTTOM of the table; human opponent at the TOP.
- Yellow "BIG BLIND" button is on my (bottom) side → I am the big blind.
- White "DEALER" button sits on opponent's (top) side.
- White "Your Turn" chip is visible on my side (bottom-left) → it is my turn.

## Loop stage
- "Your Turn" is active and there are no showdown markers (no revealed opponent
  hole cards, no win/lose chip). Stage = `acting`.
- `scene_stable` = true (image is sharp; buttons and chip stacks are at rest).

## Showdown outcome
- Not a showdown. Opponent cards remain face-down at their seat position.
- `showdown_outcome` = `not_showdown`.

## Community cards (center lane)
- The community-card lane contains some face-down rectangles plus a pair of
  clearly face-up cards toward the right:
  - face-up card ≈ `7d` (red 7 with a diamond pip visible)
  - face-up card ≈ `6s` or `6c` (black 6, partly occluded by the robot arm;
    suit between spades and clubs — best guess spades/clubs)
- Other positions appear as blue card-backs; the robot arm obscures the far
  right slot and partially covers the 6-card area, so I can't confirm whether
  a third face-up card exists under the arm.
- Best-effort read: 2 face-up cards, `[7d, 6s]`, both marked uncertain; board
  stage therefore uncertain (likely flop with one card occluded).

## Hole cards
- My two hole cards sit face-down at the bottom-right hole-card region
  (standard; not reading values).
- Opponent's two hole cards sit face-down near the top rail.

## Robot (me) inventory chips  (bottom seat, excluding bet)
Partial occlusion by the robot arm. Visible groups:
- red 5 : ~4
- blue 10 : ~3
- green 50 : ~3
- brown 100 : ~3
Counts uncertain due to arm occlusion on the right side.

## Opponent inventory chips  (top seat)
- red 5 : ~4
- blue 10 : ~4
- green 50 : ~3
- brown 100 : ~3
Counts uncertain (angle / partial occlusion).

## My current bet (chips in my betting area, near "Your Turn")
- red 5 : ~1
- blue 10 : ~2
- green 50 : 0
- brown 100 : 0

## Opponent current bet (chips just above their hole cards)
- red 5 : ~1
- blue 10 : ~2
- green 50 : 0
- brown 100 : 0

## Context files
- No `action_sequence.json`, `hole_card_cache.json`, or `sN-1/01_parsed_state.md`
  were found in the workspace. Perception is based solely on current capture.

## Uncertainty summary
- `community_cards` — only 2 face-up cards partly visible; one potentially
  occluded by the arm.
- Chip inventories and current bets — robot arm occludes part of the right
  side of the table.
