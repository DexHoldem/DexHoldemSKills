# Raw Perception Evidence

## Scene Stability
Unstable. Compared s23/00_capture.jpg and s24/00_capture.jpg. The robot hand is in motion over the community cards. In s23, it is near the 3rd community card (8c), and in s24, it has moved to partially occlude the same card.

## Robot Behavior
The dexterous hand is extended over the community card area, specifically near the 8c card. It is not in an idle or rest pose. The hand appears to be acting (possibly touching or moving a card). No cards or chips appear dropped or misplaced.

## Turn Detection
It is our turn. The white "Your Turn" button is clearly visible at the bottom-left robot seat.

## Blind Position
The robot is the big blind. The yellow "BIG BLIND" button is at the robot seat (bottom). The "DEALER" and "SMALL BLIND" buttons are at the opponent seat (top).

## Community Cards
Three community cards are visible: 7d, 6s, and 8c.
- 1st: 7d (Seven of Diamonds)
- 2nd: 6s (Six of Spades)
- 3rd: 8c (Eight of Clubs) - Partially occluded by the robot hand in s24, but clearly readable in s23.

## Robot Inventory (Bottom)
- 5 (Red): 4 chips
- 10 (Blue): 3 chips
- 50 (Green): 3 chips
- 100 (Brown): 3 chips

## Opponent Inventory (Top)
- 5 (Red): 3 chips
- 10 (Blue): 5 chips
- 50 (Green): 3 chips
- 100 (Brown): 4 chips

## Current Bets
- My current bet (bottom-left of community): 0 chips.
- Opponent bet (top-right of community): 0 chips. The area is partially occluded by the robot hand, but no chips are visible.

## Showdown Outcome
Not a showdown. Opponent hole cards are face-down.
