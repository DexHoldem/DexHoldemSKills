# Native Visual Perception — Raw Evidence

## Image: s_current/00_capture.jpg

---

## Turn Detection

The white circular button labeled "Your Turn" is clearly visible at the **bottom-left of the table**, which is the robot/player seat area. It is the robot's turn to act.

**Conclusion**: It IS our turn.

---

## Blind Button Recognition

- **DEALER button** (blue, labeled "DEALER"): positioned near the **top/opponent seat** side of the table.
- **BIG BLIND button** (yellow, labeled "BIG BLIND"): positioned near the **bottom-center** of the table, toward the robot/player seat.

With the DEALER button at the opponent seat, the opponent is the small blind (dealer = small blind in heads-up), and the robot is the big blind.

**Conclusion**: Robot = big blind; opponent = small blind (dealer).

---

## Community Cards

Scanning the central community card row (horizontal band in the middle of the table):

- **Far-left of board area**: One face-down card (blue card back) — likely a folded/mucked hole card, NOT a community card.
- **Center-left**: One face-up card appearing to show a "7" (suit unclear, possibly spades or hearts).
- **Center**: One face-up card, rank and suit partially visible (appears around "7" or another rank).
- **Right of center (near robot arm)**: Two face-up cards. One shows "6" with what appears to be spade-like pips, and another card whose rank/suit is harder to read clearly due to robot arm occlusion.

Best reading: approximately 3 face-up community cards are visible in the center zone (flop). The two cards near the robot arm are potentially community cards (turn/river) or are being manipulated.

The face-down card at the left center is NOT counted as a community card.

**Estimated community cards (flop, 3 cards)**:
- Position 1: appears to be a "7" — suit uncertain, tentatively "7s" or "7h"
- Position 2: appears to be a "6" with spade pips — tentatively "6s"
- Position 3: third card present but rank/suit unreadable due to occlusion

The two cards near the robot arm on the right: uncertain if community (turn/river) or other cards.

---

## Chip Recognition

### Robot/Player Inventory (bottom seat area)

Bottom-left cluster (near "Your Turn" button):
- Red chips (5): approximately 3 visible
- Blue chips (10): approximately 2–3 visible

Bottom-center cluster (near robot hole card zone):
- Blue chips (10): approximately 1–2 more visible
- Orange/red chips mixed in

Right-side of bottom area:
- Some green chips (50) visible: approximately 2
- Possibly brown chips (100): approximately 1–2

**Estimate**: ~3 red (5), ~4 blue (10), ~2 green (50), ~2 brown (100). Counts are approximate; partial occlusion from robot arm and angle.

### Opponent Inventory (top seat area)

Chips near the top rail:
- Blue chips (10): approximately 3 visible
- Red/orange chips (5): approximately 2–3 visible
- Larger denomination chips: some green (50) visible, brown (100) harder to count

**Estimate**: ~3 red (5), ~3 blue (10), ~2 green (50), ~2 brown (100). Counts uncertain due to distance and angle.

---

## Bet Areas

### My Current Bet (left of community cards)

One blue chip (10) appears to be in the betting zone left of the community cards.

**Estimate**: 0 red (5), 1 blue (10), 0 green (50), 0 brown (100).

### Opponent Bet (right of community cards)

The right side of the community card area is partially occluded by the robot arm. Some chips appear to be present but counts are uncertain. Possibly 1 blue chip visible.

**Estimate (uncertain)**: 0 red (5), 1 blue (10), 0 green (50), 0 brown (100). Marked uncertain due to robot arm occlusion.

---

## Loop Stage Assessment

- "Your Turn" button at robot seat: robot must act.
- Scene appears stable (board visible, chips in place, turn marker present).
- No opponent cards face-up for showdown.

**Loop stage**: acting
**Showdown**: not_showdown
**Scene stable**: true

---

## Uncertainty Notes

- Community card ranks/suits: partial reads only, suits especially uncertain
- Whether 3rd+ community cards near robot arm are part of community or not: uncertain
- Opponent bet area: partially occluded by robot arm
- All chip counts: approximate, not pixel-perfect
