# Raw Visual Perception — s_current/00_capture.jpg

## Scene Stability
Single frame assessment (no previous parsed state available for comparison).
The robot arm is visible on the right side of the frame in a near-idle/settled pose — not mid-motion or blurred. Cards and chips appear stationary. No human arm is on the table blocking the workspace. Scene assessed as **stable** based on single-frame evidence.

## Turn Detection
White "Your Turn" button is clearly visible in the bottom-left of the robot seat area (approximately x: 7-17%, y: 73-86%). It is **our turn**.

## Blind Buttons
- Blue "DEALER" button: at the opponent/top seat area (upper-center of table).
- Yellow "BIG BLIND" button: at the robot/bottom seat area (bottom-center-right of table).
- Two-player rule → opponent is dealer/small blind, **robot is big blind**.

## Community Cards
The community card row (center strip) shows face-up cards. Left to right:
1. A face-down blue-backed card at the far left edge — likely the deck position, not counted.
2. A face-up card showing a prominent heart suit symbol; rank is not clearly legible — best read: **2h** (uncertain rank).
3. A face-up **7** with a dark (clubs or spades) suit — read as **7c** (uncertain suit, possibly 7s).
4. A face-up **6** with red diamond pips — read as **6d**.
Approximately 3 face-up community cards visible = flop. Right edge of community strip is partially occluded by the robot arm (occlusion zone ~x > 62%, y < 55%); additional river/turn card cannot be excluded.

## Hole Cards
- Robot hole cards: two face-down blue-backed cards in the bottom-center hole-card area. Not visible.
- Opponent hole cards: appear face-down at the opponent seat area. No showdown.

## Showdown
No opponent hole cards are face-up. No visible showdown resolution. **not_showdown**.

## Loop Stage
"Your Turn" button is active at robot seat. No action is in progress. **acting**.

## Chip Counts (Estimates)

### Robot Inventory (bottom seat band, outside betting lane)
- Red (5): ~4 chips (left cluster near Your Turn button, reasonably clear)
- Blue (10): ~3 chips (left cluster, reasonably clear)
- Green (50): ~2 chips (right side near robot arm, uncertain — partial occlusion)
- Brown (100): ~2 chips (right side, uncertain — partial occlusion)

### Robot Current Bet (central betting lane, lower/robot side of community row)
- Red (5): 0
- Blue (10): ~1 chip visible in bet area
- Green (50): 0
- Brown (100): 0

### Opponent Inventory (top seat band, outside betting lane)
- Red (5): ~3 chips (top-left cluster, approximate)
- Blue (10): ~4 chips (top clusters combined, approximate)
- Green (50): ~2 chips (uncertain)
- Brown (100): ~2 chips (uncertain)

### Opponent Bet (central betting lane, upper/opponent side of community row)
- Red (5): 0
- Blue (10): ~2 chips (partially occluded by robot arm, uncertain)
- Green (50): 0
- Brown (100): 0
