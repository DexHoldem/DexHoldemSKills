# Eval report — native perception, s_current

**Context:** `action_sequence.json`, `hole_card_cache.json`, and any `sN-1/01_parsed_state.md` are missing. Only the capture images were available, so durable fields were cross-checked against images s24, s23, and s0 instead.

## Key evidence
- **Robot hand is mid-action.** It is extended over the right end of the board with a fingertip on one chip, so this looks like a chip push. s24 and s_current look the same. → `scene_stable=false`, `loop_stage=acting`. Recovery and failure are not judged because the frame isn't settled. If more identical frames follow, the hand may be stalled.
- **Turn:** the "Your Turn" button is at the robot seat → `is_my_turn=true`.
- **Blind:** BIG BLIND button is on the robot side; DEALER and SMALL BLIND are on the opponent side → `big_blind`.
- **Board:** the two left slots are face-down. 7d and 6s are clear. The 5th slot is partly hidden; its "7" corner is visible, and s23 shows it as 7c. Result: flop `7d 6s 7c`.
- **Showdown:** the opponent's hole cards are face-down in their normal spot → `not_showdown`.

## Merging and inference
- `my_chips`: 5/10/50 are counted directly (4/3/4). The 100s are partly hidden by the arm, so the count of 4 is carried over from s23. It may really be 3 if the chip being pushed is a 100.
- `opponent_chips`: counted directly as 2/4/4/4. This matches s0 (4/4/4/4) minus the two red 5s that went to the bet.
- `my_current_bet`: one blue 10 is visible left of the board. The chip in transit under the fingertip is not counted.
- `opponent_bet`: the area is hidden by the hand, so the two red 5s are carried over from s23.
- Uncertain: community_cards (5th slot hidden), my_chips (100s), my_current_bet (chip in transit), opponent_bet (hidden), scene_stable (hand not moving between frames).
