# Perception report

The current frame shows the robot hand extended over a brown chip, so the scene is classified as unstable and the loop as `acting`. The robot's white turn marker and yellow big-blind marker are visible. Three face-up board cards read 7d, 8s, 7c; the last is partly occluded in the current frame and corroborated by `s23`.

Chip counts separate bottom/robot inventory from the lower betting lane and top/opponent inventory from the upper betting lane. The robot's brown inventory and the opponent's two red bet chips are partly occluded, so those values are estimates informed by the clearer preceding capture. The requested context JSON and parsed-state files were absent; the merge uses visual evidence only.
