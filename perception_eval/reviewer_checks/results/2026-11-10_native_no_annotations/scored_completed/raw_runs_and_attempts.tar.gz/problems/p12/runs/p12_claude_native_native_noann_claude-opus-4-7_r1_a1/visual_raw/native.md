# Visual Raw Perception — s_current

## Scene
- Scene is stable (no motion blur beyond the robot gripper, which is at rest hovering over its hole cards).
- Two players visible: human opponent seated at top (position 1) and robot at bottom (position 5).

## Turn Button
- The white "Your Turn" button is at the robot seat (bottom-left of the robot's area).
- Verdict: it is our turn.

## Blind / Button Markers
- Yellow "BIG BLIND" button is placed in front of the robot seat.
- Blue/white "DEALER" (small blind in heads-up) button is at the opponent's seat.
- Blind role for robot: big_blind.

## Hole Cards
- Robot has two face-down cards (unseen from camera; cached hole cards unavailable this step).
- Opponent has two face-down cards at top seat.

## Community Cards
- Community row shows face-up cards toward the right side of the board. At least two face-up cards are visible: a red card that reads as 7♦ and an adjacent card with a club suit (appears to be 9♣ but partially occluded by the robot gripper).
- Additional card-shaped regions in the middle of the community area appear to be face-down/placeholder graphics from this camera angle; identification of the full flop is not reliable. Community cards are marked uncertain.

## Chips
- Robot stack (right side of robot seat): a visibly large mixed stack with multiple 50 and 100 chips, some 10s. Rough estimate: 5 and 10 chips present in small numbers; 50 and 100 chips in larger numbers.
- Opponent stack (top): similar sized pile with 5, 10, 50, 100 denominations.
- Robot current bet area (just in front of robot seat, next to BIG BLIND button): a short stack of 10-denomination chips consistent with the posted big blind (~1 chip of value 10).
- Opponent current bet: a short stack of 10 chips on the opponent side, consistent with a matching call (~1 chip of value 10). This is uncertain — could be postflop no-bet state.

## Showdown
- Not a showdown: both players' hole cards remain face-down.

## Loop Stage Estimate
- Robot's turn to act, no showdown, scene stable → `acting`.
