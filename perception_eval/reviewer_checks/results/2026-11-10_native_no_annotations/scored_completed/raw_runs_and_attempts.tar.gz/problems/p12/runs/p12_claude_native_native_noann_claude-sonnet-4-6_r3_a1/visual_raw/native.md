# Raw Perception Evidence — native

## Image: s_current/00_capture.jpg

---

## Turn Detection

The white "Your Turn" button is clearly visible at the **bottom-left** of the table, in the robot/player seat area. This confirms it IS the robot's turn.

**Conclusion:** It is our turn.

---

## Blind Button Recognition

A yellow **"BIG BLIND"** button is visible near the bottom-right of the robot seat area (bottom side of the table).  
A blue **"DEALER"** button is visible in the top/opponent area of the table.

By the two-player rule: dealer = small blind at opponent seat, so the **robot is the big blind**.

**Conclusion:** Robot is the big blind; opponent is the small blind/dealer.

---

## Scene Stability

The table appears stable. Chips and cards are in fixed positions. The robot arm is visible on the right side near the community card area, in a near-idle/holding pose but not actively moving. Scene is considered stable.

---

## Community Cards

Looking at the central community card row (center of table):
- **Left of center**: 2 cards appear face-down (blue-backed) in the community row or they may be undealt positions — not readable as community cards.
- **Center**: One face-up card visible showing what appears to be **7** with a heart (♥) symbol — likely **7h** (7 of hearts).
- **Right-center**: Two face-up cards visible:
  - Card 2: shows **6** with a spade/club (black suit) — likely **6s** (6 of spades).
  - Card 3: shows **9** with a diamond/red suit — likely **9d** (9 of diamonds). Partially occluded by robot arm.

**3 community cards visible (flop stage).** Suits on all three are uncertain; card 3 (rightmost) has additional uncertainty due to robot arm occlusion.

---

## Chip Recognition

### Robot/Player Inventory (bottom seat area, NOT in bet zones)

- **Red (5):** Approximately 4 red chips visible in the bottom-center cluster.
- **Blue (10):** Approximately 3 blue chips visible — 1 near the "Your Turn" button (far left), 2 in the main cluster.
- **Green (50):** Approximately 2–3 green chips visible in the bottom-right area near the hole card zone.
- **Brown (100):** Approximately 2 brown/dark chips visible, partially uncertain.

**Estimate:** 4 red, 3 blue, 2 green, 2 brown. Green and brown counts are approximate.

### Opponent Inventory (top seat area)

- **Red (5):** Approximately 3 red chips visible at the top-left and top-center areas.
- **Blue (10):** Approximately 4 blue chips visible at the top area.
- **Green (50):** Approximately 2–3 green chips, partially uncertain angle.
- **Brown (100):** Approximately 2 brown chips, uncertain.

**Estimate:** 3 red, 4 blue, 2 green, 2 brown. All counts approximate due to distance and angle.

---

## Bet Areas

### Robot bet (left of community card row)

- 1 blue (10) chip visible in the left betting area.
- Possibly 1 red (5) chip also present, but hard to confirm.

**Estimate:** {5: 0, 10: 1, 50: 0, 100: 0} — uncertain on the red chip.

### Opponent bet (right of community card row)

- Partially occluded by robot arm.
- Approximately 1 red (5) and 1 blue (10) chip appear visible in the right betting area before occlusion.

**Estimate:** {5: 1, 10: 1, 50: 0, 100: 0} — uncertain due to robot arm occlusion.

---

## Showdown / Hand Outcome

- Opponent hole cards are **face-down** in the top seat area (2 blue-backed cards visible at top).
- Robot hole cards are **face-down** in the bottom-right hole card area (2 blue-backed cards visible at bottom-right).
- No showdown has occurred; cards are not face-up for comparison.

**Conclusion:** not_showdown; loop stage should be `acting` (robot's turn).

---

## Loop Stage

The "Your Turn" button is at the robot seat. Community cards are dealt (flop = 3 cards). No showdown.

**Conclusion:** `acting`
