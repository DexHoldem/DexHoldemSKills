# Perception report

The current `s24` capture shows an active robot chip movement. Compared with `s23`, the hand has reached into the betting lane and red bet chips have shifted, so `loop_stage` is `acting` and `scene_stable` is false. The lower-seat white turn marker and yellow big-blind marker are visible. Three board cards are read as `7d 8s 7c`; the last card is partly hidden in the current frame and was read from `s23`. No showdown or fold is visible.

Chip inventories are estimated from the visible groups and the immediately previous image where the robot occludes the right side. The single red chip under the gripper is assigned provisionally to the robot betting lane. Bet counts remain uncertain until the hand settles. The prior workflow JSON, hole-card cache, and parsed-state file were absent from this workspace, so no durable values were inherited from them.
