# Native Perception Evidence - s24

- **Loop Stage:** acting
- **Blind:** big_blind
- **My Turn:** True (marker present)
- **Community Cards:** 7D, 6C
- **Chips (My side):** 
    - 5 (red): 3
    - 10 (blue): 3
    - 50 (black): 3
    - 100 (white): 3
- **Chips (Opponent side):**
    - 5 (red): 3
    - 10 (blue): 4
    - 50 (black): 3
    - 100 (white): 3
- **Bets:** None visible on table for either side.
- **Scene Stability:** Stable.
