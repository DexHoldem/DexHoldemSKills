# Eval Report — s_current

## Evidence summary
- White "Your Turn" button is at the robot seat → `is_my_turn: true`, loop_stage `acting`.
- Yellow BIG BLIND button in front of robot seat → `blind: big_blind`. DEALER/SB button on the opponent side.
- Both players still have face-down hole cards → not a showdown.
- Community row shows at least two face-up cards (tentatively 7♦ and 9♣); other community slots look like face-down/placeholder graphics obscured by the gripper, so the full board is uncertain.
- Chip stacks are visible on both sides; denominations present (5, 10, 50, 100) but exact counts are only estimated from pile size.

## Merging / inheritance
- No prior parsed state (`sN-1/01_parsed_state.md`) and no `action_sequence.json` / `hole_card_cache.json` were present in the workspace, so no durable fields were inherited; all values come from the current image.
- Uncertain fields (chip counts, bet stacks, community cards) are listed in `uncertain_fields`.

## Outputs written
- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
