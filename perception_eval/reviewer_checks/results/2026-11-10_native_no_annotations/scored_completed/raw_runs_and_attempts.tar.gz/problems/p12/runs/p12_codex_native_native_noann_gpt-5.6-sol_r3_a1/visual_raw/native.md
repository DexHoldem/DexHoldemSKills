# Raw visual perception

## Scene and robot

Unstable. Compared `s_current/00_capture.jpg` with `s24/00_capture.jpg` (the same visible state) and `s23/00_capture.jpg` as the preceding distinct frame. The robot arm and gripper have moved substantially inward from the right and are now over/contacting the right side of the community-card and betting lane. The hand is not near its settled/rest pose. It appears to be manipulating a red chip or chips, and the fingers obscure part of the right-side betting area and the rightmost community card. This is still in progress, so the visual state is `acting`; there is no settled evidence of failure or recovery. No dropped card, scattered inventory group, or clearly moved non-target object is visible.

## Table geometry and cards

The bottom band is the robot/player seat and the top band is the opponent seat. Three community cards occupy the central row. From left to right they read `7d`, `6s`, and `7c`. The `7c` is partly covered in the current frame but was unobstructed in the preceding distinct frame, so that board position is visually supported but marked uncertain in the current parse. The two face-down cards at the bottom are robot hole cards, and the two face-down cards at the top are opponent hole cards; neither pair is counted as community cards.

The opponent hole cards are not face-up or displaced into the community-card lane. The robot hole cards are also face-down. There is no visible fold or showdown, so the outcome is `not_showdown`.

## Turn and blind markers

The white `Your Turn` button is at the bottom-left robot seat, so it is the robot/player's turn. The yellow `BIG BLIND` button is at the bottom robot seat, so the robot is the big blind. The white dealer button is at the top/opponent seat, consistent with the heads-up blind assignment.

## Chip inventories

Using red = 5, blue = 10, green = 50, and brown = 100:

- Robot/player inventory at the bottom: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips. The red and blue groups are directly visible. The current robot body partly occludes the green/brown region, so those two counts are carried from the immediately preceding clear frame and the aggregate `my_chips` field is marked uncertain.
- Opponent inventory at the top: 3 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips. These groups remain visible and separated from the betting lane.

## Betting areas

No chips are visible in the robot/my-bet area on the left side of the community-card row: 0 red, 0 blue, 0 green, 0 brown.

The opponent/right-side betting area contained two red 5-chips in the preceding distinct frame. In the current frame the moving gripper is contacting/covering this area; one red chip is partly visible and the second is plausibly beneath the hand. The best current concrete estimate is therefore 2 red 5-chips and 0 of all other denominations, with `opponent_bet` explicitly uncertain due to active occlusion.

## Context availability

The requested `action_sequence.json`, `hole_card_cache.json`, and prior `01_parsed_state.md` files are not present in the supplied workspace. No action intent or cached hole-card value was inferred. Only the numbered image sequence was used for motion comparison and the immediately preceding clear visual counts.
