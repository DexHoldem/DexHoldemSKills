# Raw visual perception

Compared `s_current/00_capture.jpg` with `s24/00_capture.jpg` and the clearer `s23/00_capture.jpg`.

- The robot hand is extended over the right side of the board and contacts a brown 100 chip in the lower/robot betting lane. It has not returned to an idle pose. The scene is not safely settled; this looks like an action in progress. No dropped card or visibly scattered chip group is apparent.
- The white "Your Turn" marker is at the bottom/robot seat. The yellow "BIG BLIND" marker is also at the robot seat; the white dealer marker is at the opponent seat.
- Three face-up community cards appear in the board row, left to right: 7d, 8s, 7c. The third card is partly covered by the robot hand in the current capture; its read uses the clearer `s23` image. The two patterned cards to their left are face-down and are not counted as face-up community cards.
- Robot inventory at the bottom: four red 5 chips, three blue 10 chips, four green 50 chips, and an estimated three brown 100 chips. The remaining brown group is partially blocked by the robot hardware.
- Opponent inventory at the top: two red 5 chips, four blue 10 chips, four green 50 chips, and four brown 100 chips.
- Robot bet area: one blue 10 chip at the lower-left of the board and one brown 100 chip under the robot fingers near the lower-right of the board. No red or green bet chip visible there.
- Opponent bet area: two red 5 chips were visible to the upper-right of the board in `s23`; the robot now occludes that area. Current count is inferred as two red chips, with no other bet chips identified.
- Both players' hole cards remain face-down. There is no visible fold or showdown.
- `action_sequence.json`, `hole_card_cache.json`, and a prior `01_parsed_state.md` were not present in this workspace, so no workflow or cached-card fields were merged.
