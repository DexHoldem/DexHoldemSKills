# Visual Perception Raw Data - s_current/00_capture.jpg

## Table State
- **Scene Stability**: The scene appears stable. The robot hand is actively manipulating or interacting with chips in front of it.
- **My Turn**: Yes, "Your Turn" marker is visible in front of the user (human player), but the robot hand is positioned over the table, and the board has community cards.
- **Community Cards**: Two cards face-up: 7 of Diamonds, 6 of Spades.
- **My Chips**:
  - 5: 4
  - 10: 3
  - 50: 3
  - 100: 3
- **Opponent Chips**:
  - 5: 4
  - 10: 4
  - 50: 3
  - 100: 3
- **Bets**: No prominent bets in center.

## Game State
- **Loop Stage**: acting
- **Blind**: big_blind (indicated by the yellow button)
- **Showdown Outcome**: not_showdown
