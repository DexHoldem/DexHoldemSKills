# Native visual evidence

Inspected s_current/00_capture.jpg (s24), s23/00_capture.jpg, and s22/00_capture.jpg directly. Read all field guidelines in visual_guidelines/. action_sequence.json, hole_card_cache.json, and s23/01_parsed_state.md are absent; no workflow status or cached hole cards were available.

Unstable. Between s23 and s24 the robot hand moves inward and downward from the right edge to the lower edge of the board. A fingertip contacts a brown chip near (1200, 655). The hand is not at rest and appears to be moving a chip from the bottom inventory toward the betting lane. No readable held card is visible. This is still in progress, not evidence of a completed atom or a recovery/failure condition. The current human arms are off the playing surface. s22 provides earlier context, with the board still face-down and the human placing red bet chips.

The white Your Turn marker is clearly at the bottom-left robot seat: it is our turn. The yellow BIG BLIND marker is at the robot seat; the DEALER and blue SMALL BLIND markers are at the opponent seat. Robot is big blind.

Three face-up community cards are present: 7d, 6s, 7c from left to right among the exposed cards. Two additional central cards remain face-down and are excluded. In s24 the hand partly blocks 6s and heavily blocks 7c; s23 clearly shows both, with no visible board displacement. The 7c read is inherited visually from s23 and therefore uncertain in the current-frame output.

Robot inventory: four red 5 chips, three blue 10 chips, four green 50 chips. Brown inventory is partly hidden by the robot housing: two faces are at least partly visible, and the best total estimate is three brown 100 chips. s23 shows four brown inventory chips; s24 shows a brown chip moved forward under the fingertip. The inferred remaining brown count is uncertain.

Opponent inventory: two red 5 chips, four blue 10 chips, four green 50 chips, four brown 100 chips. These are flat individual faces near the top rail and distinct from the betting lane.

Robot bet: one blue 10 chip left of the board. One brown 100 chip is now below the board under the robot fingertip, forward of the inventory boundary; provisionally count it in robot current bet. No red or green robot bet chips are visible. Ownership and final placement of the moving brown chip are inferred, so this bet is uncertain.

Opponent bet: best estimate two red 5 chips and no blue, green, or brown chips. s23 shows two red chips right of the board; s24's hand/housing obscures that region, preventing direct confirmation. This count is inherited from prior visual evidence and uncertain.

Both players' hole cards remain face-down in their normal seat areas. The face-down central board positions were already present in s22 and are not displaced opponent hole cards. No showdown or fold is visible: not_showdown. No hand comparison is possible or needed.

Current loop-stage estimate: acting, based on ongoing physical chip movement. No robot action or poker action is selected.
