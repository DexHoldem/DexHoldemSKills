# Native perception evidence

Unstable. Compared current `s_current/00_capture.jpg` (s24) with s23 and s22. In s23 the robot hand is farther right and above the table; in s24 it is extended inward and downward, with a red fingertip contacting a brown chip below the right part of the board. The robot is not at rest. This is still an acting state; the images do not establish a settled failure or recovery condition. No readable held card is visible.

The white Your Turn button is clearly at the bottom-left robot seat: it is our turn. The yellow BIG BLIND button is at the robot seat. The opponent has the white DEALER and blue SMALL BLIND buttons. Robot is big blind; no visible conflict.

Three face-up community cards are present. Left-to-right among the face-up cards: 7d, 6s, 7c. The 7d and 6s are readable in s24; the rightmost card is substantially obscured by the robot, with its value carried from the clear s23 view. Two card backs occupy the other central board positions; no values are assigned to them and they are excluded from the face-up community-card list. Both players' two hole cards remain face-down in their normal seat areas. No visible fold or showdown; outcome is not_showdown.

Robot inventory: four red 5-chips, three blue 10-chips, four green 50-chips. Brown 100-chip inventory is partly hidden by the robot body: two faces are visible and three remaining chips is the best estimate. The previous image has four brown inventory chips; a brown chip is now beneath the fingertip in the central lane. Inferring one chip moved from that inventory is uncertain during motion.

Opponent inventory: two red 5-chips, four blue 10-chips, four green 50-chips, four brown 100-chips. These are the separate flat groups along the top rail, not bets or buttons.

Robot current bet area, left of the board: one blue 10-chip; no red, green, or brown chips visible.

Opponent bet area, right of the board: the robot hand/body blocks the two red chips clearly visible in s23; estimate two red 5-chips remain. One brown 100-chip is visible under the robot fingertip below the right portion of the board. Using the bet guideline's left/right convention, include it provisionally in opponent_bet. Its final placement/ownership is uncertain because it is in transit near the lower boundary of the right betting lane. No blue or green bet chips visible on this side. Best estimate: red 2, blue 0, green 0, brown 1.

Context availability: action_sequence.json, hole_card_cache.json, and s23/01_parsed_state.md were not present in the available workspace. No cached hole-card values or prior parsed fields were invented. Earlier capture images supply only the explicitly noted occlusion estimates. Uncertain fields: community_cards, my_chips, opponent_bet.
