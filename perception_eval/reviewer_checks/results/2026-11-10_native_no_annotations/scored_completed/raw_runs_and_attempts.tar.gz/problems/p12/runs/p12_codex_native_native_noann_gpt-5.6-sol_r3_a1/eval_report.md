# Perception evaluation report

The current capture shows the robot actively extended over the right side of the board/betting lane, unlike the preceding distinct settled frame. This makes the scene unstable and merges to `loop_stage: acting`; it is not treated as a failed atom or recovery state.

Direct current-frame evidence establishes the robot-side white turn button (`is_my_turn: true`), the robot-side yellow big-blind button (`blind: big_blind`), no fold/showdown, the first two board cards (`7d`, `6s`), all opponent inventory counts, and the unoccupied left/my betting area.

Occlusion-aware merging supplies concrete estimates where required by the schema. The partly covered third board card is read as `7c` from its visible portion plus the preceding clear frame. Robot green/brown inventory counts are carried from that clear frame because the robot body blocks them now. The right/opponent bet is estimated as two red chips because that area held two immediately before the moving gripper covered it; the current view is not clear enough to claim a settled post-movement count. These three structured fields are listed in `uncertain_fields`.

The named workflow/cache/prior-parsed-state context files were absent, so no nonvisual action intent, hole-card identity, or parsed durable field was merged.
