# Eval Report — s_current perception

## Evidence
- Capture: `s_current/00_capture.jpg` (= `s24/00_capture.jpg`).
- Visible markers:
  - Yellow "BIG BLIND" button at my (bottom) seat → `blind = big_blind`.
  - White "Your Turn" chip at my seat → `is_my_turn = true`, `loop_stage = acting`.
  - White "DEALER" button at opponent seat (top).
  - Opponent hole cards face-down at top rail (no showdown).
- Community lane shows 2 clearly face-up cards: `7d` and a black `6` (likely
  spades/clubs). The robot arm occludes the rightmost slot, so additional
  face-up community cards may exist.

## Merging with prior state
- No prior-state files were present
  (`action_sequence.json`, `hole_card_cache.json`, `sN-1/01_parsed_state.md`
  all absent in the workspace). Nothing was inherited; all fields come from
  the current image.

## Chip reads
- Chip inventories and current bets are rough counts; the robot arm covers
  part of my inventory and the right community region. All chip-count fields
  are marked uncertain.

## Uncertain fields
- `community_cards` — only 2 face-up cards readable; occlusion may hide a
  third flop card.
- `my_chips`, `opponent_chips`, `my_current_bet`, `opponent_bet` — approximate
  counts due to angle/occlusion.

## Output files written
- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
