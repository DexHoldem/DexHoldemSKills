# DexHoldem Visual Perception Evaluation - s24

## Evidence Summary

### Scene Stability: STABLE
- Robot hand is in a near-idle pose, not moving or holding objects
- No visible motion blur in current capture
- Chips and cards appear stationary
- Opponent present but not actively disturbing table layout
- **Decision**: Scene is stable for next action dispatch

### Loop Stage: IDLE
- Robot hand is idle and at rest
- No active action in progress (no card movement, chip movement, or gripper motion)
- Hand is not holding any cards or chips
- **Decision**: Robot is in idle state, ready to act or wait

### Turn Determination: IS_MY_TURN (True)
- White/yellow turn button visible in the lower-left area (robot/player seat region)
- Button position at bottom of table indicates robot turn
- **Decision**: It is the robot's turn to act

### Blind Position: BIG_BLIND
- Blue chip marker visible in lower-left region with number "01" overlay
- Position corresponds to big blind marker area
- Yellow marker labeled "Big Blind" appears to be at robot seat
- **Decision**: Robot is in big blind position

### Showdown Status: NOT_SHOWDOWN
- Opponent hole cards are still face-down (not revealed)
- Robot hole cards are not visible in frame (still face-down in expectation)
- No opponent fold signature visible (opponent cards not displaced to community area)
- Hand is in active play, not terminal state
- **Decision**: Hand has not reached showdown; normal poker play continues

## Chip Counts (Flat Inventory Layout)

### Robot/Player Inventory (Bottom Seat Area)
**Visible counts from left to right:**
- Red (5): ~4 chips
- Blue (10): ~3 chips  
- Green (50): ~3 chips
- Brown (100): ~3 chips
**Confidence**: Medium (chips appear unfolded and countable)

### Opponent Inventory (Top Seat Area)
**Visible counts from left to right:**
- Red (5): ~4 chips
- Blue (10): ~4 chips
- Green (50): ~3 chips
- Brown (100): ~3 chips
**Confidence**: Lower (right side partially obscured by robot hand in near-idle pose)

### Current Bets (Betting Lanes Around Community Cards)

**My Current Bet (Bottom/Left side):**
- Red (5): ~1 chip
- Blue, Green, Brown: 0 visible
**Confidence**: Medium (small bet area, limited chips)

**Opponent Bet (Top/Right side):**
- Red (5): ~1 chip
- Blue, Green, Brown: 0 visible
**Confidence**: Lower (obscured by robot hand occlusion)

## Community Cards

**Count**: 3 cards visible in the central board area
**Readable cards** (best-effort estimates):
- Position 1 (leftmost): 3♥ (3 of hearts)
- Position 2 (middle): 7♦ (7 of diamonds)
- Position 3 (rightmost): K♣ (King of clubs)

**Confidence**: Medium-to-Low (angles, lighting, and chip placement make some reads uncertain)
**Stage**: Flop (3 community cards → preflop is over, flop betting stage)

## Uncertain Fields and Rationale

| Field | Status | Reason |
|-------|--------|--------|
| `community_cards` | Uncertain | Cards are at angles; some reads are best-effort; middle card identity could shift with lighting |
| `opponent_chips` | Uncertain | Right side of opponent area partially occluded by robot hand in near-idle pose |
| `opponent_bet` | Uncertain | Right betting area blocked by robot hand |
| `blind` | Uncertain | Big blind marker visible but could verify further with separate blind-recognition pass |

## Recommendations for Next Steps

1. **If high-confidence card reads are needed**: Dispatch `reset_to_init` to move robot hand to true initial pose, then recapture for clearer view of opponent bet area and chips

2. **For next action**: Robot is at big blind, hand is idle, scene is stable. Robot can proceed with normal action sequence (check, fold, call, raise, etc.) based on strategy

3. **Chip count inheritance**: Use these as baseline inventories for the current hand; mark uncertain fields for potential re-confirmation if game state becomes ambiguous

## Merge Strategy

- **From visual evidence (this capture)**: Take all fresh chip counts, community card reads, turn state, and blind position
- **No prior state file provided**: Starting from baseline; no durable fields to inherit
- **Uncertain fields documented**: Flagged in JSON for upstream decision-making
