# Perception evidence and merging

Current image: s_current/00_capture.jpg, resolving to s24/00_capture.jpg. Read all field guidelines and compared s23 and s22 captures directly.

The changed robot pose and fingertip contact with a displaced brown chip support loop_stage acting and scene_stable false. The robot-side white turn marker supports is_my_turn true. Visible blind/dealer buttons establish robot big blind. Face-down hole cards remain at both seats; there is no showdown or clear fold.

Current visible chip faces determine the unobstructed counts. The partly hidden third board card is carried forward as 7c from s23. Opponent bet is estimated as the two red chips visible in s23, now occluded. Robot brown inventory is estimated as three after one of the four previously visible brown chips moved into the central lane. That moving chip is provisionally allocated to my_current_bet; its unfinished movement makes both inventory and bet allocation uncertain. All four affected fields are listed in uncertain_fields.

The requested action sequence, hole-card cache, and previous parsed-state Markdown are absent. No values were inherited from unavailable files, and no workflow intent was invented. Outputs contain concrete estimates without nulls. No helper scripts, robot actions, or poker decisions were run.
