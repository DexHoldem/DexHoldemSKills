# DexHoldem Native Perception - s24 Visual Raw Evidence

## Scene Stability Analysis

**Verdict: STABLE**

Compared s23/00_capture.jpg (not available, baseline first capture) and s24/00_capture.jpg.

The robot arm is in a clearly settled, near-idle pose on the right side of the table. No motion blur, no cards or chips in motion, no human arm substantially on the table interfering with play. The table layout appears fully settled with all objects at rest. Lighting is consistent and the image is clear enough for main-agent parsing.

## Turn Detection

**Verdict: It is our turn.**

The white "Your Turn" button is clearly visible on the table at the bottom-left robot seat area. The button is positioned near the robot's hole card area, indicating that the robot/player's turn to act.

## Blind and Dealer Button Recognition

Looking at the physical buttons on the table:
- A white button labeled "DEALER" is not clearly visible in this image at its usual location
- A blue button (likely "SMALL BLIND") is visible on the left/robot side of the table
- A yellow button labeled "BIG BLIND" is visible on the right/opponent side of the table

**Preliminary interpretation:** The robot/player has the small blind (blue button), the opponent has the big blind (yellow button).

However, standard two-player rules dictate that small blind = dealer. If the blue button represents small blind at robot seat, then robot is small blind and dealer, opponent is big blind.

## Chip Inventory Recognition

### Robot/Player Inventory (Bottom Seat Area)

Counting unfolded chips from left to right near the bottom rail:
- **Red chips (5):** Approximately 4 visible chips
- **Blue chips (10):** Approximately 3 visible chips
- **Green chips (50):** Approximately 3 visible chips
- **Brown chips (100):** Approximately 3 visible chips

Some chips are slightly angled or partially adjacent; counts represent best visible estimate.

### Opponent Inventory (Top Seat Area)

Counting unfolded chips near the top rail:
- **Red chips (5):** Approximately 4 visible chips
- **Blue chips (10):** Approximately 4 visible chips
- **Green chips (50):** Approximately 3 visible chips
- **Brown chips (100):** Approximately 3 visible chips

The opponent's inventory grouping is visible and relatively clear.

## Current Bet Recognition

### Betting Area Analysis

Examining the center area near the community cards:

- **My current bet (left side of community cards):** One red chip (5) and one blue chip (10) visible in the betting zone = approximately 1×5 + 1×10 in value.
  
- **Opponent bet (right side of community cards):** No chips clearly visible in the opponent's dedicated betting area on the right side of the community cards.

Current bet state appears minimal with only robot's small contribution visible.

## Community Cards Recognition

**Visible community cards in the center board area:**

Examining the shared board row in the center:
- Position 1 (left): One face-down card with back pattern visible
- Position 2 (center-left): One face-down card with back pattern visible
- Position 3 (center): One face-up card - appears to be **Qc** (Queen of clubs) or similar rank, partially visible
- Position 4 (center-right): One face-up card visible
- Position 5 (right): Potentially another card or empty space

**Best read:** Three community cards appear face-down or unclear in terms of rank/suit. The exact values are difficult to determine from this angle and lighting. At least one card appears to show a face value but is not fully clear.

Conservatively: **3 cards visible, ranks mostly uncertain** - this suggests flop stage (3 community cards dealt).

## Hole Card Recognition

### Robot Hole Cards

The robot's two hole cards are at the bottom-left card area:
- Both cards appear to be **face-down** (back pattern showing)
- They are in the standard robot hole-card position
- No values readable from current pose/angle

### Opponent Hole Cards

The opponent's two hole cards are at the top-center/top-left area:
- Both cards appear to be **face-down** (back pattern showing)
- They are in the standard opponent hole-card position
- No values readable from current angle

### Showdown Status

**Verdict: NOT in showdown**

Neither player's hole cards are face-up. Both sets of hole cards remain face-down in their normal positions. No fold signature observed (opponent's cards are still in their normal top seat area, not moved toward community cards).

**Loop stage recommendation: idle** (not acting, not showdown, waiting for action)

## Summary of Uncertain Fields

- Exact community card ranks (partially obscured or back-angle)
- Exact chip colors/counts in betting areas (small bet amounts, potential partial occlusion)
- Whether the first captured state contains prior action from a hand in progress

All other fields have clear visual evidence.
