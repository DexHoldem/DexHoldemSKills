# Perception Eval Report

## Context files

No `action_sequence.json`, `hole_card_cache.json`, or any prior
`sN/01_parsed_state.md` exist anywhere in the working directory — checked
the top level and `s0`..`s24`. `s_current` is a symlink to `s24`, and every
`sN` folder only contains `00_capture.jpg`. This run therefore has no
durable context to inherit; everything in `visual_summary.json` comes
straight from the image evidence (current frame `s24` plus the prior frame
`s23` used only for the stability comparison).

## Evidence summary

- **Turn**: "Your Turn" white button at the robot/bottom seat → `is_my_turn: true`.
- **Blind**: "DEALER" (+ small-blind) button at the opponent/top seat,
  "BIG BLIND" button at the robot/bottom seat → two-player rule gives
  `blind: big_blind` for the robot.
- **Community cards**: 7d, 9c, 7c read directly off the previous frame
  (s23); in the current frame the hand has moved onto the board and
  occludes the 7c slot, so that card's current-frame visibility is
  inferred from the immediately prior capture rather than directly seen
  now. Two further board slots remain face-down/undealt in both frames.
- **Scene stability**: the dexterous hand changed position substantially
  between s23 and the current frame (moved from near the far-right
  opponent-bet chip cluster down onto the community-card row). That is a
  significant inter-frame change, so the scene is judged **unstable** and
  `loop_stage` is set to `acting` rather than an idle/settled stage.
- **Showdown**: opponent hole cards remain face-down in their normal
  position with no fold signature → `not_showdown`.
- **Chips**: counted by rough zone (inventory clusters beside each
  player's hole cards vs. larger bet clusters nearer the board) from both
  frames. Resolution/angle make exact per-chip counts unreliable, so all
  four chip fields are flagged uncertain. The `my_current_bet` /
  `opponent_bet` zone split in particular is a judgment call based on
  TABLE_GEOMETRY.md's "between inventory and board" description, not a
  hard boundary visible on the felt.

## Merging notes

Since there is no previous parsed state to merge against, every field in
`visual_summary.json` is a fresh visual estimate, not an inherited value.
`uncertain_fields` lists `loop_stage`, `community_cards`, and all four chip
fields because they depend on cross-frame inference (the 7c card) or
approximate chip counts under imperfect zoom/resolution. `blind`,
`showdown_outcome`, and `is_my_turn`/`scene_stable` are higher-confidence
reads based on clearly visible physical buttons and hand position.

## Verification

Confirmed on disk:
- `runs/p12_claude_native_native_noann_claude-sonnet-5_r1_a1/visual_raw/native.md`
- `runs/p12_claude_native_native_noann_claude-sonnet-5_r1_a1/visual_summary.json`
- `runs/p12_claude_native_native_noann_claude-sonnet-5_r1_a1/eval_report.md`
