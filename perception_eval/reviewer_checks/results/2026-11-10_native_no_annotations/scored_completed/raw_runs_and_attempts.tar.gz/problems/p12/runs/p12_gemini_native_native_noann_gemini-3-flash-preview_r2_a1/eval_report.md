# Evaluation Report

## Evidence Summary
- **Scene Stability:** Unstable. Robot hand is moving in the `s_current` frame compared to `s23`.
- **Robot State:** `acting`. The hand is mid-motion, pushing a red chip.
- **Turn:** Robot's turn (`is_my_turn: true`) based on the "Your Turn" button.
- **Blinds:** Robot is `big_blind`.
- **Board:** 3 face-up cards: `7d`, `6s`, `7c`.
- **Chips:**
    - Robot: 5x5, 5x10, 1x50.
    - Opponent: 2x5, 3x10, 2x50.
- **Bets:** None settled. Robot is currently pushing one red 5-chip.

## Merging and Uncertainty
- `loop_stage` is set to `acting` because the robot hand is still moving.
- `my_chips` and `my_current_bet` are marked uncertain because the robot is in the middle of moving a chip from inventory to the bet area.
- `opponent_chips` marked uncertain due to the angled view at the top of the table.
- No previous `01_parsed_state.md` or `hole_card_cache.json` were found, so all state is derived from current visual evidence.
