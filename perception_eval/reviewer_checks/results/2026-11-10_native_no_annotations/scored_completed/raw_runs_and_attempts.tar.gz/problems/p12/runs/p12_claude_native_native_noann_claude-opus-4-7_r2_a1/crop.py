from PIL import Image
im = Image.open('/private/tmp/dexholdem_native_ablation/workspaces/p12_p12_claude_native_native_noann_claude-opus-4-7_r2_a1_cjhjw2zr/p12/s_current/00_capture.jpg')
w,h = im.size
print(w,h)
im.crop((int(w*0.15), int(h*0.50), int(w*0.75), int(h*0.72))).save('/tmp/community.jpg')
im.crop((int(w*0.10), int(h*0.65), int(w*0.75), int(h*0.98))).save('/tmp/robotbet.jpg')
im.crop((int(w*0.10), int(h*0.35), int(w*0.75), int(h*0.60))).save('/tmp/oppbet.jpg')
im.crop((int(w*0.55), int(h*0.55), int(w*0.95), int(h*0.95))).save('/tmp/robotchips.jpg')
im.crop((int(w*0.55), int(h*0.35), int(w*0.95), int(h*0.60))).save('/tmp/oppchips.jpg')
