# Native visual perception evidence

- Source: `s_current/00_capture.jpg`.
- The robot dexterous hand/arm is extended over the right side of the board and appears mid-action rather than returned to a settled idle pose. The scene is therefore visually unstable and the loop is `acting`.
- The white `Your Turn` button is visible near the bottom/robot seat, indicating it is the robot's turn.
- The yellow `BIG BLIND` button is on the bottom/robot side, so the robot is the big blind.
- Three face-up community cards are visible left-to-right: approximately `7d`, `6s`, and `Jc`; the rightmost card is partly affected by robot-arm occlusion and is lower confidence.
- No showdown is evident: opponent cards remain face-down and no fold/muck or face-up showdown cards are visible.
- Robot inventory at the bottom seat is estimated as 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory at the top seat is estimated as 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Betting areas: one blue 10-chip is visible in the robot-side/lower betting area; two red 5-chips are visible in the opponent-side/upper-right betting area. Other bet denominations are not visible.
- The robot hand partially occludes the right side of the table, so the opponent bet and rightmost community-card read are uncertain.
- `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` were not available in the workspace; no inherited values were used.
