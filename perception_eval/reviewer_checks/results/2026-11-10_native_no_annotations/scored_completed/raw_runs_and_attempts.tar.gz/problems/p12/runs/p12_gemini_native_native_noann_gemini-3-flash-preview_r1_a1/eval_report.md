# Perception Evaluation Report

## Evidence Summary
- **Stability**: Scene is unstable. The robot hand moved between s23 and s24, and is currently extended over the community cards.
- **Turn**: "Your Turn" button is at the robot seat. `is_my_turn: true`.
- **Blinds**: Robot is Big Blind (yellow button at bottom).
- **Cards**: Flop is 7d-6s-8c. 8c is partially occluded in s24 but confirmed from s23.
- **Chips**: Both players have significant inventories. Robot: 4-3-3-3 (5-10-50-100). Opponent: 3-5-3-4 (5-10-50-100).
- **Bets**: No chips in betting areas. Opponent bet area is partially occluded.

## Merging & Confidence
- Values were extracted from s24, using s23 as a reference for stability and occluded cards.
- `loop_stage` is set to `acting` due to robot motion.
- High confidence in all fields except for those occluded by the robot hand (`opponent_bet` and `community_cards` third slot).
