# Eval Report — s_current Perception

## Evidence Summary

**Turn:** White "Your Turn" button clearly present at robot seat (bottom-left). `is_my_turn = true`, `loop_stage = acting`.

**Blind:** Yellow BIG BLIND button at robot/bottom seat; blue DEALER button at opponent/top seat. Robot is big blind.

**Community cards:** Three face-up cards identified in the center community strip (flop). Left-to-right: a heart-suit card (rank uncertain, assigned 2h), 7c (suit uncertain, possibly 7s), 6d (confident). One face-down card at far-left edge treated as deck, not counted. Right side of community strip partially occluded by robot arm — additional cards cannot be fully ruled out, but no 4th/5th card is confirmed face-up.

**Showdown:** No opponent hole cards face-up. No showdown resolution. `showdown_outcome = not_showdown`.

**Scene stability:** Single-frame assessment (no sN-1 parsed state available). Robot arm in near-idle settled pose, no motion blur, table appears static. Assessed stable.

**Chip counts:** Robot inventory (bottom seat, excluding bet lane): ~4 red (5), ~3 blue (10), ~2 green (50), ~2 brown (100). Green and brown counts are uncertain due to partial robot arm occlusion on the right side of the robot seat. Robot current bet: ~1 blue (10). Opponent inventory: ~3 red, ~4 blue, ~2 green, ~2 brown (all approximate from top-seat clusters). Opponent bet: ~2 blue (10), uncertain due to partial occlusion.

## Merge Decisions

- `loop_stage`, `blind`, `showdown_outcome`, `is_my_turn`: derived directly from visual evidence (high confidence).
- `community_cards[0]` (heart card rank): inferred as 2h; marked uncertain.
- `community_cards[1]` (7c suit): assigned clubs based on dark pip color; could be 7s; marked uncertain.
- `community_cards[2]` (6d): red diamonds visible, confident.
- `my_chips.50`, `my_chips.100`, `opponent_chips.*`: estimated from partially occluded areas; marked uncertain.
- `my_current_bet`, `opponent_bet`: single chip denomination chips visible in bet lanes; small counts; marked uncertain.
- No previous `01_parsed_state.md` found for inheritance; all fields come from current image.
