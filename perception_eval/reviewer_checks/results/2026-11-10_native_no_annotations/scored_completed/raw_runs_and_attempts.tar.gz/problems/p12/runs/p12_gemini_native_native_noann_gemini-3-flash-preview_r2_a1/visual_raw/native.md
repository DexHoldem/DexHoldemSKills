# Raw Perception Evidence

## Scene Stability
Unstable. Compared s23/00_capture.jpg and s_current/00_capture.jpg. The robot dexterous hand is mid-motion, touching and apparently pushing a red 5-chip from the robot's right-side inventory toward the center. The hand position has changed significantly between the two frames.

## Robot Behavior
The dexterous hand is extended over the table, touching a red 5-chip. It appears to be in the middle of a chip-pushing action. The hand is not near its initial pose. The action is still in progress.

## Turn Detection
It is our turn. The white "Your Turn" button is clearly visible at the robot/player seat area (bottom-left of the table).

## Blind Buttons
The yellow "BIG BLIND" button is at the robot seat. The blue "SMALL BLIND" and white "DEALER" buttons are at the opponent seat. The robot is the big blind.

## Community Cards
Three community cards are visible. From left to right in the face-up slots: 7d (Seven of Diamonds), 6s (Six of Spades), and 7c (Seven of Clubs). There are two face-down cards to the left of these, which may be un-dealt flop cards or placeholders.

## Chip Inventory
**Robot/player inventory:**
- Red (5): 5 chips (3 on the left, 1 on the right, 1 currently being pushed by the hand).
- Blue (10): 5 chips (3 on the left, 2 on the right).
- Green (50): 1 chip (on the right).
- Brown (100): 0 chips visible.
Counts are slightly uncertain due to the robot hand's movement and some occlusion on the right side.

**Opponent inventory:**
- Red (5): 2 chips.
- Blue (10): 3 chips.
- Green (50): 2 chips.
- Brown (100): 0 chips visible.

## Bet Recognition
- My current bet area: No chips settled in the betting area yet (one 5-chip is being pushed).
- Opponent bet area: No chips visible in the betting area.

## Showdown and Outcome
Not a showdown. Opponent hole cards are face-down. Robot hole cards are face-down.
Showdown outcome: not_showdown.
