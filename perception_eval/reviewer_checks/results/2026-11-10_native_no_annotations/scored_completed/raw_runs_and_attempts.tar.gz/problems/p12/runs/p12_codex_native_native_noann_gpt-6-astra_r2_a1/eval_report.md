# Perception and merging

Current image resolves to s24. Compared s23 and s22 for motion and occluded details. Robot movement and contact with a brown chip support acting and scene_stable=false. The bottom white turn marker supports is_my_turn=true; visible blind/dealer markers identify the robot as big blind. Both hole-card pairs remain face-down, with no showdown or fold evidence.

The requested action sequence, hole-card cache, and previous parsed state were not present. No structured prior state was merged. The visible board is 7d, 6s, 7c; s23 supplies the obscured third-card identity. The two face-down board cards are excluded. Opponent red bets are estimated from s23 because the current robot occludes them. Robot brown inventory is estimated as three after one of the four previously visible brown chips moves into the lower betting lane; that chip is provisionally assigned to my_current_bet. These estimates are explicitly flagged in uncertain_fields. All other counts use current visible chip faces.

Outputs contain concrete values for every requested field, with the four denomination keys in every chip object. Only perception and file writing were performed; no helper scripts, robot actions, or poker decisions were executed.
