# Native perception — s_current/00_capture.jpg

Context: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md`
were NOT present in the workspace. Previous frames used for comparison:
`s24/00_capture.jpg` (immediately previous), `s23/00_capture.jpg` (last frame with
hand clear of the board), `s0/00_capture.jpg` (initial layout).

## Scene stability / robot behavior
Unstable. Compared s24 and s_current: the two frames are visually identical, but
in both the dexterous hand is NOT near its rest/initial pose. It is extended over
the right side of the board (community-card row), with a red fingertip pressed down
on a chip at roughly (1195, 655) px, just below/right of the community-card row in
the betting lane. In s23 no chip was at that spot and the hand was retracted at the
right edge. The hand appears to be mid chip-push (pressing/holding a chip), so the
atom looks still in progress. Because it has not moved between s24 and s_current,
it may also be stalled/pinning the chip — flag for monitoring; not judged as a
failure from this frame. No card appears disturbed; chip groups remain ordered.

Occlusion: the hand covers the opponent bet area (right of board, where s23 showed
two red 5-chips), most of the 5th community card, and the two right-most robot
brown 100-chips.

## Turn
It is our turn. The white "Your Turn" button is at the bottom-left robot seat area.

## Blinds
Yellow BIG BLIND button sits at the robot (bottom) side; white DEALER and blue
SMALL BLIND buttons are at the opponent (top) side. Dealer/small blind = opponent;
robot = big blind. No conflict.

## Community cards
Five card positions in the board row. Left-to-right: face-down, face-down, 7d,
6s, and a 5th card mostly occluded by the hand (only a "7" corner visible).
s23 (hand clear) shows the 5th card clearly as 7c, and nothing has visibly moved,
so the 5th card is read as 7c (inherited from s23, uncertain in this frame).
The two face-down cards were part of the original 5 face-down board in s0 —
not folded opponent cards. Face-up community cards: 7d, 6s, 7c (3 cards).

## Robot inventory (bottom seat)
- red 5: 4 (clear)
- blue 10: 3 (clear)
- green 50: 4 visible (clear)
- brown 100: 2 visible; 2 more seen in s23 are hidden under the hand body.
  Reported 4 (inherited), uncertain — the chip under the fingertip may be one of
  them in transit.

## Opponent inventory (top seat)
- red 5: 2, blue 10: 4, green 50: 4, brown 100: 4. All clearly visible.

## Bets
- My current bet (left of board): 1 blue 10-chip. Clear. A chip under the robot
  fingertip right of the board is in transit and not counted (denomination
  unclear, dark/brown rim).
- Opponent bet (right of board): occluded by the hand. s23 showed 2 red 5-chips;
  reported 5:2 (inherited, uncertain).

## Showdown
Not showdown. Opponent hole cards face-down at the top seat; robot hole cards
face-down at the bottom seat. No fold signature.
