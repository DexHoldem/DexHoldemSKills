# Perception Evidence
- **Table State:** Scene is stable. 
- **Turn:** Robot's turn ("Your Turn" marker present).
- **Community Cards:** Two visible: 7 of Diamonds, 6 of Clubs. 
- **Chips:**
  - My chips: 4x5, 3x10, 3x50, 3x100
  - Opponent chips: 4x5, 4x10, 3x50, 3x100
- **Bets:** None currently on the table.
- **Stage:** Acting.
