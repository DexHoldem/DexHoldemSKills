# Perception merge report

The current frame shows the robot hand extended into the betting lane and touching a chip, so the scene is unstable and `loop_stage` is `acting`. The robot's white turn button and yellow big-blind marker are visible at the bottom seat. Three face-up board cards are present; there is no visible showdown or fold.

Counts were separated by inventory and bet zones. The current capture directly shows the robot's blue 10 bet chip, both players' left-side inventory groups, and most of the top inventory. The rightmost board card, brown chip under the gripper, bottom brown inventory, and opponent bet area are partly occluded. Their concrete estimates use the visible s23 frame and are listed in `uncertain_fields`. Missing workflow/cache files supplied no additional state.
