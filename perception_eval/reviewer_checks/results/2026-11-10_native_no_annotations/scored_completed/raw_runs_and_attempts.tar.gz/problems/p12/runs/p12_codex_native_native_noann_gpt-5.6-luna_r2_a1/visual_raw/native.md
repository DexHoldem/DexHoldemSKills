# Raw visual perception

- Source: `s_current/00_capture.jpg` (`s24/00_capture.jpg` through the symlink).
- Compared with the adjacent prior capture `s23/00_capture.jpg`: the dexterous hand has moved into the lower-right robot hole-card area and is extended over the table. It appears to be in the middle of a card interaction, so the scene is not settled.
- Table geometry: robot/player seat is at the bottom; opponent seat is at the top. The robot/camera assembly partially occludes the lower-right table area.
- Turn: the white `Your Turn` button is visible by the bottom/robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is at the robot/bottom seat.
- Community cards: three face-up cards are visible in the shared center row, left-to-right approximately `7d`, `6s`, and `Jc`. They are board cards; the face-down cards in the hole-card zones are not guessed.
- Robot/player inventory (bottom seat, excluding bet chips): approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The right-side group is partly near the robot/camera occlusion.
- Opponent inventory (top seat, excluding bet chips): approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot current bet area (lower/robot side of board): one blue 10-chip is visible; no red, green, or brown bet chips are visible.
- Opponent current bet area (upper/opponent side of board): two red 5-chips are visible; no blue, green, or brown bet chips are visible. The right side is close to the robot-hand occlusion, so this count is marked uncertain.
- Showdown: no showdown is evident; opponent cards are not face-up and no fold/win/loss outcome is visually established.
