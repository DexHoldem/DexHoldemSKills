# Raw visual perception

Capture: `s_current/00_capture.jpg` (same image as `s24/00_capture.jpg`). Compared with `s23/00_capture.jpg` and `s0/00_capture.jpg` for movement and zone layout.

- **Scene/robot:** Unstable. The dexterous hand has moved from the right-side hover in s23 into the central-right betting lane. Its fingers are down against a chip near the board; it is not near rest and may still be pushing that chip. No held card is visible. The hand and camera body hide part of the right betting lane and rightmost bottom inventory.
- **Turn/blind:** The white `Your Turn` button is at the bottom robot seat. The yellow `BIG BLIND` marker is also at the bottom robot seat. The dealer button is at the top opponent seat. Therefore it is the robot's turn and the robot is big blind.
- **Community cards:** Three face-up board cards, left to right: `7d`, `8s`, `Jc`. The third is partly covered by the robot hand in the current capture; it is readable in s23. Two face-down card backs remain at the left of the five-card board layout and are not counted as community cards.
- **Hole cards/outcome:** The opponent's two hole cards remain face-down in their normal top-seat slots. The robot's two remain face-down at the bottom. No visible fold or showdown.
- **Robot inventory:** Four red 5 chips, three blue 10 chips, four green 50 chips, and an estimated three brown 100 chips. The rightmost brown group is partly hidden by the robot, and one brown chip appears under its fingers near the betting lane.
- **Opponent inventory:** Two red 5 chips, four blue 10 chips, four green 50 chips, and four brown 100 chips at the top seat.
- **Robot bet area:** One blue 10 chip left of the board. A brown 100 chip appears under the robot fingers in the central-right betting lane; count one provisionally because its placement is in progress. No red or green bet chip visible.
- **Opponent bet area:** Two red 5 chips were visible to the right of the face-up board in s23. That area is hidden by the hand/camera in the current image, so two is an inherited best estimate. No other bet chip is visible there.

The action-sequence, hole-card cache, and prior parsed-state context files were absent in this workspace. No poker action or robot action was selected or run.
