# Raw visual perception evidence

Capture inspected: `s_current/00_capture.jpg` (visually identical to `s24/00_capture.jpg`). Stability comparison used `s23/00_capture.jpg` as the immediately preceding frame; `s22/00_capture.jpg` and `s0/00_capture.jpg` were also inspected only to disambiguate durable card/chip layout. The advertised `action_sequence.json`, `hole_card_cache.json`, and previous `01_parsed_state.md` are absent from this workspace.

## Scene and robot

Unstable. Between `s23` and the current/`s24` frame, the dexterous hand moves from a near-idle pose at the right edge to an extended pose over the lower/robot betting lane. A red fingertip is contacting/transporting a brown 100-chip near the lower side of the board. The hand is not at rest, and the chip transfer is not visibly complete. This is an in-progress action rather than a settled failure or recovery state. No dropped card, scattered chip group, pinning, or other human-help condition is visible.

## Table geometry and cards

- Robot/player seat is at the bottom; opponent seat is at the top.
- Three face-up community cards occupy the center row. The unobscured preceding frame reads them left-to-right as `7d`, `9s`, `7c`. In the current frame, `7d` and `9s` remain readable; the gripper partly covers the third card, so `7c` is inherited from the immediately preceding visual frame and marked uncertain.
- Both players' hole cards remain face-down in their normal seat areas. The opponent has not exposed or displaced/mucked both hole cards, so there is no visual showdown or fold outcome.

## Turn and blind markers

- The white `Your Turn` button is clearly at the bottom-left robot seat: it is the robot/player's turn.
- The yellow `BIG BLIND` button is clearly at the bottom robot seat: the robot is the big blind.

## Chips

Colors use red=5, blue=10, green=50, brown=100. Inventory and betting zones are kept separate.

- Robot/player inventory (bottom): 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and an estimated 2 brown 100-chips remaining. The right-side gripper/body partially occludes the green/brown inventory; the immediately preceding frame shows 3 green and 3 brown before one brown chip begins moving into the betting lane.
- Opponent inventory (top): 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot/player current bet (lower/left betting side): 1 blue 10-chip is already placed. The in-transfer brown chip is best localized in the robot betting lane and is counted as 1 brown 100-chip, but this denomination/boundary count is uncertain until the action settles. No red or green bet chip is visible there.
- Opponent current bet (upper/right betting side): 2 red 5-chips; no blue, green, or brown bet chips are visible.

## State judgment

`loop_stage=acting`, `scene_stable=false`, `is_my_turn=true`, `blind=big_blind`, and `showdown_outcome=not_showdown`.
