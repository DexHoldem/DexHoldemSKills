# Native perception — s_current/00_capture.jpg

Frames inspected: s_current, s24 (previous), s23 (last frame with unoccluded right side), s0 (initial layout).
Context files `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` are **not present** in the workspace; no workflow context was available.

## Scene stability / robot behavior
Unstable. Compared s24 and s_current (they look visually identical) plus s23.
The dexterous hand is NOT near rest pose: it is extended over the table at the right end of the
community-card row, with a red fingertip pressed down on a single chip at roughly (1195, 655) px,
just below the 5th board card. This looks like a chip push in progress (betting push). In s23 the hand
was near idle at the right edge. The hand has not settled; the action is treated as still in progress
(acting). s24 and s_current being identical means the hand has not moved between captures — if this
persists it may indicate a stall/stuck pose, but no damage is visible yet: cards and chip groups are not
scattered. Not calling recovery or failure from an unsettled frame.

Occlusion: the hand/arm covers the 5th community card (partly), the opponent bet area to the
upper-right of the board, and the right part of the robot 100-chip group.

## Turn
It is our turn. The white "Your Turn" button is at the bottom-left robot seat area (~450, 805).

## Blind buttons
Dealer (white) and blue SMALL BLIND buttons are at the top/opponent seat; yellow BIG BLIND button is
on the bottom/robot side. Robot = big blind, opponent = dealer/small blind. No conflict.

## Community cards
Five board slots. Slots 1–2 (left) are face-down (unrevealed). Face-up from left to right:
slot 3 = 7d (clear), slot 4 = 6s (clear), slot 5 = partly hidden behind the robot fingers; its visible
corner shows a black "7", and s23 (unoccluded) showed it as 7c. Reading: 7d, 6s, 7c (flop, 3 cards);
slot 5 is uncertain because of occlusion.

## Showdown
Opponent's two hole cards are face-down at the normal top-seat spot (beside the SMALL BLIND/DEALER
buttons). No fold, no face-up cards → not showdown. Robot hole cards face-down in bottom area.

## Robot inventory (bottom seat)
- Red 5: 4 (clear)
- Blue 10: 3 (clear)
- Green 50: 4 (1240,707; 1318,697; 1385,737; 1428,775) — clear
- Brown 100: 2 visible (~1410,683 and ~1450,718 partial); the rest are hidden by the robot arm.
  In s23 there were 4 brown chips. The chip under the fingertip looks brownish/dark, so one 100 may be
  in transit to the bet area → inventory 3 or 4. Best estimate 4 (inherited from s23), uncertain.

## Opponent inventory (top seat)
- Red 5: 2 (s0 had 4)
- Blue 10: 4
- Green 50: 4
- Brown 100: 4
Counts are fairly clear; slight angle.

## Bets
- My bet area, left of the community cards: one blue 10-chip (~430, 647). Clear.
  Additionally one chip is under the robot fingertip at the lower-right of the board (in transit, probably
  a brown 100); not counted as a placed bet yet. Uncertain.
- Opponent bet area, right of the community cards: occluded by the robot hand in this frame. In s23 it
  held two red 5-chips (~1370,553 and ~1400,587). Inherited estimate: 2 × red 5. Uncertain due to occlusion.
