# Native perception — s_current/00_capture.jpg

Context: action_sequence.json, hole_card_cache.json and sN-1/01_parsed_state.md are NOT present in the workspace. Compared against s24, s23, s22, s0 captures.

## Scene stability
Unstable. s_current and s24 are byte-identical (cmp), so the last pair cannot show motion. The dexterous hand is extended over the table (not at rest pose), with a finger pressed down on a dark chip at ~(1195,655) at the lower-right end of the community-card row / betting lane. In s23 the hand was near rest at the right edge, so this frame shows a chip push in progress. The hand occludes the 5th community card and the opponent bet area (right of board). Treat as acting; wait and recapture.

## Robot behavior
The hand is in the middle of a chip push, pinning one chip (appears brown/100) that was moved out of the robot's right inventory group. No cards or buttons appear disturbed, and the visible chip groups are still ordered. Still in progress — no failure/recovery judgment.

## Turn
It is our turn. White "Your Turn" button at bottom-left robot seat (~(450,805)).

## Blinds
Yellow BIG BLIND button at robot seat; DEALER (white) and SMALL BLIND (blue) buttons at opponent seat. Robot = big blind, opponent = dealer/small blind.

## Community cards
Five-slot board lane. Leftmost two slots: face-down (unflipped, not counted). Face-up: 7d (slot 3), 6s (slot 4); slot 5 is mostly occluded by the hand in the current frame and is read as 7c from s23 (same board, hand not covering). Three face-up cards -> flop: 7d 6s 7c. Slot 5 read is uncertain/inherited.

## Robot inventory (bottom)
- red 5: 4 (left group)
- blue 10: 3
- dark/green 50: 4 visible at (1240,707),(1318,697),(1385,738),(1428,775)
- brown 100: 2 visible at (1413,683),(1450,718 partial); s23 showed 4. Two positions are occluded by the arm; one 100 appears to be the chip under the finger in transit. Best estimate 3 remaining. Uncertain.

## Opponent inventory (top)
- red 5: 2 (s0 had 4; 2 now in bet)
- blue 10: 4
- dark 50: 4
- brown 100: 4

## Bets
- My bet (left of board): one blue 10-chip at ~(430,647). One ~100 chip is in transit under the robot finger (not yet in a bet zone) and is not counted.
- Opponent bet (right of board): occluded by the hand. In s22/s23 there were two red 5-chips at ~(1370,553),(1400,585). Inherited 2x5, uncertain.

## Showdown
No face-up opponent hole cards; the opponent's two face-down cards remain in the normal top slot. Not showdown.
