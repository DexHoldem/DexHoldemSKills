# Perception Evidence - s24

## Table Scene
- **Scene Stability**: Unstable. Compared s23/00_capture.jpg and s24/00_capture.jpg. The robot dexterous hand is in motion over the community card area.
- **Loop Stage**: acting. The robot appears to be in the middle of dealing or revealing the 4th community card (the turn).
- **Turn Detection**: It is our turn. The white "Your Turn" button is localized at the robot seat (bottom-left of the table).
- **Blind Assignment**: The robot is the big blind (yellow BIG BLIND button at robot seat). The opponent is the dealer and small blind (white DEALER and blue SMALL BLIND buttons at opponent seat).

## Community Cards
- Three community cards are clearly visible in the central row: **7d**, **6s**, **9d**.
- A 4th card is currently being touched/placed by the robot hand and its value is not yet readable.

## Chip Inventory
- **Robot/player inventory**: 4 red (5), 3 blue (10), 3 green (50), 3 brown (100).
  - Left group: 2 red, 1 blue.
  - Center group (near Big Blind button): 2 red, 2 blue, 1 green, 1 brown.
  - Right group: 2 green, 2 brown.
- **Opponent inventory**: 4 red (5), 4 blue (10), 3 green (50), 3 brown (100).
  - Left group: 2 red, 2 blue.
  - Center group: 1 red, 1 blue, 1 green, 1 brown.
  - Right group: 1 red, 1 blue, 2 green, 2 brown.

## Betting Areas
- **Robot current bet**: No chips visible in the robot's betting lane.
- **Opponent current bet**: 2 red (5) and 1 blue (10) are visible in the opponent's betting lane to the right of the community cards. Total value: 20.

## Showdown
- **Showdown Outcome**: not_showdown. Both players' hole cards are face-down in their respective areas.
