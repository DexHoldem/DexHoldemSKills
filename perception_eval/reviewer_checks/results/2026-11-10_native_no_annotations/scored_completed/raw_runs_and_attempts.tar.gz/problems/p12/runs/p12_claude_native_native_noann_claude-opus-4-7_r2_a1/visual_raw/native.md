# Visual Raw Evidence — s_current

Source: `s_current/00_capture.jpg`

## Buttons / role markers
- **BIG BLIND** (yellow disc) is in front of the robot's seat (bottom side, position "5"). → robot is big blind this hand.
- **DEALER** (white disc) and **SMALL BLIND** (blue disc) sit on the opponent's side (top, position "1"). → opponent is dealer / small blind.
- **"Your Turn"** marker (white disc with handwritten text) is placed in the robot's bet lane. → it is the robot's turn to act; `is_my_turn = true`.

## Loop stage
- Robot hole cards are face-down on the robot's side; the "Your Turn" token is active; opponent hole cards are also face-down; no outcome overlay.
- → `loop_stage = acting`, `showdown_outcome = not_showdown`.

## Scene stability
- The arm is in a parked / overhead posture, no visible motion blur on chips or cards. Table layout is consistent and readable.
- → `scene_stable = true`.

## Community cards
- Five community positions visible in the central strip (between the two "TEXAS HOLD'EM" tabletop prints).
- Reading left→right in the image: three positions appear as blue card-backs (face-down), and two rightmost positions are clearly face-up.
- Face-up cards look like: **7♦** (red pip, diamond suit) and **6♣** (black pip, club suit) — visible at the far-right of the community row.
- Because the typical order of community reveal in this rig can appear mirrored from the robot POV, the face-up subset is read as the flop/turn fragment. The third face-up community card could not be resolved from the main capture, so the full 5-card community listing is uncertain.
- Pot chips (a stack of "10" and "5" chips) sit immediately left of the community row — this is the pot display, not cards.

## Robot chips (stacks in the robot's bank area, bottom-right)
- Several short/medium stacks of 50 (green) and 100 (beige/yellow) chips, and some 10 (blue) and 5 (red) chips mixed in.
- Rough counts (hard to be exact due to arm occluding the right edge):
  - "5": ~4
  - "10": ~3–4
  - "50": ~3
  - "100": ~3

## Opponent chips (top-right, by position "1")
- Mixed stacks of 100 (beige), 50 (green), 10 (blue), with some 5 (red).
- Rough counts:
  - "5": ~4
  - "10": ~3
  - "50": ~3
  - "100": ~3

## Robot current bet (chips in robot's betting lane in front of the hole cards)
- Two short stacks of **10** (blue) chips plus a couple of **5** (red) chips.
- Estimate: `{"5": 2, "10": 2, "50": 0, "100": 0}` ≈ bet value 30 (uncertain; could be only the big-blind post of 10).

## Opponent current bet (chips in opponent betting lane, top side)
- Small stacks of **10** chips and a few **5** chips in the opponent's bet area; smaller than the robot's forward pile.
- Estimate: `{"5": 1, "10": 1, "50": 0, "100": 0}` ≈ bet value 15 (uncertain).

## Hole cards
- Both players' hole cards are face-down. Robot's hole cards cannot be inspected from this image (face-down backs only).

## Uncertainty summary
- Community cards (exact 3rd card and total count uncertain).
- All chip counts are visual estimates from a single frame; occlusion from the robot arm makes the right-hand chip bank harder to count.
