# Raw visual perception

Source: `s_current/00_capture.jpg` (resolves to `s24/00_capture.jpg`). Stability comparison: `s23/00_capture.jpg`.

- Scene/robot: Unstable. Relative to `s23`, the dexterous hand has moved from the right-side near-idle position into the central-right betting lane. In the current frame the fingers are down over/contacting the opponent bet chips beside the third community card. The hand is not at rest, is not visibly holding a card, and appears to be in a chip-push action. No dropped card, scattered inventory, or other clearly unsafe failure is visible. This supports `acting`, not a settled recovery/failure state.
- Turn: It is our turn. The white `Your Turn` button is clearly at the bottom/robot seat.
- Blind: The yellow `BIG BLIND` button is at the bottom/robot seat, so the robot is big blind.
- Community cards: Three face-up shared cards are present, left-to-right `7d`, `9s`, `7c`. The dexterous hand partly covers the rightmost `7c` in the current frame; its exposed corner and the immediately preceding unobstructed frame support the read.
- Showdown: Not showdown. Both opponent hole cards remain face-down in their normal top-seat area; the robot hole cards remain face-down in the bottom-seat area. There is no visible fold/muck or revealed opponent hand.
- Robot/player inventory (bottom seat; excludes bet lane): 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Opponent inventory (top seat; excludes bet lane): 2 red 5-chips, 4 blue 10-chips, 4 green 50-chips, 4 brown 100-chips.
- Robot/player current bet (left/lower side of community row): one blue 10-chip; no red, green, or brown bet chips.
- Opponent current bet (right/upper side of community row): best estimate is two red 5-chips; no blue, green, or brown bet chips. This count is partially occluded by the active robot fingers and is therefore uncertain.
- Important occlusions: the current hand covers part of the rightmost community card and opponent bet area. Inventory zones and the physical turn/blind buttons remain sufficiently visible.
- Context availability: `action_sequence.json`, `hole_card_cache.json`, and a prior `01_parsed_state.md` are absent from the supplied workspace, so no values were inherited from those files.
