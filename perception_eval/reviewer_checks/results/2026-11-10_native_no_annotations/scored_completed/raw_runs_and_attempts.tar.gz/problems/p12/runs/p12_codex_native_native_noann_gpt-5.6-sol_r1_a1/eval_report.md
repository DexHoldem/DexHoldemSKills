# Perception evaluation report

The current capture is an unstable, in-progress robot chip movement. The gripper has left its prior near-idle pose and is contacting/transporting a brown 100-chip into the robot betting lane, so the merged loop stage is `acting`, not `atom_idle` or a recovery/failure state.

Direct current-frame evidence establishes the robot's white turn marker, bottom-seat big-blind marker, first two board cards (`7d`, `9s`), opponent's two-red-chip bet, and most inventory counts. The immediately preceding visual frame supplies the partly occluded third board card (`7c`) and the durable right-side robot inventory layout. The moving brown chip is counted in `my_current_bet` with a corresponding inventory decrement, but both values are flagged uncertain because the transfer has not settled. The partially occluded robot green inventory is also flagged uncertain.

No opponent showdown, muck/fold signature, or revealed hole cards are visible, so the outcome remains `not_showdown`. The requested JSON context/cache and prior parsed-state files were not present; therefore no nonvisual workflow or hole-card data was merged.
