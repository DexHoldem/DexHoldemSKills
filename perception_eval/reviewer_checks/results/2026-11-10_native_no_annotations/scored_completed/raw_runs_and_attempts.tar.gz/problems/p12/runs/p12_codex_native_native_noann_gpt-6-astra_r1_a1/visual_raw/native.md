Unstable. Compared the current capture (s_current points to s24) with s23/00_capture.jpg and s22/00_capture.jpg. The robot hand has moved inward and downward from s23 and now contacts a brown chip below the right part of the board. It is not at rest; chip movement appears still in progress. No readable held card is visible. This is an acting state, with no settled failure or recovery conclusion.

Robot seat is at the bottom and opponent seat at the top. Inventory groups are along the respective rails; bets are in the central lane. Individual flat chip faces were counted, excluding buttons.

The white Your Turn button is clearly at the bottom-left robot seat: it is our turn. The yellow BIG BLIND button is at the robot seat; the DEALER and blue SMALL BLIND buttons are at the opponent seat. Robot is big blind, with no visible conflict.

Three face-up community cards are present, left-to-right: 7d, 6s, 7c. The first two are readable in the current frame. The rightmost card is partly blocked by the hand; 7c is supported by its clear appearance in s23 and unchanged placement. The two card backs to the left are not face-up community cards and are excluded. Both players also retain two face-down cards in their respective hole-card areas. No opponent reveal or clear fold/muck is visible. No showdown comparison is possible or indicated; not_showdown.

Robot inventory: four red 5-chips, three blue 10-chips, four green 50-chips, estimated three brown 100-chips. Only two brown inventory faces are clearly exposed in the current frame; the robot body blocks the rest. In s23 four brown inventory chips are visible. The current brown chip under the fingertip appears to have moved from that group, supporting a remaining count of three, with uncertainty.

Opponent inventory: two red 5-chips, four blue 10-chips, four green 50-chips, four brown 100-chips. All are in the top inventory band.

Robot bet: one blue 10-chip is plainly visible left of the board. One brown 100-chip is under the robot fingertip below the board's right side, outside the inventory band. Best current allocation is to the robot bet, though this chip is still in transit and its zone assignment is uncertain. No red or green robot bet chips are visible.

Opponent bet: estimated two red 5-chips, zero blue, green, or brown chips. The right-side betting area is blocked by the robot in the current image; the two red chips were clearly visible there in s23. This count is carried forward visually, not freshly confirmed through the occlusion.

Missing context: action_sequence.json, hole_card_cache.json, and sN-1/01_parsed_state.md are absent. No parsed-state inheritance or cached hole-card comparison was performed. Earlier captures supply only explicitly noted visual context. No robot action or poker action was selected or executed.
