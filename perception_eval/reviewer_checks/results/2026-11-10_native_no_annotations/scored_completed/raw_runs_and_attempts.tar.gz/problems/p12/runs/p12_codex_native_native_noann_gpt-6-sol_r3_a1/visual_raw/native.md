# Raw visual evidence (s24)

- Compared `s23/00_capture.jpg` with `s24/00_capture.jpg`. The dexterous hand has moved from near the right edge into the central betting lane and is touching or carrying a red chip. The two red chips visible to the right of the board in s23 are no longer in their prior positions. The action is still in progress; the scene is unstable. No settled failure or recovery can be judged.
- The white `Your Turn` button is at the lower-left robot seat. The yellow `BIG BLIND` button is at the lower robot seat; the white dealer button is at the upper opponent seat. Thus the robot is big blind.
- Three face-up community cards are visible in the central row. Left to right, s23 reads approximately `7d`, `8s`, `7c`. In s24 the robot obscures part of the third card, so its read is inherited from the immediately preceding frame.
- The robot hole cards remain face-down near the lower seat. The opponent hole cards remain face-down in their normal upper-seat position. No visible fold or showdown.
- Robot inventory at lower seat: four red 5 chips and three blue 10 chips are clear. The right-hand green/brown groups are partly blocked by the robot body; comparison with s23 suggests four green 50 chips and three brown 100 chips.
- Opponent inventory at upper seat: two red 5 chips, four blue 10 chips, approximately four green 50 chips, and four brown 100 chips. The green/brown groups are angled, so their counts are approximate.
- One red 5 chip is visible under the gripper in the lower/robot-side betting lane, estimated as the robot current bet. No other bet chip is clearly visible. The hand obscures part of the right/opponent betting area, so both bet assignments/counts are uncertain during transfer.
