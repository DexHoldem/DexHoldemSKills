# Native visual perception

## Source and comparison

- Current image used: `s24/00_capture.jpg` (the requested `s_current/00_capture.jpg` is absent).
- Stability comparison: `s23/00_capture.jpg` versus `s24/00_capture.jpg`.
- No `action_sequence.json`, `hole_card_cache.json`, or `sN-1/01_parsed_state.md` is present in the workspace.

## Evidence

- The robot dexterous hand/arm is extended over the right side of the table and occludes part of the board/right betting and inventory zones. The pose differs from the more retracted pose in s23, so the latest scene is treated as unstable/acting.
- The white `Your Turn` button is visible at the bottom/robot seat. It indicates that it is the robot's turn.
- A yellow `BIG BLIND` button is at the bottom/robot side, so the robot is the big blind.
- Three face-up community cards are visible left-to-right: approximately `7d`, `6s`, and `2c`; the rightmost card is partly occluded and lower confidence.
- The two robot hole cards and two opponent hole cards remain face-down; no showdown is visible.
- Robot inventory, bottom seat: approximately four red 5-chips, three blue 10-chips, three green 50-chips, and three brown 100-chips. The right-side groups are partly near the apparatus but countable only approximately.
- Opponent inventory, top seat: approximately four red 5-chips, four blue 10-chips, three green 50-chips, and three brown 100-chips.
- Robot current-bet zone, lower side of the community-card row: one blue 10-chip is visible.
- Opponent current-bet zone, upper/right side of the community-card row: approximately two red 5-chips are visible/inferred from the immediately preceding frame, but the current right-side view is occluded by the robot apparatus.

## Field judgments

- Scene stable: false.
- Loop stage: `acting`.
- Showdown outcome: `not_showdown`.
- Uncertainty: scene stability, the third community-card read, opponent current-bet count, and the partly occluded inventory-side counts.
