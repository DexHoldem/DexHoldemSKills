# Raw visual perception — s28

- Geometry: robot/player seat is at the bottom; opponent seat is at the top; the shared board is the central face-up row. Inventory and betting zones were kept separate.
- Stability: **Stable** in the current capture. Compared `s27/00_capture.jpg` with `s28/00_capture.jpg`. The robot was extended across the table in s27, but in s28 it is sharply imaged and retracted to a settled near-idle pose. No card or chip is visibly in motion. The opponent is not interfering with the table.
- Robot behavior: the dexterous hand is above the upper-right portion of the table in a near-idle pose. It is not visibly holding a card or chips, is not pinning an object, and does not appear stuck. It causes some upper-right occlusion but the relevant chip groups remain substantially visible. The settled layout appears safe.
- Turn: it is the robot/player's turn. The white `Your Turn` button is at the bottom-left robot seat.
- Blind: the yellow `BIG BLIND` button is at the bottom robot seat. The dealer button is at the opponent/top seat, consistent with the robot being big blind.
- Community cards: four face-up shared cards are visible, left-to-right: `8h`, `7d`, `6s`, `7c`.
- Robot/player inventory (bottom seat), by denomination: red 5 = 4, blue 10 = 3, green 50 = 3, brown 100 = 3.
- Opponent inventory (top seat), by denomination: red 5 = 2, blue 10 = 4, green 50 = 3, brown 100 = 3. The blue count is the least certain because the chips overlap visually at the oblique angle.
- Robot/player current bet (left of the board): red 5 = 1, blue 10 = 1, green 50 = 1, brown 100 = 1.
- Opponent current bet (right of the board): red 5 = 2, blue 10 = 0, green 50 = 1, brown 100 = 1.
- Showdown: not at showdown. Both robot hole cards and both opponent hole cards remain face-down in their normal seat areas; there is no fold/muck signature and no revealed opponent hand.
- Current loop-stage visual judgment: `idle`; the scene is settled, it is the robot's turn, and no ongoing physical atom is visible. The prior workflow JSON and previous parsed-state Markdown referenced by the task were absent, so no dispatched atom could be inherited from those files.

