# Perception evaluation

The current frame shows a stable, pre-showdown turn state. The robot-side
`Your Turn` marker and bottom-side `BIG BLIND` marker establish turn ownership
and blind assignment. Four face-up community cards are visible; both players'
hole cards remain face-down. No chips are visibly placed in either betting area.

Inventory counts are estimated from the unfolded denomination groups. The
robot arm/body partially occludes the right side, so the higher-denomination
inventory groups and opponent-side bet area are lower-confidence. No prior
parsed-state or JSON context files were present to merge; the output therefore
uses current-frame evidence only.
