# Raw perception evidence

Source: `s_current/00_capture.jpg` (`s28/00_capture.jpg`). The prior frame available in the workspace is `s27/00_capture.jpg`.

- Table orientation: robot/player is the bottom side; opponent is the top side.
- Robot hand/arm: extended from the right over the upper-right table area. It is not in a settled rest pose and is not visibly holding a readable card or chips. This is consistent with an in-progress/unstable robot state.
- Turn marker: the white `Your Turn` button is visible at the lower-left robot seat area, so it is the robot's turn.
- Blind marker: the yellow `BIG BLIND` button is at the lower robot side. The blue dealer/small-blind marker is on the opponent side, so the robot is big blind.
- Community cards: four face-up cards are visible left-to-right: `8h`, `7d`, `6s`, `Jc` (the fourth rank/suit is somewhat small but appears to be jack of clubs). The face-down cards are not included as community cards.
- Robot inventory estimate: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Opponent inventory estimate: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Current betting areas: no cleanly separable full bet stacks are visible. The robot-side and opponent-side chip regions are partly affected by perspective/robot-arm occlusion; best estimate is zero countable chips on each betting area, with those bet fields marked uncertain.
- Showdown: no face-up opponent hole cards or fold/muck signature is visible; this is not a showdown.
- Stability: unstable because the robot arm is extended over the table and not visibly settled. The current image is therefore classified as `acting`.
