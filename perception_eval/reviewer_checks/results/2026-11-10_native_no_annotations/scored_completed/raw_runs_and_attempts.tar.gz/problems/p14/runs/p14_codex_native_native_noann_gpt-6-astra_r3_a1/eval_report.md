# Perception evidence and merging

Current evidence is s28, reached through `s_current`. Applied the field-specific visual guidelines and compared s26/s27 for robot stability. The board reads 8h, 7d, 6s, 7c; the face-down board-lane card is excluded. The robot has the turn marker and big-blind button. Both players retain face-down hole cards in their seat areas, so no showdown or fold is identified.

Inventory and bet counts come from individual visible chip faces in separate zones. In denomination order 5/10/50/100: robot inventory 4/3/3/3, opponent inventory 2/4/3/3, robot bet 0/1/1/1, opponent bet 2/0/1/1.

The hand has lifted away from the betting area toward rest, but substantial pose changes across the latest frames prevent confirming a settled endpoint. Conservatively estimated `acting` and `scene_stable=false`; both are marked uncertain. No failure or recovery is declared from the changing scene.

The named workflow JSON, hole-card cache, and prior parsed-state file are unavailable. Nothing was inherited or merged from workflow context; all concrete estimates use visual evidence. No robot actions, helper scripts, or poker choices were executed.
