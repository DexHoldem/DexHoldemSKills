# Raw visual perception

- Source: `s_current/00_capture.jpg` (`s_current` resolves to `s28`).
- Table orientation: robot/player is at the bottom; opponent is at the top.
- Scene: the table is readable and the robot arm/hand is settled at the upper-right edge, partially occluding the opponent-side/right betting and inventory region. No card or chip is visibly held by the hand.
- Turn: the white `Your Turn` button is visible at the bottom robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is on the bottom robot side; robot is big blind.
- Community cards: four face-up cards are visible left-to-right, appearing to be `8h`, `7d`, `6s`, and `Jc`. No fifth board card is visible.
- Robot hole cards: two cards remain face-down in the bottom hole-card area; no readable held card is visible.
- Opponent hole cards: face-down cards remain in the top hole-card area; no fold/muck or face-up showdown is visible.
- Robot inventory, bottom seat: approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The higher-denomination group is partly occluded by the robot body/arm.
- Opponent inventory, top seat: approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The right-side group is partly occluded by the robot hand/body.
- Current betting areas: no clearly placed bet chips are visible on either side of the community-card row.
- Showdown: not present; opponent cards are not face-up and no uncontested fold is evident.

