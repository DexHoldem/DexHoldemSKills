# Perception and merging

Read the current s28 capture and all visual_guidelines files; compared s27 and s26 for hand movement. Current visible evidence supplies every table estimate. Robot is big blind and the bottom-left white marker indicates its turn. The face-up board is 8h 7d 6s 7c; the remaining face-down board-lane card is excluded. No showdown or fold is visible.

Inventory and bet zones were counted separately by individual chip faces. Opponent bet counts reflect visible chips, with uncertainty because the robot assembly obscures farther-right table space.

The hand retracts substantially between the recent frames, with no subsequent frame confirming rest. Conservative estimates are acting and scene_stable=false; both are flagged as uncertain. No failed-atom or recovery conclusion is supported.

The supplied context filenames are absent, including the previous parsed state; therefore no prior workflow label, cached hole card, or durable field was merged. All schema fields contain concrete estimates. No robot actions, helper scripts, or poker decisions were executed.
