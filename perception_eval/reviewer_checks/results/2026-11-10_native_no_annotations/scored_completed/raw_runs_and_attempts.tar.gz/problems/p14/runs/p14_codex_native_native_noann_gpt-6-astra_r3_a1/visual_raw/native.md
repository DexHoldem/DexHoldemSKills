# Native visual evidence

Inspected `s_current/00_capture.jpg` (symlink to `s28/00_capture.jpg`) directly, plus `s27/00_capture.jpg` and `s26/00_capture.jpg` for temporal comparison. Read all field guidelines in `visual_guidelines/`.

Unstable, conservatively: across s26, s27, and s28 the robot moves from the right-side chip area, across the left betting area, then upward/right away from the felt. In s28 the hand is empty and raised toward a near-idle pose, but the last two frames show substantial continued pose change rather than a confirmed stationary endpoint. A board card that was face-down in s26 is now face-up. Completion cannot be confirmed from these frames alone. `scene_stable=false` and `loop_stage=acting` are inferred, uncertain estimates. No settled failure or recovery judgment is supported.

The robot hand enters from the right. No card or chips are visibly held in s28, and it is not visibly pinning an object. The large housing blocks the far-right table margin, but the visible chip groups remain separable. No readable held card is present. The human's arms are away from the active table surface.

It is our turn: the white “Your Turn” button is in the bottom-left robot seat area.

The yellow “BIG BLIND” button is at the bottom robot seat. The white dealer and blue small-blind buttons are at the top opponent seat. Robot is big blind; no button conflict is visible.

Four face-up community cards are readable left-to-right: 8h, 7d, 6s, 7c. A separate face-down card lies immediately left of 8h; its value is not guessed and it is excluded from the face-up board array. The deck at the far left is also excluded.

Robot inventory at the lower rail: four red 5 chips, three blue 10 chips, three green 50 chips, three brown 100 chips. Each is a distinct flat chip face.

Opponent inventory at the upper rail: two red 5 chips, four blue 10 chips, three green 50 chips, three brown 100 chips. The blue small-blind marker is not counted as a chip.

Robot current bet, left of the board: zero red 5 chips, one blue 10 chip, one green 50 chip, one brown 100 chip.

Opponent bet, right of the board: two red 5 chips, zero blue 10 chips, one green 50 chip, one brown 100 chip. These are separate from the inventory groups at the rails.

Both players' two hole cards remain face-down in their normal seat areas. The opponent's two cards have not been moved into the board lane. There is no visible fold or showdown; outcome is `not_showdown`. No hidden card values or hand comparison are inferred.

The requested `action_sequence.json`, `hole_card_cache.json`, and previous parsed state are absent from the workspace file listing; `s27` contains only its capture. No durable field was inherited. No robot action, helper script, or poker decision was performed.
