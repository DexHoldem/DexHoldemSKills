# Perception report

The capture shows a settled-looking turn board with four face-up community cards (`8h 7d 6s Jc`), the white turn button at the robot seat, and the yellow big-blind button at the robot seat. Inventory and current-bet chips were counted in their separate visible zones. Both players' hole cards remain face-down, so the outcome is `not_showdown`.

The image was compared with `s27/00_capture.jpg`, where the robot was over the table. The current gripper is withdrawn and the layout is visible. `action_sequence.json`, `hole_card_cache.json`, and the previous `01_parsed_state.md` were unavailable; no values were inherited from them. `loop_stage` is estimated as `idle`, and stability is inferred from the present pose rather than confirmed by a later independent frame. Both are marked uncertain.
