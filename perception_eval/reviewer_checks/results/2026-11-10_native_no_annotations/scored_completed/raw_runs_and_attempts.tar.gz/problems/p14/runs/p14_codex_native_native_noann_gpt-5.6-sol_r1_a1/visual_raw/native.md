# Raw visual perception

Capture inspected: `s_current/00_capture.jpg` (same image as `s28/00_capture.jpg`). For stability, it was compared with `s27/00_capture.jpg`; earlier settled frames were also inspected only as visual context.

- Scene and robot: The current image is sharp. The dexterous hand is at the upper-right in a settled near-idle pose, with no card or chip held. It is not pressing into or visibly disturbing any table object. In `s27` the arm was extended over the table; in the current frame it has withdrawn and settled. The table layout is countable, so the current scene is stable. The hand/camera body occludes part of the far-right background but not the board or the chip groups used below.
- Workflow stage evidence: The frame looks like a settled post-atom state, so `atom_idle` is the best visual estimate. `action_sequence.json` and a previous `01_parsed_state.md` are absent from the supplied workspace, so the exact dispatched-atom status cannot be confirmed from workflow context.
- Turn: The white `Your Turn` button is plainly visible at the bottom-left robot/player seat. It is the robot's turn.
- Blind: The yellow `BIG BLIND` button is at the bottom robot/player seat. The robot is big blind.
- Community cards: Four face-up shared cards are visible. In left-to-right image order they read `8h`, `7d`, `6s`, `7c`. One additional face-down card lies to their left and is not counted or guessed as a face-up community card.
- Hole cards/showdown: The opponent's two hole cards remain face-down in their normal top-seat area. The robot's two hole cards remain face-down in their normal bottom-seat area. There is no visible fold/muck or face-up showdown, so the outcome is `not_showdown`. No readable held card is visible.
- Robot/player inventory, bottom seat: red 5-chips = 4; blue 10-chips = 3; green 50-chips = 3; brown 100-chips = 3.
- Opponent inventory, top seat: red 5-chips = 2; blue 10-chips = 4; green 50-chips = 3; brown 100-chips = 4.
- Robot/player current bet, left of the community-card row: red 5-chips = 0; blue 10-chips = 1; green 50-chips = 1; brown 100-chips = 1.
- Opponent current bet, right of the community-card row: red 5-chips = 2; blue 10-chips = 0; green 50-chips = 1; brown 100-chips = 1.

Low-confidence item: `loop_stage` is inferred from the settled post-action appearance because prior workflow-state files are unavailable. The visually counted card, marker, inventory, and bet fields are not inherited.
