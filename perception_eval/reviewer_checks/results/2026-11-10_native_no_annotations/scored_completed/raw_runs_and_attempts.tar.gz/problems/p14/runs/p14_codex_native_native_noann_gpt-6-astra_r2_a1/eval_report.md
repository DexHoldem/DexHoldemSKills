Perception used s_current/00_capture.jpg, resolving to s28, with s27 and s26 for motion comparison, following the field-specific visual guidelines.

Visible evidence establishes robot big blind, robot turn, four face-up board cards (8h 7d 6s 7c), separate inventory and bet counts, and no showdown. The face-down board-slot card is excluded rather than assigned an invented value. Both players retain face-down hole cards in their seat areas.

The robot has substantially retracted since s27, and a board card has changed from face-down to face-up. The current elevated pose may be approaching rest, but settled completion is not confirmed. The concrete estimates are acting and scene_stable=false, with both fields explicitly marked uncertain. No failure or recovery is asserted.

The requested prior action sequence, hole-card cache, and previous parsed-state files are not present. Consequently, there was no prior-state merge or durable-field inheritance; current visible evidence supplied all other values. No helper scripts, robot actions, or poker-action selection were used.
