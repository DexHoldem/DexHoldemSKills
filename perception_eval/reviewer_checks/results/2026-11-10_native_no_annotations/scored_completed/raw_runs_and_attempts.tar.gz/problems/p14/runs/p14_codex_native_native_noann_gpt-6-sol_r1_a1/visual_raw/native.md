# Raw visual perception

Capture: `s_current/00_capture.jpg` (`s28`). Compared with `s27/00_capture.jpg` and `s26/00_capture.jpg` for motion.

- The robot seat is at the bottom; the opponent seat is at the top. The white “Your Turn” marker is at the bottom-left robot seat. The yellow “BIG BLIND” marker is at the robot seat. The white dealer marker is at the opponent seat.
- Four face-up community cards are visible, left to right: 8h, 7d, 9s, Jc. Two robot hole cards and two opponent hole cards remain face-down in their seat areas. No fold or showdown is visible.
- Robot inventory at the bottom: four red 5 chips, three blue 10 chips, three green 50 chips, three brown 100 chips.
- Opponent inventory at the top: two red 5 chips, four blue 10 chips, three green 50 chips, three brown 100 chips.
- Robot bet area to the left of the board: one blue 10 chip, one green 50 chip, one brown 100 chip; no red chip. Opponent bet area to the right of the board: two red 5 chips, one green 50 chip, one brown 100 chip; no blue chip.
- The robot hand is extended over the right/top table area and does not visibly hold a card or chip. It moved substantially from the left-side position in s27, while s26 shows it at a different right-side position. The action appears in progress. The current scene is unstable; the image alone does not establish a settled post-action pose or a physical failure.
- The referenced `action_sequence.json`, `hole_card_cache.json`, and `s27/01_parsed_state.md` are absent in this workspace. No fields were inherited from them.
