# Raw visual perception

- Capture inspected: `s_current/00_capture.jpg` (the symlink resolves to `s28/00_capture.jpg`).
- Scene appears stable: cards and chips are laid out, the dexterous hand is empty and settled at the upper-right edge, and no object transfer is visible.
- The white `Your Turn` button is at the bottom/robot seat, so it is the robot's turn.
- The yellow `BIG BLIND` button is beside the bottom/robot seat.
- Four face-up community cards are visible left-to-right: `8h`, `7d`, `6s`, `4c`.
- Robot hole cards remain face-down; opponent hole cards remain face-down. No readable held card and no showdown evidence are visible.
- Robot/player inventory estimate: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Opponent inventory estimate: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- No chips are visibly committed in either current-bet area; both current bets are estimated as zero.
- No field required inheritance from prior parsed state; the referenced context JSON/previous parsed-state files were not present in the workspace.
