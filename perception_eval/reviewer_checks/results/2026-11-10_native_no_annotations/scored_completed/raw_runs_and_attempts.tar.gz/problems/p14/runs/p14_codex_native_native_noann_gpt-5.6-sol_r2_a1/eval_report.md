# Perception evaluation

The current capture shows a clear, settled post-action table. The robot hand is near idle and empty; the board reads `8h 7d 6s 7c`; the white turn button and yellow big-blind button are both at the robot seat. The two betting zones contain equal-value but differently denominated contributions: robot 10+50+100 and opponent 5+5+50+100. Hole cards remain face-down in their normal locations, so this is not showdown.

For stability, the current capture was compared with `s27` and `s26`. Those frames show preceding arm movement over the board, while the current frame shows the hand withdrawn, sharp, and no longer manipulating objects. This supports `scene_stable: true` and a settled post-atom estimate of `atom_idle`.

No merge inputs were available: `action_sequence.json`, `hole_card_cache.json`, and a prior `01_parsed_state.md` are absent. Consequently, all table fields come from current visual evidence. `loop_stage` is listed in `uncertain_fields` because distinguishing `atom_idle` from workflow-level `idle` normally requires the missing action-sequence status.
