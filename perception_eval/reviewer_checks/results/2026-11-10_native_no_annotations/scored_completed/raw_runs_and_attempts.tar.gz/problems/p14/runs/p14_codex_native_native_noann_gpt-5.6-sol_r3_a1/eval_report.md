# Perception evaluation

The current `s28` capture was evaluated against `s27` for scene stability. The robot has retracted from the extended s27 pose and is sharply imaged in a settled near-idle pose in s28, with no visible card or chip motion, so the current scene is stable. The white turn marker and yellow big-blind button are both visually localized at the bottom robot seat.

Four board cards are directly readable as `8h 7d 6s 7c`. Both players' hole cards remain face-down in their normal areas, so this is not showdown. Inventory chips and the two betting zones were counted independently by color/denomination. The opponent's overlapping blue inventory group is the only low-confidence count and is listed in `uncertain_fields`; all fields still contain concrete best estimates as required.

No prior-state merge was possible because `action_sequence.json`, `hole_card_cache.json`, and the previous `01_parsed_state.md` were not present in the workspace. Consequently, durable fields were resolved from direct visual evidence, and `loop_stage` is set to `idle` from the settled current pose plus the robot-side turn marker rather than from workflow inheritance.
