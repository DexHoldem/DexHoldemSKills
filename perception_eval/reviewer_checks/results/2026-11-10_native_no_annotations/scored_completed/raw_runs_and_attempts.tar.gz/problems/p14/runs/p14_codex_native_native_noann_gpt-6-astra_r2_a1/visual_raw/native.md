Unstable. Compared current s_current/00_capture.jpg (s28) with s27/00_capture.jpg and s26/00_capture.jpg. The robot hand moves from low over the right-side chips in s26 to the left betting area in s27, then retracts high to the right in s28. A central card that was face-down is now face-up. A settled end of the movement is not confirmed by these frames; scene_stable=false and loop_stage=acting are conservative, uncertain estimates.

The current robot hand is elevated at the upper-right, open, with no visible held card or chips. It does not appear stuck or pinning an object. The large housing obscures the far-right table edge, but the visible bet groups are countable. No settled failure or recovery is established.

It is our turn. The white Your Turn button is at the bottom-left robot seat.

The robot has the yellow BIG BLIND button at the bottom seat. The opponent has the white DEALER and blue SMALL BLIND buttons at the top seat. No button conflict is visible.

Four face-up community cards are visible, left to right: 8h, 7d, 6s, 7c. A separate face-down card occupies the board slot immediately to their left; its value is not readable and it is excluded from the face-up community-card list. The far-left deck is also excluded.

Robot inventory, bottom seat: four red 5-chips, three blue 10-chips, three green 50-chips, three brown 100-chips.

Opponent inventory, top seat: two red 5-chips, four blue 10-chips, three green 50-chips, three brown 100-chips.

Robot current bet, left of the board: no red 5-chips, one blue 10-chip, one green 50-chip, one brown 100-chip.

Opponent bet, right of the board: two red 5-chips, no blue 10-chips, one green 50-chip, one brown 100-chip. Buttons and inventory chips are excluded from both bet counts.

Both players' two hole cards remain face-down in their respective seat areas. No readable held card, revealed opponent hand, or clear fold/muck is visible. Showdown outcome is not_showdown; no hand comparison is possible or needed.

The named action_sequence.json, hole_card_cache.json, and previous 01_parsed_state.md are absent from the available workspace. No durable field was inherited and no hidden card value was inferred. Workflow stage and scene stability are marked uncertain because the latest pose could be the end of the return motion, but there is no subsequent settled frame or workflow context to confirm that.
