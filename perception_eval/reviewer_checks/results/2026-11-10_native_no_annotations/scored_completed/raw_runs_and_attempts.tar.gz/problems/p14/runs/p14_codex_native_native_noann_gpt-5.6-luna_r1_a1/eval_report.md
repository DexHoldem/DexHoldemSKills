# Evaluation report

The current capture was read directly from `s_current/00_capture.jpg` (the `s28` image). No robot action, helper script, or poker decision was executed.

The visual merge uses the current image for turn, blind, board, chip inventories, and showdown status. The robot hand is extended and not settled, so the scene is marked unstable and the loop stage is `acting`. Four board cards are reported, with the fourth card noted as lower-confidence. Inventory and bet regions are perspective/occlusion-sensitive; the best concrete chip estimates are emitted in `visual_summary.json`, and the bet counts are explicitly marked uncertain.

The requested output files were written under this run directory.
