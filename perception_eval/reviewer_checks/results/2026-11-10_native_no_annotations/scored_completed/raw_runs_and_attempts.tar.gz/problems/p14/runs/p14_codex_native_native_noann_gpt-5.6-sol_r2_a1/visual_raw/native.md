# Raw visual perception

- Capture inspected: `s_current/00_capture.jpg` (`s28/00_capture.jpg`). For scene stability only, the robot pose was compared with `s27/00_capture.jpg` and `s26/00_capture.jpg` as directed by the stability guideline.
- Geometry: robot/player seat is at the bottom; opponent seat is at the top; the shared board runs across the center.
- Scene/robot: the current image is sharp. The dexterous hand is parked at the upper-right in a near-idle pose, with open fingers and no card or chip held. It is not contacting or pinning a table object. The preceding frames show the arm moving over the board; in the current frame it has withdrawn and the card/chip layout is orderly. The scene is judged stable and safe to parse. The hand/camera assembly occludes part of the far upper-right background but does not prevent reading the relevant card or chip zones.
- Loop-stage evidence: the visual sequence is most consistent with a completed atom followed by a settled near-idle pose, so the concrete estimate is `atom_idle`. This is uncertain because `action_sequence.json` is absent and workflow status cannot be merged.
- Turn: the white `Your Turn` button is clearly at the bottom-left robot/player seat, so it is the robot/player's turn.
- Blind: the yellow `BIG BLIND` button is clearly at the bottom robot/player seat. The white dealer button is at the top opponent seat, consistent with heads-up blind assignment. Robot blind is `big_blind`.
- Community cards: four face-up shared cards are visible, left-to-right: `8h`, `7d`, `6s`, `7c`. The separate face-down card immediately left of the board is not counted as a community card.
- Robot/player inventory (bottom): 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top): 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Robot/player current bet (left of the community-card row): no red 5-chip, 1 blue 10-chip, 1 green 50-chip, and 1 brown 100-chip.
- Opponent current bet (right of the community-card row): 2 red 5-chips, no blue 10-chip, 1 green 50-chip, and 1 brown 100-chip.
- Showdown: both players' hole cards remain face-down in their normal seat areas. The opponent's cards are not face-up and are not displaced into the community lane as a fold/muck signature. There is no showdown or decided outcome: `not_showdown`.
- Missing context: no `action_sequence.json`, `hole_card_cache.json`, or prior `01_parsed_state.md` exists in this workspace, so no durable fields were inherited and no cached hole cards were available.
