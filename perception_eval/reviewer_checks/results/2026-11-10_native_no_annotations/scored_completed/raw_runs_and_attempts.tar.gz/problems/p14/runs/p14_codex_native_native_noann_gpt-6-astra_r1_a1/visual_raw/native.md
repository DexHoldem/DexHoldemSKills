# Native perception evidence

Capture: `s_current/00_capture.jpg`, resolving to `s28/00_capture.jpg`. Compared with `s27/00_capture.jpg` and `s26/00_capture.jpg` using the field-specific visual guidelines.

Unstable, conservatively estimated. Across s26, s27, and s28 the robot hand moves from the lower-right chip region to the left betting area and then lifts/retracts toward the upper right. The latest hand is empty and elevated, approaching a rest pose, but these frames do not confirm that it has stopped. The green chip has reached the left betting area. No human hand is blocking or manipulating the table in the current capture. Scene stability and loop stage remain uncertain; best estimates are false and acting. No failure or recovery judgment is made while completion remains unconfirmed.

It is our turn. The white Your Turn marker is clearly at the bottom-left robot seat.

The yellow BIG BLIND button is at the bottom robot seat. The white DEALER and blue SMALL BLIND buttons are at the top opponent seat. Robot is big blind; opponent is dealer/small blind. No conflict is visible.

Four face-up community cards are readable from left to right: 8h, 7d, 6s, 7c. A separate face-down card lies to their left in the board lane; its value is not visible and it is excluded from the face-up community-card list. Both opponent hole cards remain face-down in their normal top-seat positions; both robot hole cards remain face-down at the bottom. The central face-down card is not evidence of an opponent fold. No readable held card is visible.

Robot inventory at the bottom: four red 5 chips, three blue 10 chips, three green 50 chips, three brown 100 chips. These are individual flat chip faces, separate from the betting area.

Opponent inventory at the top: two red 5 chips, four blue 10 chips, three green 50 chips, three brown 100 chips. The four blue chips include three along the left grouping and one offset toward the dealer button.

Robot bet to the left of the board: zero red 5 chips, one blue 10 chip, one green 50 chip, one brown 100 chip.

Opponent bet to the right of the board: two red 5 chips, zero blue 10 chips, one green 50 chip, one brown 100 chip. The robot assembly covers farther-right table space, so the visible count is the best estimate and opponent_bet is flagged for possible occlusion.

No showdown is visible: neither player's hole cards are exposed and no fold/muck signature is present. Outcome estimate: not_showdown. No poker action is selected.

The named action_sequence.json, hole_card_cache.json, and previous 01_parsed_state.md were not found in the workspace. The sN-1 alias is absent; s27 is the actual preceding image. No durable fields or cached card identities were inherited. Loop stage is inferred from visual motion alone.
