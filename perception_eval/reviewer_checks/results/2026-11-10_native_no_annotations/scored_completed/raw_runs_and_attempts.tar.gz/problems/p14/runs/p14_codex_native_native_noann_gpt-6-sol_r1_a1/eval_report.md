# Perception report

The current capture shows the robot's white turn marker, its big-blind marker, four face-up board cards (8h, 7d, 9s, Jc), distinct inventory and betting chips, and face-down hole cards with no showdown. The robot arm changed position substantially between s27 and s28, so the scene is unstable and the loop stage is `acting`.

All structured fields come from the current image, with adjacent images used only to assess robot motion. The referenced prior workflow, hole-card cache, and previous parsed state files were unavailable; no state was inherited. No robot or poker action was selected.
