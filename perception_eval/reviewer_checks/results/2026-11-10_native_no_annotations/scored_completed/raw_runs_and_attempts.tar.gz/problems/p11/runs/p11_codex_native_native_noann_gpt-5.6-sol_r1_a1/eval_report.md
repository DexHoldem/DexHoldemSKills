# Perception evaluation

The current frame is stable: it is byte-identical to `s22/00_capture.jpg`, and the dexterous hand is settled without visible object motion. The bottom `Your Turn` button establishes `is_my_turn=true`; the bottom `BIG BLIND` button establishes `blind=big_blind`. No face-up community or hole cards are present, so the board is empty and `showdown_outcome=not_showdown`.

Chip counts were kept separate by inventory and betting zones. The robot inventory is clearly readable. The opponent's green/brown inventory and extreme-right red 5-chip bet are partly occluded by the near-idle robot/camera assembly, so concrete best estimates were emitted and those fields were marked uncertain.

No prior workflow/cache/parsed-state context files were available to merge. Consequently, `loop_stage=idle` is a visual inference from the stable, settled, ready-to-act scene and is also marked uncertain. No poker action or robot action was selected or executed.
