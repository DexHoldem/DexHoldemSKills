# Perception and merge report

Current capture is s23. Compared it with s22 for stability, s21 for recent robot movement, and s0 for initially visible inventories. The latest two frames support a stable, near-idle robot after a chip movement; atom_idle is an inferred workflow label because dispatch context is unavailable.

Direct current evidence establishes robot big blind, robot turn, no face-up board, no showdown, four robot red chips, three robot blue chips, four robot green chips, three opponent red chips, four opponent blue chips, and one blue robot bet chip. A red opponent bet chip is partly visible.

Missing action_sequence.json, hole_card_cache.json, and previous parsed-state markdown precluded a context-file merge. Four robot brown chips and four each of opponent green/brown chips are continuity estimates supported by s0 and partially visible current groups. The occluded opponent bet is estimated as one red chip and zero other denominations. These inventory/bet fields and loop_stage are marked uncertain. No hidden card values were invented.

Outputs use the requested schema with concrete values. No helper scripts, robot commands, or poker actions were executed or selected.
