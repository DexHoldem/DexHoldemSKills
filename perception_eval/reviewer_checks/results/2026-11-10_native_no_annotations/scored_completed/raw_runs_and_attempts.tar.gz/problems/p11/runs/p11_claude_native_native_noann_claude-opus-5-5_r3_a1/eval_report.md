# Eval report — s23

- Missing context: action_sequence.json, hole_card_cache.json and sN-1/01_parsed_state.md were absent, so nothing was inherited. All values come from the s23 image, with s22 used for stability and s0 for the baseline layout.
- Stability: s22 and s23 are identical, so the scene is stable. The hand is settled but not at the true init pose. It occludes the opponent's green/brown inventory and the right end of the board lane, so `loop_stage` is idle. Suggest `reset_to_init` to get a clean view.
- Turn: the "Your Turn" button is at the robot seat, so is_my_turn = true.
- Blind: BIG BLIND is at the robot seat and DEALER/SB at the opponent seat, so the robot is big_blind.
- Board: 5 card backs and 0 face-up cards, so preflop with community_cards = [].
- Chips: s0 had 4/4/4/4 per side. The robot has 1 blue fewer and 1 blue sits in its bet area (10). The opponent has 1 red fewer and 1 red is partly visible in its bet area (5). Blind posting (SB 5 / BB 10) is consistent with this.
- Uncertain: the opponent's green/brown inventory and bet (occluded by the hand or robot body), the robot's 4th brown (under the arm edge), and loop_stage (hand pose not at true init).
