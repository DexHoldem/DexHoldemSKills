# Visual Perception Raw Output — Native

**Image**: `s_current/00_capture.jpg` (s23)

## Scene Stability

Stable. Compared s22/00_capture.jpg and s23/00_capture.jpg. The images appear identical: the robot hand is in a settled near-idle pose on the right side of the table, no visible card or chip movement between frames, and no human interference with the table layout.

## Table Geometry And Orientation

Using TABLE_GEOMETRY.md reference:
- Robot/player seat: bottom of image
- Opponent seat: top of image
- Community cards area: central row across the middle (showing card backs in slots)
- Community-card row spans approximately (25-70%, 52-66%)

## Turn Indicator

**Turn Detection**: It is our turn. A white button labeled "Your Jog" (possibly "Your Turn") is clearly visible at the bottom-left robot/player seat area, confirming the robot has the turn indicator.

## Blind And Dealer Button

**Blind Assignment**: Looking at the table markings:
- A yellow "BIG BLIND" button is visible in the center-right area of the table
- The "Your Jog" / turn button is at the robot/player seat (bottom)

In two-player heads-up: the player with the turn marker/button is the dealer and small blind. The opponent is the big blind.

**Interpretation**: Dealer/small blind is at the robot seat. The opponent is the big blind.

## Community Cards

**Community Card Count and Visibility**: No face-up community cards are visible. The shared board area shows card-back slots (striped pattern), indicating no community cards have been dealt or the cards are still face-down in their positions. This is consistent with a preflop state (0 community cards).

## Hole Cards

**Robot Hole Cards** (bottom area): Two face-down cards are visible in the robot hole-card position (around 45-72%, 70-86%). They appear to be in a settled position and are face-down. No readable card values can be determined from this image.

**Opponent Hole Cards** (top area): Two face-down cards are visible in the opponent hole-card position (around 35-55%, 42-52%). They are face-down and not readable from this image.

## Robot Inventory Chips (Bottom Seat)

**Zone**: Bottom-left and bottom-center areas near the robot seat and hole-card area, outside the central betting lane.

**Counts by denomination** (left-to-right order: 5, 10, 50, 100):

- **Red chips (5)**: Approximately 4 visible red chips, counted from the main inventory group on the left
- **Blue chips (10)**: Approximately 3-4 blue chips, distributed across the left and center-left zone
- **Green chips (50)**: Approximately 3 green chips visible
- **Brown chips (100)**: Approximately 3 brown chips visible, though some may be partially occluded

**Observation**: The chips are unfolded/flat on the felt. The exact boundary between inventory and potential betting chips is slightly ambiguous due to the chip arrangement, but the majority of lower-value chips appear to be in an inventory cluster near the lower rail.

## Opponent Inventory Chips (Top Seat)

**Zone**: Top-left and upper areas near the opponent seat and hole-card area, outside the central betting lane.

**Counts by denomination** (left-to-right order: 5, 10, 50, 100):

- **Red chips (5)**: Approximately 4 red chips
- **Blue chips (10)**: Approximately 4 blue chips
- **Green chips (50)**: Approximately 3 green chips
- **Brown chips (100)**: Approximately 3 brown chips

**Observation**: Opponent chips are unfolded and flat on the felt. Distribution appears similar in structure to the robot inventory, with lower denominations grouped together.

## Current Bets

**Robot Current Bet** (left/bottom side of community-card row): No distinct chips are clearly visible in the betting area to the left of the community cards. The betting lane appears empty or the chips, if any, are very small or merged with inventory positions.

**Opponent Current Bet** (right/top side of community-card row): Similarly, no distinct opponent bet chips are clearly visible in the betting area to the right of the community cards. The opponent bet area appears empty.

**Interpretation**: This is consistent with a preflop state where no bets have yet been placed, or the hand is in the pre-action idle state.

## Showdown Status

**Showdown Determination**: Not in showdown. Both players' hole cards are face-down in their normal positions, no cards are face-up for comparison, and the board shows no community cards. The hand appears to be in an idle or preflop state without active showdown logic needed.

## Buttons And Markers

- **"Your Jog" / Turn button**: White button at bottom-left robot seat area ✓ (robot's turn)
- **"BIG BLIND" button**: Yellow button visible in center-right area, indicating the opponent is the big blind
- **Dealer/Small Blind**: At the robot seat (implied from heads-up rule and turn button position)

## Robot Hand Status

The dexterous hand is visible on the right side of the image in a near-idle pose, slightly elevated or in a resting position. No card is currently held by the hand; no active manipulation is visible.

## Uncertain Or Partially Occluded Elements

1. **Exact chip counts**: The boundary between inventory chips and any small bet chips is slightly ambiguous due to overlapping groups. Red and brown denominations have the most uncertainty (±1 chip).
2. **Community card exact state**: Cards are in slots showing backs; preflop interpretation is strong but could be confirmed if needed.
3. **Bet chips**: No clear current-bet chips are visible on either side; this may reflect an idle state where no bets have been placed yet.

