# Eval Report — Perception Step

## Image
`s_current/00_capture.jpg` — latest state (s23 is the labeled latest per preflight manifest; s_current is the working copy).

## Context Files
- `action_sequence.json`: **missing** (not present in workspace) — no prior action context available.
- `hole_card_cache.json`: **missing** — no cached hole cards available.
- `sN-1/01_parsed_state.md`: No previous parsed state found in s22 or s23 directories (only `00_capture.jpg` present in both). No fields inherited.

---

## Evidence Summary

| Field | Value | Confidence | Evidence |
|---|---|---|---|
| `loop_stage` | `idle` | Medium | Scene is stable; "Your Turn" button at robot seat indicates turn is pending, no active robot motion visible |
| `blind` | `big_blind` | High | Yellow "BIG BLIND" button clearly visible at robot/bottom seat; "DEALER" button near opponent/top seat |
| `showdown_outcome` | `not_showdown` | High | No face-up hole cards from either player; preflop state |
| `scene_stable` | `true` | High | No motion blur or displacement artifacts in image |
| `is_my_turn` | `true` | High | White "Your Turn" button clearly positioned at bottom-left robot seat area |
| `community_cards` | `[]` | High | Only face-down blue-backed cards visible in community card row; no face-up board cards |
| `my_chips` | `{5:3,10:2,50:2,100:1}` | Low | Chips near right side of robot seat area; angle and partial occlusion reduce confidence |
| `opponent_chips` | `{5:3,10:3,50:2,100:2}` | Low | Chips near top rail; distance and angle reduce confidence |
| `my_current_bet` | `{5:2,10:1,50:0,100:0}` | Low | Small chip group in left-of-center bet area; "10" marker ambiguity |
| `opponent_bet` | `{5:1,10:0,50:0,100:0}` | Low | Robot arm partially occludes right bet area |

## Merging Notes
- No previous parsed state to merge/inherit from.
- `hole_card_cache.json` absent — no cached robot hole cards.
- `action_sequence.json` absent — cannot cross-check prior dispatched action.
- Chip counts are all marked uncertain; they should be treated as approximate estimates only.
- The preflop state (zero face-up community cards) and big-blind assignment are high-confidence observations.
- `loop_stage = idle` is inferred from visual stability + our turn pending; no action sequence context to confirm.

## Uncertain Fields
`my_chips`, `opponent_chips`, `my_current_bet`, `opponent_bet`
