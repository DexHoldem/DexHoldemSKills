## Perception summary

The current capture matches `s22` exactly, and the robot appears settled. The robot-side turn and big-blind buttons are visible. There are no face-up community cards or showdown cards. One blue 10-chip is in the robot bet area and one green 50-chip is in the opponent bet area.

Chip inventories were counted from the current image. The robot body covers portions of the right-hand groups, so the robot's brown count and the opponent's green and brown counts are estimates and are named in `uncertain_fields`. The requested action-sequence, hole-card-cache, and previous parsed-state files were absent from this workspace; no prior workflow value was used to override the visual evidence.
