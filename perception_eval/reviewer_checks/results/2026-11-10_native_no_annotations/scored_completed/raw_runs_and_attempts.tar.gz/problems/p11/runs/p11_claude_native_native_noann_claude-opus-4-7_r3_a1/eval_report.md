# Eval Report — s_current (s23)

## Evidence summary
- "Your Turn" token present on robot side → `is_my_turn = true`, `loop_stage = acting`.
- "BIG BLIND" button on robot side; "DEALER" + "SMALL BLIND" on opponent side → `blind = big_blind`.
- Five face-down cards in the community lane, zero face-up → pre-flop, `community_cards = []`.
- Both players' hole cards face-down, no outcome indicator → `showdown_outcome = not_showdown`.
- Central bet lane: one 10-chip in front of each player → `my_current_bet` and `opponent_bet` each have `{10:1}`.

## Merging with prior state
No prior parsed state (`sN-1/01_parsed_state.md`) was available in the workspace, so no durable fields were inherited. All fields derived directly from the current capture.

## Uncertainty
Chip stack counts (`my_chips`, `opponent_chips`) are visual estimates due to camera perspective and partial occlusion of stack heights; flagged in `uncertain_fields`.

## Outputs written
- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
