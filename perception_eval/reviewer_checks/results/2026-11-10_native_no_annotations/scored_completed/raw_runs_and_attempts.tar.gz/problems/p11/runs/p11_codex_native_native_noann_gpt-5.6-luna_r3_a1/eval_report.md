# Evaluation report

The capture was visually parsed using the field-specific guidelines. The white `Your Turn` marker is at the robot seat and the yellow `BIG BLIND` marker is also at the robot seat. No face-up community cards or showdown evidence is visible. Inventory chips were counted by denomination and zone; one blue 10-chip is assigned to the robot bet area and one red 5-chip to the opponent bet area.

The robot hand is extended over the table and partially blocks the upper/right chip region, so the scene is marked unstable and the loop stage is `acting`. The upper/right bet and inventory counts are recorded as best estimates and flagged as uncertain. No action was dispatched.
