# Native visual evidence

Current image: `s_current/00_capture.jpg` resolves to `s23/00_capture.jpg`. Inspected directly, together with `s22/00_capture.jpg`, `s21/00_capture.jpg`, and the initial `s0/00_capture.jpg`. Applied the field guidelines in `visual_guidelines/`.

Stable. Current s23 and previous s22 show the same settled robot pose and chip/card locations. In s21 the hand was lower and extended over the robot's left betting area; it has since withdrawn to the right. The current fingers are above the upper-right table region, with no readable held card or visibly carried chip. The hand/body obscures the right betting region and parts of both brown inventory groups. The latest two frames support a settled post-action state, estimated as atom_idle. Exact workflow completion cannot be established without the action sequence. No visible displaced card or scattered chip layout establishes failure.

The white Your Turn button is clearly at the bottom/robot seat. It is our turn. The yellow BIG BLIND button is at the robot seat, while the white DEALER and blue SMALL BLIND buttons are at the top/opponent seat. Robot is big blind; no button conflict is visible.

There are no readable face-up community cards. Five patterned backs/positions occupy the central lane; none supplies a rank or suit. The two hole cards at each seat remain face-down in their normal areas. No readable held card, fold/muck displacement, or showdown is visible. Outcome is not_showdown; no hand comparison is possible or needed.

Inventory counts use flat individual chip faces and exclude betting chips and buttons. Robot inventory: four red 5 chips, three blue 10 chips, four green 50 chips, and an estimated four brown 100 chips. Three brown chips are at least partly visible; the fourth position is occluded. The initial s0 image clearly shows four brown chips, supporting the current estimate without proving hidden continuity.

Opponent inventory: three red 5 chips and four blue 10 chips are visible. Four green 50 chips are estimated, with one partly hidden by the fingers. Three brown 100 faces are visible, with an estimated fourth hidden behind the hand. Initial s0 shows four green and four brown chips in the corresponding groups. These occluded counts are uncertain.

Robot current bet, left of the central row: one blue 10 chip, zero red, green, or brown chips visible. Opponent bet, right of the central row: one partly visible red 5 chip near the printed club marking; no blue, green, or brown bet chips visible. The hand/body hides the remainder of that area, so the opponent bet estimate, including zero counts for other denominations, is uncertain.

No action_sequence.json, hole_card_cache.json, or previous 01_parsed_state.md is available in the workspace. No durable fields were inherited from a parsed state. Earlier images were used only to assess stability and support explicitly uncertain occluded inventory estimates. No hidden card values were inferred.
