# Perception merge

The current and previous captures are byte-identical, supporting a stable scene. The robot-side white turn marker and yellow big-blind button are visible. No face-up community cards or showdown evidence appears. One blue 10-chip is in the robot bet area; one red 5-chip is in the opponent bet area.

Inventory counts follow visible chip groups, with `s0` used only to estimate chip faces now partly hidden by the robot. The robot also occludes part of the opponent betting area, so unseen denominations are set to zero as concrete estimates and marked uncertain. `idle` is inferred from the settled image because workflow context files were not supplied. Visual evidence takes priority over the baseline.
