# Raw visual perception

Capture: `s_current/00_capture.jpg` (`s23`). Compared with `s22/00_capture.jpg`; the image files are byte-identical. `s0/00_capture.jpg` was used to identify the original chip groups and visible blind placements.

- **Scene and robot:** Stable in the available repeated frame. The dexterous hand is extended from the right in a settled near-idle pose, holds no visible card or chip, and partly occludes the opponent's right-side inventory/betting region. No disturbed cards or chips are visible. The repeated frame does not independently establish when the preceding atom finished.
- **Turn and blinds:** The white `Your Turn` button is at the bottom robot seat. The yellow `BIG BLIND` button is also at the robot seat; the white `DEALER` button is at the top opponent seat. Robot is big blind and it is the robot's turn.
- **Community and showdown:** No face-up shared cards are visible. The five patterned rectangles in the center are the table's printed card positions, also present in `s0`. The opponent's hole cards remain face down in their top-seat area. No visible fold or face-up showdown cards. No readable card is held by the robot.
- **Robot inventory:** Four red 5-chips, three blue 10-chips, four green 50-chips, and an estimated four brown 100-chips. Some right-side brown chips are partly behind the robot housing.
- **Opponent inventory:** Three red 5-chips, four blue 10-chips, an estimated four green 50-chips, and an estimated four brown 100-chips. The robot hand blocks part of the green/brown groups; estimates use the visible group layout and `s0` baseline.
- **Robot bet area:** One blue 10-chip left of the shared board row; no red, green, or brown bet chips visible.
- **Opponent bet area:** One red 5-chip visible near the right end of the shared board row. No other bet chips are visible, but the robot housing/hand blocks part of this area; counts of other denominations are uncertain.

The named `action_sequence.json`, `hole_card_cache.json`, and prior `01_parsed_state.md` context files are absent from the provided workspace. No action or poker decision is inferred from them.
