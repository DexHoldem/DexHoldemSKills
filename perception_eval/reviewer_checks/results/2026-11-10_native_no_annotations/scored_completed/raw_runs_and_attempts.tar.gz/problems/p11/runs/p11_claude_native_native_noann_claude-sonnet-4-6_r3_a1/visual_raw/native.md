# Visual Raw Perception — native.md

## Image: s_current/00_capture.jpg

### Scene Overview
A Texas Hold'em poker table viewed from the robot/camera perspective. The human opponent is seated at the top of the table; the robot arm is visible at the right side of the image. The table has the "TEXAS HOLD'EM" text printed across the center felt.

---

### Turn Detection
The white circular button labeled "Your Turn" is clearly visible near the bottom-left of the table, in the robot/player seat area. This confirms **it is our turn**.

---

### Blind Button Recognition
- A **blue "DEALER" button** is visible in the upper-center area of the table, positioned between the community card row and the opponent seat — indicating the **opponent holds the dealer button** (and therefore is the small blind in heads-up).
- A **yellow "BIG BLIND" button** is visible near the center-bottom of the table, in the robot seat area — confirming the **robot is the big blind**.

---

### Community Cards
The community card row (center of the table) contains **face-down cards** with blue card backs. No face-up community cards are visible. The face-down cards in the community area appear to be undealt/unexposed board cards. **Zero readable community cards.**

---

### Robot Hole Cards
Two face-down blue-backed cards are visible in the robot hole card slot (bottom center of the table). They are face-down and their values cannot be read. No hole_card_cache is available.

### Opponent Hole Cards
Two face-down blue-backed cards are visible in the opponent hole card slot (top center of the table). They are face-down and their values cannot be read.

---

### Chip Recognition

#### Robot/Player Inventory (bottom seat area, excluding bets)
Chips visible to the right of the robot hole card area, near the BIG BLIND button and right bottom rail:
- Red (5): approximately 3 red chips visible
- Blue (10): approximately 2 blue chips visible
- Green (50): approximately 2 green chips visible
- Brown (100): approximately 1 brown chip visible
- **Count is uncertain** due to angle and partial occlusion by robot arm.

#### Opponent Inventory (top seat area, excluding bets)
Chips visible near the top rail, to the right of the opponent hole card area:
- Red (5): approximately 3 red chips
- Blue (10): approximately 3–4 blue chips
- Green (50): approximately 2 green chips
- Brown (100): approximately 2 brown chips
- **Count is uncertain** due to distance and angle.

#### My Current Bet (left side of community cards)
A small group of chips is visible in the left-of-center betting area:
- Red (5): approximately 2 red chips
- Blue (10): approximately 1 blue chip
- Green (50): 0
- Brown (100): 0
- **Uncertain** — the "10" marker/token near this area may be a denomination label, not an inventory chip.

#### Opponent Bet (right side of community cards)
Some chips visible to the right of the community card row; partially occluded by the robot arm:
- Red (5): approximately 1 red chip
- Blue (10): 0 clearly visible
- Green (50): 0
- Brown (100): 0
- **Uncertain** due to robot arm occlusion.

---

### Showdown Assessment
No face-up hole cards from either player. No showdown in progress. The scene is at preflop (no face-up community cards). This is **not a showdown** state.

### Scene Stability
No motion blur, no robot arm in motion, no chips in the air. The scene appears **stable**.

---

### Summary
- Turn: **Our turn** (Your Turn button at robot seat)
- Blind: **Robot is big blind**, opponent is dealer/small blind
- Community cards: **None visible face-up** (preflop)
- Showdown: **Not in showdown**
- Loop stage assessment: **idle** (stable scene, awaiting action decision)
- All chip counts are **approximate and uncertain** due to image angle and partial occlusion
