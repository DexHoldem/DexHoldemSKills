# Native Perception — Raw Evidence

Image: `s_current/00_capture.jpg` (= `s23/00_capture.jpg`). Compared against
`s22/00_capture.jpg` for stability. No `action_sequence.json`,
`hole_card_cache.json`, or prior `01_parsed_state.md` exist anywhere in this
workspace, so there is no prior-run context to inherit; this is treated as a
cold-start parse based purely on visual evidence.

## Scene Stability

`s22/00_capture.jpg` and `s23/00_capture.jpg` are visually indistinguishable:
same robot arm/hand position (camera/dexterous-hand housing at the upper
right, not reaching onto the felt), same chip layout, same card positions,
same opponent posture (seated, looking down at their own hole-card area).
No large movement, no card/chip disturbance between frames. Scene is
**stable**. The robot hand is near its rest pose at the right edge, partially
occluding the far right of the table (consistent with the documented common
robot/camera occlusion zone) but not interacting with chips or cards.

## Turn Detection

A white button reading "Your Turn" is visible at the bottom-left of the
table, in the robot-turn-button zone (lower-left of board, robot/player
side). No white turn button is visible at the opponent/top seat. -> It is the
robot/player's turn.

## Blind / Button Assignment

- A yellow button labeled "BIG BLIND" sits on the bottom/robot side of the
  table, next to the lower seat-number tile.
- A white "DEALER" button and a blue button with rotated/mirrored text
  (consistent with "SMALL BLIND", read upside-down from the robot/camera
  side) sit together on the top/opponent side, among the opponent's chips.
- Two-player rule: dealer+small-blind is one player (here, opponent); the
  other player (robot) is big blind. This matches the directly-visible
  yellow BIG BLIND button on the robot side.
- Blind assignment: **robot/player = big blind**, opponent = small
  blind/dealer.

## Community Cards

The central board row (five card slots spanning the middle of the table)
shows five cards, all face-down (visible card backs, diagonal-pattern), no
face-up board cards anywhere. -> **Zero community cards revealed**; board
not yet dealt (preflop).

## Hole Cards

- Opponent hole-card area (upper-center, near opponent seat): two face-down
  cards visible near the opponent's chips/dealer-button cluster. Not
  readable, not moved toward the board lane, so no fold/muck signature.
- Robot hole-card area (lower-center, near the BIG BLIND button and lower
  seat tile): two face-down cards visible. Not held by the dexterous hand,
  not readable. No cached robot hole-card values exist (no
  `hole_card_cache.json` in this workspace).

## Robot Behavior

The dexterous hand/camera housing is at the right edge of the frame, fingers
loosely open, not extended over the felt, not holding any card or chip. This
looks like a near-idle/rest pose. It is not mid-motion (identical across the
two most recent frames), not blurred, and not touching any table object. No
physical-failure or human-help indicators are present. The hand does
partially occlude the far-right edge of the table (part of the opponent's
upper-right chip cluster and possibly the table's far-right seat tile), a
known common occlusion zone, but this does not block the turn button, hole
cards, or community-card row.

## Chip Recognition — Robot/Player Inventory (bottom seat band)

- Red (5): a cluster of roughly 4 visible red chip faces, lower-left of the
  robot hole cards, next to the "Your Turn" button.
- Blue (10): a cluster of roughly 4 visible blue chip faces, center-lower,
  between the red cluster and the BIG BLIND button.
- Green (50): roughly 3 visible green chip faces in the lower-right cluster.
- Brown (100): roughly 2 visible brown chip faces in the same lower-right
  cluster, partially tucked behind the green chips; count is somewhat
  uncertain due to overlap.

## Chip Recognition — Opponent Inventory (top seat band)

- Red (5): roughly 2 visible red chip faces in the upper-left cluster.
- Blue (10): roughly 4 visible blue chip faces, stacked diagonally in the
  same upper-left cluster.
- Green (50): roughly 2-3 visible green chip faces in the upper-right
  cluster (near the robot arm).
- Brown (100): at most 1 chip face possibly visible in the upper-right
  cluster; this denomination is significantly occluded by the robot
  hand/camera housing at the right edge. **Uncertain / not reliably
  countable.**

## Bet Recognition

- My current bet (left of the community-card row): one blue (10) chip with
  a light marker on top is visible at the far-left edge of the community
  row. No red, green, or brown chips visible in this bet lane.
- Opponent bet (right of the community-card row): the right side of the
  community row, near the robot arm/camera housing, is partially occluded.
  No clearly separate bet chips are confidently visible there beyond the
  general inventory cluster; this side is **uncertain due to robot hand
  occlusion**.

## Showdown / Outcome

No face-up hole cards for either player. No fold/muck signature (both
hole-card pairs remain face-down in their normal seat positions). This is a
normal pre-decision state, not a showdown. -> `not_showdown`.

## Loop Stage Judgment

Turn button says it is the robot's turn; scene is stable; robot hand is at
rest, not mid-action; no action sequence context exists in this workspace;
no win/lose/showdown signal. This matches the normal "waiting for a poker
decision" state. -> `idle`.
