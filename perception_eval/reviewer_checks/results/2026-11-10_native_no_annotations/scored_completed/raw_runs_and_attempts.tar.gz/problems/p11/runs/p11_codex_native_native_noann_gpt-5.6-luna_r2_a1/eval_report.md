# Perception evaluation

Used the latest available capture, `s23/00_capture.jpg`, because the requested `s_current/00_capture.jpg`, `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` were absent. Compared the available latest frame with `s22/00_capture.jpg` for stability.

The image shows a stable table, the robot/player as big blind, and a visible `Your Turn` button at the robot seat. No face-up community cards or showdown result are visible. Inventory chip counts were read from the bottom and top seat bands; the opponent-side apparatus occludes part of the betting area, so opponent bet and some opponent inventory counts are marked uncertain. No action was dispatched.
