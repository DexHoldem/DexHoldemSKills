# Eval Report — Perception Step

## Context

- `action_sequence.json`, `hole_card_cache.json`, and any prior
  `sN-1/01_parsed_state.md` do not exist anywhere in the workspace. There is
  no prior parsed state to inherit durable fields from, so every field below
  is derived directly from the current and previous capture images.
- Compared `s_current/00_capture.jpg` against the most recent prior capture,
  `s23/00_capture.jpg`. The two frames are visually identical (same robot
  pose, same chip layout, same buttons), so the scene is stable.

## Merging / Derivation

- `scene_stable`: true — no change between `s23` and `s_current`.
- `is_my_turn`: true — white "Your Turn" button is at the bottom/robot seat.
- `blind`: `big_blind` — yellow "BIG BLIND" button sits at the robot seat;
  dealer/small-blind markers are at the opponent seat, consistent with the
  two-player dealer=SB rule.
- `community_cards`: empty — all five board slots are face-down card backs
  (preflop).
- `loop_stage`: `idle` — scene is stable, it is the robot's turn, no robot
  action is visibly in progress, and no action-sequence context exists to
  suggest an atom is dispatched.
- `showdown_outcome`: `not_showdown` — no face-up hole cards, no fold/muck
  signature.
- Chip counts: derived by zone per `TABLE_GEOMETRY.md`/`CHIP_RECOGNITION.md`/
  `BET_RECOGNITION.md`. Robot-side chips are reasonably clear (outer cluster
  = inventory, middle cluster nearer the board = current bet, cluster beyond
  the hole cards = additional inventory). Opponent-side chips are less
  reliable: part of the cluster beyond the opponent's hole cards falls near
  the common robot/camera occlusion zone on the right of the frame, and no
  cluster is clearly separable as a distinct opponent current bet, so those
  values are marked uncertain in `visual_summary.json`.

## Uncertainty

- `opponent_chips` (all denominations): partially occluded by the robot
  arm/camera housing; counts are best-effort.
- `opponent_bet`: no clearly distinct bet cluster was identifiable separate
  from the opponent's inventory/button cluster; reported as zero with low
  confidence.
- `my_chips.50` / `my_chips.100`: the green/brown cluster beyond the robot's
  hole cards is assumed to be inventory rather than bet chips, based on its
  position relative to the board, but this split is a judgment call.

## Outputs

- `visual_raw/native.md` — written.
- `visual_summary.json` — written.
- `eval_report.md` — this file.
