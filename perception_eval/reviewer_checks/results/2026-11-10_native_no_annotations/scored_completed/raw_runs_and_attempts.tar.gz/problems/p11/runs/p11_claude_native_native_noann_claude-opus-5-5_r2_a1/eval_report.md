# Eval report — native perception

- **Inputs:** s_current/00_capture.jpg, with s23/00_capture.jpg for the stability comparison. The context files (action_sequence.json, hole_card_cache.json, previous parsed state) are missing, so I inherited nothing and every value comes from this image.
- **Stage:** `idle`. The scene is stable (same as s23), and the hand is settled in its near-idle pose with nothing held.
- **Turn:** true. The "Your Turn" button is at the robot seat.
- **Blind:** big_blind. BIG BLIND is at the robot seat; DEALER and SMALL BLIND are at the opponent seat.
- **Board:** [] — preflop. Five face-down card backs are placed in the board slots; none are face-up.
- **Showdown:** not_showdown.
- **Chips:** robot 4/3/4/3 and opponent 3/4/3/3 (counts of 5/10/50/100 chips). The robot hand covers part of the robot's right-side 50/100 group and the opponent's 50 group.
- **Bets:** robot has 1x10 (big blind). Opponent has 1x5 (small blind), read from a mostly occluded chip right of the board.
- **Uncertain:** opponent_bet, my_chips.50, my_chips.100, opponent_chips.50. Use reset_to_init and recapture if the next step needs exact counts for these.
