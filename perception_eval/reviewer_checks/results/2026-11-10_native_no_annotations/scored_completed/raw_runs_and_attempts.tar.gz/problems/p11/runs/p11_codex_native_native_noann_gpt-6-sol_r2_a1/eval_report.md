# Perception merge

The current capture shows a settled preflop table: five board card backs, the robot's Your Turn and BIG BLIND buttons, one blue 10 chip in the robot betting area, and an apparent red 5 chip in the opponent betting area. `s22` supports the stability judgment. `s0` supports estimates for chip faces obscured by the robot; those counts and the partly hidden red bet are flagged in `uncertain_fields`.

The action-sequence, hole-card cache, and previous parsed-state files were unavailable. `loop_stage` is an idle estimate based on the settled image, without workflow-state confirmation. No showdown or poker action was inferred.
