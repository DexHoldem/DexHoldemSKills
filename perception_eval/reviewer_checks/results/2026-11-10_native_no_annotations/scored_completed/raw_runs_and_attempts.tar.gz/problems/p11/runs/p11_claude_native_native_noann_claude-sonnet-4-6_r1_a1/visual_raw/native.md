# Visual Perception — Raw Evidence
## Image: s_current/00_capture.jpg (compared against s23/00_capture.jpg)

---

### Scene Stability

Compared s_current/00_capture.jpg and s23/00_capture.jpg.
The two frames appear essentially identical — robot hand and arm are in the same near-idle position (upper-right of frame), no cards or chips have moved, and no human arm is actively interfering with the table surface.
Conclusion: **Stable**.

---

### Turn Detection

A white circular button labeled **"Your Turn"** is clearly visible in the bottom-left area of the table, squarely within the robot/player (bottom) seat zone.
Conclusion: **It is our turn.**

---

### Blind Button Detection

- **BIG BLIND** yellow button: visible at the lower-center-right of the table, within the robot/player (bottom) seat area.
- **DEALER** blue button: visible at the upper-center area of the table, within the opponent (top) seat area.

Per the two-player rule — the seat with the DEALER button is also the small blind; the other seat is the big blind.
Conclusion: Opponent is dealer/small blind. Robot is **big blind**.

---

### Community Cards

The center horizontal strip (community card zone) shows approximately 4–5 face-down card positions (blue card backs visible). No face-up cards are readable.
Conclusion: **0 community cards face-up** (preflop stage).

---

### Chip Recognition

**Robot/player inventory chips (bottom seat area, excluding bet zone):**
- Left cluster (near "Your Turn" button): ~2 red (5) chips and ~1 blue (10) chip visible.
- Center-bottom cluster: ~2 red (5), ~2 blue (10) chips visible.
- Right cluster (near BIG BLIND button): green (50) chips and a brown/dark (100) chip visible; label text "50" and "001"/"100" legible.
- Best estimate: **4 red (5), 3 blue (10), 2 green (50), 1 brown (100)**. Brown count is partially occluded.

**Opponent inventory chips (top seat area, excluding bet zone):**
- Upper-left of community card strip: a cluster with ~3 blue (10) chips and ~2 red (5) chips visible.
- Upper-right of community card strip (partially occluded by robot arm in upper-right frame corner): some additional chips, likely green and brown, difficult to count.
- Best estimate: **3 red (5), 4 blue (10), 2 green (50), 1 brown (100)**. Right-side counts uncertain due to partial occlusion from robot arm frame position.

---

### Bet Area Recognition

**My current bet (chips left of community card strip):**
- A small cluster with approximately 2 blue (10) chips visible in the bet zone, possibly also 1 red (5) chip.
- Best estimate: **1 red (5), 2 blue (10), 0 green (50), 0 brown (100)**. These appear consistent with the big blind posting (value ~25).

**Opponent bet (chips right of community card strip):**
- A small group visible to the right of the community cards with approximately 1 red (5) chip.
- Best estimate: **1 red (5), 0 blue (10), 0 green (50), 0 brown (100)**. This is consistent with a small blind posting (value ~5). Some occlusion from robot arm position in upper right frame.

---

### Showdown

No cards are face-up for comparison; no showdown indicators visible.
Conclusion: **not_showdown**.

---

### Loop Stage

Scene is stable. The "Your Turn" button is at the robot seat. No robot motion in progress. The game appears to be in the acting state awaiting the robot's decision.
Conclusion: **acting**.
