# Eval report — p11 native perception

- **Sources:** s_current/00_capture.jpg, compared with s23 (stability) and s0 (initial chip layout). `action_sequence.json`, `hole_card_cache.json`, and the previous `01_parsed_state.md` are not in the workspace, so no fields were inherited from files.
- **Stage:** idle. The scene is stable (same as s23), the hand is near-idle and holds nothing, and the "Your Turn" button is at the robot seat.
- **Blind:** big_blind. The BIG BLIND button is on the robot side; DEALER and SMALL BLIND are at the opponent seat.
- **Board:** preflop. All 5 board cards are face-down, so community_cards = [].
- **Bets:** robot has 1×10 (blue) left of the board. Opponent most likely has 1×5 (red), but it is mostly hidden by the robot camera body. Inferred from the opponent's red count dropping from 4 to 3 relative to s0.
- **Inventories:** robot 4/3/4/4 and opponent 3/4/4/4 (5/10/50/100).
  - Robot 100s: 3 visible, 1 occluded. Estimated as 4 using s0.
  - Opponent 50s and 100s: partly occluded by the fingers. Estimated as 4 each using s0.
- **Uncertain:** opponent_bet, opponent_chips, and my_chips (all because of hand/arm occlusion). A `reset_to_init` and a fresh capture would confirm them.
- **Showdown:** not_showdown. No face-up hole cards and no fold signature.
