# Perception Evaluation Report

## Evidence Summary
- **Turn**: Robot's turn confirmed by the "Your Turn" button at the bottom-left.
- **Blinds**: Big Blind button is at the robot's seat; Small Blind and Dealer buttons are at the opponent's seat.
- **Bets**: Robot has 10 (1 blue chip) as a Big Blind bet. Opponent has 5 (1 red chip) as a Small Blind bet.
- **Inventory**: Robot has 500 in inventory; Opponent has 505. Both totals (including bets) equal 510.
- **Cards**: All community and hole cards are face-down. Preflop stage.
- **Robot**: Hand is idle and not occluding any critical game state.

## Merging and Confidence
The visual state is clear and consistent across frames (`s22` and `s_current`). The chip counts and bets balance perfectly, providing high confidence in the extracted inventory and bet values. No fields are marked as uncertain.
