# Native visual evidence

Inspected s_current/00_capture.jpg (symlink target s23), s22/00_capture.jpg, s21/00_capture.jpg, and s0/00_capture.jpg. Read all field guidelines in visual_guidelines/.

Stable. The robot hand and table layout appear unchanged between s22 and s23. In s21 the hand was extended over the robot betting lane; in s22 and s23 it is withdrawn to a near-idle pose at the right, with fingers projecting over the opponent inventory in camera perspective. No held card or held chip is visible. The housing blocks portions of the right betting area and brown inventory. No visible scattering, displaced card, or ongoing transfer is apparent. The latest pose supports a completed atom (atom_idle), although the missing action context prevents confirming sequence completion.

It is our turn. The white Your Turn button is at the bottom-left robot seat.

The robot has the yellow BIG BLIND marker. The opponent has the white DEALER and blue SMALL BLIND markers. No conflict is visible.

No face-up community cards are visible. The five patterned central rectangles do not supply readable board cards; the same pattern is present in the initial view. Community-card output is empty. Both seats have face-down hole cards in their normal areas. No readable held card, exposed opponent cards, or clear fold/muck is visible. This is not showdown.

Denominations below are red 5, blue 10, green 50, brown 100. Count flat chip faces, not stacks.

- Robot inventory: four red, three blue, four green, approximately four brown. Three brown faces are at least partly visible; the remaining brown chip position is blocked by the housing. Four brown chips are clear in s0, so four is the best continuity estimate.
- Opponent inventory: three red, four blue, approximately four green and four brown. Fingers partially hide the green group and part of the brown group. The initial view supports four of each, and the visible layout is consistent with that count.
- Robot current bet, left of the central row: one blue chip, no red, green, or brown chips visible. It is separate from the lower inventory.
- Opponent bet, right of the central row: one partly visible red chip near the housing edge; estimate no blue, green, or brown chips. This area is occluded, so the full count is uncertain.

action_sequence.json, hole_card_cache.json, and a previous 01_parsed_state.md are absent from the supplied workspace. No cached hole-card values or parsed durable fields were available to inherit. Earlier images support only the explicitly identified continuity estimates. No robot action, helper script, or poker decision was performed.
