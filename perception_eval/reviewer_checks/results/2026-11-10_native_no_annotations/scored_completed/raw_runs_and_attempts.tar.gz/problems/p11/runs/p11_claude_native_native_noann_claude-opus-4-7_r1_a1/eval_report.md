# Eval Report — s_current (s23)

## Evidence summary
- Capture shows robot arm mid-motion over the opponent's card area → scene_stable=false.
- "Your Turn" marker is present on my side → is_my_turn=true, loop_stage=acting.
- BIG BLIND marker on my side; DEALER + SMALL BLIND on opponent side → blind=big_blind (heads-up: dealer is SB).
- All five community card positions show face-down backs → community_cards=[] (pre-flop).
- No face-up cards anywhere → showdown_outcome=not_showdown.

## Chip / bet reasoning
- Four denominations visible on both sides: 5 (red), 10 (blue), 50 (green/purple), 100.
- Stacks are approximate: my side ≈ {5:4, 10:3, 50:3, 100:3}; opponent ≈ {5:4, 10:4, 50:3, 100:3}. Perspective and partial stacking make exact counts uncertain.
- Bets: pre-flop blinds assumed posted — my BB=10 (one "10" chip), opponent SB=5 (one "5" chip). A "10" chip near the dealer line is treated as the posted BB or pot contribution; boundary between bet-zone and pot is ambiguous because of occlusion.

## Merging with context
- No `sN-1/01_parsed_state.md`, `action_sequence.json`, or `hole_card_cache.json` present in `s_current/`; nothing to inherit. All fields derived directly from the current image.

## Uncertainty
Flagged: scene_stable, my_current_bet, opponent_bet, my_chips, opponent_chips.
