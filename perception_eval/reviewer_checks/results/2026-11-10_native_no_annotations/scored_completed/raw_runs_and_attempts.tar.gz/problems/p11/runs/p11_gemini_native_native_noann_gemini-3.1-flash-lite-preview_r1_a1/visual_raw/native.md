# Raw Perception Evidence - s23

- **Loop Stage**: The "Your Turn" indicator is present on the table. The opponent is waiting. This is clearly an `acting` stage.
- **Blind**: "BIG BLIND" marker is clearly visible near the player's side.
- **Showdown Outcome**: No cards are revealed, so `not_showdown`.
- **Table Stability**: Scene appears stable.
- **My Turn**: "Your Turn" sign is visible, so `is_my_turn`: true.
- **Community Cards**: 0 cards face-up.
- **My Chips**:
  - 5: 3 (Red)
  - 10: 2 (Blue)
  - 50: 0
  - 100: 0
- **Opponent Chips**:
  - 5: 2
  - 10: 2
  - 50: 0
  - 100: 0
- **Bets**: No chips in the betting area for either. Both `my_current_bet` and `opponent_bet` are zero.
