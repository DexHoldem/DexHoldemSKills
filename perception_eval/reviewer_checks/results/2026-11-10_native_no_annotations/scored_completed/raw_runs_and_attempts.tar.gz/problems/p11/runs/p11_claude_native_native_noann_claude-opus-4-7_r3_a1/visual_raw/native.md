# Raw Perception Evidence — s_current (s23)

## Scene stability
Image is sharp and well-lit. Robot arm is visible on the right but not actively moving a chip into any lane. Scene is stable.

## Turn indicator
- A white "Your Turn" token is visible on the bottom-left side of the table (robot side, near the seat-6 label).
- No "Your Turn" token on the opponent side.
- Conclusion: `is_my_turn = true`.

## Blind / Dealer buttons
- Yellow "BIG BLIND" button is on the robot (my) side, in the central betting lane.
- Blue "SMALL BLIND" button + white "DEALER" button are on the opponent side.
- Conclusion: `blind = big_blind`.

## Community cards
Five face-down card backs are visible in the center lane. No cards are face up.
- Conclusion: `community_cards = []` (pre-flop).

## Hole cards
- Two face-down cards in the robot hole-card slot.
- Two face-down cards in the opponent hole-card slot.

## Bets in the central lane
- Opponent side: a single 10-chip (blue) sits in the opponent bet area just below their hole cards (small blind would normally be 5, but the visible chip reads "10"; could be SB posted + an added chip, or actual bet of 10).
- Robot (my) side: a single 10-chip (blue) is in my bet area in front of my hole cards.
- Conclusion:
  - `opponent_bet = {5:0, 10:1, 50:0, 100:0}`
  - `my_current_bet = {5:0, 10:1, 50:0, 100:0}`

## Stack chips (NOT in the bet lane)
### My (robot) side — bottom
- 5-chips (red/white): one short stack of ~4.
- 10-chips (blue/white): one stack of ~3.
- 50-chips (blue/green): one stack of ~3.
- 100-chips (purple/blue): one stack of ~3.

### Opponent side — top
- 5-chips: ~4 chips total across the stack(s).
- 10-chips: ~4 chips.
- 50-chips: ~3 chips.
- 100-chips: ~3 chips.

Chip counts are visual estimates; marked as uncertain.

## Showdown
No cards are face-up for either player, and there is no win/lose indicator. Not a showdown.
- `showdown_outcome = not_showdown`.

## Loop stage
"Your Turn" token active + pre-flop + BB posted → robot is being asked to act → `loop_stage = acting`.
