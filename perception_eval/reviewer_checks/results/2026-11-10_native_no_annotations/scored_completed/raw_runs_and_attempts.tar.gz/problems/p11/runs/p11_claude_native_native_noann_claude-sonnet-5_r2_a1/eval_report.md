# Eval Report — Perception Step (s23)

## Context Check

Searched the whole working tree for `action_sequence.json`, `hole_card_cache.json`,
and any `sN-1/01_parsed_state.md`. None exist anywhere (s0–s23 each contain only
`00_capture.jpg`). There is nothing to inherit; every field below was derived
directly from the image evidence, so none of them are "inherited" in the
durable-field sense, though several are flagged uncertain due to chip-count
approximation and occlusion.

## Evidence Used

- Current capture: `s23/00_capture.jpg`.
- Previous capture: `s22/00_capture.jpg` — byte-identical in size (478088 bytes)
  and visually identical on inspection, confirming the scene is stable.
- `s21/00_capture.jpg` checked only to confirm no recent large motion; not
  needed further since s22/s23 already agree.

## Merging Logic

- **Turn detection**: white "Your Turn" button is at the bottom/robot seat ->
  `is_my_turn: true`. Per `TURN_DETECTION.md`, this is decided solely from the
  button, not betting/dealer cues.
- **Blind**: a white DEALER + blue SMALL BLIND button both sit at the top/opponent
  seat; a yellow BIG BLIND button sits at the bottom/robot seat. Two-player rule
  (dealer = small blind) is consistent, no conflict -> `blind: big_blind` (robot's
  blind role).
- **Community cards**: all five central board cards are face-down -> preflop,
  `community_cards: []`.
- **Showdown**: both hole-card pairs are face-down and normally positioned (no
  fold/muck displacement toward the board) -> `showdown_outcome: not_showdown`.
- **Scene stability**: s22 and s23 show the same hand position, same chip/card
  layout -> `scene_stable: true`.
- **Chips**: counted unfolded chip faces by color in each player's inventory
  band, per `CHIP_RECOGNITION.md`. The robot's bottom-right brown (100) group
  and the opponent's top-right group (including a lone red chip at the extreme
  corner) are partly cropped by the camera housing/robot arm, so those counts
  are approximate and flagged uncertain.
- **Bets**: the betting lane between each player's hole cards and the central
  board is empty felt in this frame -> both `my_current_bet` and `opponent_bet`
  read as all-zero. Flagged uncertain since this is a blind-posted preflop spot
  where bet chips might otherwise be expected in that lane, but none are
  visible there.
- **loop_stage**: chosen as `idle` (hand settled, no atom in progress, awaiting
  the next poker decision). Flagged uncertain because there is no
  `action_sequence.json` to confirm whether a more specific `atom_idle` label
  would be more precise under this harness's conventions.

## Output Files

- `visual_raw/native.md` — full plain-language perception notes per guideline
  response styles.
- `visual_summary.json` — structured summary per the required schema.
- `eval_report.md` — this file.

All three files were verified to exist after writing.
