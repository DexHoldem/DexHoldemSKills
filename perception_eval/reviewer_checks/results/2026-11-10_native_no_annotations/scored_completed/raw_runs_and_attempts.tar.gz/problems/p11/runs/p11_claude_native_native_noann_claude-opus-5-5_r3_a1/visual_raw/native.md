# Raw perception — s23 (s_current)

Context: action_sequence.json, hole_card_cache.json and sN-1/01_parsed_state.md are NOT present in the workspace. Compared s23 against s22 (previous) and s0 (initial reference).

## Scene stability
Stable. s22 and s23 are visually identical (hand pose, cards, chips, buttons unchanged). The opponent is seated and is not touching the table.

## Robot behavior
The dexterous hand is extended over the upper-right of the table, with its fingertips resting on or just above the opponent's green/brown inventory chips (top seat, ~x 1000-1250, y 450-500). It is not in the true initial pose seen in s0, where the hand was raised higher and further right. It holds no card or chips. It has not moved between frames, so it is settled in a near-idle pose that occludes part of the opponent's inventory and part of the upper-right board lane. No disturbed layout is visible. Recommend `reset_to_init` before the next precise parse.

## Turn
It is our turn. The white "Your Turn" button is at the bottom-left robot seat.

## Blinds
The white DEALER button and blue SMALL BLIND button are at the top/opponent seat. The yellow BIG BLIND button is at the bottom/robot seat. The robot is the big blind.

## Community cards
Five card backs lie in the board row and none are face-up, so there are 0 readable community cards (preflop).

## Robot hole cards
Two face-down cards in the robot hole-card area. No card is held.

## Robot inventory (bottom)
- Red 5: 4
- Blue 10: 3 (s0 had 4; one has moved to the bet area)
- Green 50: 4
- Brown 100: 3 clearly visible plus 1 likely under the robot arm edge (~x1400-1480, y670-690) = 4. Uncertain.

## Opponent inventory (top)
- Red 5: 3 (s0 had 4)
- Blue 10: 4
- Green 50: about 4. Fingertips partly occlude this group, so the count is uncertain.
- Brown 100: about 4. Partly occluded, so the count is uncertain.

## Bets
- My bet, left end of the board lane: one blue 10-chip.
- Opponent bet, right end of the board lane: one red 5-chip partly visible at the board edge near the club marking (~x1345, y568). It is mostly occluded by the robot body, so the count is uncertain. It matches the opponent's missing red chip (small blind 5).

## Showdown
Not a showdown. Opponent cards are face-down in their normal slots, with no fold or muck signature.
