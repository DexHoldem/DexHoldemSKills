# Perception Evidence - s23

- **Loop Stage**: acting
- **Blind Status**: big_blind (confirmed by BIG BLIND chip)
- **Scene Stability**: Stable.
- **My Turn**: Yes ("Your Turn" marker present).
- **Community Cards**: No cards flipped (all face down).
- **My Chips**:
  - 5: 3 (red)
  - 10: 2 (blue)
  - 50: 0
  - 100: 0
- **Opponent Chips**:
  - 5: 4 (red)
  - 10: 2 (blue)
  - 50: 0
  - 100: 0
- **My Bet**: 0
- **Opponent Bet**: 0
- **Showdown**: Not showdown.
