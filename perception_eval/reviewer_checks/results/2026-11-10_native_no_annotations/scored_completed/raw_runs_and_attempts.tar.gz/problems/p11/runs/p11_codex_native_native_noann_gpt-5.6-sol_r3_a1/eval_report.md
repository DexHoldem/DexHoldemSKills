# Perception evaluation report

The current frame was merged from direct visual evidence, a stability comparison with `s22`, and earlier captures used only to disambiguate the partly occluded opponent chip zones. The current and previous frames are unchanged, the robot is settled after an apparently successful blue-chip transfer, and the white turn button is at the robot seat. This supports `scene_stable: true`, `loop_stage: atom_idle`, and `is_my_turn: true`.

The visible yellow big-blind button assigns the robot `big_blind`. No face-up board cards or showdown evidence is present. Inventory and bet accounting is consistent with one robot blue 10-chip moved from inventory to the left betting area and one opponent red 5-chip moved from inventory to the right betting area. The robot occludes part of the opponent-side area, so `opponent_chips` and `opponent_bet` are flagged uncertain while retaining concrete best estimates.

The named workflow/cache/prior-state context files were absent, so no durable fields were inherited from them. This specifically makes `loop_stage` contextual rather than fully confirmed; the settled post-transfer pose is classified as `atom_idle`. No robot or poker action was selected or executed.
