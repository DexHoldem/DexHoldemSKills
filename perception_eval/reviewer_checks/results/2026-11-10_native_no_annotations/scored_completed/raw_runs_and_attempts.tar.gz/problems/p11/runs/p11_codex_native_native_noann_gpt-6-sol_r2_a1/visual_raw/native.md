# Raw visual perception

Observed `s_current/00_capture.jpg` (the latest capture, `s23`) and compared it with `s22/00_capture.jpg`; `s0/00_capture.jpg` helps identify chips hidden by the robot. The named action-sequence, hole-card cache, and previous parsed-state files are absent from this workspace.

- The bottom/robot seat has the yellow BIG BLIND button and the white Your Turn button. The white DEALER button is on the top/opponent side, so the robot is big blind and it is the robot's turn.
- Five shared board positions show card backs, not face-up community cards. Both players' two hole cards remain face-down in their normal seat zones. No visible fold, showdown, or outcome.
- Robot inventory at the bottom: four red 5 chips, three blue 10 chips, four green 50 chips, and about four brown 100 chips. Three brown chips are visible; the camera body hides the fourth chip's expected position, which was visible in `s0`.
- Opponent inventory at the top: three red 5 chips, four blue 10 chips, about four green 50 chips, and about four brown 100 chips. Three green and three brown faces are visible; the dexterous hand occludes the expected fourth face in each group. These are inferred from `s0` and should be treated as uncertain.
- Robot betting area, left of the shared board: one blue 10 chip, no other visible bet chips. Opponent betting area, right end of the shared board: one red 5 chip, partly hidden by the camera body, and no other visible bet chips. The red bet count is less certain due to occlusion, but the opponent's red inventory has one fewer chip than in `s0`.
- The robot hand is extended near the opponent chip area, close to its near-idle pose and not visibly carrying a card or chip. `s22` and `s23` show no discernible hand or table-object movement. The camera/hand occludes parts of the right board edge and chip inventories. No displaced cards or scattered chips are evident. The scene appears settled.
