# Eval Report — Visual Perception Step

## Image Compared
- Current: `s_current/00_capture.jpg`
- Previous: `s23/00_capture.jpg`

---

## Key Findings

| Field | Value | Confidence |
|---|---|---|
| scene_stable | true | High — both frames are essentially identical; robot hand in near-idle pose |
| is_my_turn | true | High — white "Your Turn" button clearly visible at bottom-left (robot seat) |
| blind | big_blind | High — BIG BLIND yellow button at robot seat; DEALER blue button at opponent seat |
| loop_stage | acting | High — stable scene, our turn, no robot motion in progress |
| showdown_outcome | not_showdown | High — no face-up cards for comparison visible |
| community_cards | [] | High — all cards in center strip are face-down (blue backs); preflop |

---

## Chip Counts

**Robot inventory** (bottom area, excluding bet zone):
- 4 red (5), 3 blue (10), 2 green (50), 1 brown (100)
- Confidence: medium — brown chip partially occluded; cluster sizes estimated from visible chip faces

**Opponent inventory** (top area, excluding bet zone):
- 3 red (5), 4 blue (10), 2 green (50), 1 brown (100)
- Confidence: medium — right portion of opponent area partially obstructed by robot arm in upper-right corner of frame

**My current bet** (center-left of community cards):
- 1 red (5), 2 blue (10), 0 green, 0 brown
- Confidence: medium — consistent with big blind posting; exact count uncertain

**Opponent bet** (center-right of community cards):
- 1 red (5), 0 blue, 0 green, 0 brown
- Confidence: medium — consistent with small blind posting; partial occlusion from robot arm

---

## Inheritance / Inference

- No previous `01_parsed_state.md` files found in state directories; no inherited fields.
- No `action_sequence.json` or `hole_card_cache.json` available (noted as missing in preflight warnings).
- All chip counts derived from direct visual inspection of `s_current/00_capture.jpg`.
- Bet amounts are consistent with standard blind structure (SB=5, BB=10 at 5-chip denomination).

---

## Uncertain Fields

`my_chips`, `opponent_chips`, `my_current_bet`, `opponent_bet` — all chip counts are estimates from a single viewpoint with partial occlusions. Denominations 50 and 100 have the most uncertainty.
