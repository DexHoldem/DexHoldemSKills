# Native Visual Perception — s_current (s23)

## Scene overview
Texas Hold'em table, human opponent seated opposite (top of frame), robot arm on right side of frame is extended over the table reaching toward the opponent's card / chip area. Capture is NOT fully stable (robot mid-motion visible), but table-level markers and chip stacks are legible.

## Markers
- "Your Turn" white hemisphere chip: present on my (bottom) side, near my chip stack on the left → **is_my_turn: true**.
- "BIG BLIND" yellow button: on my (bottom) side in the bet area → **blind: big_blind**.
- "DEALER" white button: on opponent (top) side.
- "SMALL BLIND" blue button: on opponent (top) side.
- Heads-up consistency: dealer+SB on opponent = BB on me. ✓

## Community cards
Five card positions in the middle row all show face-down card backs (blue/gray diamond pattern). No face-up community cards visible.
- **community_cards: []** (pre-flop)

## Hole cards
- Two face-down card backs in front of opponent (top).
- Two face-down card backs in front of me (bottom).
- Robot arm obscures right side of opponent's cards; no face-up reveal.

## Bets
- A single "10" chip sits in the community/dealer-line area on the left side — ambiguous whether this is a pushed-in bet or layout. Treated as part of posted blinds area.
- My bet area (in front of BIG BLIND marker): no clearly separated bet chip stack — blinds may already be pushed in; estimate BB (10) posted.
- Opponent bet area: SB (5) posted estimated.
- Marking bets as uncertain due to robot occlusion and ambiguous bet-line chips.

## Chip stacks (counts of each denomination)

### My chips (bottom row, excluding bet area)
- Leftmost stack: ~4 red "5" chips.
- Middle-left stack: ~3 "5" chips mixed with stack of ~3 "10" blue chips.
- Right side: stack of ~3 "50" chips (green/purple), one "100" chip.
- Estimate: {"5": 4, "10": 3, "50": 3, "100": 3}

### Opponent chips (top row)
- Leftmost: stack of ~4 red "5" chips.
- Middle: stack of ~3 "10" chips plus a few "5".
- Right side: stack of ~3 "50" chips and a "100" chip (right end).
- Estimate: {"5": 4, "10": 4, "50": 3, "100": 3}

## Scene stability
Robot arm clearly mid-motion over opponent's area → scene is NOT fully stable. However, chip layout, marker positions, and card positions are all readable.
- **scene_stable: false**

## Showdown
No face-up community board, no face-up hole cards. Not a showdown.
- **showdown_outcome: not_showdown**

## Loop stage
- "Your Turn" marker present, pre-flop, BB on my side, robot arm appears to be returning/moving (no action confirmation marker visible).
- Best fit: **acting** (my turn to act, pre-flop).

## Uncertain fields
- scene_stable (robot in motion)
- my_current_bet, opponent_bet (occlusion + ambiguous bet-line chip)
- Chip counts (approximate due to perspective/stacking)
