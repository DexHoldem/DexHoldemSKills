# Eval Report — Native Perception

## Context found

No `action_sequence.json`, `hole_card_cache.json`, or prior
`sN-1/01_parsed_state.md` exist anywhere in this workspace (only
`sN/00_capture.jpg` images for s0-s23, and `s_current` symlinked to `s23`).
This perception step is therefore a cold-start visual read with no prior
parsed-state fields to inherit; every field below comes from the image
itself.

## Evidence -> field mapping

- **Scene stability**: `s22/00_capture.jpg` and `s23/00_capture.jpg` are
  effectively identical (same hand pose, same chips/cards) -> `scene_stable:
  true`.
- **Turn detection**: white "Your Turn" button at the robot-side
  lower-left -> `is_my_turn: true`.
- **Blind**: yellow "BIG BLIND" button on the robot/bottom side; white
  "DEALER" + blue small-blind button together on the opponent/top side ->
  `blind: big_blind` for the robot.
- **Community cards**: all five board slots show face-down card backs, no
  face-up cards -> `community_cards: []` (preflop).
- **Showdown**: no face-up hole cards, no fold/muck signature ->
  `showdown_outcome: not_showdown`.
- **Loop stage**: stable scene, robot's turn, rest-pose hand, no
  failure/recovery/showdown signal -> `loop_stage: idle`.
- **Chips**: counted by denomination cluster per `CHIP_RECOGNITION.md` and
  `BET_RECOGNITION.md` zones; see `visual_raw/native.md` for the per-cluster
  breakdown.

## Uncertainty / merging notes

- `opponent_chips` (all denominations, especially the upper-right cluster)
  and `my_chips.100` are uncertain: that part of the table is partially
  occluded by the dexterous hand/camera housing at the right edge, and chips
  are stacked diagonally with overlapping faces.
- `opponent_bet` is uncertain for the same robot-hand-occlusion reason on
  the right side of the community-card row; no confidently separable bet
  chips were seen there, so it is reported as all-zero but flagged
  uncertain rather than asserted confidently.
- `my_current_bet` (one blue/10 chip, left of the board) was clearly visible
  and is not flagged uncertain.
- No fields were inherited from a previous parsed state because none
  exists; all values are fresh visual estimates, so none are marked
  "inherited" — the `uncertain_fields` list reflects only occlusion/overlap
  uncertainty, not inheritance.

## Outputs written

- `runs/p11_claude_native_native_noann_claude-sonnet-5_r1_a1/visual_raw/native.md`
- `runs/p11_claude_native_native_noann_claude-sonnet-5_r1_a1/visual_summary.json`
- `runs/p11_claude_native_native_noann_claude-sonnet-5_r1_a1/eval_report.md` (this file)
