# Native Visual Perception — s23/00_capture.jpg

Context note: no `action_sequence.json`, `hole_card_cache.json`, or
`sN-1/01_parsed_state.md` files exist anywhere in the working tree (checked
s0 through s23). This perception is therefore based entirely on the current
and previous raw captures, with no durable/cached fields to inherit.

## Scene Stability (vs s22/00_capture.jpg)

Stable. Compared `s22/00_capture.jpg` and `s23/00_capture.jpg` (also spot
checked `s21/00_capture.jpg` for broader context). The two most recent frames
are visually identical: the dexterous hand is extended over the table toward
the upper-right chip area in the same position in both frames, not blurred,
not holding a card or chips, and no card or chip changed position. The human
opponent is seated normally with no arm on the table. No human interference or
robot motion is visible between frames. The latest frame is clear enough to
use.

## Robot Behavior

The dexterous hand enters from the right side of the frame and is extended
over the table near the top-right area, close to the opponent's far-right
inventory chip group (not over the central betting lane or either hole-card
area). It is not holding a card or chips, is not near its true initial pose,
but is not moving (identical across the last two captures) and does not
appear stuck, pressing, or pinning anything. No action-sequence intent was
provided (file does not exist), so this is read as a settled near-idle pose
rather than a mid-atom pose. No human-help condition is visible.

## Turn Detection

It is our turn. A white button reading "Your Turn" is near the bottom/robot
seat area (lower-left of the board, next to the table position number "6"),
not on the opponent/top side.

## Blind / Button Recognition

Dealer/small blind is at the opponent seat (top side): a white "DEALER"
button and a blue "SMALL BLIND" button both sit in the opponent's hole-card
band, next to each other. A yellow "BIG BLIND" button sits in the robot/player
seat area (bottom side), next to the table position number "5". This matches
the two-player rule (dealer = small blind) with no conflict: opponent is
dealer/small blind, robot is big blind.

## Community Cards

No community cards are visible. Five cards lie face-down in the central
board row between the two seat areas; none are turned face-up. This reads as
preflop (0 revealed community cards).

## Hole Cards

Both players' hole cards are face-down and in their normal zones:
- Opponent (top) hole cards: two face-down cards flanking the
  SMALL BLIND/DEALER buttons, in the upper hole-card band.
- Robot (bottom) hole cards: two face-down cards flanking the BIG BLIND
  button, in the lower hole-card band.
Neither side shows a fold/muck signature (no hole cards displaced toward the
community-card lane).

## Showdown / Outcome

Not showdown. Opponent hole cards are face-down (not face-up), and the
robot's hole cards are also still face-down with no cache available. No
outcome comparison is possible or needed; this is a normal pre-decision state,
not an end-of-hand state.

## Chip Recognition (Inventory)

Robot/player inventory (bottom seat, outside the central betting lane):
approximately 4 red 5-chips, 5 blue 10-chips, 3 green 50-chips, and 3 brown
100-chips. The brown 100-chips sit at the far right of the robot's chip row
and are partially cropped by the camera housing in the frame; count is
approximate.

Opponent inventory (top seat, outside the central betting lane):
approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 4 brown
100-chips. The far-right opponent chip group (including a single red chip at
the very top-right corner) is partially cut off by the robot arm/camera
housing; this group's exact count is uncertain.

## Bet Recognition

My current bet area, between my hole cards and the community-card row: no
chips visible.

Opponent bet area, between the opponent's hole cards and the community-card
row: no chips visible.

The felt in both betting lanes (the band immediately around the central board
row) is empty in this frame; all visible chip groups sit within each player's
hole-card band rather than in the betting lane, so both current bets read as
zero. This is noted as a soft uncertainty because it is a preflop/blind-posted
state and blind chips are sometimes expected in the bet lane, but none are
visually present there.
