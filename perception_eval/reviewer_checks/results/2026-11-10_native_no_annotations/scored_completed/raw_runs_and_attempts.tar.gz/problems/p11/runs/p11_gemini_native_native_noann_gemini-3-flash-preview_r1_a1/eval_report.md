# Perception Evaluation Report

## Evidence Summary
- **Current Scene**: `s_current` (linked to `s23`).
- **Stability**: Confirmed stable by comparing `s22` and `s23`. The robot hand is settled.
- **Turn**: Confirmed robot turn via "Your Turn" button at the bottom-left.
- **Blinds**: Robot is the big blind; opponent is the dealer/small blind.
- **Board**: Preflop stage. 0 community cards visible.
- **Chips**: 
    - Robot: 4/3/3/3 (Red/Blue/Green/Brown)
    - Opponent: 4/4/3/3 (Red/Blue/Green/Brown)
- **Bets**: No active bets visible in the betting lanes.

## Context Merging
- **Context Files**: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` were not found in the workspace.
- **Inference**: Visual evidence was used exclusively. Since no previous state was found, all fields were derived from the current image. The loop stage is set to `idle` as it is the robot's turn to act in a stable scene.
