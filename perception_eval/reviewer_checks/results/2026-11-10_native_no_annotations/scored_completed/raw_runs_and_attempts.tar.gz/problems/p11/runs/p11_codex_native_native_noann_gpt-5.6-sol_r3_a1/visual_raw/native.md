# Raw visual perception

Source: `s_current/00_capture.jpg` (`s23/00_capture.jpg`). Stability comparison: `s22/00_capture.jpg`; the robot and table objects are visually unchanged between the two frames.

- Scene/robot: Stable. The dexterous hand is settled near its rest/near-idle pose at the upper-right and is not holding a card or chip. No blur, active transfer, stuck contact, scattered chips, moved card, or unsafe physical failure is visible. The robot body partly occludes the opponent-side/right betting and inventory zones. Earlier frames show the blue chip transfer, and the settled result appears physically successful, so this is an `atom_idle`-compatible post-atom state.
- Turn: It is our turn. The white `Your Turn` button is clearly at the bottom-left robot seat.
- Blinds: The yellow `BIG BLIND` button is at the bottom/robot seat. The white dealer button and blue small-blind button are at the top/opponent seat. Robot blind assignment is therefore `big_blind`.
- Community cards: No face-up community cards are visible. The five hatched rectangles in the center are printed card positions on the felt, not dealt cards.
- Robot/player inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top seat: best estimate 3 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The robot partly occludes the green/brown side; the count is supported by the unobstructed initial layout and the single red chip now in the opponent bet area.
- Robot/player current bet, left of the community-card row: one blue 10-chip; no red, green, or brown bet chips.
- Opponent current bet, right of the community-card row: best estimate one red 5-chip; no blue, green, or brown bet chips. The red chip is only partly visible beside/under the robot-side occlusion, so this field is low confidence.
- Showdown: No player has face-up hole cards, no moved/mucked opponent cards are in the board lane, and there is no showdown evidence. Outcome is `not_showdown`.

Context note: `action_sequence.json`, `hole_card_cache.json`, and a prior `01_parsed_state.md` are not present in this workspace snapshot. No hole-card value or poker action was inferred. `loop_stage`, `opponent_chips`, and `opponent_bet` are marked uncertain because the first lacks workflow context and the latter two involve occlusion/inference.
