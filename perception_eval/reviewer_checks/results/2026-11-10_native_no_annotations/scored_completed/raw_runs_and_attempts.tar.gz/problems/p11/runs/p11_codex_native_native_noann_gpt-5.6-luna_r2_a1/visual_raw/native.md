# Raw visual perception

- Capture path requested: `s_current/00_capture.jpg` (not present); latest available numbered capture inspected: `s23/00_capture.jpg`.
- Scene: two-player Texas Hold'em table; table layout is stable relative to `s22/00_capture.jpg`.
- Robot/player side is the bottom of the image. The white `Your Turn` button is visible near the lower-left robot seat, so it is my turn.
- The yellow `BIG BLIND` button is on the robot/player side; blind is big blind.
- No face-up community cards are visible. The central board cards are face-down backs and are not read as community-card values.
- No showdown evidence: opponent cards are not face-up and no win/loss result is visible.
- Robot inventory (bottom seat band, excluding blind/turn buttons and betting lane): approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top seat band): approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- No clearly separable current-bet chips are visible in the two betting lanes; the opponent-side lane is partly occluded by the robot apparatus, so the zero opponent-bet read is lower confidence.
- The robotic apparatus is present at the right/top-right but appears settled between the compared frames; it occludes part of the opponent-side table. No card or chip disturbance is evident.

