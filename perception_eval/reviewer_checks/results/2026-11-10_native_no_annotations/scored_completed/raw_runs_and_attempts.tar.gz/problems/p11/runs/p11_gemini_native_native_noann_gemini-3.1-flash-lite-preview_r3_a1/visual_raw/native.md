## Perception Analysis

- **Loop Stage**: The game state is active, waiting for the user to act. The "Your Turn" sign is visible on the robot's side.
- **Blind**: The "BIG BLIND" chip is on the robot's side.
- **Community Cards**: No cards are face-up in the community section.
- **Robot Chips**: 
    - 5s: 3
    - 10s: 2
    - 50s: 0 (or ambiguous)
    - 100s: 0
    (Need to re-examine carefully)
- **Opponent Chips**: 
    - 5s: 3
    - 10s: 2
    - 50s: 0
    - 100s: 0
- **Robot Bet**: 0
- **Opponent Bet**: 0
