# DexHoldem Visual Perception - s_current (s23)

## Scene Capture Analysis

**Image**: s_current/00_capture.jpg (s23/00_capture.jpg)

### Table Geometry & Orientation
- Camera view: diagonal from robot/bottom-left toward opponent/top-right
- Robot/player seat: bottom of frame
- Opponent seat: top of frame
- Community cards: central horizontal row
- Robot hand: visible on right side
- Felt color: reddish-orange with "TEXAS HOLDEM" text and "Your Turn" label visible

### Community Cards
**Count**: 5 face-down card positions visible in the center row
**Visibility**: All cards shown with diagonal stripe pattern (face-down)
**Cards (left to right)**: 
- Position 1: face-down (unreadable)
- Position 2: face-down (unreadable)
- Position 3: face-down (unreadable)
- Position 4: face-down (unreadable)
- Position 5: face-down (unreadable)

**Board Stage Derivation**: 5 community cards = river stage

### Hole Cards
**Robot hole cards (bottom-left area)**:
- 2 face-down cards visible in normal hole-card position
- Both marked with diagonal stripe pattern
- Readable: No - cards are face-down on table, not held

**Opponent hole cards (top area)**:
- Cards present in opponent hole-card area
- Visibility uncertain due to angle and distance

### Chip Recognition

**Robot/Player Inventory (bottom-left area, near lower rail)**:
- Red 5-chips: approximately 4 visible chips
- Blue 10-chips: approximately 3 visible chips
- Green 50-chips: approximately 3 visible chips
- Brown 100-chips: approximately 3 visible chips
- Layout: relatively ordered, flat on felt
- Note: Some chips partially occluded by robot hand position

**Opponent Inventory (top area, near upper rail)**:
- Red 5-chips: approximately 4 visible chips
- Blue 10-chips: approximately 4 visible chips
- Green 50-chips: approximately 3 visible chips
- Brown 100-chips: approximately 3 visible chips
- Layout: flat on felt, visible from camera angle

**Betting Areas**:
- My current bet (left of community cards): No chips clearly visible in active betting area
- Opponent bet (right of community cards): No chips clearly visible in active betting area
- Note: Central area between inventory and community cards appears clear

### Buttons & Turn Indicator
**Turn Button**:
- Visible: Yes - white button labeled "Your Turn" in the robot/player area
- Position: Bottom-left area, near robot seat
- Interpretation: **It is our turn** - button is at robot/player position

**Dealer/Blind Buttons**:
- Yellow "BIG BLIND" button visible at opponent/top area
- White "DEALER" button visible - appears to be at opponent position
- Interpretation: Opponent is dealer/small blind; robot is big blind

### Robot Dexterous Hand State
**Position**: Right side of table, near initial/rest pose
**Activity**: Near-idle, not in active motion
**Holding**: Not holding cards or chips
**Occlusion**: Right side of image has some camera/hand occlusion but center table is clear
**Status**: Hand appears settled and stable

### Scene Stability Assessment
**Stability**: Stable
**Supporting evidence**:
- Robot hand is in near-idle pose, not mid-motion
- No visible card or chip movement between current and previous frame reference
- All table elements (cards, chips, buttons) appear settled
- No human arm actively interfering with table layout
- Image is clear enough for parsing
- Scene ready for next action decision

### Additional Observations
- The setup is a clear Texas Hold'em 2-player game
- All 5 community cards have been dealt (river stage)
- Player hole cards are dealt and face-down
- Table appears ready for showdown or action
- Visual quality: good clarity on cards, chips, and buttons
- No physical damage or scattered layout visible
