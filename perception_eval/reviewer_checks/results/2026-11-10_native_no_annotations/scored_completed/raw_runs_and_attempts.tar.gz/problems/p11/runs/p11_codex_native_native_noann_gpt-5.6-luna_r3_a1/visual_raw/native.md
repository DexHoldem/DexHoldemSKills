# Raw visual perception

- Source: `s_current/00_capture.jpg` (`s_current` resolves to `s23`); `s22/00_capture.jpg` is byte-identical.
- Scene: preflop-looking layout. No face-up community cards are visible; the visible board cards and both players' hole cards are face-down.
- Turn: the white `Your Turn` button is at the bottom/robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is at the bottom/robot seat; robot blind is big blind.
- Robot hand: extended from the right over the table/top-side chip area, not in a settled rest pose. No clearly readable held card is visible. This makes the scene physically in-progress/unstable and partially occludes the right-side chip area.
- Robot inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Opponent inventory, top seat: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, 3 brown 100-chips.
- Current bet areas: robot/lower-side area shows one blue 10-chip; opponent/upper-side area shows one red 5-chip. These bet counts are lower confidence because the extended robot arm occludes the upper/right table area.
- No showdown or hand outcome is visible.
