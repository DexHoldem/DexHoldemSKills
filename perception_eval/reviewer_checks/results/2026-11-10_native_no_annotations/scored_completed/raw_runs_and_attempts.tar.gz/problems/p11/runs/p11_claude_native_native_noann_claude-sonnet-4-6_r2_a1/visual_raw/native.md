# Raw Perception Evidence — s_current/00_capture.jpg

## Turn Detection
The white "Your Turn" button is clearly visible at the bottom-left of the table, in the robot/player seat area. It is our turn.

## Blind Button Recognition
The yellow "BIG BLIND" button is visible near the bottom (robot/player) seat area, to the right of center. The blue "DEALER" button is visible in the upper-middle area of the table, on or near the opponent side. By the two-player rule (dealer = small blind, other = big blind), the dealer/small blind is at the opponent seat and the robot is the big blind.

## Scene Stability
The robot arm is visible in the upper-right portion of the frame. The dexterous hand appears to be in a near-idle resting position — not actively grasping, lifting, or moving cards or chips. No cards or chips appear to be in mid-transfer. The scene appears stable. No previous state image is available to compare, but the hand pose is consistent with an idle state.

## Community Cards
No face-up community cards are visible in the shared board area. The center area shows what appear to be face-down blue-backed cards in the community card lane, but none are face-up and readable. This corresponds to preflop (0 community cards revealed).

## Chip Inventory — Robot/Player (bottom seat)

Looking at the bottom area of the table:
- Red 5-chips: approximately 4 chips visible in the center-left cluster
- Blue 10-chips: approximately 3 chips visible in the center-left cluster
- Green 50-chips: approximately 1 chip visible near the bottom-right area (chip labeled "05" partially visible)
- Brown 100-chips: approximately 1 chip visible near the bottom-right edge (chip labeled "001" partially visible)

The 50 and 100 counts are uncertain due to the right edge of the frame and limited visibility.

## Chip Inventory — Opponent (top seat)

Looking at the top area of the table (partially occluded by the robot arm):
- Red 5-chips: approximately 4 chips visible (uncertain — robot arm partially obscures this area)
- Blue 10-chips: approximately 4 chips visible (uncertain)
- Green 50-chips: approximately 3 chips visible (uncertain)
- Brown 100-chips: approximately 3 chips visible (uncertain)

Opponent inventory counts are approximate because the robot arm partially occludes the top-right area.

## Bet Areas

**My current bet (left of community cards):**
In the center-left betting zone, I can see approximately 1 blue 10-chip. This is consistent with the big blind bet of 10. No red, green, or brown chips visible in this area.

**Opponent bet (right of community cards):**
In the center-right betting zone, I can see approximately 1 red 5-chip. This is consistent with the small blind bet of 5. No blue, green, or brown chips clearly visible. Count is uncertain due to partial robot arm occlusion of the opponent's side.

## Showdown Outcome
No opponent hole cards are face-up. No showdown is in progress. The hand appears to be in a standard preflop acting state.

## Loop Stage Assessment
- "Your Turn" marker is at robot seat: active turn confirmed
- Scene appears stable (robot hand near idle)
- No showdown in progress
- Assessment: `acting`
