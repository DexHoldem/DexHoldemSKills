# Raw visual perception

Source: `s_current/00_capture.jpg` (`s23/00_capture.jpg`). For stability, it was compared with `s22/00_capture.jpg`; the files are byte-identical.

- Geometry: robot/player seat is at the bottom; opponent seat is at the top. The five patterned rectangles across the center are printed board placeholders, not dealt cards.
- Stability and robot: stable. The dexterous hand is settled in a near-idle pose over the upper-right/opponent chip region. It is not visibly holding a card or chip, and no blur or object movement is visible. The hand/camera assembly partly occludes the opponent's right-side inventory and the extreme right betting lane; no disturbed layout, dropped card, or unsafe contact is evident.
- Turn: the white `Your Turn` button is clearly at the bottom-left robot seat, so it is the robot/player's turn.
- Blind: the yellow `BIG BLIND` button is at the bottom robot seat. The white `DEALER` button is at the opponent seat, consistent with the opponent being dealer/small blind and the robot being big blind.
- Community cards: none. The center row has no face-up dealt cards.
- Robot/player inventory (bottom): 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top): best visible estimate is 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The green/brown side is partly occluded by the dexterous hand, so the opponent inventory estimate is lower confidence.
- Robot/player current bet (left of the community-card row): one blue 10-chip; no red, green, or brown bet chips visible.
- Opponent current bet (right of the community-card row): best estimate is one red 5-chip at the extreme right edge; no blue, green, or brown bet chips visible. This bet is partly occluded by the robot/camera assembly and is lower confidence.
- Held cards/showdown: both players' hole cards remain face-down. No readable held card is visible, the opponent has not exposed or visibly mucked their cards, and there is no showdown evidence.
- Workflow context: `action_sequence.json`, `hole_card_cache.json`, and the prior `01_parsed_state.md` are absent from this workspace. Therefore `loop_stage=idle` is inferred from the stable, settled, ready-to-act table rather than merged from workflow context.

