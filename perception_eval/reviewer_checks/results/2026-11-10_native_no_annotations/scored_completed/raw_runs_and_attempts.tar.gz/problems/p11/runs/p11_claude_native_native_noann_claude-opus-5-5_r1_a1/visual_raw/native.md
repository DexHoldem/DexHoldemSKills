# Native perception — s_current/00_capture.jpg

Context: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` are absent from the workspace. Compared s_current against s23 (previous) and s0 (initial layout reference).

## Scene stability
Stable. s23/00_capture.jpg and s_current/00_capture.jpg look the same, with no visible change to the hand, cards, or chips. The dexterous hand sits in its near-idle pose at upper right. It holds no card or chips. Its fingers hang over the opponent's 50/100 inventory chips (upper right) and its body covers the right end of the board and the opponent bet area.

## Turn
It is our turn. The white "Your Turn" button is at the robot seat, lower left (~x390, y795).

## Blind buttons
The yellow BIG BLIND button is on the robot side (~x1070, y720). The white DEALER button and the blue SMALL BLIND button are at the opponent seat. Dealer/small blind is the opponent, so the robot is the big blind.

## Community cards
Five cards sit in the board row, all face-down. No face-up community cards are visible, so this is preflop.

## Hole cards
Two face-down robot hole cards are in the bottom area. Two face-down opponent hole cards are in the top area, in their normal position. The hand is not holding a card. No fold signature and no showdown.

## Robot inventory (bottom)
- Red 5: 4 (x590/680/700/730)
- Blue 10: 3 (x828/843/872). s0 had 4; one blue moved to the bet area.
- Green 50: 4 (x1240/1318/1385/1428)
- Brown 100: 3 clearly visible (x1398 partial, 1466, 1520). The 4th slot (~x1477, y677) is hidden by the robot arm/camera body. s0 had 4 brown and none moved to a bet, so the estimate is 4 (uncertain).

## Opponent inventory (top)
- Red 5: 3 (x552/557/567). s0 had 4; the outer one at ~x480 is gone, and it is presumably the small-blind bet.
- Blue 10: 4 (x640/655/672/745)
- Green 50: 3 clearly visible plus 1 partly under the finger (~x1035, y478). Estimate 4 (uncertain).
- Brown 100: 3 visible (x1125/1160/1210), with the top slot ~x1100 partly occluded. Estimate 4 (uncertain).

## Bets
- My current bet (left of the community cards, lower lane): one blue 10-chip (~x480, y650). No other chips.
- Opponent bet (right of the community cards): a chip edge is partly visible at ~x1340, y565, mostly hidden by the robot camera body. It is most likely the single red 5 small blind, consistent with the missing opponent red chip. Uncertain because of occlusion. A `reset_to_init` before relying on the opponent bet count would help.

## Outcome
not_showdown
