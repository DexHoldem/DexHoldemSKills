# Eval Report — s_current

## Evidence Summary
- Turn: "Your Turn" button at robot (bottom) seat → `is_my_turn = true`,
  `loop_stage = acting`.
- Blinds: Robot has yellow BIG BLIND button; opponent has DEALER button
  → `blind = big_blind`. Heads-up: opponent is dealer/SB.
- Street: All five community card slots face-down → preflop,
  `community_cards = []`.
- Bets: Robot shows a "10" chip in the bet area (posted BB = 10). Opponent
  shows a "10" chip (SB completed to call BB). Both bets set to one 10 chip.
- Showdown: no revealed cards or outcome indicator → `not_showdown`.
- Scene: no manipulation in the action region; robot gripper idle →
  `scene_stable = true`.
- Chip stacks: visual estimates with low-to-moderate confidence; flagged as
  uncertain.

## Merging With Prior State
- No `action_sequence.json`, `hole_card_cache.json`, or prior
  `sN-1/01_parsed_state.md` was located in the workspace, so no durable fields
  were inherited. All values were derived from the current image.

## Uncertainties
- `my_chips`, `opponent_chips`: counts estimated from stack height at an
  oblique camera angle; some occlusion by the robot gripper on the opponent's
  right-side 100/50 stacks.
- `opponent_bet`: the opponent-side bet count was inferred from a compact
  chip cluster; one 10 chip is the most likely reading but partial occlusion
  is possible.

## Output Verification
- `visual_raw/native.md` — written.
- `visual_summary.json` — written with concrete values for every field.
- `eval_report.md` — this file.
