# Visual Perception Evidence (native)

## Scene Stability
Stable. Compared s22/00_capture.jpg and s23/00_capture.jpg (via s_current). The robot hand is in a settled, near-idle pose on the right side of the image. No movement of cards or chips is detected between these frames.

## Turn Detection
It is our turn. The white "Your Turn" button is clearly visible in the robot/player seat area at the bottom-left of the table.

## Blind / Button Assignment
Dealer/small blind is at the opponent seat. The robot is the big blind.
- The white DEALER button and blue SMALL BLIND button are located near the opponent seat (top side).
- The yellow BIG BLIND button is located near the robot seat (bottom side).

## Community Cards
No community cards are visible. There are five face-down cards in the central board row.

## Chip Inventories
### Robot/Player Inventory (Bottom)
- Red (5): 4 chips
- Blue (10): 3 chips
- Green (50): 3 chips
- Brown (100): 3 chips
The count is clear and stable.

### Opponent Inventory (Top)
- Red (5): 4 chips
- Blue (10): 4 chips
- Green (50): 3 chips
- Brown (100): 3 chips
The count is clear and stable.

## Current Bets
### Robot Current Bet (Left of Board)
No chips visible in the robot's betting area.

### Opponent Current Bet (Right of Board)
No chips visible in the opponent's betting area.

## Hole Cards
The robot's hole cards and the opponent's hole cards are both face-down and currently unreadable.

## Showdown Outcome
Not a showdown. No face-up hole cards are visible for either player.
