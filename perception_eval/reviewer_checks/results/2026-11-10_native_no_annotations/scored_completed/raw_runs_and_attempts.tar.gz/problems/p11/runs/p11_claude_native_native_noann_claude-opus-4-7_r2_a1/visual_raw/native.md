# Visual Raw Perception — s_current/00_capture.jpg

## Turn Button
The small white "Your Turn" button is on the bottom-left (robot seat) side of
the table. It is our turn.

## Blind Marker
The yellow "BIG BLIND" button is on the robot (bottom) side, and the white
"DEALER" button is on the opponent (top) side. Robot is the big blind;
opponent is the dealer/small blind (heads-up).

## Community Cards
Five face-down card slots are visible in the middle row of the table. No
community cards have been revealed. Street = preflop.

## Hole Cards
Two face-down cards are at the robot seat (bottom) and two face-down cards at
the opponent seat (top). Robot's hole cards are not shown face-up in this
capture.

## Current Bets (chips in front of player, between hole cards and community)
- Robot current bet: one blue "10" chip visible in the robot-side bet area →
  10 (the posted big blind).
- Opponent current bet: a stack in front of opponent that reads as a "10" chip
  (one 10 chip) — appears opponent completed the call to 10.

## Chip Stacks

### Robot stacks (bottom side)
- "5" red/white stacks: two short stacks, about 4 chips total visible.
- "10" blue stack: around 3 chips.
- "50" striped stack: around 3 chips.
- "100" dark stack: around 3 chips.

### Opponent stacks (top side)
- "5" red/white: about 4 chips.
- "10" blue: about 4 chips.
- "50" striped: about 3 chips.
- "100" dark: about 3 chips.

Exact counts are hard to resolve from this camera angle; counts are reasonable
estimates with low-to-moderate confidence.

## Scene Stability
Robot gripper is visible near the top-right of the opponent side but is not
actively manipulating chips in the robot's action region. No blur across chip
stacks. Scene reads as stable for perception purposes.

## Showdown
No community cards revealed, no face-up hole cards, no winner indicator.
Not a showdown.

## Loop Stage
"Your Turn" button present at the robot seat → loop_stage = acting.
