# Native Perception — Raw Visual Evidence

Source image: `s_current/00_capture.jpg`. Compared against `s23/00_capture.jpg`
(the previous capture) for stability. No `action_sequence.json` or
`hole_card_cache.json` were found anywhere in the workspace, and no
`sN-1/01_parsed_state.md` exists, so this parse relies on the image alone.

## Scene Stability

`s23/00_capture.jpg` and `s_current/00_capture.jpg` appear pixel-for-pixel
identical: same robot-hand position (raised, near the right edge, not over
the table), same chip layout, same card backs, same button positions. No
cards or chips moved, no human arm is on the table. Stable.

## Turn Detection

A white button reading "Your Turn" sits at the bottom/robot seat corner
(lower-left of the felt, near the "6" table marker). No turn button is visible
at the opponent/top seat. It is our turn.

## Blind / Button Recognition

- A yellow button labeled "BIG BLIND" sits at the bottom/robot seat band
  (center-right of the robot's side, near the robot hole cards).
- A white button labeled "DEALER" and a blue button (mirrored text, reads as
  a small-blind style label) sit at the top/opponent seat band, both resting
  near/over the opponent's face-down hole cards.
- Two-player rule: dealer/small blind = opponent seat, so the robot is the
  big blind. Consistent with the yellow BIG BLIND marker at the robot seat.

## Community Cards

All five card-shaped slots in the central board row are face-down card backs.
No community cards are face-up. Zero visible community cards -> preflop.

## Hole Cards

- Opponent hole-card area (top/opponent band, center): two face-down cards,
  partially covered by the DEALER/blind buttons. Both face-down, unreadable,
  not moved toward the board lane, so no fold/muck is evident.
- Robot hole-card area (bottom/robot band, center-right): two face-down cards
  next to the BIG BLIND button. Both face-down, not held by the dexterous
  hand, unreadable.
- The dexterous hand is not holding any card in this frame.

## Robot Behavior

The dexterous hand/camera rig is raised and pulled back toward the right edge
of the frame, above and clear of the table surface. It is not touching cards
or chips, is not mid-motion relative to the previous frame, and is not near
any inventory/bet/hole-card zone. This looks like a settled, near-idle/rest
pose; it does not block the opponent betting area or the board in this frame
(the usual right-edge occlusion zone mainly covers deep background, not the
central chip clusters). No action appears in progress, no failure, no
human-help condition.

## Chips

Chips are flat/unfolded on the felt. Colors: red=5, blue=10, green=50,
brown=100. Table markers "9" (top) and "6"/"5" (bottom) are felt position
numbers, not chips or buttons of denomination.

### Robot/player side (bottom band)

- Outer cluster nearest the "Your Turn" corner / rail (left of the robot's
  hole cards): about 5 red (5) chips and 2 blue (10) chips. Read as
  **robot inventory**.
- A second cluster sitting between that outer cluster and the robot's hole
  cards, closer to the board: about 2 red (5) chips and 3 blue (10) chips.
  Positioned in the central betting lane on the robot's side -> read as
  **my current bet**.
- A third cluster on the other side of the robot's hole cards (toward the
  board's right edge): about 3 green (50) chips and 3 brown (100) chips.
  This sits close to the rail-side inventory logic (flanking the hole cards
  away from the bet lane) -> read as additional **robot inventory**.
- Two more face-down cards are visible further right beyond this chip
  cluster, past the normal hole-card slot; these look like extra placeholder
  card backs on the felt, not part of any player's hand, and are not counted
  as hole or community cards.

### Opponent side (top band)

- Outer cluster near the "9" marker (left of the opponent's hole cards):
  about 3 red (5) chips and 2 blue (10) chips. Read as **opponent inventory**,
  low confidence on exact blue count (chips overlap).
- A cluster on the other side of the opponent's hole cards, partially under
  the robot arm/camera housing shadow: looks like about 2 green (50) chips
  and 1 brown (100) chip, with a single red chip visible further right at the
  frame edge. This area is close to the common robot/camera occlusion zone,
  so counts here are **uncertain**.
- No clearly separate opponent "current bet" cluster is visible between the
  outer inventory and the board; if a small blind-sized bet is posted, it is
  not distinguishable from the inventory/button cluster in this frame.
  Treating opponent current bet as not confidently countable -> estimated as
  zero/near-zero, **uncertain**.

## Showdown

No face-up hole cards for either player, no fold/muck signature (both
players' hole-card backs remain in their normal seat positions). Not a
showdown state.
