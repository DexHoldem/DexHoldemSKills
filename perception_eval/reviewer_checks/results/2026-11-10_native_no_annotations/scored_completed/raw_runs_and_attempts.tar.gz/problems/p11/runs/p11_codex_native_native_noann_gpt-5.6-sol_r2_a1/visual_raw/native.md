# Raw visual perception

Source: `s_current/00_capture.jpg`, resolving to `s23/00_capture.jpg`.

- Stability: Stable. Compared `s22/00_capture.jpg` with `s23/00_capture.jpg`; the views are visually unchanged. The dexterous hand is settled near the upper-right/opponent chip area, is not visibly carrying a card or chip, and no card or chip movement is visible. The hand partially occludes the opponent's right-side inventory.
- Turn: The white `Your Turn` button is visible at the bottom-left robot seat, so it is the robot/player's turn.
- Blind: The yellow `BIG BLIND` button is at the bottom robot seat. The blue `SMALL BLIND` button and white dealer button are at the top opponent seat. The robot is big blind.
- Community cards: No face-up community cards are visible. Five face-down card backs occupy the central board row and are excluded from the community-card list.
- Hole cards/showdown: Two face-down robot hole cards remain in the normal bottom-seat area, and two face-down opponent hole cards remain in the normal top-seat area. No cards are face-up, neither pair is visibly mucked toward the center, and there is no visual showdown or fold outcome.
- Robot/player inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top seat: best visual count is 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The right-side green/brown groups are partly occluded by the dexterous hand, so this field is lower confidence.
- Robot/player current bet, left of the community-card row: 1 blue 10-chip; no red, green, or brown bet chips visible.
- Opponent current bet, right of the community-card row: 1 red 5-chip; no blue, green, or brown bet chips visible.
- Robot behavior: settled and safe-looking, with no visible dropped card, scattered chips, pinned object, or other physical failure. Because the dispatched-action context file is unavailable, the visually stable state is classified as `idle` rather than tied to a specific completed atom.

