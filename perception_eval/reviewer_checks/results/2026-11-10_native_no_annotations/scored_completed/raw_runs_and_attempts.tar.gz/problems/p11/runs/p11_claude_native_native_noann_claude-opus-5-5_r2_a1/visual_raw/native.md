# Native perception — s_current/00_capture.jpg

Context: `action_sequence.json`, `hole_card_cache.json`, and any `sN-1/01_parsed_state.md` are absent from the workspace, so there was nothing to inherit. Previous frame s23/00_capture.jpg was used to check stability.

## Scene stability
Stable. I compared s23/00_capture.jpg with s_current/00_capture.jpg and they look the same: no card, chip, or hand movement. The dexterous hand is in a near-idle settled pose at the upper right. One fingertip rests just above the opponent's dark (50) chips and does not hold a card or chips. The hand/camera body covers the right end of the table: the right end of the opponent bet lane, and the top of the robot's right-side chip group.

## Turn
It is our turn. The white "Your Turn" button is at the robot seat, bottom-left (~x 395, y 795).

## Blinds
The white DEALER button and the blue SMALL BLIND button are at the opponent (top) seat. The yellow BIG BLIND button is at the robot (bottom) seat, next to the robot hole cards. So dealer/small blind = opponent, and the robot is the big blind. There is no conflict.

## Community cards
No face-up community cards. There are five face-down card backs laid out in the board row (5 slots), which means the board has not been revealed yet: 0 readable community cards, i.e. preflop. Nothing in the image looks like a muck or fold.

## Hole cards / held card
The robot's two hole cards are face-down at the bottom centre. The opponent's two hole cards are face-down in the normal top slot. The hand is not holding a card.

## Robot inventory (bottom seat)
- Red 5: 4 (left cluster, x~590-735)
- Blue 10: 3 (column x~830-870)
- Green 50: about 4 (dark-faced chips at x~1240, 1318, 1385, 1428). The chip at 1240 is somewhat ambiguous, but its dark face matches the 50s.
- Brown 100: about 3 (x~1465, 1520, plus one partly hidden under the hand at x~1395, y~680)
- The right-side group is partly occluded, so the green/brown counts are uncertain.

## Opponent inventory (top seat)
- Red 5: 3 (left column x~550-565)
- Blue 10: 4 (x~640, 655, 672, 745)
- Green 50: about 3 (x~980, 1018, 1072). The robot fingertip partly covers this area, so there may be a 4th under it.
- Brown 100: 3 (x~1128, 1160, 1210)

## Bets
- My current bet (left of the community row, robot lane): 1 blue 10-chip (~x 480, y 650). This matches the robot posting the big blind.
- Opponent bet (right of the community row): a chip edge with reddish/white rim is visible at ~x 1345, y 568, mostly hidden by the robot hand. Best read: 1 red 5-chip (matches the small blind). Uncertain because the hand covers it.

## Showdown
Not showdown. The opponent's cards are face-down in place, and there are no face-up hole cards and no fold.
