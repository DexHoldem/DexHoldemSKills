# Perception and merge summary

Read all field guidelines and inspected s_current/00_capture.jpg (s23), comparing s22 and the earlier s21, s19, s18, and s0 captures. Current visual evidence indicates a stable, settled post-chip-push pose, robot turn, robot big blind, no readable community cards, and no showdown. The inferred workflow label is atom_idle.

Counts are separated into inventory and left/right betting areas. The robot has one blue 10-chip in its betting area; one red 5-chip is visible in the opponent area. Current visible counts take precedence over older images. Earlier images support occluded inventory estimates: four robot brown chips, and four opponent green and brown chips. The opponent bet area remains partly hidden.

No action_sequence.json, hole_card_cache.json, or previous parsed state was available; there was no structured prior-state merge. Uncertainty is explicitly recorded for loop_stage, both inventories, and opponent_bet. Every schema field has a concrete estimate, with no null values. No robot actions, helper scripts, or poker decisions were executed.
