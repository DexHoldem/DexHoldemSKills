# Visual Perception Evidence

## Scene Stability
Stable. Compared s22/00_capture.jpg and s23/00_capture.jpg. The robot hand is in a near-idle pose and is not moving. All cards, chips, and buttons are stationary.

## Turn Detection
It is our turn. The white "Your Turn" button is near the robot seat at the bottom-left of the table.

## Blind and Dealer
Dealer/small blind is at the opponent seat. The robot is the big blind.
- Dealer button (white) is near the opponent.
- Small blind button (blue) is near the opponent.
- Big blind button (yellow) is in front of the robot.

## Community Cards
No community cards are visible. All five board cards are face-down.

## Chip Counts
### Robot Inventory (Bottom)
- 4 red 5-chips
- 3 blue 10-chips
- 3 green 50-chips
- 3 brown 100-chips

### Opponent Inventory (Top)
- 4 red 5-chips
- 4 blue 10-chips
- 3 green 50-chips
- 3 brown 100-chips

## Betting Areas
- My current bet area (left of community cards): no chips visible.
- Opponent bet area (right of community cards): no chips visible.

## Showdown and Outcome
Not a showdown. All hole cards and community cards are face-down. No player has folded or mucked.
