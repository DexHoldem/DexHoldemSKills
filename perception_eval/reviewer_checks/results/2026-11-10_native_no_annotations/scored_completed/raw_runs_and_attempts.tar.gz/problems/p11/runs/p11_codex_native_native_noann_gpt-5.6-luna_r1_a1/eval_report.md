# Perception evaluation

The current capture supports an idle, stable preflop state: the robot-side
`Your Turn` marker is visible, the robot-side `BIG BLIND` marker is visible,
and no community card is face-up. Inventory chips were counted by color and
denomination, while blind/turn markers and inventory groups were excluded from
the bet counts. The opponent-side betting area is partly occluded by the robot
hardware, so `opponent_bet` is recorded as zero with uncertainty. No showdown
evidence is visible. The requested context files were absent, so no durable
fields were inherited.
