# Native perception evidence

Stable. Compared current s23 (s_current) with s22; the robot hand, exposed chips, cards, and buttons occupy the same positions. In s21 the robot was extended over the left betting lane; in s22 and s23 it has retracted to a settled near-idle pose at upper right. No human hand interferes with the table. Additional references inspected: s19, s18, and s0.

The robot hand is empty, with no readable held card or chip in its fingers. Its body obscures the right betting area and portions of the brown inventory groups. No visible scattered chips, displaced board cards, pinned objects, or settled physical failure. The sequence of images supports a completed chip-push atom: a blue chip previously near the robot inventory is now in the left betting lane. Estimate loop_stage as atom_idle; exact workflow status is uncertain without action_sequence.json.

The white Your Turn button is clearly at the bottom-left robot seat: it is our turn. The yellow BIG BLIND button is at the bottom robot seat. DEALER and SMALL BLIND markers are at the top opponent seat; robot is big blind, with no button conflict.

No face-up community cards are visible. Five patterned rectangular board positions are visible, but no rank or suit is exposed; none supplies a community-card value. Both seats have two face-down hole cards in their normal areas. No visible fold/muck or showdown. No cached hole-card data is available, and no hidden values are guessed. Outcome: not_showdown.

Inventory counts use individual flat chip faces, excluding central bets and labeled buttons. Denomination order is red 5, blue 10, green 50, brown 100.

- Bottom robot inventory: 4 red, 3 blue, 4 green, estimated 4 brown. Three brown faces are at least partly visible; the upper-right portion is hidden by the robot body. Four brown chips are clearly present in s0, and the visible current arrangement is consistent with that count. The brown count is inherited from visual reference, not fully observable now.
- Top opponent inventory: 3 red, 4 blue, estimated 4 green and 4 brown. The fingers overlap the green group and hide part of the brown group; s19 clearly shows four of each in matching positions. These partially occluded counts are supported by that earlier image.
- Robot current bet, left of board: 1 blue 10-chip, no red, green, or brown chips visible.
- Opponent bet, right of board: 1 visible red 5-chip, no other denominations visible. The robot body blocks the rest of this zone, so the estimate of zero additional chips is uncertain.

The requested action_sequence.json, hole_card_cache.json, and previous parsed-state file were not present in the workspace search. s_current resolves to s23, so s22 is the previous capture; s22 contains no parsed-state file. No durable fields were inherited from unavailable structured context.
