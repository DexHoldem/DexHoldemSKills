# Raw visual perception

- Capture: `s_current/00_capture.jpg`.
- Scene: settled table view; robot hardware/hand is at the right side and partially occludes the opponent-side betting region, but there is no visible active card or chip transfer.
- Turn: the white `Your Turn` marker is at the bottom robot/player seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` marker is at the robot/player seat.
- Community cards: no face-up community cards are visible; the central board slots are face-down.
- Robot inventory, bottom seat: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top seat: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Current bets: no chips are visibly placed in the distinct central betting areas; inventory chips and blind/turn markers are excluded.
- Showdown: no face-up hole cards or showdown outcome is visible.
