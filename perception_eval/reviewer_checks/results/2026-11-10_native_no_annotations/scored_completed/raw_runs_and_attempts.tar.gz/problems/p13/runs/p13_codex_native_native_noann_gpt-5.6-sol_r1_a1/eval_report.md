# Perception evaluation

The current capture is visually an in-progress robot atom: relative to `s24`, the hand has lifted away from a chip-contact pose but has not returned to a settled near-idle pose. Accordingly, `scene_stable` is false and `loop_stage` is `acting`.

Direct visual evidence gives robot big blind, robot turn, flop `7d 6s 7c`, both inventory counts, and the two distinct bet zones. The opponent bet is marked uncertain because ongoing robot motion and right-side occlusion make that zone less reliable; the concrete best estimate is two red 5-chips. There is no visual showdown or fold.

No merge from durable context was possible because the named action sequence, hole-card cache, and prior parsed-state file are absent. All output values therefore come from the current capture, with `s24` used only for stability comparison.
