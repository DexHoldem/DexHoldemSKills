# Raw visual perception — s25/00_capture.jpg

- Stability: Unstable. Compared s23, s24, and s25. The dexterous hand moved from a low position over the right betting lane in s24 to a raised, extended position in s25. It has not returned to its settled pose. No card or chip is visibly held. The action appears still in progress; no physical failure is evident.
- Turn: The white "Your Turn" button is at the bottom/robot seat, so it is the robot's turn by the button cue.
- Blind: The white dealer button is at the top/opponent seat. In heads-up play that makes the opponent the small blind and robot the big blind; the yellow BIG BLIND button is also at the robot seat.
- Community cards: Three face-up cards in the shared row, left to right: 7d, 6s, Jc. Two adjacent patterned backs are face-down and are not counted as face-up community cards. The third face-up card rank is slightly hard to read.
- Robot/player inventory, bottom seat: four red 5 chips, three blue 10 chips, four green 50 chips, three brown 100 chips. The brown count appears one lower than s23 because one brown chip is now in the robot bet lane.
- Opponent inventory, top seat: two red 5 chips, four blue 10 chips, three green 50 chips, three brown 100 chips. The boundary of the green and brown groups is somewhat angled, so these are best visible counts.
- Robot current bet, left of the shared row: one blue 10 chip and one brown 100 chip; no red or green chips visible. The brown chip has appeared since s24.
- Opponent bet, right of the shared row: approximately two red 5 chips, one blue 10 chip, no green chips, and one brown 100 chip. The rightmost group is angled; its denomination counts are less certain.
- Showdown: The opponent's two hole cards remain face-down at the top seat, as do the robot's two at the bottom. No fold or face-up showdown is visible. No readable card is held by the robot.
- Context limitation: `action_sequence.json`, `hole_card_cache.json`, and `s24/01_parsed_state.md` are absent from this workspace snapshot. The frame sequence and visible buttons/cards/chips supply the estimates above.
