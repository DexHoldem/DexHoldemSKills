# Raw visual perception

- Current image: `s_current/00_capture.jpg`.
- Stability comparison: the current frame and `s25/00_capture.jpg` show the same settled table layout and the same stationary dexterous-hand pose. The hand is not holding a card or chips, no game object appears in motion, and no human hand is interfering with the table. Scene is stable.
- Robot behavior: the dexterous hand is at the upper-right/right side in a settled near-idle pose. It partly overhangs the opponent-side chip region but does not appear stuck, does not contact an object, and does not show a physical failure.
- Turn: the white button labeled `Your Turn` is at the bottom/robot seat, so it is our turn.
- Blind: the yellow `BIG BLIND` button is at the bottom/robot seat. The white dealer marker is on the top/opponent side, consistent with the opponent being dealer/small blind and the robot being big blind.
- Community cards: three face-up shared cards are visible in the central row, left-to-right `7d`, `9s`, `7c`.
- Hole/showdown evidence: the opponent's two hole cards remain face-down in their normal top-seat area. The robot's two hole cards remain face-down in the normal bottom-seat area. No hole cards are exposed or displaced into the board lane, so there is no showdown or fold/muck signature.
- Robot inventory (bottom seat, excluding bets/buttons): red 5-chips = 4, blue 10-chips = 3, green 50-chips = 4, brown 100-chips = 3.
- Opponent inventory (top seat, excluding bets/buttons): red 5-chips = 2, blue 10-chips = 3, green 50-chips = 3, brown 100-chips = 3.
- Robot current bet (left of the community cards): red 5-chips = 0, blue 10-chips = 1, green 50-chips = 0, brown 100-chips = 2.
- Opponent current bet (right of the community cards): red 5-chips = 2, blue 10-chips = 1, green 50-chips = 0, brown 100-chips = 1.
- Context availability: `action_sequence.json`, `hole_card_cache.json`, and a previous `01_parsed_state.md` are absent from the supplied workspace, so no fields were inherited or merged from those files.
- Uncertainty: the robot hand partly overhangs the opponent-side inventory region, making the opponent inventory counts the least certain visual field; the reported counts are the best visible estimates.
