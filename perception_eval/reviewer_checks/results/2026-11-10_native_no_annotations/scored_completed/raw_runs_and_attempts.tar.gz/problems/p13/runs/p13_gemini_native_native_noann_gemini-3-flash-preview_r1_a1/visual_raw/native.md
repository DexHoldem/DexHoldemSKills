# Visual Perception Evidence - s25

## Table Orientation & Stability
- Robot seat at bottom, opponent seat at top.
- Robot hand is in a near-idle pose on the right, settled and not in motion.
- Scene is stable with no blur.

## Turn Detection
- The white "Your Turn" button is clearly visible at the bottom-left area of the table, near the robot seat.
- **Judgment: it is our turn.**

## Blind Assignment
- Dealer button (white) is at the opponent seat (top).
- Small Blind button (blue) is at the opponent seat (top).
- Big Blind button (yellow) is at the robot seat (bottom).
- **Judgment: Dealer/small blind is at the opponent seat. The robot is the big blind.**

## Community Cards
- Three community cards are face-up in the central board row.
- They are placed in the rightmost three slots (positions 3, 4, 5).
- Card reads (left to right): 7d, 6s, 8c.
- Positions 1 and 2 contain face-down cards.
- **Judgment: Three community cards are visible. They are 7d, 6s, and 8c.**

## Hole Cards
- Robot hole cards: Two face-down cards at the bottom center.
- Opponent hole cards: Two face-down cards at the top center.

## Chip Inventories
- **Robot Inventory (bottom seat area):**
  - Red (5): 4 chips.
  - Blue (10): 6 chips (4 in left cluster, 2 in right cluster).
  - Green (50): 2 chips.
  - Brown (100): 3 chips.
- **Opponent Inventory (top seat area):**
  - Red (5): 2 chips.
  - Blue (10): 3 chips.
  - Green (50): 2 chips.
  - Brown (100): 3 chips.

## Betting Areas
- **My Current Bet (left of community cards):**
  - Red (5): 2 chips.
  - Blue (10): 1 chip.
  - Total: 20.
- **Opponent Bet (right of community cards):**
  - Red (5): 2 chips.
  - Blue (10): 1 chip.
  - Total: 20.

## Robot Behavior
- The dexterous hand is near its initial pose and is not holding a card or chips.
- It is positioned slightly to the right of the betting area and is not occluding any critical game objects.
- The action looks safe to continue.
