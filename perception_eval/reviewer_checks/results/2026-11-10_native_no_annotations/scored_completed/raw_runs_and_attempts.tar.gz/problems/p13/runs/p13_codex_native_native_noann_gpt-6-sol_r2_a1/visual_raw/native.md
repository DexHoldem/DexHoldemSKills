# Raw visual perception — s25/00_capture.jpg

- Compared the current capture with s24/00_capture.jpg and s23/00_capture.jpg. The robot hand has lifted away from the table and is back near its initial upper-right pose. It holds no visible card or chip. No card or chip is visibly moving or disturbed. The current scene appears stable. The human's posture change does not affect the table.
- The white “Your Turn” button is at the lower robot seat. The yellow “BIG BLIND” button is also at the robot seat; the white dealer button is at the upper opponent seat.
- Three face-up community cards are visible, left to right: 7d, 6s, 7c. The two earlier positions in the community-card row remain face-down; they are not counted as visible board cards. Opponent hole cards remain face-down in their normal upper-seat positions. Robot hole cards remain face-down at the lower seat. No fold or showdown is visible.
- Robot inventory, lower seat: 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, 3 brown 100-chips. The fourth original brown chip is now in the left betting area.
- Opponent inventory, upper seat: 2 red 5-chips, 4 blue 10-chips, 3 green 50-chips, approximately 4 brown 100-chips. The right edge of the brown group is partly behind the robot hand, so that count is uncertain.
- Robot current bet, left of the board: 1 blue 10-chip and 1 brown 100-chip; no red or green chips.
- Opponent bet, right of the board: 2 red 5-chips and 1 green 50-chip; no blue or brown chips. The isolated green chip has moved from the upper betting lane to the right side between captures.
- No readable card is held by the robot. There is no visible physical failure or need for recovery.
- The referenced action_sequence.json, hole_card_cache.json, and prior 01_parsed_state.md are absent from this workspace snapshot; no values were inherited from them.
