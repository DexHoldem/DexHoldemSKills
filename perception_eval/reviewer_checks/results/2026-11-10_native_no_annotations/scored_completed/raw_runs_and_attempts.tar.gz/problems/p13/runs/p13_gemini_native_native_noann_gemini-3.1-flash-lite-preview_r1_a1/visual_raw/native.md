# Perception Evidence - Native
- **Stage**: The "Your Turn" chip is present in the robot's area. Stage: acting.
- **Blind**: Big Blind chip is in the robot's area. Blind: big_blind.
- **Showdown**: No showdown outcome visible.
- **My Chips**: 3x100, 3x50, 3x10, 4x5.
- **Opponent Chips**: 3x100, 3x50, 4x10, 4x5.
- **My Bets**: None currently in the pot.
- **Opponent Bets**: None currently in the pot.
- **Community Cards**: 7 of Diamonds, 6 of Spades, 8 of Clubs.
