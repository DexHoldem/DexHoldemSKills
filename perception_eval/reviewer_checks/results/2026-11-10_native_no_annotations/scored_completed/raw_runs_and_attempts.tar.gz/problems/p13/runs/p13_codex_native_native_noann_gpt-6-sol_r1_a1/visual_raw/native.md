# Raw visual perception — s25/00_capture.jpg

Unstable. Compared s23, s24, and s25 captures. The dexterous hand touched a chip near the right side of the board in s24 and is raised and farther back in s25, still away from its settled pose. The hand is empty; no card or chip is visibly held. The layout is countable, but the atom's completion is not yet established. No obvious scattered chips, displaced cards, or pinned object.

- Orientation: robot inventory at the bottom, opponent inventory at the top, community row across the center. Betting areas are kept separate from inventories.
- Board: three face-up shared cards, left to right **7d, 6s, Jc**. Two adjacent face-down cards to their left are not community cards.
- Turn: white "Your Turn" marker sits at the lower-left robot seat. It is the robot's turn by the marker.
- Blind: dealer marker is at the top/opponent seat and the yellow "BIG BLIND" marker is at the bottom/robot seat; robot is big blind.
- Robot inventory: four red 5, three blue 10, four green 50, three brown 100.
- Opponent inventory: two red 5, four blue 10, three green 50, three brown 100.
- Robot bet area, left of the board: one blue 10 and one brown 100; no red or green chips.
- Opponent bet area, right of the board: two red 5, one green 50, and one brown 100; no blue chips. The green/brown distinction in this angled group is less certain than the other counts.
- Both players' hole cards remain face-down. No fold or showdown is visible. The robot hand is still in progress, so no outcome or recovery judgment is warranted.

The named prior workflow and parsed-state context files were not present in this workspace. This read uses the current image for all fields and earlier images only for visual motion comparison.
