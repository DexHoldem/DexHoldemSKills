# Native visual evidence

Current image: `s_current/00_capture.jpg`, resolving to `s25/00_capture.jpg`. Compared with `s24`, `s23`, and the initial/rest-pose reference `s0`.

Stable, best visual estimate. In s24 the robot hand is low over a brown chip near the lower-right board area; in s25 it has returned to the elevated, empty rest pose seen in s0. The latest image shows no contact with cards or chips, no visible transport, and no human interference. Chips have changed position since s24, but the current pose supports completed movement rather than ongoing manipulation. Only one final rest-pose capture is available, so stability remains an estimate.

Robot behavior: the dexterous hand enters from the right, elevated above the table, with no card or chip visibly held. The right-side housing obscures the far-right table edge, but the visible inventory and betting groups are countable. No visible dropped card, pinned object, or disordered chip group. The best workflow label is `atom_idle`, inferred from the transition from manipulation to rest; dispatch context is unavailable.

Turn: it is our turn. The white Your Turn button is at the bottom-left robot seat.

Blinds: the yellow BIG BLIND button is at the bottom robot seat. The white DEALER and blue SMALL BLIND buttons are at the top opponent seat. Robot is big blind, opponent is dealer/small blind; no conflict.

Community cards: three face-up cards, left-to-right `7d`, `6s`, `7c`. Two other central cards remain face-down and are excluded from the face-up community-card array. These face-down board positions were already present in s0; they are not evidence of a muck.

Robot inventory at the bottom seat: four red 5-chips, three blue 10-chips, four green 50-chips, three brown 100-chips. The four greens form two upper faces and two descending faces beside the right hole card. Counts exclude all chips in the central betting lane.

Opponent inventory at the top seat: two red 5-chips, four blue 10-chips, three green 50-chips, three brown 100-chips.

Robot current bet, left of the board: zero red, one blue, zero green, one brown chip.

Opponent bet, right of the board: two red, zero blue, one green, one brown chip. All four visible faces are separate from the top-seat inventory and from buttons.

Showdown: both players' two hole cards remain face-down in their normal seat areas. No readable held card, revealed opponent hand, or fold/muck signature is visible. Outcome is `not_showdown`; no hole-card values are guessed.

Context availability: `action_sequence.json`, `hole_card_cache.json`, and `s24/01_parsed_state.md` are absent from the supplied workspace. No durable fields were inherited. Uncertainty applies to `loop_stage` (workflow inference) and `scene_stable` (single final rest-pose frame after visible changes).
