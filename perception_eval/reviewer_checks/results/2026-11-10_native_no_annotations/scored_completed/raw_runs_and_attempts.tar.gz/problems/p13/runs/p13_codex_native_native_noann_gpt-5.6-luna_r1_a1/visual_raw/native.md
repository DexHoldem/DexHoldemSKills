Capture used: `s_current/00_capture.jpg` (latest state `s25`).

Scene: stable, clear settled frame. The dexterous hand/robot hardware is parked at the upper-right and partially occludes the far-right table area, but no card or chip motion is visible.

Turn/blind: the white `Your Turn` button is at the bottom robot seat, so it is the robot's turn. The yellow `BIG BLIND` button is at the robot seat.

Community cards: three face-up cards, left to right: 7d, 6s, 9c. The two face-down cards below are robot hole cards and are not guessed; the two face-down cards above are opponent hole cards and are not guessed.

Inventories: robot/bottom inventory is approximately four red 5-chips, three blue 10-chips, three green 50-chips, and three brown 100-chips. Opponent/top inventory is approximately four red 5-chips, four blue 10-chips, three green 50-chips, and three brown 100-chips. The right-side inventory/betting region is partly occluded, so counts there are lower-confidence.

Bets: robot-side betting area left of the community cards shows one blue 10-chip and one brown 100-chip. Opponent-side betting area right of the community cards shows an approximately four-chip mixed group, best read as three red 5-chips and one blue 10-chip; this count is uncertain because the robot hardware occludes the right edge.

Outcome: no showdown or fold evidence; `not_showdown`.
