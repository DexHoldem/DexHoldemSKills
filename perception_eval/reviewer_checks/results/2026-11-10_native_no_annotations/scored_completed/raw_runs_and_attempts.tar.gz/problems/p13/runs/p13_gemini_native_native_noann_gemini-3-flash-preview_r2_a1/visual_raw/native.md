# Perception Evidence - s_current/00_capture.jpg

## Robot Behavior and Scene Stability
- The robot dexterous hand is in a near-idle pose, not holding any cards or chips.
- No movement is visible; the scene appears stable.
- The white "Your Turn" button is located at the bottom-left of the table, near the robot seat.
- Conclusion: Stable, it is the robot's turn.

## Board State
- Community cards: Three face-up cards are visible in the central row.
  - Card 1 (left): 7 of diamonds (7d)
  - Card 2 (middle): 6 of spades (6s)
  - Card 3 (right): 8 of clubs (8c)
- Board stage: Flop.
- Showdown: No hole cards are face-up. Opponent hole cards are face-down in the top area. Robot hole cards are face-down in the bottom area.

## Blind Assignment
- Dealer button (white): At the opponent seat.
- Small Blind button (blue): At the opponent seat.
- Big Blind button (yellow): At the robot seat.
- Conclusion: Robot is big_blind.

## Chip Counts
### Robot Current Bet (bottom side of community cards)
- 1 blue 10-chip
- 1 brown 100-chip
- Total bet: 110.

### Opponent Current Bet (top side of community cards)
- 1 blue 10-chip
- 1 brown 100-chip
- Total bet: 110.

### Robot Inventory (bottom seat)
- Red (5): 4 chips
- Blue (10): 3 chips
- Green (50): 3 chips
- Brown (100): 3 chips

### Opponent Inventory (top seat)
- Red (5): 4 chips
- Blue (10): 3 chips
- Green (50): 3 chips
- Brown (100): 3 chips

## Uncertainties
- Scene stability is assumed to be true as no previous frame is available for comparison, but the robot hand is settled.
- Inventory counts for denominations 10, 50, and 100 are 3 each, which matches the expected game state given the active bets of 10 and 100.
