# Perception merge

The current capture shows 7d, 6s, Jc on the board, the white turn marker at the robot seat, and the robot's big-blind marker. Inventory and bet chips were counted in their separate table zones. The opponent bet color split is somewhat uncertain because the chips are angled.

Compared with s23 and s24, the robot hand has moved from contact with a chip to a raised position without reaching a settled pose. Accordingly the scene is unstable and the loop stage is `acting`. Neither player's hole cards are face-up, and no fold is visible, so the outcome is `not_showdown`.

The named action sequence, hole-card cache, and previous parsed-state files were unavailable; no field was inherited from them. No robot or poker action was run or selected.
