# Native visual evidence

Current capture: `s_current/00_capture.jpg`, resolving to `s25/00_capture.jpg`. Compared directly with `s24/00_capture.jpg` and `s23/00_capture.jpg`. Read the field guidelines in `visual_guidelines/`.

Unstable, conservatively. Across s23, s24, and s25 the robot moves from the right side to contact with a brown chip near the lower board edge, then rises above the table. In s25 its fingers appear empty and it is approaching a raised rest-like pose, but there is no consecutive settled frame confirming completion. The blue chip in the robot betting area also shifts, a brown chip now accompanies it, and the opponent betting area now visibly contains green and brown chips as well as red chips. The human is not touching or blocking the table. Scene stability and the inferred still-acting stage remain uncertain; no failure or recovery is established.

The white `Your Turn` marker is clearly at the bottom-left robot seat: it is our turn. The yellow `BIG BLIND` marker is beside the robot hole cards. The white `DEALER` and blue small-blind markers are at the opponent seat. Robot is big blind; opponent is dealer/small blind, with no visible conflict.

Three face-up community cards are readable left-to-right: 7d, 6s, 7c. Two card backs farther left in the central lane are excluded from the face-up community-card list. Both normal opponent hole-card positions at the top still contain face-down cards, and both robot hole cards are face-down at the bottom. There is no visible showdown or clear fold/muck. No readable held card is visible; no hidden ranks are inferred.

Chips are counted as individual flat faces, using red=5, blue=10, green=50, brown=100. Bottom robot inventory: four red, three blue, four green, three brown. Top opponent inventory: two red, four blue, three green, three brown. These are distinct from the central betting lane.

Robot current bet, left of the board: zero red, one blue, zero green, one brown. Opponent bet, right of the board: two red, zero blue, one green, one brown. The raised robot body obscures the far-right table edge but the visible betting cluster and inventory groups are countable. No extra hidden chips are assumed.

The specified `action_sequence.json`, `hole_card_cache.json`, and previous parsed-state file are absent; a workspace search found no alternative copies. No durable fields could be inherited and no dispatched intent could be verified. All counts and card reads come from s25; prior images are used only for motion/layout comparison. `acting` is a conservative visual estimate, not a claim about a known dispatched workflow step.
