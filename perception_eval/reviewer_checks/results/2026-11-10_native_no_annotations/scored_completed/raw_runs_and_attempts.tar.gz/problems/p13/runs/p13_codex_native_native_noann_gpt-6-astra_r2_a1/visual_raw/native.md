# Native visual evidence

Capture: `s_current/00_capture.jpg` resolves to `s25/00_capture.jpg`. Compared with `s24/00_capture.jpg` and `s23/00_capture.jpg`; read all field guidelines in `visual_guidelines/`.

Unstable. Across s23, s24, and s25 the robot hand changes substantially: it approaches the lower-right chip area, contacts a brown chip in s24, and is raised above the table in s25. A brown chip is now beside the blue chip in the robot betting area. The latest frame is clear, but consecutive settled poses are not established and chips changed position. Best estimate is still acting/returning from chip movement, with uncertainty about whether the raised hand has just finished. No visible held card or chip in s25, no pinned object, and no clear damaged layout. No failure or recovery conclusion is supported.

Robot is the bottom seat; opponent is the top seat. Inventory is outside the central betting lane. For bets, use the field-specific left/right-of-board convention.

The white handwritten Your Turn button is at the lower-left robot seat: it is our turn. The yellow BIG BLIND button is beside the robot hole cards. White DEALER and blue SMALL BLIND buttons are at the opponent seat. Robot is big blind; no button conflict.

Three face-up community cards read left-to-right as 7d, 6s, 7c. Two additional card backs to their left are not readable board values and are excluded. Both opponent hole cards remain face-down in their normal top-seat positions; both robot hole cards are face-down in the bottom seat. No readable held card, exposed opponent hand, or clear fold/muck is visible. This is not showdown; no hand comparison is possible or needed.

Robot inventory: four red 5-chips, three blue 10-chips, four green 50-chips, three brown 100-chips. These are individual flat faces, not stacks.

Opponent inventory: two red 5-chips, four blue 10-chips, three green 50-chips, three brown 100-chips. The blue marker between hole cards is a blind button, not a chip.

Robot bet, left of the central cards: zero red, one blue 10-chip, zero green, one brown 100-chip.

Opponent bet, right of the central cards: two red 5-chips, zero blue, one green 50-chip, one brown 100-chip. These four faces are visible. The robot assembly blocks the farther-right continuation of the table, so completeness of this bet count is uncertain; use the visible count as the concrete estimate.

The requested action_sequence.json, hole_card_cache.json, and previous parsed state are absent from the supplied workspace. No durable field was inherited. The loop stage and stability are temporal estimates from the images, not dispatch metadata.
