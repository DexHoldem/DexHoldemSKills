# Perception evaluation

The current capture is visually stable against `s25/00_capture.jpg`. The robot hand is settled and empty, the bottom-seat `Your Turn` marker makes `is_my_turn` true, and the bottom-seat `BIG BLIND` marker makes the robot the big blind. The visible board is `7d 9s 7c`; both players' hole cards remain face-down in their normal seat areas, so the state is not showdown and the loop stage is `idle`.

Inventory and bet chips were counted separately by table zone and denomination. The opponent inventory estimate is marked uncertain because the settled robot hand partly overhangs that side of the table. No prior fields were merged: `action_sequence.json`, `hole_card_cache.json`, and a previous `01_parsed_state.md` were not present in the workspace. All structured fields therefore use concrete estimates from current visual evidence.
