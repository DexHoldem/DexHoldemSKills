# Perception and merging

Read s25 through s_current and compared s24 and s23. Current visual evidence supplies all card, marker, inventory, and bet values. Board: 7d, 6s, 7c; robot turn and big blind are directly visible. Both players retain face-down hole cards in their seat areas; no showdown or fold is established.

Substantial hand movement and chip relocation across these frames support the conservative acting / scene_stable=false estimate. The current raised hand may have just finished returning, so both temporal fields are marked uncertain. Opponent bet counts use four visible faces, with uncertainty because the assembly occludes the farther-right area. Inventory and bet zones were counted separately; buttons and face-down cards were excluded.

No action_sequence.json, hole_card_cache.json, or prior parsed state was supplied on disk, including no s24/01_parsed_state.md. Consequently no cached or prior field was merged, and no dispatched atom success was assumed. Every schema field has a concrete value; uncertainty is explicit. No helper scripts, robot actions, or poker decisions were executed.
