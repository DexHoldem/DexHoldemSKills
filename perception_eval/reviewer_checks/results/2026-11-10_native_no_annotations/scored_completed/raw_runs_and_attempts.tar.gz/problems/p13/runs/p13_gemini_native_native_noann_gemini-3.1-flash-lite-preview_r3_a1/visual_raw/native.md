# Perception Evidence (s25)

- **Loop Stage:** acting (robot's "Your Turn" marker is visible)
- **Blind:** big_blind
- **Showdown Outcome:** not_showdown
- **Scene Stability:** stable
- **Turn Detection:** "Your Turn" marker is present near robot's position.
- **My Chips (Robot):**
  - 100: 0
  - 50: 0
  - 10: 3
  - 5: 3
- **Opponent Chips:**
  - 100: 0
  - 50: 0
  - 10: 2
  - 5: 3
- **My Current Bet:** 0
- **Opponent Current Bet:** 0
- **Community Cards:** 7d, 6s, 7s (visible on table)
