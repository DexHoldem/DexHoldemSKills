# Perception merge

Current capture s25 shows three face-up community cards (7d, 6s, likely Jc), the robot-side turn button, and the robot-side big blind button. The dealer button is at the opponent seat. A brown 100 chip is newly visible beside the robot's blue 10 bet chip. The robot hand has lifted away from the right betting area between s24 and s25 but remains extended, so the scene is unstable and the loop stage is `acting`.

Chip estimates come from visible unfolded faces in separate inventory and betting zones. The opponent-side inventory and bet denominations, plus the last community-card rank, have some visual uncertainty. No showdown or fold is visible. The requested prior JSON and parsed-state files are absent, so no prior values were merged; s23 and s24 capture images were used only to judge movement and chip placement.
