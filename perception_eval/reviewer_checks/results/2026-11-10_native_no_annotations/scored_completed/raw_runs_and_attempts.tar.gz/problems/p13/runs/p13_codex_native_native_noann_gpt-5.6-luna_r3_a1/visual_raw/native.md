# Raw visual perception

- Compared `s_current/00_capture.jpg` (`s25`) with `s24/00_capture.jpg`.
- The robot dexterous hand/arm is extended over the upper-right table area and is not in a settled rest pose. The current frame differs from the previous frame, so the scene is unstable and the physical action appears still in progress.
- The white `Your Turn` button is visible at the bottom/robot seat. It is the robot's turn.
- The yellow `BIG BLIND` button is at the bottom/robot seat. The robot is the big blind.
- Three face-up community cards are visible left-to-right: `7d`, `6s`, and `Jc` (the rightmost card is partly affected by the robot-side occlusion but is readable enough as a jack of clubs).
- Both players' hole cards remain face-down; no readable held card is visible and no showdown outcome is present.
- Robot/player inventory, bottom-side: approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top-side: approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The upper-right inventory/bet boundary is partly occluded by the robot arm.
- Best visible betting-area estimate: robot/bottom-side bet has 3 red 5-chips and 1 blue 10-chip; opponent/top-side bet has 1 green 50-chip. These bet counts are low-confidence because the robot arm overlaps the right-side table geometry.
- No chips were merged into a generic pot; inventory and betting areas were kept separate.
