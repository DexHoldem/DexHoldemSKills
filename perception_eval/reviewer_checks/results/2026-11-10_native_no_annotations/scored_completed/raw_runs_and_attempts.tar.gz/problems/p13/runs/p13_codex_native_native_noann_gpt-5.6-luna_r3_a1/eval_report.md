# Perception evaluation

The current capture is an unstable, still-acting frame: the robot hand is extended over the table and has moved relative to `s24`. The robot-side `Your Turn` marker and `BIG BLIND` marker are visible, supporting `is_my_turn: true` and `blind: big_blind`. Three board cards are visible (`7d 6s Jc`); hole cards are face-down, so this is not showdown.

Inventory counts were read by color/denomination and kept separate from betting areas. The right-side bet and inventory zones are partially occluded by the robot arm, so those estimates and the rightmost community-card read are explicitly marked uncertain. No poker action was selected or dispatched.
