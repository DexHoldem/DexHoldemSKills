# Raw visual perception

Source used: latest available capture, `s25/00_capture.jpg`. The requested
`s_current/00_capture.jpg` was absent. Compared visually with `s24/00_capture.jpg`
as the preceding available frame.

- Scene: the robot hand is raised/settled at the upper-right and is no longer
  contacting cards or chips. The table layout is readable; scene treated as
  stable.
- Turn: the white `Your Turn` button is at the bottom robot/player seat, so it
  is the robot's turn.
- Blind: the yellow `BIG BLIND` button is at the bottom robot/player seat.
- Board: three face-up community cards are visible, left to right approximately
  `7d`, `6s`, `Jc`. No other shared cards are visible.
- Hole cards: both robot and opponent table cards remain face-down; no held card
  is readable. There is no showdown evidence.
- Robot inventory (bottom seat): approximately 4 red 5-chips, 3 blue 10-chips,
  3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top seat): approximately 4 red 5-chips, 4 blue 10-chips,
  3 green 50-chips, and 3 brown 100-chips.
- Robot-side current-bet area, left of the community-card row: one blue 10-chip
  and one brown 100-chip are visible; no red or green bet chips.
- Opponent-side current-bet area, right of the community-card row: about three
  red 5-chips and one blue 10-chip are visible. The robot hardware partly
  occludes the far-right area, so this count is uncertain.
- The supplied `action_sequence.json`, `hole_card_cache.json`, and
  `sN-1/01_parsed_state.md` were also absent, so no durable fields were
  inherited from them.
