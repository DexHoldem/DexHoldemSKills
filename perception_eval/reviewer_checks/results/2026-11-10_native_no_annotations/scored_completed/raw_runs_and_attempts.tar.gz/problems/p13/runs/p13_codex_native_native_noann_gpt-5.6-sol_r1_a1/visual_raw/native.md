# Raw visual perception

- Capture: `s_current/00_capture.jpg`, which is the same file as `s25/00_capture.jpg`.
- Geometry used: robot/player seat at the bottom; opponent seat at the top; community-card row in the center; robot bet area left of the community cards; opponent bet area right of them.
- Stability/robot: Unstable. Compared `s24/00_capture.jpg` with `s25/00_capture.jpg`. In `s24` the dexterous hand is down at and apparently contacting/pushing a chip; in the current frame it has lifted substantially and changed pose. The hand is sharp but not back at a settled near-idle pose, so the atom appears still in progress. It is not visibly holding a card or chip. No dropped card, scattered layout, or clear human-help condition is visible.
- Turn: the white **Your Turn** button is plainly at the bottom-left robot/player seat, so it is the robot's turn.
- Blind: the yellow **BIG BLIND** button is at the bottom robot/player seat. The robot is big blind.
- Community cards: three face-up board cards, left-to-right: `7d`, `6s`, `7c`.
- Robot/player inventory (bottom): 4 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips.
- Opponent inventory (top): 3 red 5-chips, 4 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot/player current bet, left of the board: 1 blue 10-chip and 2 brown 100-chips; no red or green chips visible.
- Opponent current bet, right of the board: 2 red 5-chips visible; no blue, green, or brown chips clearly visible. Because the robot is still moving through this region and the right side is partly occluded, this is a best current-frame estimate.
- Showdown: neither player's hole cards are face-up, there is no fold/muck signature, and only three community cards are present. This is not showdown.
- Context limitation: `action_sequence.json`, `hole_card_cache.json`, and a prior `01_parsed_state.md` were not present, so no fields were inherited from them.
