# Perception evidence and merge

Inspected current s25 and comparison captures s24 and s23 directly. Current evidence gives board 7d/6s/7c, robot big blind, robot turn, and no showdown. Inventory and betting counts come exclusively from visible current chip faces, with buttons and face-down cards excluded.

The robot has risen away from the chip-contact position in s24, and chips have changed position. Completion is not confirmed by consecutive settled captures, so the concrete estimate is `acting` with `scene_stable=false`; both fields are flagged uncertain because the current raised pose could be the end of the movement.

The requested workflow, hole-card cache, and previous parsed state were unavailable. No state was inherited, and no prior dispatched action was treated as current visual truth. No robot actions, helper scripts, or poker decisions were performed.
