# Perception evaluation

The current capture directly supports an idle, usable table state: the image is sharp, the robot hand appears settled, the bottom-seat `Your Turn` button is visible, and the bottom-seat `BIG BLIND` button fixes the blind assignment. The board has three readable face-up community cards (`7d 9s 7c`), while both players' hole cards remain face-down in their normal areas, so this is not a showdown.

Inventory chips were counted only in the bottom/robot and top/opponent inventory zones. Bet chips were counted separately in the left-of-board robot bet zone and right-of-board opponent bet zone. Buttons and face-down cards were excluded from all chip counts.

No prior-state merge was possible: `action_sequence.json`, `hole_card_cache.json`, and a previous `01_parsed_state.md` were not present in the workspace. All populated values therefore come from current visual evidence. `scene_stable` is listed as uncertain only because stability could not be checked against a previous frame; the current frame itself shows no blur or visible object motion.
