# Raw visual perception

- Source: `s_current/00_capture.jpg`.
- Scene/stability: The frame is sharp. The dexterous hand is stationary-looking in a settled near-idle pose at the upper-right and is not visibly holding a card or chip. No card or chip is visibly in motion. No previous capture was available for frame-to-frame comparison, so stability is judged from this frame alone.
- Turn: The white physical button labeled `Your Turn` is at the bottom-left robot/player seat. It is the robot's turn.
- Blind: The yellow `BIG BLIND` button is beside the bottom/robot hole-card area. The white `DEALER` button and blue small-blind marker are on the top/opponent side. The robot is big blind.
- Community-card row: Three face-up shared cards are visible: `7d`, `9s`, `7c`. The two other board positions are face-down and their values are not inferred.
- Robot/player inventory, bottom seat outside the betting lane: 5 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, top seat outside the betting lane: 2 red 5-chips, 3 blue 10-chips, 4 green 50-chips, and 4 brown 100-chips.
- Robot current bet, left of the community cards: 0 red 5-chips, 1 blue 10-chip, 0 green 50-chips, and 2 brown 100-chips.
- Opponent current bet, right of the community cards: 2 red 5-chips, 1 blue 10-chip, 0 green 50-chips, and 1 brown 100-chip.
- Showdown: Both players' two hole cards remain face-down in their normal seat areas. There is no visible fold/muck or showdown; outcome is `not_showdown`.
- Robot/workflow state: The hand looks settled and the table layout is intact, with no visible physical failure. With no action-sequence context available, the visual state is treated as `idle`, not as a dispatched atom completion.
- Uncertainty: `scene_stable` is based on a single frame because no preceding capture was available. The requested `action_sequence.json`, `hole_card_cache.json`, and prior `01_parsed_state.md` were not present, so no values were inherited or merged from them.
