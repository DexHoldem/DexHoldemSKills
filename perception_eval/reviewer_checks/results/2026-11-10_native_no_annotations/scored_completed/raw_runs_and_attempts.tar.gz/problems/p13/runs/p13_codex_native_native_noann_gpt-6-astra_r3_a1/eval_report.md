# Perception evidence and merging

Read all field guidelines and inspected the current s25 capture directly. Compared s24 and s23 for recent manipulation and s0 for initial pose and face-down board placement.

Current evidence gives robot big blind, robot turn, board `7d 6s 7c`, and no showdown. Inventories and bets were counted as individual flat chip faces in their separate zones. Face-down cards were excluded from readable community cards.

The robot has returned from the low manipulation pose in s24 to the empty elevated rest pose seen in s0. Estimated `atom_idle` and stable; both are flagged uncertain because dispatch metadata is missing and there is only one final rest-pose capture after changes.

The named action sequence, hole-card cache, and previous parsed-state files are absent. No fields were inherited and no hidden card values were invented. Every schema field has a concrete estimate. No helper scripts, robot actions, or poker decisions were executed.
