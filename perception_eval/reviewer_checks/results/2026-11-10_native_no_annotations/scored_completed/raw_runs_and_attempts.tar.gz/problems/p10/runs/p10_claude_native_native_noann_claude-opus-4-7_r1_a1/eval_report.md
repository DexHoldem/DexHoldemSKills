# Eval Report — s_current perception

## Evidence

- Turn: "Your Turn" white button at lower-left (robot seat) → `is_my_turn = true`.
- Blind: Blue small-blind button on opponent side; two-player rule →
  robot is `big_blind`.
- Scene: Robot dexterous hand is extended well into the center of the table,
  gripper hovering over the community-card lane — not a near-idle pose →
  `scene_stable = false`, `loop_stage = acting`.
- Community cards: Center lane largely occluded by gripper; no cards are
  confidently readable → `community_cards = []` (uncertain).
- Bets: Central betting lane is occluded by gripper; no confidently placed
  bet chips countable → both bet objects zero (uncertain).
- Inventory: Red (5) and blue (10) chips visible on both sides; green (50)
  and brown (100) are occluded on the right half by the robot arm.
  Used standard starting counts as fallback for occluded denominations.
- Showdown: No face-up opponent hole cards and <5 community cards →
  `not_showdown`.

## Merging

No prior `sN-1/01_parsed_state.md` was available at the path specified.
Durable fields (chip inventories, blind assignment) use best visible counts
with standard-start fallbacks where occlusion forbids a confident count.
All occluded/inferred fields are listed in `uncertain_fields`.

## Outputs written

- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
