# Perception evaluation

The current frame was merged with visual comparison against `s20`, `s21`, and `s22`. Those captures show an unchanged, settled robot pose, supporting `scene_stable: true` and the post-atom `atom_idle` estimate. The bottom-seat `Your Turn` and `BIG BLIND` buttons directly support turn and blind assignment. The empty face-up board and absence of exposed opponent cards support `not_showdown`.

Visible red/blue inventories were counted directly. Green/brown inventory estimates use the last less-occluded table layout because the robot assembly blocks them in the current frame. Both betting regions are also occluded, so concrete zero estimates are supplied but flagged uncertain. No prior `action_sequence.json`, `hole_card_cache.json`, or `sN-1/01_parsed_state.md` was present to merge; no absent-context value was treated as visual evidence.
