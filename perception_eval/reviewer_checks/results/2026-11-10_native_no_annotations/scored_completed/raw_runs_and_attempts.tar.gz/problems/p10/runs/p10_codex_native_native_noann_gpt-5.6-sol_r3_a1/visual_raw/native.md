# Raw visual perception

Source inspected: `s_current/00_capture.jpg` (current frame only). The requested prior workflow files, hole-card cache, and previous parsed-state file were not present, so no durable values could be inherited.

- Geometry: robot/player seat is at the bottom; opponent seat is at the top; the robot arm enters from the right and substantially occludes the center-right table.
- Scene/robot: the dexterous hand is extended over the central betting lane, with its fingers at or immediately above the red and blue blind chips. It is not in the true initial pose and does not look sufficiently settled to certify a completed atom from this single frame. No card is visibly held. Best visual classification: action still in progress; scene unstable. No dropped card, scattered inventory, or other clear unsafe failure is visible.
- Turn: the white button labeled "Your Turn" is clearly in the bottom-left robot seat area. It is the robot/player's turn.
- Community cards: no face-up shared cards are visible in the central board row. Do not count face-down cards as community cards.
- Blind assignment: the top/opponent seat has the visible blue blind/dealer-area marker, though its labeling and the adjacent marker are partly obscured. Best estimate under the heads-up dealer/small-blind rule is opponent small blind and robot big blind; this assignment is not fully certain from the occluded frame.
- Robot/player inventory (bottom): 4 red 5-chips and 3 blue 10-chips are visibly countable. The green 50 and brown 100 inventory areas are hidden by the arm; best concrete estimate is 3 of each, marked uncertain.
- Opponent inventory (top): 4 red 5-chips and 4 blue 10-chips are visibly countable. The green 50 and brown 100 groups are obscured; best concrete estimate is 3 of each, marked uncertain.
- Current bets: one blue 10-chip is visible on the lower/robot side of the central blind area, and one red 5-chip is visible slightly above it on the opponent side. Best estimate is robot bet = one 10 and opponent bet = one 5. Both assignments are uncertain because the robot fingers overlap the area and the chips may still be in transit.
- Showdown/outcome: neither player has face-up hole cards, there is no face-up board, and no fold/muck signature is clear. This is not a showdown and no outcome is visible.

