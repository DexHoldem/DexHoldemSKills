# Native visual evidence

Current image: `s_current/00_capture.jpg` resolves to `s22/00_capture.jpg`. Read all field guidelines. Compared s22 with s21 and s20, and inspected s18, s15, s10 and s0 for less occluded historical evidence. The named action_sequence.json, hole_card_cache.json and previous parsed-state file are absent from this workspace.

## Robot and stability

Unstable for decision purposes. In s22 the robot is extended low over the lower-left betting lane, with a red fingertip apparently contacting a blue chip. The large wrist housing blocks the middle/right board, robot hole cards, high-denomination inventories and opponent betting area. No readable held card is visible. The hand is not in its initial/rest pose. s20, s21 and s22 look essentially unchanged, so ongoing velocity cannot be established from these images; however, completion or release of the chip cannot be established either. s18 shows the hand farther right and four blue inventory chips; the current image shows three blue inventory chips and one blue chip under the finger in the betting lane. Best estimate: chip movement is still in progress, loop_stage acting. This is uncertain without workflow context; no settled post-action failure or recovery is established. The opponent has folded arms away from game objects and is not interfering with the table.

## Turn and blinds

It is our turn. The white Your Turn button is clearly visible at the bottom-left robot seat.

The current blind marker is hidden. Earlier s0 and s18 clearly show the yellow BIG BLIND marker at the robot seat and the blue SMALL BLIND and white DEALER markers at the opponent seat. Carry forward robot big_blind as an inferred durable assignment; no visible contrary evidence.

## Cards and outcome

No face-up community cards are visible. Earlier clear views show five face-down patterned board positions, which do not supply readable community-card values. Current board is mostly obscured; estimate community_cards as empty, with uncertainty for the hidden region. The opponent's visible hole-card back remains near its normal top-seat position. No current face-up opponent hand, clear fold/muck, or showdown is visible. Robot hole cards are hidden. Estimate not_showdown; no hand comparison is possible or required. Do not import the earlier held-card view as a current community card.

## Inventory and bets

Counts below use denomination order 5, 10, 50, 100 and distinguish flat chip faces from markers.

- Robot inventory: four red chips and three blue chips directly visible. Green and brown groups are occluded; earlier s15 shows four green and four brown chips, carried forward as estimates. Final estimate: 4, 3, 4, 4.
- Opponent inventory: three red and four blue chips directly visible. Green and brown groups are occluded; earlier s18 shows four green and four brown chips. Final estimate: 3, 4, 4, 4.
- Robot bet, lower-left board lane: one blue chip beneath the fingertip; no visible red, green or brown chips in the exposed lane. Estimate: 0, 1, 0, 0. Chip is still contacted by the hand and part of the zone is hidden, so placement/count is uncertain.
- Opponent bet, right of board: hidden by robot. Earlier s10 and s15 show one red chip in this lane. Carry forward estimate: 1, 0, 0, 0, uncertain under current occlusion.

Hidden counts are estimates from earlier visual evidence, not direct current observations or values copied from the example schema.
