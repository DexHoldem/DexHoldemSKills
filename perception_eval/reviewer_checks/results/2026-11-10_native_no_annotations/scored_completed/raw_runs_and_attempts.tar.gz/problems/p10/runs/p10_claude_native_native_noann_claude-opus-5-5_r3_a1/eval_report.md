# Eval report — s22 native perception

- **Context files missing**: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` do not exist, so no parsed state could be inherited. Durable fields were cross-checked against s0 instead.
- **Stage**: `acting`, `scene_stable=false`. The robot hand is extended over the board with its fingertips on a chip in the robot bet lane (chip push in progress), not at rest. s20, s21 and s22 show the identical pose, so it may be paused or stuck. No layout damage is visible. Recommend wait/recapture; escalate if it persists.
- **Turn**: "Your Turn" button is at the robot seat, so `is_my_turn=true`.
- **Blind**: dealer and small-blind buttons are at the opponent seat, so the robot is `big_blind` (BB button occluded; matches s0).
- **Board**: no face-up community cards visible; most of the row is occluded, so `[]`, uncertain.
- **Chips**: robot red 4 / blue 3 visible; green/brown occluded, so 3/3 is taken from s0. Opponent red 3 / blue 4 visible; green/brown occluded, so the s0 estimate of 4/4 is used (low confidence).
- **Bets**: my bet is 1 chip under the fingertips, best read blue 10 (uncertain). Opponent bet area is occluded, so 0, uncertain.
- **Showdown**: `not_showdown`; no face-up hole cards, no fold signature.
