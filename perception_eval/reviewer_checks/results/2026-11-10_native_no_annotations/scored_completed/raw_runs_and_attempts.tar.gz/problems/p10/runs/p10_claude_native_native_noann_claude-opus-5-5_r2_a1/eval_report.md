# Eval report — s22

- Context files are missing (no action_sequence.json, hole_card_cache.json, or prior parsed state). I inferred durable fields from earlier capture images s0 and s19 instead.
- The robot hand is extended over the board with its fingertips on a 10-chip it just pushed into the robot bet lane. s20, s21, and s22 are identical, so the hand has not returned to rest and may be stuck or pinning the chip. Result: `scene_stable=false`, `loop_stage=acting`. If the hand stays frozen, escalate or reset rather than make a poker decision.
- `is_my_turn=true`: the "Your Turn" button is visible at the robot seat.
- `blind=big_blind`: inferred from s19, where the BIG BLIND button is on the robot side. It is occluded now.
- Community cards: none face-up (preflop; board slots show backs).
- Chips seen in the image: robot 4x5 and 3x10; opponent 3x5 and 4x10. The 50/100 counts on both sides are hidden by the arm and inherited as 4 each from s19.
- Bets: robot 1x10 visible under the hand. The opponent bet area is occluded; 1x5 is inferred from the missing opponent red chip (small blind).
- Recommend `reset_to_init` and a fresh capture to clear the occlusion before any betting math.
