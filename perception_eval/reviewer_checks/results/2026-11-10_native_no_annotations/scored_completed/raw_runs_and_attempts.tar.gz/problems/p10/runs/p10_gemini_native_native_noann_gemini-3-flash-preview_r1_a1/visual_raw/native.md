# Raw Perception Evidence (s22)

## Scene Stability
- Compared `s21/00_capture.jpg` and `s22/00_capture.jpg`. The images are identical.
- **Status:** Stable.

## Robot Behavior
- The dexterous hand is settled and near its idle pose, though slightly extended over the table.
- It is not holding any cards or chips.
- No movement or blur is visible.
- **Status:** idle.

## Turn Detection
- The white "Your Turn" button is located at the bottom-left of the table, which is the robot's seat area.
- **Status:** It is our turn (`is_my_turn: true`).

## Blind Recognition
- A yellow "BIG BLIND" button is visible near the robot's seat.
- A blue "SMALL BLIND" button is visible near the opponent's seat.
- **Status:** robot is big_blind.

## Community Cards
- The central community-card area is empty. No face-up cards are visible.
- **Status:** Preflop (0 cards).

## Chip Recognition
- **Robot Inventory (Bottom):**
  - Red (5): 4 chips
  - Blue (10): 3 chips
  - Green (50): 3 chips
  - Light Blue (100): 3 chips
- **Opponent Inventory (Top):**
  - Red (5): 4 chips
  - Blue (10): 4 chips
  - Green (50): 3 chips
  - Light Blue (100): 3 chips
- **Status:** Counted successfully.

## Bet Recognition
- **Robot Bet Area:** No chips visible.
- **Opponent Bet Area:** No chips visible.
- **Status:** No active bets.

## Showdown Outcome
- No hole cards are face-up.
- No community cards are face-up.
- **Status:** not_showdown.
