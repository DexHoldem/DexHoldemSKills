# Evaluation report

Used `s22/00_capture.jpg` as the current capture because `s_current/00_capture.jpg` and the named context files are not present. Compared against `s21/00_capture.jpg`; the scene is visually stable and the robot is visibly marked `Your Turn`. The yellow `BIG BLIND` marker is visible in the recent clear frame. No face-up community cards or showdown evidence is present. Inventory and bet values are best visual estimates; the robot-side inventory/betting region is partly hidden by the settled robot assembly, so `my_chips` and `my_current_bet` are flagged uncertain.
