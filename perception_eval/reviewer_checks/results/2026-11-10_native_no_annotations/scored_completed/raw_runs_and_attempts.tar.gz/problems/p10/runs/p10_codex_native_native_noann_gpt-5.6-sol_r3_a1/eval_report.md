# Perception evaluation

The current capture was used as the controlling evidence. No `action_sequence.json`, `hole_card_cache.json`, or previous `01_parsed_state.md` was available in the workspace, so nothing was inherited or merged from prior state.

The clear evidence is the bottom-seat "Your Turn" marker, no face-up community cards, visible red/blue inventory counts, and no showdown. The robot hand overlaps the central blind/bet area and the right-side inventory denominations. Accordingly, the frame is classified conservatively as `acting` with `scene_stable: false`; occluded 50/100 inventories use concrete best estimates, and the visible lower blue 10 / upper red 5 chips are assigned as robot/opponent bets with uncertainty. The partially obscured top-seat blind marker yields a best estimate that the robot is the big blind.

