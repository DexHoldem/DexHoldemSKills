# Native visual evidence

Current image: `s_current/00_capture.jpg`, resolving to `s22/00_capture.jpg`. Compared with s21 and s20; inspected s19, s18, and s0 for the pre-movement layout and obscured durable fields.

Unstable for confirming action completion. In s22 the robot reaches far across the lower board lane, with red fingertips contacting a blue chip near (710, 700). The hand and wrist conceal most of the right half of the board, both right-side inventories, the robot hole cards, and the opponent betting area. s20–s22 look essentially unchanged, but none shows a return to rest or clear release of the chip. s19 shows contact with a blue inventory chip; s18 shows the earlier pose at the right side. The best workflow estimate is acting, with uncertainty: repeated similar frames alone do not establish completion or a failure. No recovery or failure determination is made. The human has folded arms above the rail and is not interfering with table objects.

The white Your Turn marker is clearly visible at the bottom-left robot seat. It is the robot's turn according to that marker.

The current blind marker is hidden. s18 and s0 clearly show the yellow BIG BLIND button at the robot seat and the dealer and blue small-blind buttons at the opponent seat. Estimate robot big blind by carrying forward this visual assignment.

No face-up community cards are visible. The earlier clear board in s18 contains five face-down patterned cards; these are not readable community cards. The current visible patterned card at the left board position remains face-down. Estimate the face-up community list as empty, with the hidden board positions uncertain.

Robot inventory: four red 5-chips and three blue 10-chips are directly visible in the bottom inventory boxes. The fourth blue chip visible in s18 has moved forward beneath the fingertips into the betting lane. Green and brown inventory groups are hidden; estimate four of each from s0 and the green group in s18.

Opponent inventory: three red 5-chips and four blue 10-chips are visible at the top seat. The green and brown groups are obscured in s22; s18 shows four green and four brown chips. Carry those counts forward as uncertain.

Robot current bet: one blue 10-chip is visible under the fingertips in the lower-left betting lane, forward of the inventory boundary. No red, green, or brown bet chips are visible there. Estimate 0 red, 1 blue, 0 green, 0 brown; the hand may still be moving the chip, and the region is partly blocked.

Opponent bet: the right-side betting area is hidden. In s18 a red chip is partly visible beside the right end of the board, and the opponent red inventory has decreased from four in s0 to three. Estimate one red 5-chip and zero other denominations, with substantial occlusion uncertainty.

No readable held card is visible. No face-up opponent hole cards or fold/muck signature is visible. Earlier opponent cards remain in their normal top-seat slots. Robot hole cards are hidden in the current view and were face-down near the bottom seat in s18. Estimate not_showdown; there is no basis for a hand comparison or win/lose label.

The requested action_sequence.json, hole_card_cache.json, and previous parsed-state file are absent from the workspace. No cached hole-card values or prior workflow status were assumed. Counts inherited here come from inspected images, not a parsed-state file.
