# Perception Eval Report — s_current (s22)

## Evidence sources
- `s_current/00_capture.jpg` (only input available)
- No `action_sequence.json`, `hole_card_cache.json`, or `sN-1/01_parsed_state.md`
  were present in the workspace, so no prior parsed state could be inherited.

## Key observations
- Robot arm is center-frame with the dexterous gripper above the community-card
  row — clearly mid-action. Scene is **unstable**, `loop_stage=acting`.
- "Your Turn" white marker is visible on my (bottom) side ⇒ `is_my_turn=true`.
- Face-up card with spade symbol visible; rank and other community cards
  occluded by the gripper. Community cards left empty and marked uncertain.
- Chip counts are partially occluded by the robot arm; small conservative
  estimates provided and marked uncertain for all four chip fields.
- No showdown signals: no card flip/pile-push and both players still have chips
  in their resting rows.
- Blind: no definitive small-blind marker on my side; a blue disk near opponent
  may be a dealer button. Defaulted to `big_blind` per the schema example and
  listed as uncertain.

## Merging
With no prior parsed state available, nothing was inherited. All fields are
first-capture estimates; uncertainty is captured in `uncertain_fields`.

## Outputs written
- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
