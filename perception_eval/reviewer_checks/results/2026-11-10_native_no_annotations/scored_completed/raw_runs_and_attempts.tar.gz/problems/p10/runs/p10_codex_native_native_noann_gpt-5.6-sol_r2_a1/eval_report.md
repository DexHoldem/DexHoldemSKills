# Perception evaluation

The current capture supports a stable, settled near-idle robot pose, so the merged stage estimate is `atom_idle`. The white turn button is clearly at the robot seat. No face-up community cards or showdown evidence are visible.

Visible inventory counts were used directly. The robot's green/brown inventories and portions of both betting lanes are hidden by the robot assembly, so concrete best estimates were supplied and explicitly listed in `uncertain_fields`. The blind assignment is also uncertain because its button is occluded in the current frame.

No prior workflow/cache/parsed-state context files were available to merge. No robot action or poker action was executed or selected.
