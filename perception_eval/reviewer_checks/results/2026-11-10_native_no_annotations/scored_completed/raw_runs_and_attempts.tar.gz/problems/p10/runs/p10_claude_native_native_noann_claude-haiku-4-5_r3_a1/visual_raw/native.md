# Raw Perception Evidence - s22

## Image Overview
- Captured: s_current (s22)
- Table orientation: Camera views diagonally from robot/player side (bottom) toward opponent (top)
- Robot arm visible on right side, camera body visible, arm in settled pose
- Opponent seated at top, in relaxed posture

## Chip Inventory Analysis

### Robot/Player Chips (bottom seat area, near lower rail)
Examined the lower-left region for inventory chips outside the betting lane.
- Red 5-chips: approximately 4 visible
- Blue 10-chips: approximately 3 visible
- Green 50-chips: approximately 3 visible
- Brown 100-chips: approximately 3 visible
- Status: All counts appear clear and unoccluded

### Opponent Chips (top seat area, near upper rail)
Examined the upper regions for opponent inventory chips.
- Red 5-chips: approximately 4 visible
- Blue 10-chips: approximately 4 visible
- Green 50-chips: approximately 3 visible
- Brown 100-chips: approximately 3 visible
- Status: All counts appear clear and unoccluded

## Community Cards
Central row across middle-lower table (area between community-card row): 
- **No community cards are visible** - the board appears empty
- Stage: Preflop (0 cards visible)

## Turn/Button Detection
Examined the bottom-left robot seat area for white "Your Turn" button:
- A white button labeled "Your Turn" is visible at the robot/player seat area (bottom-left)
- **It is our turn.** The white turn button is at the bottom-left robot seat area.

## Blind Assignment
Examined button positions:
- The "Your Turn" button is at the robot seat
- In two-player poker, the player with dealer button is also the small blind
- **Robot/player is small blind, opponent is big blind**

## Current Bets (Central Betting Lane)
- Robot bet area (left side of community cards): No chips visible - no current bet
- Opponent bet area (right side of community cards): No chips visible - no current bet

## Hole Cards
- Robot hole cards (bottom area): Face-down, not yet revealed - no read possible
- Opponent hole cards (top area): Face-down, not yet revealed - no read possible

## Hand Status
- No showdown indicators visible
- Opponent cards still face-down
- No fold signature (opponent cards have not been displaced from normal hole-card position)
- Stage: Preflop, playing action

## Scene Stability
- Robot hand/arm is in settled near-idle pose on the right side
- No visible motion blur or mid-action positioning
- No cards or chips currently moving
- Opponent is not substantially blocking table
- Image is clear and sharp
- **Scene appears stable** - suitable for next decision

## Occluded or Uncertain Zones
- None noted - all relevant zones are clearly visible
