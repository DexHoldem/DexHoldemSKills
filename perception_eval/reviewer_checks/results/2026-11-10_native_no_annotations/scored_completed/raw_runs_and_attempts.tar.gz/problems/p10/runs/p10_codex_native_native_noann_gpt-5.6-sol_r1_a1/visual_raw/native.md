# Raw visual perception

- Current capture: `s_current/00_capture.jpg` (visually identical to `s22/00_capture.jpg`).
- Stability: Stable. Compared the current frame with `s21/00_capture.jpg` and `s20/00_capture.jpg`; the dexterous hand and all visible table objects remain in the same positions without blur or active motion.
- Robot behavior: The hand is settled in a near-idle pose over the center-right/lower betting region. It is not visibly holding a card or chip, but its body and fingers substantially occlude the robot hole-card area, much of both central betting regions, and the lower-right inventory groups. No scattered chips, pinned object, or obvious unsafe physical failure is visible.
- Turn: The white `Your Turn` button is clearly at the bottom-left robot seat, so it is the robot's turn.
- Blinds: The yellow `BIG BLIND` button is at the bottom robot seat. The blue `SMALL BLIND` button and white dealer button are at the top opponent seat. The robot is therefore big blind.
- Community cards: No face-up community cards are visible in the five-card center row.
- Showdown: Neither player's hole cards are face-up in their normal seat areas. There is no fold/muck signature or other visible showdown evidence; outcome is not showdown.
- Robot inventory: Four red 5-chips and three blue 10-chips are clearly visible at the bottom seat. The green 50-chip and brown 100-chip groups are occluded in the current frame; the concrete estimate is three of each, consistent with the last unobstructed layout.
- Opponent inventory: Four red 5-chips and four blue 10-chips are visible at the top seat. The opponent green 50-chip and brown 100-chip groups are partly hidden by the robot/camera assembly; the concrete estimate is three of each from the durable layout.
- Current bets: No bet chip is safely distinguishable from the robot fingers/occlusion in either central betting area. Both bet objects are estimated as zero, with both bet fields marked uncertain because their zones are blocked.
- Loop-stage evidence: The hand is settled after the preceding card-view/return motion seen in older captures, so the physical state is best labeled `atom_idle`, not `acting`. This is inferred from image comparison because the referenced workflow context files are absent from this workspace.

