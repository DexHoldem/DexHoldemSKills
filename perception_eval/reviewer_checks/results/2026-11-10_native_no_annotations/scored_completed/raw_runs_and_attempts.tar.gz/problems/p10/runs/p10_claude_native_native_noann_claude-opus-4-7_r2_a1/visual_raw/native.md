# Visual Perception — s22 (s_current)

## Images Compared
- Current: `s_current/00_capture.jpg` (symlink → `s22/00_capture.jpg`)
- Previous: `s21/00_capture.jpg`
- The two frames are visually indistinguishable: the robot arm, gripper, and
  the camera head are in the exact same pose; chip stacks and cards show no
  change.

## Scene Stability
- The UR-style robot arm extends across the middle of the table from the
  right, with the Shadow-Hand dexterous hand resting roughly over the
  community-card area.
- No motion blur; the hand appears settled rather than mid-transfer.
- The human opponent sits with arms crossed, not touching the table.
- Verdict: **Stable**, though heavily occluded by the arm and gripper.

## Turn Marker
- A clear white "Your Turn" chip/marker is placed on the robot's own side
  (bottom-left of the frame, next to the chip stacks).
- Interpretation: **It is my (robot's) turn to act.**

## Blind / Dealer Button
- A small round white disk is visible on the opponent's side of the felt
  (middle-left-of-top area, next to the opponent chip stacks).
- Shape/size match the dealer-button marker. The "Your Turn" is on my side,
  and the dealer/blind indicator is on the opponent side → treat me as the
  **big blind** this hand (opponent is small-blind / button in heads-up).
- Confidence: low — partially occluded; inherit-style estimate.

## Community Cards
- The dexterous hand hovers directly over the community-card line.
- One card (back / spade suit visible) is partially seen just under the
  gripper, and another dark rectangle (card back) is visible just above the
  gripper.
- The majority of the community row is occluded by the arm.
- Best estimate: pre-flop or early-flop; community cards cannot be read
  reliably. Default to **empty list** and flag as uncertain.

## My Chips (robot side, bottom of frame)
- Visible stacks (bottom-left and bottom-center of felt):
  - Two red/white "5" stacks and one additional red "5" stack partially
    behind the gripper → roughly **4 × chip-5**.
  - A blue/white "10" stack of ~3 chips → roughly **3 × chip-10**.
  - 50 / 100 denominations are not clearly visible on my side; inherit
    a baseline of 3 each.
- All counts are rough; heavy occlusion from the arm.

## Opponent Chips (top of frame)
- Visible stacks on opponent side:
  - A short stack of red "5" chips (approximately 4).
  - A tall stack of blue "10" chips (approximately 4).
  - Taller denomination stacks (likely 50 / 100) are suggested behind the
    gripper but not countable.
- Rough estimates with inherited defaults for higher denominations.

## Current Bets
- No distinct "bet line" chip clusters are visible forward of either player's
  stack. The chip clusters I can see sit in the normal stack zones.
- Treat current bets as **0 for both sides** (pre-decision on my turn).

## Showdown
- No cards are face-up in a comparison layout; the hand is still active.
- `showdown_outcome`: **not_showdown**.

## Loop Stage
- Robot hand is settled (not mid-atom), "Your Turn" visible → the system is
  waiting for me to choose a poker action.
- `loop_stage`: **idle**.

## Uncertain Fields
- `community_cards` (occluded by arm)
- `my_chips` all denominations (occluded / inherited)
- `opponent_chips` all denominations (occluded / inherited)
- `blind` (button only partially visible)
