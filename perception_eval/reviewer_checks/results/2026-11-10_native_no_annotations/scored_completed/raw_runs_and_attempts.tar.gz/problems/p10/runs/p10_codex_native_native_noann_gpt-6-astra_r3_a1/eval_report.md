# Perception evidence and merging

Parsed s_current (s22) directly using the visual_guidelines. Current evidence clearly supports the robot-side turn marker, four robot red inventory chips, three robot blue inventory chips, three opponent red inventory chips, four opponent blue inventory chips and one blue chip under the robot fingertip in the robot betting lane.

The hand is extended over a chip and obscures much of the table. s20–s22 are visually almost unchanged, but release/completion is not established. Selected acting and scene_stable=false conservatively, with both marked uncertain. No failure/recovery label was inferred merely from occlusion or lack of visible movement.

The provided context-file paths are absent, so no prior workflow state, hole-card cache or parsed-state values could be merged. Earlier captures supply estimates for durable/hidden fields: robot big blind, four green and four brown inventory chips per seat, and one red opponent bet. Current evidence overrides the earlier four-blue robot inventory: three remain visible and one is in the betting lane. No face-up board or showdown evidence is visible; empty community_cards and not_showdown are concrete estimates with occlusion uncertainty. All inherited, inferred or low-confidence fields are listed in uncertain_fields.

Only image viewing, guideline/file inspection and output writing were performed. No helper scripts, robot actions or poker-action selection were used.
