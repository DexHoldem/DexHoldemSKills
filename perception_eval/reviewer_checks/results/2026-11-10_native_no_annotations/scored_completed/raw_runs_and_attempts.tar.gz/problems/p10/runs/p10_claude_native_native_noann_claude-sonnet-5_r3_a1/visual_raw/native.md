# Native Visual Perception — s_current (s22)

Context note: no `action_sequence.json` or `hole_card_cache.json` exist anywhere
in this workspace, and no prior `sN/01_parsed_state.md` exists either (s0-s21
contain only `00_capture.jpg`). `s0/00_capture.jpg` was used as the preflight
baseline for blind/button identification per `BLIND_BUTTON_RECOGNITION.md`, and
`s21/00_capture.jpg` was used as the immediately-previous frame for scene
stability per `SCENE_STABILITY.md`.

## Scene stability (s21 vs s22/current)

Stable. Compared `s21/00_capture.jpg` and `s_current/00_capture.jpg` (=`s22`).
The two frames are visually identical: the dexterous hand is in the same
near-idle pose extended over the lower-left of the table, no card or chip has
moved, and the human opponent is in the same arms-crossed posture. No human
arm is on the table. The scene is safe for the next decision.

## Turn detection

It is our turn. The white "Your Turn" button is visible at the bottom-left of
the table, in the robot/player seat area, at the same position as in the
baseline `s0` image.

## Blind / button recognition (from s0 preflight baseline)

In `s0/00_capture.jpg`, a blue round button labeled "...BLIND" (reads as SMALL
BLIND) and a white round button labeled "DEALER" both sit at the opponent/top
seat area, next to the opponent's chip clusters. A yellow round button labeled
"BIG BLIND" sits at the robot/bottom seat area, next to the robot's chip
clusters. Applying the two-player rule (dealer = small blind, other player =
big blind): the opponent is dealer/small blind, and the robot/player is big
blind. The same blue "small blind" button is still visible at the opponent
side in the current frame, consistent with this being unchanged.

## Community cards

Current frame: the robot's forearm/camera housing occludes most of the
central board row. Only the left-most board-card slot is partially visible,
still showing a face-down card-back texture (same gray diagonal-weave pattern
as the other four slots in the `s0` baseline, where all five slots were
face-down). No rank or suit is readable anywhere in the board row. The other
four slots are not visible at all in the current frame (hidden behind the
robot hand/arm). No community cards can be confidently reported as dealt;
this looks like preflop, but the occlusion makes the remaining four slots
unconfirmed.

## Hole cards

Opponent hole-card area (upper-middle): a gray face-down card-back shape is
visible, consistent with two face-down cards stacked/overlapping. Not moved
toward the board, so no fold/muck signature.

Robot hole-card area (lower-middle): occluded by the dexterous hand/wrist
housing in the current frame; not visible.

No hole cards are face-up or held by the dexterous hand in a readable
orientation. No held-card value can be reported.

## Opponent inventory chips (top/opponent seat band)

Visible cluster at the opponent's near/left side: a mixed group of red and
blue unfolded chips, roughly 3 red (5) chips and 3 blue (10) chips.

The opponent's far/right-side chip cluster (which in the `s0` baseline showed
roughly 3 more blue (10) chips and 2 brown (100) chips, next to the
dealer/small-blind buttons) is now fully hidden behind the robot's arm/camera
housing. No green (50) chips were visible for the opponent in either frame
(that area may be occluded in all available frames). Opponent chip totals
beyond the visible near cluster are inherited from the `s0` baseline and are
uncertain due to current occlusion.

## Robot/player inventory chips (bottom/robot seat band)

Visible cluster near the "Your Turn" button: roughly 4 red (5) chips and 4
blue (10) chips, arranged in two small sub-groups, unfolded and individually
countable.

The robot's far/right-side chip cluster (which in the `s0` baseline showed
roughly 3 more blue (10) chips, 3 green (50) chips, and 3 brown (100) chips,
further toward the table edge) is now fully hidden behind the robot's own
arm/body in the current frame. These additional counts are inherited from the
`s0` baseline and are uncertain due to current occlusion.

## Bet areas (central lane near community cards)

No chips are visible sitting in the central betting lane between either
player's inventory and the community-card row, in either the `s0` baseline or
the current frame. The blind obligations appear to be marked only by the
physical SMALL BLIND / BIG BLIND buttons rather than chips pushed into a
separate bet lane. Reporting both `my_current_bet` and `opponent_bet` as no
chips visible (all zero), with low-to-moderate confidence given that most of
the lane is also occluded in the current frame by the robot arm.

## Robot behavior

The dexterous hand/arm is extended from the right side of the frame into the
lower-left table area, in a near-idle pose (not the true initial/retracted
pose). It is not blurred and is not visibly holding a card or chips — the
red-tipped fingers rest near, but do not appear to grip, the robot's own chip
cluster. The pose is identical between `s21` and `s22`, so the hand is settled,
not mid-action. The near-idle pose occludes: most of the community-card row,
the robot's own hole-card area, the robot's far-side chip cluster, and the
opponent's far-side chip cluster/dealer button. No stuck/pinned/damaged-layout
signs are visible.

## Showdown / outcome

Opponent hole cards are face-down (not shown face-up), no fold/muck
displacement is visible, and the board shows no readable community cards.
Showdown comparison is not applicable; this is not a showdown state.
