# Eval Report — Native Perception (s22)

## Context available

- `action_sequence.json`: not found anywhere in the working tree.
- `hole_card_cache.json`: not found anywhere in the working tree.
- `sN-1/01_parsed_state.md`: not found (no prior parsed state exists for
  `s21` or any earlier state).

Since none of the prior-context files exist, this run treats the capture as
the first parsed state in this session. No durable fields were inherited;
every field in `visual_summary.json` is a direct read (or best estimate) from
`s_current/00_capture.jpg` (= `s22/00_capture.jpg`), cross-checked against
`s21/00_capture.jpg` for stability only.

## Merging logic

- **scene_stable**: `s21` and `s22` are visually identical (same hand
  position, no chip/card movement) → `true`.
- **is_my_turn**: the white "Your Turn" button is at the bottom/robot seat
  → `true`, per `TURN_DETECTION.md` (button-only rule, no inference from
  posture/chips).
- **community_cards**: the only board-area card is face-down → `0` cards →
  `loop_stage` community-derived stage would be preflop; since it's the
  robot's turn with no in-flight robot action, `loop_stage` = `idle`.
- **blind**: no legible "DEALER"/"SMALL BLIND"/"BIG BLIND" text could be
  confirmed on the one visible button disc (occluded by the mic stand).
  Defaulted to `big_blind` and flagged uncertain rather than guessing a
  specific button read.
- **chips**: counted visible unfolded chip faces by color in the robot and
  opponent seat bands, per `CHIP_RECOGNITION.md`. Green (50) and brown (100)
  denominations were not identifiable in either inventory cluster at this
  resolution/angle — recorded as `0` and flagged uncertain rather than
  guessing a nonzero count.
- **my_current_bet / opponent_bet**: no chip cluster distinct from each
  side's inventory was visible in the betting lane next to the community
  cards, per `BET_RECOGNITION.md` — recorded as all-zero. The opponent side
  is flagged uncertain since the inventory and any bet chips sit close
  together at this camera angle.
- **showdown_outcome**: no face-up opponent cards, no fold signature (no
  opponent hole-card displacement toward the board vs. `s21`) → `not_showdown`.

## Uncertain fields

`blind`, `my_chips.50`, `my_chips.100`, `opponent_chips.50`,
`opponent_chips.100`, `opponent_bet` — see `visual_raw/native.md` for the
specific occlusion/resolution reasons for each.

## Outputs written

- `runs/p10_claude_native_native_noann_claude-sonnet-5_r2_a1/visual_raw/native.md`
- `runs/p10_claude_native_native_noann_claude-sonnet-5_r2_a1/visual_summary.json`
- `runs/p10_claude_native_native_noann_claude-sonnet-5_r2_a1/eval_report.md`
