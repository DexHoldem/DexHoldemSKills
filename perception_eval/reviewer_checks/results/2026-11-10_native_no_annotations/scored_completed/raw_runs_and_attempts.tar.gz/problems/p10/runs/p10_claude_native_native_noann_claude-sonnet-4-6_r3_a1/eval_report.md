# Eval Report — Perception Step

## Image Analyzed
`s_current/00_capture.jpg` (same as `s22/00_capture.jpg`, the latest state)

## Key Evidence and Decisions

| Field | Value | Confidence | Evidence |
|-------|-------|------------|----------|
| `is_my_turn` | true | HIGH | "Your Turn" white button clearly visible at bottom-left robot seat area |
| `scene_stable` | false | HIGH | Dexterous hand in non-idle pose over chips in center betting area |
| `loop_stage` | acting | MEDIUM | Robot hand engaged with chips in bet area; not in rest/init pose |
| `community_cards` | [] | HIGH | No face-up cards in center lane; preflop |
| `showdown_outcome` | not_showdown | HIGH | No hole cards face-up from either player |
| `blind` | big_blind | MEDIUM | Blue button near opponent seat suggests opponent holds small blind |

## Chip Count Summary

Chip counts carry **LOW confidence** due to:
- Robot arm/hand occluding center betting area
- No previous parsed state for inheritance
- Camera angle makes top stacks hard to count

**My inventory (bottom-left rail):** ~4×5, ~2×10, ~2×50, ~2×100 — all uncertain  
**Opponent inventory (top):** ~3×5, ~4×10, ~2×50, ~3×100 — uncertain  
**My bet (center-left):** ~3×5, ~3×10 — uncertain, hand partially occludes  
**Opponent bet (center-right):** 0 chips visible — uncertain

## Context Files
- `action_sequence.json`: not present (warned by preflight)
- `hole_card_cache.json`: not present (warned by preflight)
- `sN-1/01_parsed_state.md`: not found in any prior state directory

All chip fields and `blind` added to `uncertain_fields`.
