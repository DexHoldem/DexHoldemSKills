# Raw visual perception

Source: `s_current/00_capture.jpg`.

## Scene and robot

- The image is sharp, with no visible motion blur in the dexterous hand, cards, or chips.
- The robot arm extends from the right and appears settled in a near-idle pose rather than the unobstructed true initial pose.
- The fingers are not visibly holding a card or chip. No dropped card, scattered chips, pinning, or other clear physical failure is visible.
- The arm and wrist housing occlude the robot-side green/brown inventory region, the robot hole-card area, and a substantial part of the central/right betting region.
- Best visual stage judgment: `atom_idle`. The pose looks settled after an atom, but this is context-limited because `action_sequence.json` is absent.
- Scene stability: stable. The current frame is clear and the robot appears settled; normal opponent posture is irrelevant to this judgment.

## Turn and blind buttons

- The white `Your Turn` button is clearly visible at the bottom/robot seat, so it is the robot's turn.
- The blind button itself is hidden by the robot assembly in this capture. Best concrete assignment is robot `big_blind`, treated as an inferred durable field rather than a direct current-frame read.

## Cards and showdown

- No face-up community cards are visible in the central board row: `[]`.
- Two face-down cards remain in the opponent hole-card area. No opponent cards are face-up or displaced into the community lane as a clear fold/muck signature.
- The robot hole-card area is substantially occluded, and no readable held card is visible.
- There is no visible showdown and no visually established winner: `showdown_outcome = not_showdown`.

## Inventory chips

Chip colors are read as red=5, blue=10, green=50, brown=100. Buttons are excluded.

- Robot/player inventory at the bottom: four red 5-chips and three blue 10-chips are visible. The green and brown groups are occluded; the concrete estimates are three green 50-chips and three brown 100-chips, both inferred and uncertain.
- Opponent inventory at the top: four red 5-chips, four blue 10-chips, three green 50-chips, and three brown 100-chips are visible/countable.

## Current bets

- No bet chip is clearly visible in the exposed robot betting lane; best estimate is zero of every denomination.
- No bet chip is clearly visible in the exposed opponent betting lane; best estimate is zero of every denomination.
- Both bet objects are marked uncertain because the robot assembly blocks a substantial part of the relevant central/right betting area. Inventory chips were not counted as bets.

## Missing merge context

- `action_sequence.json`, `hole_card_cache.json`, and a prior `sN-1/01_parsed_state.md` are not present in the workspace, so no values were inherited from those files.
