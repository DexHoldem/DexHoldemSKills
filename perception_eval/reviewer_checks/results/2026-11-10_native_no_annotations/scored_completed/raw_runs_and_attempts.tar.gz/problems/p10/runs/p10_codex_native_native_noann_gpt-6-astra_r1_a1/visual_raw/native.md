# Native visual evidence

Current image: `s_current/00_capture.jpg`, resolving to `s22/00_capture.jpg`. Read all field guidelines in `visual_guidelines/`. Compared with s21, s20, s10, and s0 captures. No helper scripts or robot actions were run.

Unstable. The robot is extended low over the lower central betting lane, with red fingertips contacting or hovering immediately over one blue chip. It is not in its initial/rest pose, and completion of the chip manipulation is not established. s20, s21, and s22 are byte-identical captures; these do not provide independent temporal evidence that the robot has settled. Best stage estimate is acting, with uncertainty. No failure or recovery conclusion is justified by this view.

The white Your Turn button is clearly at the bottom-left robot seat: it is our turn.

Current top-seat blue small-blind marker and partial white dealer marker agree with the clearer s0/s10 images: dealer/small blind belongs to the opponent and big blind to the robot. The current robot big-blind marker is hidden; assignment is inherited from earlier visual evidence.

No face-up community cards are visible. One central card back is partly visible; the remainder of the board lane is substantially obscured. Earlier s0/s10 show five face-down board cards. These are excluded from community_cards; the current empty face-up board estimate is uncertain because of occlusion.

Robot inventory: four red 5-chips and three blue 10-chips are visible at the bottom. Green and brown groups are hidden by the robot. s0 shows four green 50-chips and four brown 100-chips; retain those as uncertain estimates, not current visible counts.

Opponent inventory: three red 5-chips and four blue 10-chips are visible at the top. Green and brown groups are hidden. s10 shows four green 50-chips and four brown 100-chips; retain those as uncertain estimates.

Robot current bet: one blue 10-chip is visible under the fingertips in the lower central lane, separated from the three remaining blue inventory chips. Best estimate is zero red, one blue, zero green, zero brown. The manipulation may still be in progress, and the hand hides part of this zone, so the whole bet estimate is uncertain.

Opponent bet: the right-of-board zone is hidden by the robot body. s10 clearly shows one red 5-chip there; inherit one red and zero of the other denominations with uncertainty. Do not count the current occlusion as an empty bet area.

No readable held card is visible. No exposed opponent hole cards, face-up robot hole cards, or fold signature are visible. Earlier hole cards were in their seat areas. Best outcome estimate is not_showdown, uncertain because relevant current regions are hidden. No hand comparison is possible or needed from this evidence.

Requested action_sequence.json, hole_card_cache.json, and previous parsed-state files were not found in the workspace (including a hidden/unignored filename search). s21 contains only its capture. No dispatched action intent or cached hole-card values were assumed.
