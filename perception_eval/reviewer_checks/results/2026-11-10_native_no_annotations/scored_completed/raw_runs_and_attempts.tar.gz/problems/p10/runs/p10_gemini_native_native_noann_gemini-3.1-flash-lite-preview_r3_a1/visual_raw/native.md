# Raw Perception Evidence

- Loop Stage: The "Your Turn" indicator is visible on the table. The robot hand is near the chips. The stage is `acting`.
- Blind: The game appears to be in progress, no clear blind marker. Assuming standard state, `big_blind` if not specified.
- Showdown: No community cards or cards revealed. `not_showdown`.
- Table Stability: Scene is stable.
- Turn Detection: "Your Turn" marker is present. `is_my_turn`: true.
- Community Cards: None visible.
- Chips Analysis:
  - My Chips (estimated stacks near robot):
    - 5 (Red): 1 stack of 4.
    - 10 (Blue): 1 stack of 4.
    - 50 (White/Gray): 1 stack of 4. (Hard to see exact stacks, estimating).
  - Opponent Chips (near opponent):
    - 5 (Red): 1 stack of 4.
    - 10 (Blue): 1 stack of 4.
    - 50 (White/Gray): 1 stack of 4.
- Bets: Both appear to have minimal bets/chips in play.
