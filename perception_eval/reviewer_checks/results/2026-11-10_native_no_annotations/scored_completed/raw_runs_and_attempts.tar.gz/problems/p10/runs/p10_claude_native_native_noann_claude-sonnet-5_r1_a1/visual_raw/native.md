# Native Visual Perception — s22 (s_current)

Image: `s_current/00_capture.jpg` (resolves to `s22/00_capture.jpg`).
Comparison image: `s21/00_capture.jpg` (byte-identical to current capture).

No `action_sequence.json`, `hole_card_cache.json`, or `sN-1/01_parsed_state.md`
exist in the workspace yet, so there is no prior parsed state to inherit from
and no cached hole cards. This appears to be a cold-start parse.

## Turn Detection (TURN_DETECTION.md)

A white circular button labeled "Your Turn" is visible in the lower-left
portion of the felt, inside the robot/player seat band (near the printed "6"
table-position marker, close to the bottom rail). This matches the
robot-turn-button area in TABLE_GEOMETRY.md. No turn button is visible on the
opponent/top side.

Judgment: **it is our turn**. The white "Your Turn" button is near the
robot/player seat at the bottom-left of the table.

## Scene Stability (SCENE_STABILITY.md)

Compared `s21/00_capture.jpg` and `s_current/00_capture.jpg` (= `s22`): the two
frames are pixel-identical. The dexterous hand is in a settled, near-idle pose
hovering just above the felt (not holding any card or chips), no cards or
chips have moved, and the human opponent is seated with arms crossed, not
interacting with the table.

Judgment: **Stable**. No motion between the last two captures, hand settled,
no human interference with table objects.

## Robot Behavior (ROBOT_BEHAVIOR.md)

The dexterous hand (Shadow Robot gripper) enters from the right side of the
frame and is positioned low over the felt, near the center-left betting lane,
in a near-idle/settled pose. It is not holding a card or chips. It partially
occludes the right-center and upper-right portions of the table (consistent
with the documented common occlusion zone), including part of the community
card lane and a chip cluster near the opponent side. No sign of being stuck,
pinning, or having disturbed any chip/card layout. Nothing indicates a failed
atom or need for human help.

## Blind/Button Recognition (BLIND_BUTTON_RECOGNITION.md)

A small blue circular button is visible near the upper/opponent side of the
table (left of the printed "1" position marker, close to the opponent
hole-card area). No white "DEALER" button or yellow "BIG BLIND" button is
separately resolvable at this image resolution/angle — the robot arm and
image clarity limit a fully confident read. Using the two-player rule (dealer
= small blind, other player = big blind): if the blue button is the small
blind marker at the opponent seat, the opponent is dealer/small blind and the
robot is big blind. This reading is low-confidence given the lack of a
preflight (`s0`) reference image and the small/blurry button text.

## Community Cards (COMMUNITY_CARDS.md)

The visible (unoccluded, left-of-arm) portion of the community-card lane
shows only printed felt artwork (a heart-suit icon and partial "TE..." text,
part of the mat design) and no face-up board cards. The right portion of this
lane is occluded by the robot arm/hand. No community cards are confidently
readable.

Judgment: **No community cards are visible** in the readable portion of the
board lane; the occluded portion cannot rule out a hidden card, so this is
treated as 0 visible community cards (preflop-consistent).

## Held Card Recognition (HELD_CARD_RECOGNITION.md)

The dexterous hand is not holding any card in this frame — fingers are empty,
hovering over the felt. No readable held card is visible.

## Chip Recognition (CHIP_RECOGNITION.md) and Bet Recognition (BET_RECOGNITION.md)

Chip geometry is difficult to fully disambiguate between "inventory" vs
"current bet" at this resolution/angle, and the robot arm occludes part of
the opponent-side and center-right chip groups. Visible chip clusters:

- Lower/robot-side cluster (left of the hand, near the "Your Turn" button and
  the printed lower "6" marker): multiple unfolded chip stacks showing red
  chips marked "5" and blue chips marked "10". Approximately 4 red (5-value)
  and 4 blue (10-value) chip faces are countable across this cluster. No green
  (50) or brown (100) chips are visible in this cluster.
- Upper/opponent-side cluster (near the opponent hole-card area, left of the
  blue button): a smaller group of red "5" and blue "10" chips, roughly 3 red
  and 3 blue faces visible. No green or brown chips are visible here either,
  but this cluster sits close to the robot-arm occlusion boundary, so
  additional chips (including possible 50/100 stacks) could be hidden behind
  the arm/hand and are not ruled out.
- No chip group is clearly separated into a distinct "left of community
  cards" vs "right of community cards" bet lane that is unambiguously
  different from the inventory clusters described above — the current-round
  bet areas are not confidently distinguishable from inventory at this
  resolution. No chips are confidently identifiable as sitting in a separate
  bet-only zone this frame; best visual read is that the visible clusters are
  inventory chips near each seat with no clearly separated active bet,
  consistent with a preflop/idle moment before a bet has been placed, but this
  is uncertain.
- 50 (green) and 100 (brown) denominations are not countable from the image
  for either side due to resolution and occlusion; reported as 0 with low
  confidence rather than confirmed absence.

## Showdown / Outcome (SHOWDOWN_OUTCOME.md)

No opponent hole cards are face-up. No robot hole cards are face-up or held.
No fold/muck signature (cards displaced toward the board) is visible. This is
not a showdown state.
