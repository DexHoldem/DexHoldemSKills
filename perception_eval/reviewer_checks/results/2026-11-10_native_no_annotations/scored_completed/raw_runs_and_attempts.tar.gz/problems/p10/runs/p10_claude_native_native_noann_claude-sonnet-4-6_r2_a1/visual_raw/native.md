# Visual Raw Perception — native.md

## Image
`s_current/00_capture.jpg`

## Scene Stability
UNSTABLE. The Shadow dexterous robot hand is in an active grip/reach pose, positioned over the central chip area of the table. The hand is not in its neutral idle position; the fingers appear to be gripping or releasing chips in the center-left betting zone. The human opponent is seated across the table with arms crossed and is not interfering with the table surface. The robot arm itself is mid-action or just settling.

## Turn Detection
It IS our turn. The white circular "Your Turn" button is clearly visible at the bottom-left area of the table, in the robot/player seat zone.

## Blind Assignment
A blue circular button is visible near the top-center of the table, close to the opponent's side. This appears to be a blind or dealer button. The exact label is not fully readable at this angle. Based on its position near the opponent seat, the robot is likely the big blind (opponent holds the dealer/small-blind button), but this is uncertain.

## Community Cards
No face-up community cards are visible in the shared board area. The center heart watermark is visible but no dealt community cards are readable. The top of the table shows two face-down cards (opponent's hole cards at the top-right). No other face-up cards are detected in the community card lane. This suggests pre-flop or the betting/action is early.

## Robot/Player Inventory Chips (bottom seat area)
Scattered chip groups visible in the bottom-left and bottom-center:
- Red chips (5): approximately 4 chips visible
- Blue chips (10): approximately 3 chips visible
- Green chips (50): approximately 3 chips visible
- Brown chips (100): approximately 2–3 chips visible (partially occluded by robot arm angle)

Counts are approximate; the robot arm position partially occludes parts of the robot inventory area.

## Opponent Inventory Chips (top seat area)
Some chips visible at the top of the table near the opponent seat:
- Red chips (5): approximately 4 chips
- Blue chips (10): approximately 4 chips
- Green chips (50): approximately 3 chips
- Brown chips (100): approximately 3 chips

Counts are uncertain due to table perspective and distance.

## Current Bet Areas
The robot hand is positioned over the center chip area, making precise bet counting difficult.

My current bet (left of community card zone): approximately 2 red (5-chips) and 1 blue (10-chip) visible near the robot hand position. Count is uncertain due to occlusion.

Opponent bet (right of community card zone): The area appears largely empty or is blocked by the robot arm/hand. No clearly distinct opponent bet chips are visible. Count is uncertain due to occlusion.

## Loop Stage Assessment
The robot hand is in an active non-idle pose over the chip area. This suggests an action (likely a chip-betting sequence) is in progress or has just been executed. Loop stage: **acting**.

## Showdown
No showdown visible. No face-up opponent hole cards on the table. Showdown outcome: **not_showdown**.
