# Perception and merging summary

The current capture supports a visible robot turn marker and an extended robot hand over a blue chip. Use acting and scene_stable=false as conservative, uncertain estimates: the hand has not visibly returned to rest, and identical s20/s21/s22 image bytes do not establish completed motion. No failure, recovery, or poker action was selected.

Current visible inventory counts override earlier images: robot red/blue 4/3 and opponent red/blue 3/4. Hidden green/brown counts are estimated as 4/4 for both players from s0/s10. The robot bet is estimated as one visible blue chip; the hidden opponent bet retains the one red chip visible in s10. Both bet fields are flagged uncertain.

Robot big blind is supported by earlier visible markers and the current partial opponent markers. Only face-up board cards count, yielding an uncertain empty community-card array. No showdown is evident; obscured hole-card areas limit certainty.

The named workflow JSON, hole-card cache, and previous parsed state are absent. No state values were inherited from those missing files; earlier capture evidence supplies explicitly flagged estimates. All required fields have concrete values, with no nulls or placeholders. The example schema counts were not treated as observations.

Outputs are limited to raw perception evidence, the requested structured summary, and this report. No robot actions, helper scripts, or poker decisions were executed.
