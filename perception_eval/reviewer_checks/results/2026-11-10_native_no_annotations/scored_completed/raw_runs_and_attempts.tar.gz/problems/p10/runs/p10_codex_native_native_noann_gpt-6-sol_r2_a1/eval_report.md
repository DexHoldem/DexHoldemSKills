# Perception evaluation

The current s22 capture matches s20–s21 while the robot arm remains extended over a blue bet chip. The white turn button is at the robot seat; no face-up board or showdown cards are visible. I therefore record `acting`, an unstable scene, and `not_showdown`.

Visible lower inventory is four red and three blue chips; visible upper inventory is three red and four blue. The arm hides both green/brown inventories and much of the betting lane. Counts for those hidden groups, the opponent's red bet, and the blind assignment use earlier capture images; the blue robot bet is partly visible under the gripper. The affected fields are listed in `uncertain_fields`.

The requested prior workflow/cache/parsed-state files were absent, so no nonvisual state was merged.
