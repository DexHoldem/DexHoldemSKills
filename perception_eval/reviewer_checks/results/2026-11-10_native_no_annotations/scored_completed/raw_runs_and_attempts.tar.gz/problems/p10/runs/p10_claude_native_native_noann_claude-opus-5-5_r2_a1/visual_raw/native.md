# Native perception — s22 (s_current)

Context: `action_sequence.json`, `hole_card_cache.json`, and `s21/01_parsed_state.md` are NOT present in the workspace. Compared images s0, s19, s20, s21, s22 directly.

## Scene stability / robot behavior
Unstable. Compared s20, s21, s22: the three frames are pixel-identical. The Shadow hand is NOT at its rest pose: the arm is extended across the center of the table, fingertips pressing down on a blue-edged 10-chip at roughly (710,700) on the lower/robot side of the board lane. In s19 the hand was pushing a 10-chip from the robot inventory toward the bet lane, so this looks like a chip push (bet) that did not return to rest. The hand has stayed on top of the chip for 3+ captures, so it may be stuck or pinning the chip. Following SCENE_STABILITY, I mark the scene unstable and leave escalation to the state machine. The hand and arm hide most of the board, the robot hole cards, the robot 50/100 inventory, the right side of the opponent inventory, and the opponent bet area. The layout that is still visible looks intact: no chips are scattered and no cards are exposed.

## Turn
It is our turn: the white "Your Turn" button is at the bottom-left robot seat (~(390,800)).

## Blind
The blind buttons are occluded in s22. In s19 the yellow BIG BLIND button is on the robot side and the DEALER and SMALL BLIND buttons are on the opponent side, so the robot is big blind (inferred from s19).

## Community cards
No face-up community cards are visible. One face-down card back shows in the first board slot (~(610,615)); the rest of the row is occluded. In s19 all board slots show card backs, i.e. preflop.

## Showdown
Not a showdown: no face-up hole cards, and the opponent's two face-down cards are still in the top hole-card area.

## Chips — robot inventory (bottom)
- Red 5: 4 visible ((580,780),(680,765),(700,815),(730,860)).
- Blue 10: 3 visible ((805,750),(840,800),(870,855)). s0 and s19 had 4, and one has been pushed into the bet lane.
- Green 50 / brown 100: occluded by the arm. Both were 4 in s0 and s19, so 4 each is inherited (uncertain).

## Chips — opponent inventory (top)
- Red 5: 3 visible ((550,485),(555,505),(565,527)). s0 had 4, s19 had 3.
- Blue 10: 4 visible ((640,478),(655,500),(670,522),(745,517)).
- Green 50 / brown 100: occluded by the arm. Both were 4 in s19, so 4 each is inherited (uncertain).

## Bets
- My current bet (lower/robot side of board): one blue 10-chip visible under the robot fingertips (~(710,700)). Part of the area is occluded, so the count is uncertain.
- Opponent bet (upper/opponent side): occluded by the arm. Opponent inventory dropped by one red 5 since s0, consistent with the small blind, so 1x 5-chip is inferred (uncertain).
