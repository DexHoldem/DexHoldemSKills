# Eval report — s22 perception

**Missing context:** action_sequence.json, hole_card_cache.json and sN-1/01_parsed_state.md do
not exist in the workspace. Durable fields were inherited from the s0 image instead.

**Key evidence**
- The robot hand is extended over the table with its fingertips on a red 5-chip in the robot bet
  lane. A chip push is in progress or the hand has not retracted → `loop_stage: acting`,
  `scene_stable: false`.
- s20, s21 and s22 look identical, so the hand has not moved for 3 captures. It may have stalled.
  Wait and recapture first. If it persists, escalate (reset_to_init or a human check).
- The "Your Turn" button is at the robot seat → `is_my_turn: true`.
- Blind comes from s0: BIG BLIND at the robot seat, DEALER + SMALL BLIND at the opponent seat
  (the opponent-side buttons are still visible now).
- No face-up board cards are visible and most board slots are occluded → `community_cards: []`
  (uncertain).

**Merging**
- Visible counts used directly: my 5s (4), my 10s (3), opp 5s (3), opp 10s (4), my bet 1×5.
- Occluded counts inherited from s0: my 50/100 (4/4), opp 50/100 (4/4).
- The opponent bet is occluded, so it is inferred as 1×5 (small blind; one red chip is missing
  from the opponent's inventory).
- All inherited or inferred fields are listed in `uncertain_fields`.
