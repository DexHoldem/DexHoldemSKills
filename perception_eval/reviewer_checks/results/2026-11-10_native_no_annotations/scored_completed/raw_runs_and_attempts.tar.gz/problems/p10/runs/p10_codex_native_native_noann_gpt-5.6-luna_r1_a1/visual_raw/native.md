# Raw visual perception

- Current image: `s_current/00_capture.jpg`.
- Compared with the matching recent frames `s21/00_capture.jpg` and `s22/00_capture.jpg`: the scene appears stable; the robot hardware/hand is settled but substantially occludes the center-right table.
- Orientation: robot/player seat is at the bottom; opponent seat is at the top.
- Turn: the white `Your Turn` button is visible at the bottom robot seat, so it is the robot's turn.
- Community cards: no face-up community cards are visible. Face-down card backs are not read as cards.
- Robot inventory: visible red and blue chip groups support 4 red 5-chips and 3 blue 10-chips; green 50-chips and brown 100-chips are largely occluded, estimated from the table setup as 3 each.
- Opponent inventory: visible top-side groups support 4 red 5-chips and 4 blue 10-chips; green 50-chips and brown 100-chips are occluded, estimated as 3 each.
- Betting areas: no betting chips can be safely separated from the inventory groups in this occluded frame; best estimate is zero on both sides, with bet counts marked uncertain.
- Blind: the preflight frame shows the big-blind marker at the robot/bottom seat; use `big_blind`.
- Showdown: no face-up hole cards, fold/muck signature, or showdown evidence is visible.
