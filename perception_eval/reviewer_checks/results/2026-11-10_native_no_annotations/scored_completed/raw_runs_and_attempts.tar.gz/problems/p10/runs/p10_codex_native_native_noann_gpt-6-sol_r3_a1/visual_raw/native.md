# Raw visual perception

Capture: `s_current/00_capture.jpg` (`s22`). Compared with `s21`, `s20`, `s19`, and `s18`. The s20–s22 image files are identical; s18–s19 show the robot hand moving from the lower chip area toward the center.

- The robot hand is extended over the lower central betting lane, with a fingertip on or immediately above a blue 10-chip. It is not near its rest pose and obscures much of the right half of the table, including the robot's green/brown inventory and parts of both betting areas. No held card is visible. The scene is not safely settled for a completed-action judgment.
- The white `Your Turn` button is visible at the lower robot seat. The yellow `BIG BLIND` button was visible at the robot seat in the last unobscured frame. The opponent has the dealer/small blind markers.
- No face-up community cards are visible. Five face-down backs occupy the board positions but are not readable community cards. The opponent's two hole cards remain face-down at the upper seat. There is no visible showdown or fold.
- Robot inventory: four red 5-chips and three blue 10-chips are visible at the lower seat. The green 50 and brown 100 groups are hidden by the arm; the last clear view showed four of each.
- Opponent inventory: three red 5-chips and four blue 10-chips are visible at the upper seat. The green 50 and brown 100 groups are hidden; the last clear view showed four of each.
- Robot bet area: one blue 10-chip is visible under the robot fingertip in the lower central lane. Its final placement is uncertain while the hand remains there. No other bet chip is visible outside the occlusion.
- Opponent bet area: no chip is visible in the exposed portion. Much of the right side is occluded by the robot arm, so zero for each denomination is only a provisional estimate.

The named context files `action_sequence.json`, `hole_card_cache.json`, and `s21/01_parsed_state.md` are absent from this workspace. Earlier images are used only to estimate obscured durable chip groups and blind assignment.
