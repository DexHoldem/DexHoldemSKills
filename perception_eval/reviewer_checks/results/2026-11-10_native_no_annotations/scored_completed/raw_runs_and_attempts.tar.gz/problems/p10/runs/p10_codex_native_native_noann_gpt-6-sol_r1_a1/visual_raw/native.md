# Raw perception: s22/00_capture.jpg

- Compared s19, s20, s21, and s22. The robot arm moved from the lower-right seat area at s19 into the central betting lane at s20 and remains extended there in s21–s22. Its hand is over a blue 10 chip, away from its initial pose. No card face is visible in the hand. The action does not appear complete; scene is unstable for the next decision.
- The white “Your Turn” button is visible at the bottom-left robot seat. The yellow “BIG BLIND” button was visible at the robot seat in earlier unobstructed frames; the current arm obscures its area.
- No face-up community cards are visible. The central cards are face-down. No opponent hole cards are face-up or visibly mucked; no showdown outcome is evident.
- Robot inventory, bottom seat: four red 5 chips and three blue 10 chips are visible. The fourth blue chip appears under the robot hand in the betting lane. Green 50 and brown 100 groups are hidden by the arm; last unobstructed view supports four of each.
- Opponent inventory, top seat: three red 5 chips and four blue 10 chips are visible. The green 50 and brown 100 groups are occluded by the arm; earlier unobstructed frames support four of each.
- Robot betting area: one blue 10 chip appears under the hand; placement is in progress, so the exact zone assignment is uncertain. No other bet chips are visible on this side.
- Opponent betting area: obscured by the robot arm. An earlier unobstructed frame (s10) shows one red 5 chip to the right of the board; this is carried forward as the best estimate. No other bet chips were visible there.
- The provided prior workflow JSON, hole-card cache, and previous parsed-state Markdown are absent from this workspace. Earlier captures supply only visual continuity for occluded fields.
