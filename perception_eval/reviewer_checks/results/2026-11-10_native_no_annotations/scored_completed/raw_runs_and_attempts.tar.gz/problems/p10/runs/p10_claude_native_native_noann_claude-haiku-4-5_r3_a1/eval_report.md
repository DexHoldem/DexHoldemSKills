# Evaluation Report - s22 Perception

## Frame Summary
- State: s22 (s_current)
- Stage: Preflop (0 community cards)
- Turn: Robot/player's turn (white "Your Turn" button at bottom-left seat)
- Blind: Robot is small blind (has dealer button)

## Evidence Collection

### Chip Inventories
All chip counts were directly visible and unoccluded:
- **Robot chips**: 4 red (5s), 3 blue (10s), 3 green (50s), 3 brown (100s)
- **Opponent chips**: 4 red (5s), 4 blue (10s), 3 green (50s), 3 brown (100s)
- Confidence: High - all denominations clearly visible

### Community Cards
- **Count**: 0 cards visible
- **Stage derivation**: Preflop
- **Confidence**: Certain - central row is empty

### Turn Detection
- **Button location**: White "Your Turn" button at bottom-left (robot seat)
- **Result**: `is_my_turn = true`
- **Confidence**: High - button clearly visible at robot position

### Current Bets
- **Robot bet area** (left of community cards): No chips visible
- **Opponent bet area** (right of community cards): No chips visible
- **Result**: Both bet zones empty; `my_current_bet` and `opponent_bet` are all zeros
- **Confidence**: High - betting lane is clear

### Blind Position
- **Dealer button location**: At robot seat (bottom-left)
- **Two-player rule**: Dealer = Small Blind, other player = Big Blind
- **Result**: `blind = "small_blind"` (robot is small blind)
- **Confidence**: High - dealer button visible at robot position

### Hand Status (Showdown)
- **Opponent hole cards**: Face-down, position unchanged from normal
- **Robot hole cards**: Face-down (unreadable)
- **Fold signature**: Absent - opponent cards in normal position
- **Stage**: Not in showdown; preflop action ongoing
- **Result**: `showdown_outcome = "not_showdown"`
- **Confidence**: High - clear preflop state with no fold indicators

### Scene Stability
- **Robot hand**: Settled near-idle pose on right side
- **Motion**: No blur or mid-action positioning
- **Table objects**: No visible movement in cards or chips
- **Opponent interference**: None - opponent at relaxed posture
- **Image quality**: Clear and sharp
- **Result**: `scene_stable = true`
- **Confidence**: High - stable scene ready for next decision

## Loop Stage Determination
- **Current action**: None running (robot hand is idle)
- **Table state**: Stable, not in motion
- **Parking position**: Near-idle pose (robot arm on right, settled)
- **Result**: `loop_stage = "idle"`
- **Confidence**: High - no active atom; scene is stable

## Uncertain Fields
None identified. All observable zones are clear and countable.

## Conclusion
The frame is suitable for the main agent's next decision. The robot is small blind, it is the robot's turn to act preflop, no bets are currently in play, the scene is stable, and all chip counts are directly visible.
