# Raw visual perception

- Capture used: `s22/00_capture.jpg` (the requested `s_current/00_capture.jpg` is absent).
- Stability comparison: `s22/00_capture.jpg` and `s21/00_capture.jpg` appear visually identical; the robot hand/camera assembly is settled in a near-idle pose, but occludes the lower-right table.
- Table geometry: robot/player is at the bottom; opponent is at the top.
- Turn: the white `Your Turn` button is visible at the bottom-left robot seat, so it is the robot's turn.
- Blind: the yellow `BIG BLIND` button is visible at the robot/bottom seat in the preceding clear frame (`s18`), so the robot is the big blind.
- Community cards: no face-up community card is visible. The central card area is mostly blocked; no card face can be safely read.
- Robot inventory: visible groups support approximately 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips. The lower-right groups are partly occluded by the robot assembly.
- Opponent inventory: visible top groups support approximately 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Current bets: no distinct chips are visibly placed in either betting area. The robot-side/lower-right bet lane is partly occluded, so zero is an estimate for that side.
- Showdown: no face-up opponent or robot hole cards and no fold/muck signature are visible; this is not showdown.

