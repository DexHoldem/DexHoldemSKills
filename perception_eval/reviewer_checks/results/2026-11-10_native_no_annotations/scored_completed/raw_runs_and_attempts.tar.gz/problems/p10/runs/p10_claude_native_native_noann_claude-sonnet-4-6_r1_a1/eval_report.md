# Eval Report — s_current (s22)

## Evidence Summary

**Images used**: s_current/00_capture.jpg, s22/00_capture.jpg (identical frames).
No prior parsed states, action_sequence.json, or hole_card_cache.json available.

---

## Key Findings

| Field | Value | Confidence |
|---|---|---|
| scene_stable | true | High — both frames identical, hand settled |
| is_my_turn | true | High — "Your Turn" button clearly visible at robot seat |
| loop_stage | acting | High — "Your Turn" showing, robot needs to decide |
| community_cards | [] (preflop) | High — no face-up cards in central row |
| showdown_outcome | not_showdown | High — no face-up hole cards |
| blind | big_blind | Medium — blue button at opponent seat suggests opponent is SB; robot is BB |
| my_chips | {5:3, 10:3, 50:2, 100:2} | Low — partial occlusion by robot arm |
| opponent_chips | {5:4, 10:4, 50:2, 100:2} | Low — distance and angle limit precision |
| my_current_bet | {5:3, 10:0, 50:0, 100:0} | Low — robot hand obscures bet area |
| opponent_bet | {5:0, 10:0, 50:0, 100:0} | Low — robot arm occludes opponent bet zone |

---

## Merging Notes

- No prior parsed state to inherit from (first perception pass in this run).
- Blind assignment inferred from blue button at opponent seat; no dealer button text
  confirmed at this resolution. Field marked uncertain.
- Chip counts are direct visual reads; all denominations above 10 have elevated
  uncertainty due to robot arm occlusion and camera angle. If a clearer frame is
  available, re-running chip recognition is recommended.
- Robot hand is in central table position (not init pose), suggesting the robot has
  recently acted or is mid-decision. Scene is stable; next step is acting decision.
