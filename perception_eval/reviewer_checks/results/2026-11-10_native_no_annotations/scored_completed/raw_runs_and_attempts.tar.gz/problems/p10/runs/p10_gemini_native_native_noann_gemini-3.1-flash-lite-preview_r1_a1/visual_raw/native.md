# Raw Perception Evidence - Step s22

## Scene Analysis
- The scene appears stable.
- Community cards are not visible in this capture (assuming a pre-flop or early stage state if this is the start of the game).
- Robot chip count: 4x5, 3x10, 3x50, 3x100.
- Opponent chip count: 4x5, 4x10, 3x50, 3x100.
- No bets are currently placed on the table (all chip counts for bets are 0).
- Robot is in the big blind position.
- Loop stage is idle.

## Field Extraction
- `loop_stage`: idle
- `blind`: big_blind
- `showdown_outcome`: not_showdown
- `table.scene_stable`: true
- `table.is_my_turn`: true
- `table.community_cards`: []
- `table.my_chips`: {"5": 4, "10": 3, "50": 3, "100": 3}
- `table.opponent_chips`: {"5": 4, "10": 4, "50": 3, "100": 3}
- `table.my_current_bet`: {"5": 0, "10": 0, "50": 0, "100": 0}
- `table.opponent_bet`: {"5": 0, "10": 0, "50": 0, "100": 0}
- `table.uncertain_fields`: []
