# Eval Report — s22

## Summary
Scene is stable: `s21` and `s22` are visually identical. The robot's arm and
Shadow-Hand are extended across the middle of the table in a settled pose over
the community-card row. A "Your Turn" marker is clearly visible on the robot's
own side of the felt, indicating it is my turn to act.

## Key Evidence
- Turn marker: "Your Turn" chip on bottom-left felt → `is_my_turn = true`.
- Blind: a small round white marker (dealer/blind button) sits on the
  opponent's side of the felt, suggesting I am the big blind in this heads-up
  hand.
- Community cards: the dexterous hand occludes the center community row;
  only a partial card back and a hint of a spade suit are visible. No read
  possible, so `community_cards` left empty and flagged uncertain.
- Chips: both sides show visible 5 and 10 denomination stacks; 50/100 stacks
  are mostly hidden by the arm. Counts are rough estimates — flagged
  uncertain.
- Bets: no distinct forward bet piles visible → both bets set to zero.
- Showdown: no face-up comparison cards → `not_showdown`.
- Loop stage: arm settled, "Your Turn" visible → `idle`.

## Merging From Context
- No `sN-1/01_parsed_state.md`, `action_sequence.json`, or
  `hole_card_cache.json` files were present in the workspace, so durable
  fields were estimated from the capture plus conservative defaults
  (3 × 50-chips and 3 × 100-chips per side) rather than inherited.
- All occluded or inherited fields are listed in `uncertain_fields`.

## Outputs Verified
- `runs/p10_claude_native_native_noann_claude-opus-4-7_r2_a1/visual_raw/native.md`
- `runs/p10_claude_native_native_noann_claude-opus-4-7_r2_a1/visual_summary.json`
- `runs/p10_claude_native_native_noann_claude-opus-4-7_r2_a1/eval_report.md`
