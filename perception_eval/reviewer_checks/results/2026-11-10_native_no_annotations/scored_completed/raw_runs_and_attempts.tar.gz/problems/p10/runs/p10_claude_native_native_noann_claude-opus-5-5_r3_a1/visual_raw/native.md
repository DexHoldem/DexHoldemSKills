# Native perception — s_current (-> s22/00_capture.jpg)

Context: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` are NOT present in the workspace. Compared frames: s20, s21, s22 (visually identical), plus s0 for durable/initial layout.

## Robot behavior / scene stability
Unstable. Compared s21/00_capture.jpg and s22/00_capture.jpg (and s20). The dexterous hand + arm are extended far over the centre of the table, NOT at rest/near-idle pose. Fingertips rest on/at a single chip in the robot-side betting lane (just below the community row, ~x=710,y=700), consistent with a chip push in progress. Hand is not holding a card. The same pose appears in three consecutive captures (s20–s22), so it is either a paused/slow atom or possibly stuck pressing on the chip. No damage to the layout is visible, but the hand has not settled. Treat as still in progress (acting); repeated identical extended frames may warrant escalation by the higher-level state machine.

## Turn
It is our turn. The white "Your Turn" button is at the robot seat, bottom-left of the table (~x=390,y=800).

## Blinds
Dealer button (white) and blue SMALL BLIND button are at the top/opponent seat (~x=830–860,y=470–500). Opponent = dealer/small blind; robot = big blind (consistent with s0, where the yellow BIG BLIND button was on the robot side). The big-blind button itself is occluded by the arm in s22.

## Community cards
No face-up community cards visible. One face-down card back is visible at the left of the board row (~x=620,y=615); the rest of the board row is occluded by the hand/arm. Board read: none visible (uncertain due to occlusion).

## Robot inventory (bottom seat)
- red 5: 4 visible (clear)
- blue 10: 3 visible (clear)
- green 50: not visible, occluded by robot arm (s0 showed 3)
- brown 100: not visible, occluded by robot arm (s0 showed 3)

## Opponent inventory (top seat)
- red 5: 3 visible (s0 showed 4; the leftmost 4th chip is no longer visible)
- blue 10: 4 visible
- green 50 / brown 100: occluded by the robot arm (s0 appeared to show ~4 and ~4; low confidence)

## Bets
- My current bet area (robot side of board): one chip under the robot fingertips, white/blue-rim face. Best read 1x blue 10 (uncertain; could be a red 5; partly occluded by fingers). The rest of the lane to the right is occluded by the arm.
- Opponent bet area (opponent side of board): left portion empty; right portion occluded by the arm/hand. No chips countable, so uncertain.

## Showdown
Not showdown. The opponent card back (one visible, ~x=750,y=483) is in its normal top-seat slot, face-down; no fold signature, no face-up hole cards.
