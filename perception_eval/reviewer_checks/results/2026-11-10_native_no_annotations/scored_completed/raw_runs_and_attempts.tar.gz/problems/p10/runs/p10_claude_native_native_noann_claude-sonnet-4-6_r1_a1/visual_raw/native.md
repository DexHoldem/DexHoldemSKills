# Raw Perception Evidence — s_current (s22)

## Images Compared
- s_current/00_capture.jpg (= s22/00_capture.jpg, latest state)
- s22/00_capture.jpg (previous frame for stability comparison)

Both frames appear pixel-identical, confirming the scene is settled.

---

## Scene Stability

Stable. Compared s_current/00_capture.jpg and s22/00_capture.jpg. The two frames are
identical. The Shadow dexterous hand is in a static position over the central table area.
No card or chip movement is visible between frames. The opponent is seated with arms
crossed and is not interfering with the table. The scene is stable enough for the main
agent to continue.

---

## Turn Detection

It is our turn. The white circular "Your Turn" button is clearly visible at the
lower-left of the table in the robot/player seat band (approximately x=250, y=600 in the
image), which matches the expected robot-turn button zone (7–17% x, 73–86% y per
TABLE_GEOMETRY). No other turn button is visible at the opponent side.

---

## Blind Button

A blue circular button is visible in the opponent's seat area (upper portion of the felt,
left of center). Per BLIND_BUTTON_RECOGNITION, a blue button is consistent with a
"SMALL BLIND" marker. This suggests the opponent holds the dealer/small-blind position
and the robot is the big blind. The button text is not fully readable at this resolution,
so the blind assignment is marked uncertain.

---

## Community Cards

No face-up community cards are visible in the central row. The heart suit symbol visible
in the center of the table is a felt decoration, not a card. There is a face-down card
visible to the left-center of the community card row area, likely the deck stub or a
face-down dealt card. No community card values are readable. Board stage: preflop (0
face-up community cards).

---

## Chip Recognition

### Robot/Player Inventory (bottom seat band, outside bet lane)
Chips visible in the lower seat area, to the right of the "Your Turn" button:
- Red chips (5): approximately 3 visible
- Blue chips (10): approximately 3 visible
- Green chips (50): 2 estimated (partially occluded, behind red/blue group)
- Brown chips (100): 2 estimated (partially occluded at rear of inventory group)
Counts for 50 and 100 are uncertain due to angle and partial occlusion by robot arm.

### Opponent Inventory (top seat band, outside bet lane)
Chips visible in the opponent's area at the upper-left of the felt:
- Red chips (5): approximately 4 visible
- Blue chips (10): approximately 4 visible
- Green chips (50): approximately 2 estimated (less distinct at distance)
- Brown chips (100): approximately 2 estimated (less distinct at distance)
All opponent inventory counts are approximate; angle and distance reduce clarity.

---

## Bet Recognition

### Robot Current Bet (central lane, robot side of community cards)
The Shadow dexterous hand is hovering over the robot bet area. Under and near the
hand, approximately 3 red chips (5-denomination) are visible. No blue, green, or brown
chips are clearly identifiable in the robot bet zone. Robot bet count is uncertain due
to hand occlusion.

### Opponent Bet (central lane, opponent side of community cards)
The robot arm partially occludes the opponent bet area. No chips are clearly countable
on the opponent side of the community card row. Opponent bet count is uncertain due
to robot arm occlusion; zero is the best estimate but should be treated with low
confidence.

---

## Showdown / Hand Outcome

No showdown in progress. The opponent's hole cards are face-down in the upper
seat area; no face-up opponent hole cards are visible. The robot's hole cards area
(lower seat, near the hand) is partially occluded by the robot arm but no face-up
robot cards are visible either. No showdown outcome is determinable. Status:
not_showdown.

---

## Loop Stage Assessment

The "Your Turn" button is at the robot seat. The robot hand is settled in a mid-table
position over the bet area. This is consistent with an acting state where the robot
needs to decide its next poker action. Loop stage: acting.
