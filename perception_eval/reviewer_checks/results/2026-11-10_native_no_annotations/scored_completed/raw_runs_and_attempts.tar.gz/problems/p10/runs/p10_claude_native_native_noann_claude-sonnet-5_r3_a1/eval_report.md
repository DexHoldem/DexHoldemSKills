# Eval Report — Perception Step (s22 / s_current)

## Context available

- No `action_sequence.json` or `hole_card_cache.json` exist in this workspace.
- No prior `sN/01_parsed_state.md` exists at all (checked s0 through s21); only
  raw `00_capture.jpg` files exist per state folder. So there is no durable
  parsed-state field to inherit — every field below is derived fresh from
  images.
- Used `s0/00_capture.jpg` as the preflight baseline (clear, unoccluded view)
  to establish blind/button assignment and initial chip-cluster layout, per
  `BLIND_BUTTON_RECOGNITION.md`.
- Used `s21/00_capture.jpg` as the immediately-previous frame for scene
  stability, per `SCENE_STABILITY.md`.

## Key evidence and merging

- **Scene stability**: `s21` and `s22` are visually identical (same hand pose,
  same chip/card positions) → `scene_stable: true`.
- **Turn**: white "Your Turn" button visible at robot/bottom seat in both `s0`
  and current frame → `is_my_turn: true`.
- **Blind**: `s0` shows "DEALER" + blue "...BLIND" (small blind) buttons at the
  opponent seat and a yellow "BIG BLIND" button at the robot seat. Two-player
  rule: dealer = small blind, so opponent is dealer/SB and robot is BB →
  `blind: big_blind`. The same blue button is still present at the opponent
  side in the current frame, so this assignment is treated as unchanged/stable
  for this hand.
- **Community cards**: all 5 board slots were face-down in the `s0` baseline
  (preflop). In the current frame, 4 of 5 slots are hidden behind the robot's
  arm/camera housing; the one visible slot is still face-down. No rank/suit is
  readable anywhere → `community_cards: []`, flagged uncertain because most of
  the row is currently occluded and cannot be re-confirmed from this frame
  alone.
- **Chips**: both players' near-side chip clusters (closest to the "Your Turn"
  button / opponent's hole cards) are visible and countable in the current
  frame: robot ≈ 4×5 + 4×10; opponent ≈ 3×5 + 3×10. Both players' far-side
  clusters (higher denominations, nearer the table edge/dealer button) are
  fully hidden behind the robot's arm/body in the current frame but were
  visible in the `s0` baseline (robot: +3×10, 3×50, 3×100; opponent: +3×10,
  2×100, 0×50 observed). Since the layout has not visibly changed between
  frames (stable scene, no betting action evidenced), these baseline counts
  are carried forward for the occluded portions and reported as the best
  concrete estimate, with `my_chips` and `opponent_chips` flagged uncertain.
- **Bets**: no chips are visible in the central betting lane between either
  inventory and the community-card row in either `s0` or the current frame →
  both `my_current_bet` and `opponent_bet` reported as all-zero.
- **Showdown**: opponent hole cards are face-down, no fold/muck displacement
  toward the board, no community cards readable → `showdown_outcome:
  not_showdown`.
- **Loop stage**: robot hand is settled in a near-idle (not true-initial) pose,
  identical across the last two frames, not holding a card or chips, not
  stuck. With no `action_sequence.json` to confirm which atom was last
  dispatched, this is reported as `atom_idle` (settled, ready for next
  decision) and flagged uncertain since the specific stage label can't be
  cross-checked against dispatch history.

## Uncertain fields

- `my_chips` — far-side denominations (10/50/100) inherited from `s0` baseline
  due to current occlusion by the robot arm.
- `opponent_chips` — far-side denominations (10/100) inherited from `s0`
  baseline; 50-count never observed in any available frame.
- `community_cards` — 4 of 5 board slots occluded in current frame; only
  inferred as still face-down from the one visible slot and the `s0` baseline.
- `loop_stage` — no `action_sequence.json` available to confirm the specific
  dispatched atom; `atom_idle` is the best visual read of a settled,
  near-idle, non-moving hand.

## Output files written

- `visual_raw/native.md`
- `visual_summary.json`
- `eval_report.md`
