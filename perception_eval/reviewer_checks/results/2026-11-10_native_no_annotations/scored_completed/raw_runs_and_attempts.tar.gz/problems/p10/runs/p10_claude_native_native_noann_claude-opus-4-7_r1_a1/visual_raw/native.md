# Native Visual Perception — s_current

## Turn
A small white "Your Turn" button is clearly visible at the lower-left side of
the table near the robot/player seat. It is our turn.

## Blind / Button
A blue (small blind) button is visible on the opponent side of the table,
near the top-center next to the opponent's chips. By the two-player rule, the
opponent holds the dealer/small-blind position, so the robot is the big blind.

## Scene Stability
The robot arm/dexterous hand is extended well into the center of the table
with the gripper positioned over the community-card row, apparently in the
middle of placing/holding a card. This is NOT a near-idle pose. The scene is
unstable — the arm is mid-motion/mid-action over the board.

## Community Cards
Heavy occlusion by the robot gripper over the center. I can make out one
face-up card in the community row showing a black suit symbol (appears to be
a spade/heart pip near where the gripper is). The exact card rank/suit are
not safely readable. Other community positions are either empty felt or
occluded by the robot body. Best estimate: 0 clearly readable community
cards; the central area is largely obscured. Treating as preflop / unknown.

## Robot Hole Cards
Not visible in this frame — the bottom area near the robot seat does not show
face-down robot hole cards clearly (they may be face-down on the lower rail
but the lower edge is cropped/obscured).

## Opponent Hole Cards
Two face-down cards appear on the opponent side (top-center of the table),
consistent with opponent holding hole cards.

## Chip Inventories
Heavy right-side occlusion by the robot arm. Visible chip groups:

- Opponent inventory (top seat band):
  - Red 5-chips: ~4 visible
  - Blue 10-chips: ~4 visible
  - Green 50-chips: not clearly visible (likely occluded)
  - Brown 100-chips: not clearly visible (likely occluded)
- Robot inventory (bottom seat band, lower-left and lower-center):
  - Red 5-chips: ~4 visible (in a row near the lower rail)
  - Blue 10-chips: ~3 visible
  - Green 50-chips: not clearly visible (likely occluded by arm)
  - Brown 100-chips: not clearly visible (likely occluded)

Green and brown chips for both players are uncertain due to the robot-arm
occlusion over the right half of the table. Using standard starting
inventory as a fallback for durable denomination counts.

## Current Bets
The central betting lane between players is largely occluded by the robot
gripper. I can see what looks like one or two red (5) chips just below the
gripper in the robot bet lane area, but this may be the gripper holding a
chip, not a placed bet. No clearly placed bets are confidently countable.
Treating both current-bet areas as empty/no visible bet chips.

## Showdown
No showdown layout visible — the community cards area has at most 1 unclear
card and the opponent's hole cards are face-down. Not a showdown.

## Summary
It is our turn (robot seat has "Your Turn" button). Robot is the big blind
(opponent has SB/dealer). Scene is unstable: robot hand is mid-motion over
the board. Bets, community cards, and portions of both inventories are
occluded and uncertain.
