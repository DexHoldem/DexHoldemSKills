# Native Visual Perception — s22 (s_current)

Image: `s_current/00_capture.jpg` (symlink -> `s22/00_capture.jpg`).
Comparison image: `s21/00_capture.jpg`.

No `action_sequence.json`, `hole_card_cache.json`, or prior `sN-1/01_parsed_state.md`
were found anywhere in the working directory — this appears to be the first
parsed state for this session, so there is no durable prior state to inherit.
All fields below are derived from visual evidence only.

## Scene Stability

Compared `s21/00_capture.jpg` and `s22/00_capture.jpg`. The two frames are
visually identical: the dexterous hand is in the same position hovering just
above/near the chip area (not the true initial pose, but not moving), no
card or chip has changed position, and the opponent's crossed-arm posture is
unchanged. **Stable.** No large robot movement, no card/chip transfer, no
human arm on the table.

## Turn Detection

A white circular button labeled "Your Turn" is visible at the bottom/robot
seat area (lower-left of the board, near the "6" seat label on the robot
side). Per the turn-detection rule (physical button only), this means **it
is the robot/player's turn.**

## Table Geometry / Orientation

Camera looks diagonally from the robot side toward the opponent (white
T-shirt, arms crossed, top of frame). Robot arm/gripper enters from the
right and partially occludes the right-center of the table. A camera/mic
stand further occludes the upper-right area. Seat number "6" is printed on
the felt at both the opponent (upper) and robot (lower) seat positions
(fixed table markings, not blind indicators). A seat label "1" is visible at
the upper-right edge of the felt.

## Community Cards

No face-up community cards are visible. A single face-down card sits near
the center of the board (near the heart icon / "TEXAS" text), consistent
with the community-card row zone, but it is face-down, so its value is not
read and it is not counted as a community card per the guideline (do not
guess face-down cards). **0 community cards visible → preflop.**

A face-down card stack is also visible at the far-left edge of the table —
this is the deck, not a community or hole card.

## Hole Cards

- Opponent hole-card area (upper-center, roughly aligned under the "6" seat
  label and the opponent's chip cluster): a face-down card/card-back square
  is visible. It is face-down, so no value is read. No opponent hole cards
  are face-up, so no showdown-relevant read is possible here.
- Robot hole cards: not clearly distinguished as a separate face-down pair
  in this frame; the robot hole-card zone is partially crowded by chip
  clusters and the gripper. No robot hole card is currently held/visible
  face-up in the dexterous hand, so no held-card read applies.

## Held Card / Robot Behavior

The dexterous hand is extended over the table near the chip area, fingers
close to the inventory/bet chip region on the robot side, but it is not
holding a card or chips, and it is not in the exact initial rest pose (a
near-idle pose per `ROBOT_BEHAVIOR.md`). This near-idle pose does not appear
to be blocking the opponent's betting area in this frame. No stuck/pinned
behavior, no scattered chips, no dropped/exposed card. The scene is safe to
continue; no human-help condition observed.

## Chips

Chips are unfolded/flat, arranged in small overlapping fans rather than
vertical stacks, consistent with the chip guideline (count individual faces,
not stack height). Denominations: red=5, blue=10, green=50, brown=100.

- **Opponent inventory** (top/opponent seat band, near the "6" seat label
  and opponent hole-card area): roughly 3 red (5) chips and 3 blue (10)
  chips visible in a fanned cluster. No green or brown chips are clearly
  visible in this cluster — could be occluded or absent; **uncertain**.
- **Robot inventory** (bottom/robot seat band, below/right of the "Your
  Turn" button, outside the central betting lane): a fanned cluster of red
  (5) chips (~3-4 visible faces) and two fanned clusters of blue (10) chips
  (~7-8 visible faces total). No green or brown chips are clearly
  identifiable in this zone from this image; **uncertain**, since the
  gripper partially overlaps the edge of the red-chip cluster.
- **My current bet** (betting lane, robot/lower side of the community-card
  row): no distinct chip cluster is visible between the robot inventory and
  the single face-down center card. Best read: **no bet chips visible** on
  the robot side.
- **Opponent bet** (betting lane, opponent/upper side of the community-card
  row): no distinct chip cluster separate from the opponent inventory
  cluster is visible. Best read: **no bet chips visible** on the opponent
  side. This read is **uncertain** because the opponent inventory and any
  possible bet chips sit close together at this camera angle/resolution.

## Blind / Button

A small blue circular disc is visible near the opponent's hole-card area,
partially occluded by the camera/mic stand; its label text is not readable
at this resolution. No clearly labeled "DEALER", "SMALL BLIND", or "BIG
BLIND" button text could be confirmed. Following the two-player rule, if
this blue disc is the small-blind/dealer marker on the opponent side, the
robot would be the big blind. This is **uncertain** — the button label
itself could not be confirmed legible.

## Showdown / Outcome

No opponent hole cards are face-up, there is no evidence of a fold (the
face-down card near the opponent hole-card area has not been displaced
toward the community-card lane relative to the prior frame), and the board
shows no face-up community cards. This is an ordinary in-progress
(preflop, robot's turn) state, not a showdown. **not_showdown.**
