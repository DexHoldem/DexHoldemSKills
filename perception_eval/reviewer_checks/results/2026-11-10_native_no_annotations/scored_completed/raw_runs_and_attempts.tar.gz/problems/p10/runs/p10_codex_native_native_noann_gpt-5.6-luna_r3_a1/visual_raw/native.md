# Raw visual perception

- Compared `s_current/00_capture.jpg` (`s22`) with the preceding capture `s21/00_capture.jpg`; the frames are visually identical. The dexterous hand/arm is in a fixed settled pose, with no visible card or chip transfer. Scene is stable.
- The white `Your Turn` button is at the bottom robot/player seat, so it is the robot's turn.
- No face-up community cards are visible in the center board area.
- No chips are visible in either current betting area adjacent to the community-card lane.
- Robot/player inventory, counted by denomination/color: 4 red 5-chips, 3 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- Opponent inventory, counted by denomination/color: 4 red 5-chips, 4 blue 10-chips, 3 green 50-chips, and 3 brown 100-chips.
- The table is preflop by the zero-card board count. The visible blind/turn arrangement is consistent with the robot being big blind.
- No face-up showdown cards, fold/muck displacement, or outcome indicator is visible. Showdown outcome is not_showdown.
