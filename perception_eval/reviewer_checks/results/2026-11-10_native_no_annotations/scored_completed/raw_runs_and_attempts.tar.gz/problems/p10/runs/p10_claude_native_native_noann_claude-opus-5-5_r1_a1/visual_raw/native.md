# Native perception — s_current (-> s22/00_capture.jpg)

Context note: `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md`
were NOT present in the workspace. Context came from earlier captures only
(s0 for blinds/initial layout, s20/s21 for stability comparison).

## Robot behavior
The Shadow dexterous hand is extended far over the table (fingers around x≈580-870, y≈540-700).
It is not in initial/rest pose. Its fingertips rest on/at a single red 5-chip at ~(710,700) on the
robot side of the community lane. This looks like a chip push (bet) that is in progress or finished
without the hand retracting. It is not holding a card. No scattered chips or displaced cards are
visible in the unoccluded areas. The hand/wrist occludes the right half of the table: robot hole
cards, robot 50/100 inventory, the right community-card slots, the opponent's right-side
inventory, and the opponent bet area.

## Scene stability
Unstable (robot not settled). Compared s20, s21, s22: the three frames look visually identical
(s21 and s22 have identical file sizes). The hand has not moved across three captures while
extended over the table, which suggests a possible stall after a chip push. The hand is still not in
a settled idle pose and occludes key zones, so the frame is not safe for a poker decision.
The human opponent is seated with arms crossed and is not touching the table.

## Turn
It is our turn. The white "Your Turn" button is at the bottom-left robot seat (~(390,800)).

## Blind
From s0: the yellow BIG BLIND button is at the robot seat. The blue SMALL BLIND and white DEALER
buttons are at the opponent seat. In the current frame the blue small-blind and white dealer
buttons are still visible at the opponent seat (~(845,467), (860,500)). Robot = big blind.

## Community cards
No face-up community cards are visible. One face-down card back sits at ~(620,615) in the leftmost
board slot, and the hand occludes the remaining slots. A face-down deck is at the far left edge.
Treat as 0 community cards (preflop). This is uncertain because of the occlusion.

## Robot inventory (bottom seat)
- red 5: 4 visible (~(590,780), (680,768), (700,812), (730,860))
- blue 10: 3 visible (~(805,752), (840,803), (870,858)); a 4th position at ~(895,745) from s0
  is at the hand edge, so this count is uncertain
- green 50 / brown 100: fully occluded by the arm; inherited from s0 (4 / 4)

## Opponent inventory (top seat)
- red 5: 3 visible (~(550,485), (555,505), (565,528)); s0 had a 4th at ~(480,540) that is now gone
- blue 10: 4 visible (~(640,478), (655,500), (670,522), (745,517))
- green 50 / brown 100: occluded by the hand; inherited from s0 (4 / 4)

## Bets
- My current bet (robot side of board): 1 red 5-chip at ~(710,700), under the fingertips and being
  pushed. Uncertain, because more chips may be hidden under the hand.
- Opponent bet (opponent side of board): not countable because the robot hand occludes it. Best
  estimate is 1 red 5-chip (small blind; the opponent's 4th red chip is missing from inventory).
  Uncertain.

## Showdown
No face-up opponent hole cards. One opponent card back is visible in its normal top-seat slot
(~(750,480)). Not showdown.
