# Perception summary

The robot hand remains extended over a blue chip in the lower betting lane. Earlier frames show motion toward that position; the latest three files are identical, but the hand has not returned to rest or clearly completed placement. The current state is therefore estimated as `acting` with `scene_stable: false`. The white turn marker is at the robot seat, the robot is the big blind, and no face-up community or showdown cards are visible.

Visible inventory counts are robot 4 red/3 blue and opponent 3 red/4 blue. Green and brown inventory counts are carried from the last unobscured image as four each. One blue chip is visible beneath the robot fingertip in the robot betting lane, with its final placement uncertain. The occluded opponent betting lane is estimated empty. These uncertainties are listed in `visual_summary.json`.

The requested prior JSON caches and previous parsed state are absent, so no workflow state was merged from them. No robot or poker action was selected or executed.
