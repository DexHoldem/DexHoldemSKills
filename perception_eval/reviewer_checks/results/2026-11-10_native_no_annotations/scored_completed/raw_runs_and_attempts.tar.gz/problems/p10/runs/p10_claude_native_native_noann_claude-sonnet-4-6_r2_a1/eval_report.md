# Eval Report

## Image
`s_current/00_capture.jpg`

## Evidence Summary

**Scene stability**: UNSTABLE. The Shadow dexterous hand is in an active grip pose over the central chip area, not in its neutral idle position. Loop stage is `acting`.

**Turn**: The white "Your Turn" button is clearly visible at the bottom-left robot seat area → `is_my_turn = true`.

**Community cards**: No face-up community cards observed in the shared board lane. Two face-down cards at top-right are the opponent's hole cards. → `community_cards = []` (pre-flop or no cards dealt yet).

**Blind**: A blue circular button near the top-center of the table (opponent side) is consistent with a dealer/small-blind button at the opponent seat, making the robot the big blind. This assignment is uncertain (button label not clearly readable) and is flagged in `uncertain_fields`.

**Chip counts**: Robot inventory in the bottom seat area shows approximately 4 red, 3 blue, 3 green, 2 brown chips. Opponent inventory shows approximately 4 red, 4 blue, 3 green, 3 brown chips. Both sets are approximate and flagged uncertain because the robot arm partially occludes parts of the table.

**Bets**: The robot hand is over the center chip zone, making bet counts uncertain. My current bet estimated at 2 red + 1 blue. Opponent bet appears empty. Both flagged uncertain.

**Showdown**: No face-up opponent hole cards on the table. Outcome = `not_showdown`.

## Merging Notes

- No prior `01_parsed_state.md` or `action_sequence.json` / `hole_card_cache.json` available; all values are based solely on direct visual evidence from the current frame.
- All chip fields and blind assignment carry uncertainty flags.
- The scene being unstable (robot mid-action) means downstream action selection should wait for a stable frame before making a poker decision.
