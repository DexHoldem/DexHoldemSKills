# Raw visual perception — s22

Compared `s_current/00_capture.jpg` (resolves to `s22`) with `s21/00_capture.jpg`, `s20/00_capture.jpg`, `s19/00_capture.jpg`, and the initial `s0/00_capture.jpg`.

- **Scene/robot:** The dexterous hand and large camera housing remain extended across the central and right table. The gripper is over a blue chip near the robot betting lane. Its pose looks unchanged across s20–s22, but it has not returned to a rest pose and still contacts or covers the chip. The action cannot be judged finished from these frames. The hand/housing blocks both betting areas and the green/brown inventory groups. No scattered chips or displaced cards are visible in the uncovered area.
- **Turn:** The white `Your Turn` button is clearly at the lower-left robot seat. It is the robot's turn.
- **Board:** No face-up community cards are visible. Gray card backs in the central lane are not face-up board cards.
- **Hole cards/outcome:** The opponent's two cards remain face-down near their normal top-seat position. There is no visible fold or showdown. Robot hole cards are obscured or face-down; no readable held card is visible.
- **Blind:** In s0 and s19, the dealer button is at the opponent seat and the yellow big-blind button is at the robot seat. Current buttons are obscured by the robot body; robot big blind is inherited from those visual frames.
- **Robot inventory:** Four red 5 chips and three blue 10 chips are visible in the lower inventory. Green 50 and brown 100 groups are behind the robot housing; estimate four of each from the earlier unobscured image.
- **Opponent inventory:** Three red 5 chips and four blue 10 chips are visible at the upper seat. Green 50 and brown 100 groups are obscured; estimate four of each from the earlier unobscured image.
- **Robot bet:** One blue 10 chip is visible beneath the gripper in the central/lower betting lane. No other bet chips can be confirmed; estimated counts are 0 red, 1 blue, 0 green, 0 brown.
- **Opponent bet:** The opponent betting lane is blocked. The opponent inventory has one fewer red chip than the initial view, consistent with one red 5 chip posted as the small blind. Estimate 1 red, 0 blue, 0 green, 0 brown; this is inferred, not directly visible.

`action_sequence.json`, `hole_card_cache.json`, and a prior parsed-state markdown file are not present in this workspace. The estimates above use the capture images only.
