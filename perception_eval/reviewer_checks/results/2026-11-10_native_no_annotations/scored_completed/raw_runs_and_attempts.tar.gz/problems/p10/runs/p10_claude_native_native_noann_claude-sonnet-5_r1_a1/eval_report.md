# Eval Report — Perception Step (s22 / s_current)

## Context Available

- `action_sequence.json`: not present in the workspace — no prior dispatched
  action context to merge.
- `hole_card_cache.json`: not present — no cached robot hole cards.
- `sN-1/01_parsed_state.md`: not present — no previous parsed-state fields to
  inherit. This is treated as a cold-start parse; no field values were
  inherited from a prior step.
- `s21/00_capture.jpg` was used only for the scene-stability comparison and is
  pixel-identical to `s_current/00_capture.jpg` (= `s22/00_capture.jpg`).

## Evidence Summary

- **Turn**: a white "Your Turn" button sits at the robot/player seat
  (bottom-left of the felt), matching the robot-turn-button zone in
  `TABLE_GEOMETRY.md` → `is_my_turn = true`.
- **Scene stability**: identical consecutive frames, hand settled in a
  near-idle pose, no card/chip motion, no human interference → `scene_stable
  = true`.
- **Loop stage**: with the scene stable, the hand idle/not mid-action, and no
  showdown signature, `loop_stage = idle` is the best fit (ready for the main
  agent's next decision).
- **Blind**: a small blue button near the opponent/top seat is the only blind
  marker resolvable in this frame; no preflight (`s0`) reference was
  available to validate the dealer/SB/BB assignment, so `blind = big_blind`
  (robot) is a low-confidence inference from the two-player dealer=SB rule,
  not a confirmed read.
- **Community cards**: none visible in the unoccluded part of the board lane
  → `community_cards = []` (preflop-consistent), though the robot arm
  occludes part of this lane, so this is a best-effort read.
- **Chips**: visible unfolded stacks show only red (5) and blue (10)
  denominations on both sides (~4/4 for the robot, ~3/3 for the opponent); no
  green (50) or brown (100) chips are visible anywhere in frame. Because the
  robot arm occludes part of the opponent-side/center table, and because the
  bet-area vs. inventory-area split could not be confidently resolved at this
  image resolution, chip counts (especially 50/100 and any current-bet
  amounts) are reported as best-effort estimates and flagged uncertain rather
  than treated as confirmed zero/complete counts.
- **Showdown**: no face-up opponent or robot cards, no fold/muck signature →
  `showdown_outcome = not_showdown`.

## Merging Notes

No inherited durable fields existed to merge/override, so all fields in
`visual_summary.json` come directly from this frame's visual evidence. Several
fields (`blind`, chip-denomination counts for 50/100, and both bet fields) are
listed in `uncertain_fields` because they rely on a low-resolution or
partially occluded read rather than a clear, unambiguous view.
