# Evidence and merge report

The current capture was visually compared with the nearest available prior captures (`s21` and `s22`); they match closely, so the settled scene is classified as stable and the loop stage as `idle`. The bottom `Your Turn` marker determines `is_my_turn: true`. No face-up board cards or showdown/fold evidence is present, so the board is empty and the outcome is `not_showdown`.

Chip inventories use the fixed color mapping red=5, blue=10, green=50, brown=100. The robot hardware occludes much of the center/right table, so the green/brown inventory counts and both separated bet areas are inherited/estimated and explicitly listed as uncertain. The requested `action_sequence.json`, `hole_card_cache.json`, and `sN-1/01_parsed_state.md` were not present in the workspace; no unavailable context was fabricated. The big-blind assignment is supported by the visible preflight marker in `s0/00_capture.jpg`.
