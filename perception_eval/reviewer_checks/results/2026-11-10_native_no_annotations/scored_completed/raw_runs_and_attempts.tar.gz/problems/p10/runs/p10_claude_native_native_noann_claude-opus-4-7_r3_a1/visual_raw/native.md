# Native Perception — s_current (s22)

## Robot arm / scene stability
The robot arm is prominently in the frame, reaching across the center of the
table with the dexterous gripper positioned above the community-card area. The
gripper appears to be mid-action (actively holding/manipulating objects near
the community row). This is **not a settled pose** — scene is **unstable**;
loop_stage = **acting**.

## Turn marker
A white round "Your Turn" marker is clearly visible on my (bottom) side of the
table, left of my chip stacks. Standard interpretation: it is my turn.

## Community cards
Partially occluded by the robot gripper. I can see:
- One face-up card near the center with a visible **spade** suit symbol
  (rank obscured by the gripper).
- At least one face-down card to the left of the gripper.
- Rank/exact count cannot be confirmed — mark community_cards uncertain.

## Blind / dealer button
I see a blue circular disk near the opponent's chip row (top center). It may
be a dealer / small-blind marker on the opponent side. No clear BB/SB chip is
visible on my side. Blind = inherit uncertain ("big_blind" as default per
prior schema example since no clear SB marker is on my side).

## Chips — my side (bottom)
Partially visible due to arm/gripper occlusion:
- A pair of stacks of red/white (value 5) chips — roughly two stacks of
  ~2 chips each visible.
- A stack of blue (value 10) chips — roughly 3 visible.
- No clearly visible green (50) or black (100) chips on my side.

## Chips — opponent side (top)
Behind the robot arm, partially occluded:
- Two stacks of red/white (value 5) chips visible (~2 chips each).
- A stack of blue (value 10) chips (~3).
- Green/black stacks not clearly discernible.

## Bets in the betting zones
No distinct bet-zone chip piles are clearly visible outside the normal stacks.
Both bets are treated as zero (uncertain due to occlusion).

## Showdown
Not a showdown — community cards are being arranged and the robot is mid-
action. showdown_outcome = not_showdown.

## Summary
- Scene unstable (robot arm mid-motion over community area)
- loop_stage = acting
- is_my_turn = true (Your Turn marker)
- Many chip/card fields uncertain due to arm occlusion
