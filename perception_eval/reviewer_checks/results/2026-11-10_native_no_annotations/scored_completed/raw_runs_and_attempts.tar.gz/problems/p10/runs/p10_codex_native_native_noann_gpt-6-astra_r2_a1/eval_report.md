# Perception and merge report

Read all field guidelines and directly inspected the current s22 capture, recent s21/s20 captures, and s19/s18/s0 for movement and hidden-field context. No helper scripts, robot actions, or poker-action selection were used.

Current evidence supports a visible robot-side turn marker, four red and three blue robot inventory chips, three red and four blue opponent inventory chips, and one blue chip beneath the robot fingertips in the betting lane. The robot remains extended over the table; clear completion is not established. The concrete estimate is acting with scene_stable=false, rather than a failure or recovery classification.

Missing context files prevented merging from prior workflow state, cached hole cards, or previous parsed state. Hidden green/brown inventories are estimated as four each from earlier visual evidence; the robot big-blind assignment is carried forward from visible earlier buttons. The hidden opponent bet is estimated as one red chip. No face-up board or showdown evidence is visible, so the estimates are an empty community list and not_showdown.

All inferred, carried-forward, or occlusion-sensitive fields are listed in uncertain_fields. Current visible evidence overrides earlier counts where a blue chip has moved from robot inventory into the betting lane. The JSON contains all required fields, concrete enum/boolean/array values, and integer counts for all four denominations; no nulls or placeholders are used.
