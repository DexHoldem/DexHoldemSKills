# Native Visual Perception — Raw Evidence

## Image: s_current/00_capture.jpg

### Turn Detection
The white circular "Your Turn" button is clearly visible at the bottom-left area of the table, in the robot/player seat zone. **It is our turn.**

### Scene Stability
The Shadow dexterous hand is positioned over chips in the center-left betting area of the table. The hand is in an engaged, non-resting pose — fingers appear curved/closed near chips, arm angled downward toward the felt. This is not a neutral idle/init pose. **Scene is unstable; robot arm appears to be mid-action placing or releasing chips.**

No previous frame available for direct comparison (no sN-1 parsed state found). Judgment based solely on current frame arm position.

### Community Cards
No face-up cards are visible in the shared community card lane at the center of the table. The heart (♥) symbol visible in the center is the felt table design, not a card. Cards visible at the top-center of the table appear to be the opponent's face-down hole cards (normal position near opponent seat). **No community cards — preflop stage.**

### Showdown / Outcome
Neither player's hole cards are face-up. No showdown is in progress. **not_showdown.**

### Blind Button
A blue circular button is visible near the upper area of the table close to the opponent's card area. This is consistent with the small blind button at the opponent seat. Per two-player rule: opponent has small blind, robot is big blind. **Confidence: moderate (button partially obscured by angle).**

### Chip Inventory — Robot/Player (bottom rail, not counting bets)
Chips visible in the bottom-left area of the table near the "Your Turn" button:
- Red (5-chips): approximately 4 visible, possibly partially occluded by arm
- Blue (10-chips): approximately 2 visible
- Green (50-chips): approximately 2 — uncertain, partially out of view
- Brown (100-chips): approximately 2 — uncertain, far from camera angle

Robot inventory partially occluded by robot arm/body in lower frame.

### Chip Inventory — Opponent (top area)
Chip stacks visible at the top of the table (opponent seat area):
- Two visible chip groups
- Red (5-chips): approximately 3
- Blue (10-chips): approximately 4
- Green (50-chips): approximately 2 — uncertain
- Brown (100-chips): approximately 3 — uncertain

### Betting Area — My Current Bet (center-left of community cards)
Several chips visible under and near the robot dexterous hand in the center area:
- Red (5-chips): approximately 3
- Blue (10-chips): approximately 3
- Green/Brown: none clearly visible
Bet area partially occluded by robot hand.

### Betting Area — Opponent Bet (center-right of community cards)
Minimal chips visible on the right side of the community card lane. Opponent bet area is mostly clear or opponent has not yet bet. **Estimate: 0 chips (uncertain).**
